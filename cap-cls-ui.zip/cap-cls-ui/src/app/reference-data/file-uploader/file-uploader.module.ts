import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { FileUploaderComponent } from './file-uploader.component';

@NgModule({
    imports: [ CommonModule, BrowserModule, LoaderModule, DialogModule, ButtonsModule,
        InputsModule ],
    declarations: [ FileUploaderComponent ],
    exports: [ FileUploaderComponent ]
})
export class FileUploaderModule {
}
