import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class FileUploaderService {
    public progressObserver;
    public progress: number;
    public xhr: XMLHttpRequest;

    constructor() {
        this.xhr = new XMLHttpRequest();
    }

    makeFileRequest( url: string, params: string[], files: File[] ) {
        return Observable.create(observer => {
            const formData: FormData = new FormData();
            formData.append('file', files);
            this.xhr.onreadystatechange = () => {
                if (this.xhr.readyState === 4) {
                    if (this.xhr.status === 200) {
                        observer.next(JSON.parse(this.xhr.response));
                        observer.complete();
                    } else {
                        observer.error(this.xhr.response);
                    }
                }
            };
            this.xhr.open('POST', url, true);
            //don't set header without xhr open
            this.xhr.setRequestHeader('Authorization', this.getAccessToken());
            this.xhr.send(formData);
        });
    }

    private getAccessToken() {
        return 'Bearer ' + sessionStorage.getItem('access_token');
    }
}
