class EventObject {
    name: String;
}

export class EventMock {
    files = new Array();

    pushToArray( value: string ): any {
        let c = new EventObject();
        c.name = value;
        this.files.push(c);
        return this.files;
    }
}





