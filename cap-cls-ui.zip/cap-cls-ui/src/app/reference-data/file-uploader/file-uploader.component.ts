import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FileUploaderService } from './file-uploader.service';
import { environment } from '../../../environments/environment';
import { isUndefined } from 'util';

@Component({
    selector: 'upload',
    styleUrls: [ './file-uploader.component.scss'
    ],
    templateUrl: './file-uploader.component.html',
    providers: [ FileUploaderService ],
})

export class FileUploaderComponent implements OnInit {

    fileTextShow: string = '';
    showLoader: boolean = false;
    showErrorMessage: boolean = false;
    showSuccessMessage: boolean = false;
    showUploadButton: boolean = false;
    messagelist: string[] = [];
    bulkOpened: boolean = false;

    enableBulkUploadBtnDiabledProp: boolean = true;
    enableBulkUploadBtnPrimaryProp: boolean = false;
    showFileInputTag: boolean = false;


    constructor( private fileUploaderService: FileUploaderService ) {
    }

    ngOnChanges( changes: SimpleChanges ) {
        if (changes[ 'refName' ]) {
            this.enableDisableButton();
        }
    }

    ngOnInit() {

    }

    @ViewChild('fileInput')
    myInputVariable: any;

    @Output() upMsg: EventEmitter<any> = new EventEmitter();
    @Input() refName: string;
    @Input() getEventFromParentForUpload: any;

    @Output() listRefreshEventFromUploader: EventEmitter<any> = new EventEmitter();

    @Output()
    globalMessageEventFromUploader: EventEmitter<any> = new EventEmitter<any>();

    hideMessage() {
        this.messagelist = [];
        this.showErrorMessage = false;
        this.showSuccessMessage = false;
    }

    openBulkUpload() {
        this.bulkOpened = true;
    }

    closeBulkUpload() {
        this.bulkOpened = false;
        this.fileTextShow = '';
        if (typeof this.refName !== 'undefined') {
            this.enableBulkUploadBtnDiabledProp = false;
            this.enableBulkUploadBtnPrimaryProp = true;
            this.showFileInputTag = true;

        }
        if (this.refName.trim() === '') {
            this.enableBulkUploadBtnDiabledProp = true;
            this.enableBulkUploadBtnPrimaryProp = false;
            this.showFileInputTag = false;
        }
    }

    files: any;

    fileEvent( fileInput ): any {
        if (!isUndefined(fileInput.files[ 0 ])) {
            if (fileInput.files[ 0 ].name !== '' && fileInput.files[ 0 ].name !== 'undefined') {
                this.showUploadButton = true;
                this.fileTextShow = fileInput.files[ 0 ].name;
                this.bulkOpened = true;
                this.files = fileInput.files[ 0 ];
                if (typeof this.myInputVariable !== 'undefined') {
                    this.myInputVariable.nativeElement.value = '';
                }
            }
        }
    }

    emitRefreshEventForListFromUploader( referenceType: string ) {
        this.listRefreshEventFromUploader.emit(referenceType);
    }

    emitGlobalMessageEvent( value ) {
        this.globalMessageEventFromUploader.emit(value);
    }

    jsonMsgType: string;
    jsonMsgBody: string[];

    globalMessageValueFromUploader: {} = {
        'msg_type': this.jsonMsgType,
        'msg_body': this.jsonMsgBody
    };

    triggerUploadFile( fileInput ) {
        this.showLoader = true;
        let tempURL = environment.apiBaseUrl + environment.apiToPostReferenceTypeBulk + this.refName;
        this.fileUploaderService.makeFileRequest(tempURL,
            [], this.files).subscribe(
            x => {
                this.showLoader = false;
                this.bulkOpened = false;
                this.fileTextShow = '';
                this.emitRefreshEventForListFromUploader(this.refName);
                this.globalMessageValueFromUploader[ 'msg_type' ] = 'SUCCESS';
                this.globalMessageValueFromUploader[ 'msg_body' ] = [ 'Reference Data has been successfully uploaded.' ];
                this.emitGlobalMessageEvent(this.globalMessageValueFromUploader);

            },
            e => {
                this.showLoader = false;
                this.bulkOpened = false;
                let json = JSON.parse(e);
                this.fileTextShow = '';
                let errmsg = [];
                for (let i = 0; i < json[ "errors" ].length; i++) {
                    errmsg.push(json[ 'errors' ][ i ][ 'message' ]);
                }
                this.messagelist = errmsg.filter(function ( item, index, inputArray ) {
                    return inputArray.indexOf(item) === index;
                });
                /*
                 * Event to Show Global Message
                 **/
                this.globalMessageValueFromUploader[ 'msg_type' ] = 'FAILURE';
                this.globalMessageValueFromUploader[ 'msg_body' ] = this.messagelist;
                this.emitGlobalMessageEvent(this.globalMessageValueFromUploader);
            },
            () => {
            }
        );
    }

    enableDisableButton() {
        if (typeof this.refName !== 'undefined') {
            this.enableBulkUploadBtnDiabledProp = false;
            this.enableBulkUploadBtnPrimaryProp = true;
            this.showFileInputTag = true;
        }

        if (typeof this.refName !== 'undefined' && this.refName.trim() === '') {
            this.enableBulkUploadBtnDiabledProp = true;
            this.enableBulkUploadBtnPrimaryProp = false;
            this.showFileInputTag = false;
        }
        if (isUndefined(this.refName)) {
            this.enableBulkUploadBtnDiabledProp = true;
            this.enableBulkUploadBtnPrimaryProp = false;
            this.showFileInputTag = false;
        }
    }
}