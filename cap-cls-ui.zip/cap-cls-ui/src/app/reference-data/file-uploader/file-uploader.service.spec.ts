import { MockBackend, MockConnection } from '@angular/http/testing';
import { fakeAsync, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod } from '@angular/http';
import { environment } from '../../../environments/environment';
import { FileUploaderService } from './file-uploader.service';

describe('Service : FileUploaderService', () => {
	let fileUploaderService: FileUploaderService;
	let mockBackend: MockBackend;

	let tempURL = environment.apiBaseUrl + environment.apiToPostReferenceTypeBulk + this.refName;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				FileUploaderService
			],
			imports: [HttpModule]
		});
	});

	beforeEach(
		inject([FileUploaderService, MockBackend], (service: FileUploaderService, backend: MockBackend) => {
			fileUploaderService = service;
			mockBackend = backend;
		})
	);

	it('should load file uploader service', () => {
		expect(fileUploaderService).toBeDefined();
	});

	it('should connect mock server ', fakeAsync(() => {
		//let mockedFile = new File[1]([], "sample_refcode.xlsx");
		let mockedFile = File[1];
		fileUploaderService.makeFileRequest(tempURL, [], mockedFile);
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Post);
			expect(connection.request.url).toBe(tempURL);
		});
	}));

});
