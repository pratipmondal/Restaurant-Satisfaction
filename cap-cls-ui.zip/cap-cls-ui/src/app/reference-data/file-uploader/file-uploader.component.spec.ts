import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { FileUploaderComponent } from './file-uploader.component';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { FileUploaderService } from './file-uploader.service';
import { MockBackend } from '@angular/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BaseRequestOptions, Http } from '@angular/http';
import { EventMock } from './file-uploader.mock';
import { By } from '@angular/platform-browser';

describe('Component : FileUploaderComponent', () => {
	let fileUploaderComponent: FileUploaderComponent;
	let fileUploaderService: FileUploaderService;
	let fixture: ComponentFixture<FileUploaderComponent>;
	let de: DebugElement;
	let el: HTMLElement;
	let mockBackend: MockBackend;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [DialogModule, ButtonsModule, InputsModule, LoaderModule, BrowserAnimationsModule],
			declarations: [FileUploaderComponent],
			providers: [MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				FileUploaderService],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		inject([FileUploaderService, MockBackend], (service: FileUploaderService, backend: MockBackend) => {
			mockBackend = backend;
			fileUploaderService = service;
		});
		fixture = TestBed.createComponent(FileUploaderComponent);
		fileUploaderComponent = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create component', () => {
		expect(fileUploaderComponent).toBeTruthy();
	});

	it('Bulk Upload button should be disabled',
		async(() => {
			expect(fileUploaderComponent.enableBulkUploadBtnDiabledProp).toBe(true);
		}));

	it('Bulk Upload button should be enabled when reftype is selected', () => {
		fileUploaderComponent.refName = 'Countrys';
		fixture.detectChanges();
		fileUploaderComponent.enableDisableButton();
		expect(fileUploaderComponent.enableBulkUploadBtnDiabledProp).toBe(false);
		expect(fileUploaderComponent.enableBulkUploadBtnPrimaryProp).toBe(true);
		expect(fileUploaderComponent.showFileInputTag).toBe(true);
	});

	it('should open popup on click event of Bulk upload button ', () => {
		fixture.detectChanges();
		if (fileUploaderComponent.enableBulkUploadBtnDiabledProp === true) {
			let btn = fixture.debugElement.query(By.css('button.upload_file_custom'));
			btn.triggerEventHandler('click', 'Bulk Upload');
			fileUploaderComponent.openBulkUpload();
			fixture.detectChanges();
			expect(fileUploaderComponent.bulkOpened).toBe(true);
		}
	});

	it('should get file upload event and show the dialog', () => {
		let fileEventObj = new EventMock();
		fileEventObj.pushToArray('sample_refcode.xlsx');
		fileUploaderComponent.fileEvent(fileEventObj);
		fixture.detectChanges();
		expect(fileUploaderComponent.showUploadButton).toBe(true);
		expect(fileUploaderComponent.fileTextShow).toBe(fileEventObj.files[0].name);
		expect(fileUploaderComponent.bulkOpened).toBe(true);
		expect(fileUploaderComponent.files).toBe(fileEventObj.files[0]);
	});

	it(' should event emit  method emitGlobalMessageEvent call', async((done) => {
		fixture.detectChanges();
		fileUploaderComponent.refName = 'Countrys';
		fileUploaderComponent.emitGlobalMessageEvent('Countrys');
		fileUploaderComponent.globalMessageEventFromUploader.subscribe(response => {
			expect(response).toEqual('Country');
			done();
		});
		fixture.detectChanges();
	}));
	it(' should event emit method emitRefreshEventForListFromUploader call', async((done) => {
		fixture.detectChanges();
		fileUploaderComponent.refName = 'Countrys';
		fileUploaderComponent.emitRefreshEventForListFromUploader('Countrys');
		fileUploaderComponent.listRefreshEventFromUploader.subscribe(response => {
			expect(response).toEqual('Country');
			done();
		});
		fixture.detectChanges();
	}));

});
