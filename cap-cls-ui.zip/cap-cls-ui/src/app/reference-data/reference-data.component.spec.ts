import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReferenceDataComponent } from './reference-data.component';
import { CounterpartyDetailsModule } from '../shared/counterparty-details/counterparty-details.module';
import { ListRefDataModule } from './list-ref-data/list-ref-data.module';
import { FileUploaderModule } from './file-uploader/file-uploader.module';
import { LoaderModule } from '../shared/progression/loader/loader.module';
import { SingleDataUploadComponent } from './single-data-upload/single-data-upload.component';
import { AutoCompleteRefDataModule, ClsSharedCommonModule } from '../shared/';
import { GridModule } from '@progress/kendo-angular-grid';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FileUploaderService } from './file-uploader/file-uploader.service';
import { AuthenticationService } from '../login/authentication.service';
import { SingleDataUploadService } from './single-data-upload/single-data-upload.service';
import { BaseRequestOptions, Http } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

describe('ReferenceDataComponent', () => {
	let component: ReferenceDataComponent;
	let fixture: ComponentFixture<ReferenceDataComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [CommonModule,
				BrowserModule, FormsModule, ReactiveFormsModule,
				ButtonsModule, BrowserAnimationsModule, AutoCompleteRefDataModule,
				LoaderModule, ListRefDataModule, GridModule, FileUploaderModule, CounterpartyDetailsModule],
			declarations: [ReferenceDataComponent, SingleDataUploadComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [FileUploaderService, AuthenticationService, FormBuilder, SingleDataUploadService,
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				}]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ReferenceDataComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create reference-data componenent', () => {
		expect(component).toBeTruthy();

	});
	it('should not show loader on Component load', async(() => {
		expect(component.showLoader).toEqual(false);

	}));
	it('should not show confirmation dialog on Component load', async(() => {
		expect(component.showYesNoPrompt).toEqual(false);

	}));
	it('should not show global message  on Component load', async(() => {
		expect(component.showGlobalMessage).toEqual(false);

	}));
	it('sholud  event emit on  onRowEditEventFromList function call', () => {
		fixture.detectChanges();
		component.onRowEditEventFromList('');
		fixture.detectChanges();
		expect(component.showYesNoPrompt).toBe(true);

	});
	it('should Global Message Box close on closeEventGlobalMessage function call', () => {
		fixture.detectChanges();
		component.closeEventGlobalMessage();
		fixture.detectChanges();
		expect(component.showGlobalMessage).toBe(false);

	});
	it('should referenceNameInParent get Message  on onNotify function call', () => {
		fixture.detectChanges();
		component.onNotify('');
		fixture.detectChanges();
		expect(component.referenceNameInParent).toBe('');

	});
	it('should event emit when file is submitted ', () => {
		fixture.detectChanges();
		let showG = component.showGlobalMessage;
		component.onEventChangeForGlobalMessageFromUploader('');
		fixture.detectChanges();
		expect(component.messageFromParentToGlobalMessageComp).toBe('');
		expect(showG).toBe(!component.showGlobalMessage);

	});
	it('should event emit when list updated ', () => {
		fixture.detectChanges();
		let showG = component.showGlobalMessage;
		component.globalMessageEventFromListForParent('');
		fixture.detectChanges();
		expect(component.messageFromParentToGlobalMessageComp).toBe('');
		expect(showG).toBe(!component.showGlobalMessage);

	});

	it('should method  receiveEventAddSingleUpdate gets called  when event is triggered from single update component', () => {
		fixture.detectChanges();
		let showG = component.showGlobalMessage;
		component.receiveEventAddSingleUpdate('');
		fixture.detectChanges();
		expect(component.messageFromParentToGlobalMessageComp).toBe('');
		expect(showG).toBe(!component.showGlobalMessage);

	});

});
