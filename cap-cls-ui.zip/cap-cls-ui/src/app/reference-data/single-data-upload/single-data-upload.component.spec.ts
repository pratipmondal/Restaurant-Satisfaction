import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule, By } from '@angular/platform-browser';
import { SingleDataUploadComponent } from './single-data-upload.component';
import { REFERENCES } from './mock-references';

describe('Component : SingleDataUploadComponent', () => {
	let component: SingleDataUploadComponent;
	let fixture: ComponentFixture<SingleDataUploadComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [CommonModule, BrowserModule, ReactiveFormsModule, ButtonsModule, DialogModule, LoaderModule, HttpModule],
			declarations: [SingleDataUploadComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(SingleDataUploadComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create component', () => {
		expect(component).toBeTruthy();
	});

	it('Add button should be disabled',
		async(() => {
			expect(component.enableSingleUploadBtnDiabledProp).toBe(true);
		}));

	it('should display Add', async(() => {
		let de: DebugElement;
		let el: HTMLElement;
		de = fixture.debugElement.query(By.css('button.single_button_class'));
		el = de.nativeElement;
		fixture.detectChanges();
		expect(el.textContent).toContain('Add');
	}));

	it('Add button enabled when reftype selected', () => {

		// spyOn(component, 'enableDisableButton');
		component.refName = 'Countrys';
		fixture.detectChanges();
		component.enableDisableButton();
		//tick();
		expect(component.enableSingleUploadBtnDiabledProp).toBe(false);
		expect(component.enableSingleUploadBtnPrimaryProp).toBe(true);
	});

	it('Should open popup on click event of Add button ', fakeAsync(() => {
		fixture.detectChanges();
		spyOn(component, 'singleUploadModal');
		if (component.enableSingleUploadBtnDiabledProp === true) {
			let btn = fixture.debugElement.query(By.css('button.single_button_class'));
			btn.triggerEventHandler('click', 'Add');
			tick();
			fixture.detectChanges();
			expect(component.singleUploadModal).toHaveBeenCalled();
		}
	}));

	it('Save button should be disabled',
		async(() => {
			expect(component.SingleDataUploadForm.invalid).toBe(true);
		}));
	it('onReflect function check for changing Auto Complete box',
		async(() => {
			component.refObjs = REFERENCES;
			component.onRefSelect('Country');
			expect(component.saveRefType).toEqual('Country');
			expect(component.showLoader).toBe(false);
			fixture.detectChanges();
			component.onRefSelect('');
			expect(component.saveRefType).toEqual('');
			fixture.detectChanges();
		}));

	it('Cancel button should close the popup', fakeAsync(() => {
		fixture.detectChanges();
		spyOn(component, 'cancelForm');
		component.cancelForm();
		tick();
		fixture.detectChanges();
		expect(component.opened).toBe(false);
	}));

	it('getReferenceData function check for checking ',
		async(() => {
			fixture.detectChanges();
			component.refObjs = REFERENCES;
			component.getReferenceData('Country');
			expect(component.showLoader).toBe(false);
		}));

	it('Hide message function should have to work', () => {
		fixture.detectChanges();
		component.hideMessage();
		fixture.detectChanges();
		expect(component.showErrorMessage).toBe(false);
		expect(component.successMsg).toBe(false);
	});
	it('should showLoader false on fillAutoCompTwo  function call', () => {
		fixture.detectChanges();
		component.fillAutoCompTwo();
		fixture.detectChanges();
		expect(component.showLoader).toBe(false);

	});

	it('should focusAutocompleteSearch false on focusRefTypeAutocomplete  function call', () => {
		fixture.detectChanges();
		component.focusRefTypeAutocomplete('');
		fixture.detectChanges();
		expect(component.saveRefType).toBe('');
		expect(component.saveRefCode).toBe('');
		expect(component.focusAutocompleteSearch).toBe(false);

	});
	it('should focusAutocompleteSearch false on hideOverlay  function call', () => {
		fixture.detectChanges();
		component.hideOverlay('');
		fixture.detectChanges();
		expect(component.focusAutocompleteSearch).toBe(false);

	});
	it('should referance type change on function focusRefCodeAutocomplete call', () => {
		fixture.detectChanges();
		component.focusRefCodeAutocomplete('');
		fixture.detectChanges();
		expect(component.saveRefType).toBe('');
		expect(component.focusAutocompleteSearch).toBe(false);
	});
	it('should showloader false on genRefCodes  function call', () => {
		fixture.detectChanges();
		component.genRefCodes('');
		fixture.detectChanges();
		expect(component.showLoader).toBe(false);
	});
	it('should Referance code generate on function onRefCodeSelect call', () => {
		fixture.detectChanges();
		component.onRefCodeSelect('');
		fixture.detectChanges();
		expect(component.saveRefCode).toBe('');
	});
	it(' should event emit to list component on method emitRefreshEventForListFromSingleUpload call', async((done) => {
		fixture.detectChanges();
		component.refName = 'Countrys';
		component.emitRefreshEventForListFromSingleUpload('Countrys');
		component.listRefreshEventFromSingleUpload.subscribe(response => {
			expect(response).toEqual('Country');
			done();
		});
		fixture.detectChanges();
	}));
	it(' should event emit on method emitSingleGlobalMessageEvent call', async((done) => {
		fixture.detectChanges();
		component.refName = 'Countrys';
		component.emitSingleGlobalMessageEvent('Countrys');
		component.onAddSingleUpdateEmit.subscribe(response => {
			expect(response).toEqual('Country');
			done();
		});
		fixture.detectChanges();
	}));

});
