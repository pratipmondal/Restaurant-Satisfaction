import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { SingleDataUploadService } from './single-data-upload.service';
import { environment } from '../../../environments/environment';
import { isUndefined } from 'util';

@Component({
    selector: 'app-single-data-upload',
    templateUrl: './single-data-upload.component.html',
    styleUrls: [ './single-data-upload.component.scss'
    ],
    providers: [ SingleDataUploadService ]
})
export class SingleDataUploadComponent implements OnInit {
    code: string;
    description: string;
    parentRefType: string;
    parentRefCode: string;
    id: string;
    public successMsg = false;
    public message = '';
    public disableCodeInput = false;
    tempObj: any;
    @Input()
    refName: string;
    @Input()
    updateModal: any;
    @Input()
    refObjs: any;
    focusAutocompleteSearch: boolean = true;

    private singleUploadUrl: string;

    public SingleDataUploadForm: FormGroup;
    public submitted: boolean;
    public events: any[] = [];
    result = {};
    public newArray: any[] = [];
    public saveRefType: string = '';
    public saveRefCode: string = '';
    public refTypeOnUpdate: string = '';
    public refCodeOnUpdate: string = '';
    public version: string = '';

    showErrorMessage: boolean = false;
    showErrorMessageVal: string;
    messagelist: any[] = [];


    @Output() listRefreshEventFromSingleUpload: EventEmitter<any> = new EventEmitter();
    @Output() onUpdateRowValue: EventEmitter<any> = new EventEmitter();
    @Output() onAddSingleUpdateEmit: EventEmitter<any> = new EventEmitter<any>();

    showLoader: boolean;

    enableSingleUploadBtnDiabledProp: boolean = true;
    enableSingleUploadBtnPrimaryProp: boolean = false;

    public saveReference = true;
    public updateReference = false;

    jsonMsgType: string;
    jsonMsgBody: string[];

    messagePopupFromSingleUpdate: {} = {
        'msg_type': this.jsonMsgType,
        'msg_body': this.jsonMsgBody
    };

    constructor( private _fb: FormBuilder, private http: Http, private singleDataUpdateService: SingleDataUploadService ) {
    }

    ngOnChanges( changes: SimpleChanges ) {
        if (changes[ 'updateModal' ]) {
            this.getUpdateData(this.updateModal);
        }
        if (changes[ 'refName' ]) {
            this.enableDisableButton();
        }
        if (changes[ 'refObjs' ]) {
            this.fillAutoCompTwo();
        }
    }

    private getUpdateData( item: any ): void {
        this.focusAutocompleteSearch = true;
        if (item !== undefined) {
            if (item[ 0 ][ 'OP_CODE' ] === 'UPDATE') {
                this.opened = true;
                this.saveReference = false;
                this.updateReference = true;
                this.tempObj = item[ 1 ];
                this.code = item[ 1 ][ 'code' ];
                this.description = item[ 1 ][ 'description' ];
                this.onRefSelect(item[ 1 ][ 'parentRefType' ]);
                this.onRefCodeSelect(item[ 1 ][ 'parentRefCode' ]);
                // if((this.saveRefType='') || (this.saveRefCode=''))
                //  {
                //     this.focusAutocompleteSearch = false;
                // }

                // this.saveRefType = item[1]['parentRefType'];
                // this.saveRefCode = item[1]['parentRefCode'];
                this.version = item[ 1 ][ '_version' ];
                this.id = item[ 1 ][ 'id' ];

                this.SingleDataUploadForm = this._fb.group({
                    code: [ this.code, [ <any>Validators.required, <any>Validators.minLength(2) ] ],
                    description: [ this.description, [ <any>Validators.required, <any>Validators.minLength(2) ] ],

                });
                this.subscribeToFormChanges();
            }
        }

    }

    ngOnInit() {

        this.SingleDataUploadForm = this._fb.group({
            code: [ '', [ <any>Validators.required, <any>Validators.minLength(0) ] ],
            description: [ '', [ <any>Validators.required, <any>Validators.minLength(0) ] ]
        });
        this.subscribeToFormChanges();
    }

    subscribeToFormChanges() {
        const SingleDataUploadFormStatusChanges$ = this.SingleDataUploadForm.statusChanges;
        const SingleDataUploadFormValueChanges$ = this.SingleDataUploadForm.valueChanges;
        SingleDataUploadFormStatusChanges$.subscribe(x => this.events.push({event: 'STATUS_CHANGED', object: x}));
        SingleDataUploadFormValueChanges$.subscribe(x => this.events.push({event: 'VALUE_CHANGED', object: x}));
        SingleDataUploadFormValueChanges$.subscribe(x => this.events.push({event: 'VALUE_CHANGED', object: x}));
    }


    resetForm( e ) {
        this.SingleDataUploadForm.reset();
        e.preventDefault();
        this.messagelist = [];
        this.showErrorMessage = false;
    };

    hideMessage() {
        this.messagelist = [];
        this.showErrorMessage = false;
        this.successMsg = false;
    }

    emitSingleGlobalMessageEvent( value ) {
        this.onAddSingleUpdateEmit.emit(value);
    }

    uploadSingleData( data: JSON ) {
        this.messagelist = [];
        data[ 'parentRefType' ] = this.saveRefType;
        data[ 'parentRefCode' ] = this.saveRefCode;
        data[ '_version' ] = this.version;
        data[ 'id' ] = this.id;
        this.showLoader = true;
        this.SingleDataUploadForm.reset();
        let tempURL = environment.apiBaseUrl + environment.apiToGetPostReferenceData + this.refName;
        this.opened = false;
        this.singleDataUpdateService.postSingleData(tempURL, data).subscribe(
            x => {
                this.showLoader = false;
                this.emitRefreshEventForListFromSingleUpload(this.refName);
                this.messagePopupFromSingleUpdate[ 'msg_type' ] = 'SUCCESS';
                this.messagePopupFromSingleUpdate[ 'msg_body' ] = [ 'Reference Data has been successfully uploaded.' ];
                this.emitSingleGlobalMessageEvent(this.messagePopupFromSingleUpdate);
                this.saveRefType = '';
                this.saveRefCode = '';
            },
            e => {
                this.showLoader = false;
                let json = JSON.parse(e._body);
                for (let i = 0; i < json[ "errors" ].length; i++) {
                    this.messagelist.push(json[ 'errors' ][ i ][ 'message' ]);
                    this.messagePopupFromSingleUpdate[ 'msg_type' ] = 'FAILURE';
                    this.messagePopupFromSingleUpdate[ 'msg_body' ] = this.messagelist;
                    this.emitSingleGlobalMessageEvent(this.messagePopupFromSingleUpdate);
                    this.saveRefType = '';
                    this.saveRefCode = '';
                }
            },
            () => {
                this.showLoader = false;
            }
        );
    }


    updateSingleReferenceFromGrid( data: JSON ) {
        this.disableCodeInput = true;
        this.messagelist = [];
        data[ 'parentRefType' ] = this.saveRefType;
        data[ 'parentRefCode' ] = this.saveRefCode;
        data[ '_version' ] = this.version;
        data[ 'id' ] = this.id;
        this.showLoader = true;
        this.SingleDataUploadForm.reset();
        this.opened = false;
        let tempURL = environment.apiBaseUrl + environment.apiToGetPostReferenceData + this.refName;
        this.singleDataUpdateService.updateSingleDataFromGrid(tempURL, data).subscribe(
            response => {
                this.showLoader = false;
                let tempArr = [];
                tempArr.push({OP_CODE: 'UPDATED'});
                this.tempObj.code = data[ 'code' ];
                this.tempObj.description = data[ 'description' ];
                this.tempObj.parentRefType = data[ 'parentRefType' ];
                this.tempObj.parentRefCode = data[ 'parentRefCode' ];
                tempArr.push(this.tempObj);
                this.onUpdateRowValue.emit(tempArr);
                this.messagePopupFromSingleUpdate[ 'msg_type' ] = 'SUCCESS';
                this.messagePopupFromSingleUpdate[ 'msg_body' ] = [ 'Reference Data has been successfully Updated.' ];
                this.emitSingleGlobalMessageEvent(this.messagePopupFromSingleUpdate);
                this.updateReference = false;
                this.saveReference = true;
                this.saveRefType = '';
                this.saveRefCode = '';
            },
            error => {
                this.showLoader = false;
                let json = JSON.parse(error._body);
                if ((error.status === 404)) {
                    this.messagePopupFromSingleUpdate[ 'msg_type' ] = 'FAILURE';
                    this.messagePopupFromSingleUpdate[ 'msg_body' ] = [ json[ 'error' ], json[ 'message' ] ];
                    this.emitSingleGlobalMessageEvent(this.messagePopupFromSingleUpdate);
                    this.saveRefType = '';
                    this.saveRefCode = '';
                }
                if ((error.status === 401)) {
                    this.messagePopupFromSingleUpdate[ 'msg_type' ] = 'FAILURE';
                    this.messagePopupFromSingleUpdate[ 'msg_body' ] = [ json[ 'error' ], json[ 'error_description' ] ];
                    this.emitSingleGlobalMessageEvent(this.messagePopupFromSingleUpdate);
                    this.saveRefType = '';
                    this.saveRefCode = '';
                }
                else {
                    for (let i = 0; i < json[ "errors" ].length; i++) {
                        this.messagelist.push(json[ 'errors' ][ i ][ 'message' ]);
                        this.messagePopupFromSingleUpdate[ 'msg_type' ] = 'FAILURE';
                        this.messagePopupFromSingleUpdate[ 'msg_body' ] = this.messagelist;
                        this.emitSingleGlobalMessageEvent(this.messagePopupFromSingleUpdate);
                        this.saveRefType = '';
                        this.saveRefCode = '';
                    }
                }
                this.updateReference = false;
                this.saveReference = true;
            },
            () => {
            }
        );
    }


    private handleError( error: any ): Promise<any> {
        return Promise.reject(error.message || error);
    }

    private showSuccessMsg() {
        this.successMsg = true;
        this.message = 'Reference Data Submitted';
    }

    emitRefreshEventForListFromSingleUpload( referenceType: string ) {
        this.listRefreshEventFromSingleUpload.emit(referenceType);
    }

    public opened: boolean = false;

    public close( status ) {
        this.opened = false;
        this.SingleDataUploadForm.reset();
        this.showErrorMessage = false;
        this.successMsg = false;
        this.saveReference = true;
        this.updateReference = false;
        this.saveRefType = '';
        this.saveRefCode = '';
        this.enableDisableButton();
    }

    public cancelForm() {
        this.opened = false;
        this.saveReference = true;
        this.updateReference = false;
        this.saveRefType = '';
        this.saveRefCode = '';
        this.SingleDataUploadForm.reset();
    }

    public singleUploadModal() {
        this.opened = true;
    }

    enableDisableButton() {
        if (typeof this.refName !== 'undefined') {
            this.enableSingleUploadBtnDiabledProp = false;
            this.enableSingleUploadBtnPrimaryProp = true;
        }
        if (typeof this.refName !== 'undefined' && this.refName.trim() === '') {
            this.enableSingleUploadBtnDiabledProp = true;
            this.enableSingleUploadBtnPrimaryProp = false;
        }
        if (isUndefined(this.refName)) {
            this.enableSingleUploadBtnDiabledProp = true;
            this.enableSingleUploadBtnPrimaryProp = false;
        }

    }

    // ref type service called
    getReferenceData( refType: string ) {
        this.showLoader = false;
        if (refType === '') {
            //When Autocomplete Component returns Empty String
            this.showLoader = false;

        } else if (typeof refType !== 'undefined') {
            let url = environment.apiBaseUrl + environment.apiToGetPostReferenceData + refType;
            this.singleDataUpdateService.getData(url, []).subscribe(
                response => {
                    this.genRefCodes(response);
                },
                error => {
                    this.showLoader = false;
                    this.successMsg = false;

                },
                () => {
                }
            );
        } else {
            this.showLoader = false;
        }
    }

    fillAutoCompTwo() {
        this.showLoader = false;
        this.genRefCodes(this.refObjs);

    }

    onRefSelect( e ) {
        this.showLoader = false;
        this.saveRefType = e;
        this.newArray = [];
        let dataObj = this.refObjs.find(item => item.name === e);
        if (typeof (dataObj) !== 'undefined' && dataObj) {
            this.getReferenceData(dataObj.plural);
        }
        if (e === '' || dataObj === undefined) {
            this.saveRefType = '';
        }
    }

    focusRefTypeAutocomplete( e ) {
        // this.onRefSelect(e);
        this.saveRefType = '';
        this.saveRefCode = '';
        this.focusAutocompleteSearch = false;
    }

    hideOverlay( e ) {
        this.focusAutocompleteSearch = false;
    }

    focusRefCodeAutocomplete( e ) {
        this.saveRefCode = '';
        this.focusAutocompleteSearch = false;
    }

    genRefCodes( res ) {
        this.showLoader = false;
        if (res !== undefined) {
            this.newArray = Object.keys(res).map(function ( k ) {
                return res[ k ][ 'code' ];
            })
        }
    }

    onRefCodeSelect( e ) {
        this.saveRefCode = e;
    }
}