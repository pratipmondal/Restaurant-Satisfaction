import { MockBackend, MockConnection } from '@angular/http/testing';
import { fakeAsync, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions } from '@angular/http';
import { environment } from '../../../environments/environment';
import { REFERENCES } from './mock-references';
import { SingleDataUploadService } from './single-data-upload.service';

describe('Service : SingleDataUploadService', () => {
	let singleDataUploadService: SingleDataUploadService;
	let mockBackend: MockBackend;

	let tempUrl = environment.apiBaseUrl + environment.apiToGetPostReferenceData + this.refName;
	let upadteURL = environment.apiBaseUrl + environment.apiToGetPostReferenceData + this.refName + '/' + this.id;
	let data = REFERENCES;
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				SingleDataUploadService
			],
			imports: [HttpModule]
		});
	});

	beforeEach(
		inject([SingleDataUploadService, MockBackend], (service: SingleDataUploadService, backend: MockBackend) => {
			singleDataUploadService = service;
			mockBackend = backend;
		})
	);

	it('should ...', inject([SingleDataUploadService], (service: SingleDataUploadService) => {
		expect(service).toBeTruthy();
	}));

	it('service should be defined', () => {
		expect(singleDataUploadService).toBeDefined();
	});

	it('Add Single Ref - should connect mock service api', fakeAsync(() => {
		singleDataUploadService.postSingleData(tempUrl, data);
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Post);
			expect(connection.request.url).toBe(tempUrl);
		});
	}));

	it('Add Single Ref - should get response from mock server ', fakeAsync(() => {
		let mockResponseBody = REFERENCES;
		mockBackend.connections.subscribe((connection: MockConnection) => {
			let response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
			connection.mockRespond(new Response(response));
		});
		singleDataUploadService.postSingleData(tempUrl, data).subscribe((response: Response) => {
		});

	}));

	it('Update Single Ref - should connect mock service api', fakeAsync(() => {
		singleDataUploadService.updateSingleDataFromGrid(upadteURL, data);
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Put);
			expect(connection.request.url).toBe(tempUrl);
		});
	}));

	it('Update Single Ref - should get response from mock server ', fakeAsync(() => {
		let mockResponseBody = REFERENCES;
		mockBackend.connections.subscribe((connection: MockConnection) => {
			let response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
			connection.mockRespond(new Response(response));
		});
		singleDataUploadService.updateSingleDataFromGrid(tempUrl, data).subscribe((response: Response) => {
		});

	}));

});
