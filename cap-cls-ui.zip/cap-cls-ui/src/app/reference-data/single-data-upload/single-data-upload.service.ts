import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Observable } from 'rxjs';

@Injectable()
export class SingleDataUploadService {

    constructor( private http: Http ) {
    }

    public postSingleData( url: string, data: any ): Observable<any> {
        let headers = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers: headers});
        return this.http.post(url, data, options)
            .map(this.extractData)
            .catch(this.handleError);

    }

    public updateSingleDataFromGrid( url: string, data: any ): Observable<any> {
        let headers = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers: headers});
        return this.http.put(url, data, options)
            .map(res => res.json())

    }

    public getData( url: string, params: string[] ): Observable<any> {
        return this.http.get(url)
            .map(
                res => res.json()
            );

    }

    private extractData( res: Response ) {
        let body = res.json();
        return body.data || {};
    }

    private handleError( error: any ): Promise<any> {
        return Promise.reject(error.message || error);
    }

}