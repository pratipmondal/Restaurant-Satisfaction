import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AutoCompleteRefDataComponent } from './auto-complete-ref-data.component';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule, By } from '@angular/platform-browser';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { HttpModule } from '@angular/http';
import { AutoCompleteRefDataService } from './auto-complete-ref-data.service';
import { REFERENCES } from './mock-references';

describe('Component : AutoCompleteComponent', () => {
	let autoCompleteRefDataComponent: AutoCompleteRefDataComponent;
	let fixture: ComponentFixture<AutoCompleteRefDataComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [CommonModule, BrowserModule, AutoCompleteModule, LoaderModule, HttpModule],
			declarations: [
				AutoCompleteRefDataComponent
			],
			providers: [{provide: AutoCompleteRefDataService}],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		});
		TestBed.compileComponents();

	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AutoCompleteRefDataComponent);
		autoCompleteRefDataComponent = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create the component', async(() => {
		expect(autoCompleteRefDataComponent).toBeTruthy();
	}));

	it('should display original title', async(() => {
		let de: DebugElement;
		let el: HTMLElement;
		de = fixture.debugElement.query(By.css('span.ref-type'));
		el = de.nativeElement;
		fixture.detectChanges();
		expect(el.textContent).toContain('Reference Types');
	}));

	it('should emit reference type value as (BusinessLocations)', (done) => {
		autoCompleteRefDataComponent.changeValue.subscribe(retVal => {
			expect(retVal).toEqual('BusinessLocations');
			done();
		});
		autoCompleteRefDataComponent.refObj = REFERENCES;
		autoCompleteRefDataComponent.handleValue('BusinessLocation'); // data is present in Ref Object
		fixture.detectChanges();
	});

	it('should emit reference type value as (\'\')', (done) => {
		autoCompleteRefDataComponent.changeValue.subscribe(retVal => {
			expect(retVal).toEqual('');
			done();
		});
		autoCompleteRefDataComponent.refObj = REFERENCES;
		autoCompleteRefDataComponent.handleValue('BuinessLocation'); //Not there in the testdata
		fixture.detectChanges();
	});

});