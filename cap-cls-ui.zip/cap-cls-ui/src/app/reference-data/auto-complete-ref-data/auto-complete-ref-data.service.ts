import { Observable } from 'rxjs';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';


@Injectable()
export class AutoCompleteRefDataService {

    constructor( private http: Http ) {

    }

    public getReferenceTypes( url: string ): Observable<any> {
        return this.http.get(url)
            .map(
                res => res.json()
            );
    }
}