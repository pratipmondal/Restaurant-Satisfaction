import { MockBackend, MockConnection } from '@angular/http/testing';
import { fakeAsync, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions } from '@angular/http';
import { environment } from '../../../environments/environment';
import { AutoCompleteRefDataService } from './auto-complete-ref-data.service';
import { REFERENCES } from './mock-references';

describe('Service : AutoCompleteRefDataService', () => {
	let autoCompleteRefDataService: AutoCompleteRefDataService;
	let mockBackend: MockBackend;

	let tempUrl = environment.apiBaseUrl + environment.apiToGetAllReferenceTypes + environment.token;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				AutoCompleteRefDataService
			],
			imports: [HttpModule]
		});
	});

	beforeEach(
		inject([AutoCompleteRefDataService, MockBackend], (service: AutoCompleteRefDataService, backend: MockBackend) => {
			autoCompleteRefDataService = service;
			mockBackend = backend;
		})
	);

	it('should load auto complete reference data  service', () => {
		expect(autoCompleteRefDataService).toBeDefined();
	});

	it('should connect mock server ', fakeAsync(() => {
		autoCompleteRefDataService.getReferenceTypes(tempUrl);
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(tempUrl);
		});
	}));

	it('should response mock server ', fakeAsync(() => {
		let mockResponseBody = REFERENCES;
		mockBackend.connections.subscribe((connection: MockConnection) => {
			let response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
			connection.mockRespond(new Response(response));
		});
		autoCompleteRefDataService.getReferenceTypes(tempUrl).subscribe((response: Response) => {
			expect(response[0]['name']).toBe('BusinessLocation');
			expect(response[0]['plural']).toBe('BusinessLocations');
		});
	}));
});
