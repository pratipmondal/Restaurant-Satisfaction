import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { AutoCompleteRefDataComponent } from './auto-complete-ref-data.component';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { ListRefDataModule } from '../list-ref-data/list-ref-data.module';

@NgModule({
    imports: [ CommonModule, BrowserModule, AutoCompleteModule, LoaderModule
        , ListRefDataModule, GridModule ],
    declarations: [ AutoCompleteRefDataComponent ],
    exports: [ AutoCompleteRefDataComponent ]
})
export class AutoCompleteRefDataModule {
    public static forRoot(): ModuleWithProviders {
        return {ngModule: AutoCompleteRefDataModule, providers: []};
    }
}