import { Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { AutoCompleteRefDataService } from './auto-complete-ref-data.service';
import { environment } from '../../../environments/environment';

@Component({
    selector: 'auto-complete-component',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './auto-complete-ref-data.component.html',
    styleUrls: [ './auto-complete-ref-data.component.scss' ],
    providers: [ AutoCompleteRefDataService ]

})
export class AutoCompleteRefDataComponent implements OnInit {

    refObj: any = [];
    showLoader: boolean = false;
    public tempArr: any[];
    public data: any[];

    ngOnInit() {
    }

    constructor( private autoCompleteRefDataService: AutoCompleteRefDataService ) {
        this.showLoader = true;
        let tempURL = environment.apiBaseUrl + environment.apiToGetAllReferenceTypes;
        this.autoCompleteRefDataService.getReferenceTypes(tempURL).subscribe(
            response => {
                this.showLoader = false;
                this.refObj = response;
            },
            error => {
                this.showLoader = false;
            },
            () => {
                this.showLoader = false;
            }
        );
    }

    @Output()
    changeValue: EventEmitter<string> = new EventEmitter<string>();

    @Output()
    sendValueTOAddSingleRef: EventEmitter<string> = new EventEmitter<string>();

    handleValue( e ) {
        let dataObj = this.refObj.find(item => item.name === e);
        if (typeof (dataObj) !== 'undefined' && dataObj) {
            this.changeValue.emit(dataObj.plural);
            this.sendValueTOAddSingleRef.emit(this.refObj);
        }
        if (e === '' || dataObj === undefined) {
            this.changeValue.emit('');
        }
    }

    public filterChange( filter: any ): void {
        this.tempArr = this.refObj.map(function ( item ) {
            return item[ 'name' ];
        });
        this.data = this.tempArr.filter(( s ) => s.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
    }

}