import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridModule } from '@progress/kendo-angular-grid';
import { ListRefDataComponent } from './list-ref-data.component';
import { LoaderModule } from '../../shared/progression/loader/loader.module';

@NgModule({
    imports: [ CommonModule, LoaderModule, GridModule
    ],
    declarations: [
        ListRefDataComponent,
    ],
    exports: [ ListRefDataComponent ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ListRefDataModule {
}
