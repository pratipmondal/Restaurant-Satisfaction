import { async, ComponentFixture, ComponentFixtureAutoDetect, TestBed } from '@angular/core/testing';
import { ListRefDataComponent } from './list-ref-data.component';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridModule } from '@progress/kendo-angular-grid';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { HttpModule } from '@angular/http';
import { By } from '@angular/platform-browser';
import { ListResponse } from './list-ref-data.data';

describe('Testing ListRefDataComponent', () => {
	let listRefDataComponent: ListRefDataComponent;
	let fixture: ComponentFixture<ListRefDataComponent>;

	beforeEach(async(() => {

		TestBed.configureTestingModule({
			imports: [GridModule, CommonModule, LoaderModule, HttpModule],
			declarations: [ListRefDataComponent],
			providers: [{provide: ComponentFixtureAutoDetect, useValue: true}],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		});

		fixture = TestBed.createComponent(ListRefDataComponent);
		listRefDataComponent = fixture.debugElement.componentInstance;
		TestBed.compileComponents();

	}));

	it('should create the List Component', async(() => {
		expect(listRefDataComponent).toBeTruthy();

	}));

	it('should display Header in kendo grid', () => {

		let de: DebugElement = fixture.debugElement.query(By.css('.k-header'));
		let el: HTMLElement = de.nativeElement;

		expect(el.textContent).toContain('Code');

	});

	it('should display 5 columns in kendo grid', () => {

		let de: DebugElement = fixture.debugElement.query(By.css('thead tr'));
		let el: HTMLElement = de.nativeElement;
		expect(el.childElementCount).toEqual(5);

	});
	it('should emit data item on editfunction call', (done) => {
		var tempArr = [];
		let item = {
			'code': 'CHENNAI',
			'description': 'Tamilnadu',
			'parentRefType': '',
			'parentRefCode': '',
			'id': '58e1ad9753fdaf0700691a2c',
			'_type': 'City',
			'_createdBy': 'demoadmin',
			'_modifiedBy': 'demoadmin',
			'_createdOn': '2017-04-03T02:04:07.082Z',
			'_modifiedOn': '2017-04-03T02:04:07.082Z',
			'_version': 'e5ec00b6-e89c-47e2-864f-a85ee402e891',
			'_isDeleted': false
		};
		tempArr.push({OP_CODE: 'UPDATE'});
		tempArr.push(item);
		listRefDataComponent.onSelectRowValue.subscribe(response => {
			expect(response).toEqual(tempArr);
			done();
		});
		listRefDataComponent.editFunc(item);

		fixture.detectChanges();
	});

	it('Data should display in grid when reftype is selected', () => {
		listRefDataComponent.refName = 'Countrys';
		listRefDataComponent.gridData = ListResponse;
		listRefDataComponent.getReferenceData(this.refName);
		expect(listRefDataComponent.gridData).toBe(ListResponse);
	});

	it('Data not should display in grid when reftype is not selected or null', () => {
		listRefDataComponent.refName = '';
		listRefDataComponent.gridData = '';
		listRefDataComponent.getReferenceData(this.refName);
		expect(listRefDataComponent.gridData).toBe('');
	});

	/*TODO Need to uncomment below test for softdelete of ref data from grid*/

	/*it('Delete Data from grid when delete is called', () => {
	 listRefDataComponent.gridData = ListResponse;
	 let response = ListResponse;
	 let respForDelete = [{OP_CODE: "UPDATE"}, {
	 "code": "INDIA",
	 "description": "India",
	 "id": "58d345625d848b0600e08167",
	 "_type": "Country",
	 "_createdBy": "upload",
	 "_modifiedBy": "upload",
	 "_createdOn": "2017-03-23T03:47:45.990Z",
	 "_modifiedOn": "2017-03-23T03:47:45.990Z",
	 "_version": "71d85790-115d-4f2f-90c1-fb7c6f96b70e",
	 "_isDeleted": false
	 }];

	 listRefDataComponent.softDeleteReferenceData();
	 let dataObj = listRefDataComponent.gridData.find(item => item.code === respForDelete[1]["code"]);
	 let index = listRefDataComponent.gridData.indexOf(dataObj);
	 listRefDataComponent.gridData.splice(index, 1);
	 let dataObj1 = response.find(item => item.code === respForDelete[1]["code"]);
	 let index1 = response.indexOf(dataObj1);
	 response.splice(index1, 1);
	 expect(listRefDataComponent.gridData).toBe(response);
	 console.log("Component : ListRefDataComponent -- Data should not display in grid when reftype is not selected and null -- PASSED");
	 });*/

});
