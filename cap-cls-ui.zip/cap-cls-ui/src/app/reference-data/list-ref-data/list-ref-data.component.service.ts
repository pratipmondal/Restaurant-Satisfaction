import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Headers, Http, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';

@Injectable()
export class ListService {
    public params: any;

    constructor( private http: Http ) {

    }

    public getData( url: string, params: string[] ): Observable<any> {
        return this.http.get(url)
            .map(
                res => res.json()
            );

    }

    public deleteData( url: string, data: any ): Observable<any> {
        let headers = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers: headers});
        /*TODO change to DELETE Function*/
        return this.http.get(url, options)
            .map(res => res.json())

    }
}