import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { ListService } from './list-ref-data.component.service';
import { environment } from '../../../environments/environment';
import { DataStateChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { process, State } from '@progress/kendo-data-query';
@Component({
    selector: 'list-ref-data',
    templateUrl: './list-ref-data.component.html',
    styleUrls: [ './list-ref-data.component.scss' ],
    providers: [ ListService ]
})
export class ListRefDataComponent implements OnChanges {
    // Set our default values
    public gridData: any = [];
    successMsg: boolean = false;
    errMsg: boolean = false;
    errorMessage: string;
    showLoader = false;
    private state: State = {
        skip: 0,
        take: 10
    };
    private gridView: GridDataResult;
    @Input() refName: string;
    @Input() eventChangeFromUploader: string;
    @Input() eventChangeFromSingleUploader: string;
    @Input() eventChangeFromSingleUploaderUpdate: any;
    @Input() yesNoPromptForDelete: any;

    ngOnChanges( changes: SimpleChanges ) {
        if (changes[ 'refName' ]) {
            this.getReferenceData(this.refName);
        }
        if (changes[ 'eventChangeFromUploader' ]) {
            this.getReferenceData(this.refName);
        }
        if (changes[ 'eventChangeFromSingleUploader' ]) {
            this.getReferenceData(this.refName);
        }
        /*if (changes['yesNoPromptForDelete']) {
         this.softDeleteReferenceData();
         }*/
        if (changes[ 'eventChangeFromSingleUploaderUpdate' ]) {
            this.getReferenceData(this.refName);
        }
    }

    @Output()
    onSelectRowValue: EventEmitter<any> = new EventEmitter<any>();
    @Output()
    globalMessageEventFromList: EventEmitter<any> = new EventEmitter<any>();

    constructor( public listService: ListService ) {
    }

    public ngOnInit() {
        this.state.skip = 0;
        this.gridView = process(this.gridData, this.state);
    }

    public getReferenceData( refType: string ) {
        this.showLoader = true;
        if (refType === '') {
            //When Autocomplete Component returns Empty String
            this.showLoader = false;
            this.gridData = [];
            this.state.skip = 0;
            this.gridView = process(this.gridData, this.state);
        } else if (typeof refType !== 'undefined') {
            let url = environment.apiBaseUrl + environment.apiToGetPostReferenceData + refType;
            this.listService.getData(url, []).subscribe(
                response => {
                    setTimeout(() => {
                        this.showLoader = false;
                    }, 1000);
                    this.successMsg = true;
                    this.errMsg = false;
                    this.gridData = response;
                    this.state.skip = 0;
                    this.gridView = process(response, this.state);
                },
                error => {
                    this.showLoader = false;
                    this.successMsg = false;
                    this.errMsg = true;
                    this.errorMessage = 'Oops! something went wrong.    ' + error._body;
                },
                () => {
                }
            );
        } else {
            this.showLoader = false;
        }
    }

    protected dataStateChange( state: DataStateChangeEvent ): void {
        this.state = state;
        this.gridView = process(this.gridData, this.state);
    }

    /**Edit Button click event emit */
    public editFunc( item ): void {
        let tempArr = [];
        tempArr.push({OP_CODE: 'UPDATE'});
        tempArr.push(item);
        this.onSelectRowValue.emit(tempArr);
    }

    /*TODO Need to uncomment below method for softdelete of ref data from grid*/

    /**Delete Button click event emit
     public removeItemFunc(item): boolean {
        /!*let tempArr = [];
         tempArr.push({ OP_CODE: "DELETE" });
         tempArr.push(item);
         this.onSelectRowValue.emit(tempArr);*!/
        return false;
    }

     jsonMsgType: string;
     jsonMsgBody: string[];
     globalMessageEventFromDeleteFunct: {} = {
        "msg_type": this.jsonMsgType,
        "msg_body": this.jsonMsgBody
    };

     softDeleteReferenceData() {

        this.showLoader = true;
        if (this.yesNoPromptForDelete === "") {
            //When Autocomplete Component returns Empty String
        } else if (typeof this.yesNoPromptForDelete !== 'undefined') {
            //let url = environment.apiBaseUrl + environment.apiToGetPostReferenceData + this.yesNoPromptForDelete + environment.token + this.tokenVal;
            let url = "./app/shared/list/list.data.json";
            this.listService.deleteData(url, []).subscribe(
                response => {
                    setTimeout(() => {
                        this.showLoader = false;
                    }, 1000);
                    // /!*For DEMO Manipulate Grid Data for remove row from GRID*!/
                    // /!*this.gridData = response;
                    //  this.loadProducts(response);*!/
                    let dataObj = this.gridData.find(item => item.code === this.yesNoPromptForDelete[1]["code"]);
                    let index = this.gridData.indexOf(dataObj);
                    this.gridData.splice(index, 1);
                    this.gridView = process(this.gridData, this.state);
                    this.globalMessageEventFromDeleteFunct["msg_type"] = "SUCCESS";
                    this.globalMessageEventFromDeleteFunct["msg_body"] = ["Success!! The selected reference data is successfully deleted."]
                    this.globalMessageEvent(this.globalMessageEventFromDeleteFunct);
                },
                error => {
                    this.showLoader = false;
                    this.errorMessage = "Oops! something went wrong." + error._body;
                    this.globalMessageEventFromDeleteFunct["msg_type"] = "FAILURE";
                    this.globalMessageEventFromDeleteFunct["msg_body"] = ["Reference Data could not be deleted.", "Service API not available."];
                    this.globalMessageEvent(this.globalMessageEventFromDeleteFunct);
                },
                () => {
                    //this.showLoader = false;
                }
            );
        } else {
            this.showLoader = false;
        }
    }

     globalMessageEvent(value) {
        this.globalMessageEventFromList.emit(value);
    }*/
}