import { MockBackend, MockConnection } from '@angular/http/testing';
import { fakeAsync, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions } from '@angular/http';
import { environment } from '../../../environments/environment';
import { ListService } from './list-ref-data.component.service';
import { ListResponse } from './list-ref-data.data';

describe('Service : ListService', () => {
	let listService: ListService;
	let mockBackend: MockBackend;

	let tempUrl = environment.apiBaseUrl + environment.apiToGetPostReferenceData + 'Countrys';

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				ListService
			],
			imports: [HttpModule]
		});
	});

	beforeEach(
		inject([ListService, MockBackend], (service: ListService, backend: MockBackend) => {
			listService = service;
			mockBackend = backend;
		})
	);

	it('should load list data service', () => {
		expect(listService).toBeDefined();
	});
	it('should connect mock server ', fakeAsync(() => {
		listService.getData(tempUrl, []);
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(tempUrl);
		});
	}));

	it('should response mock server ', fakeAsync(() => {
		let mockResponseBody = ListResponse;
		mockBackend.connections.subscribe((connection: MockConnection) => {
			let response = new ResponseOptions({body: JSON.stringify(mockResponseBody)});
			connection.mockRespond(new Response(response));
		});
		listService.getData(tempUrl, []).subscribe((response: Response) => {
			expect(response[0]['code']).toBe('INDIA');
			expect(response[0]['description']).toBe('India');
			expect(response[0]['id']).toBe('58d345625d848b0600e08167');
			expect(response[0]['_type']).toBe('Country');
			expect(response[0]['_createdBy']).toBe('upload');
			expect(response[0]['_modifiedBy']).toBe('upload');
			expect(response[0]['_createdOn']).toBe('2017-03-23T03:47:45.990Z');
			expect(response[0]['_modifiedOn']).toBe('2017-03-23T03:47:45.990Z');
			expect(response[0]['_version']).toBe('71d85790-115d-4f2f-90c1-fb7c6f96b70e');
			expect(response[0]['_isDeleted']).toBe(false);

		});
	}));

});
