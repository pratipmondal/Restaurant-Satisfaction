import { Route } from '@angular/router';

import { UserRouteAccessService } from '../shared';
import { ReferenceDataComponent } from './reference-data.component';

export const REF_DATA_ROUTE: Route = {
    path: 'ref-data',
    component: ReferenceDataComponent,
    data: {
        authorities: [],
        pageTitle: 'CLS - Reference Data'
    },
    canActivate: [ UserRouteAccessService ]

};
