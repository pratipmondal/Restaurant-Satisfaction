import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AuthenticationService } from '../login/authentication.service';
import { ClsSharedCommonModule } from '../shared/';
import { LoaderModule } from '../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { CounterpartyDetailsModule } from '../shared/counterparty-details/counterparty-details.module';
import { REF_DATA_ROUTE, ReferenceDataComponent } from './index';
import { FileUploaderService } from './file-uploader/file-uploader.service';
import { ListRefDataModule } from './list-ref-data/list-ref-data.module';
import { FileUploaderModule } from './file-uploader/file-uploader.module';
import { SingleDataUploadComponent } from './single-data-upload/single-data-upload.component';
import { AutoCompleteRefDataModule } from './auto-complete-ref-data/auto-complete-ref-data.module';


@NgModule({
    imports: [
        RouterModule.forChild([ REF_DATA_ROUTE ]), CommonModule,
        BrowserModule, FormsModule, ReactiveFormsModule,
        ButtonsModule, BrowserAnimationsModule, AutoCompleteRefDataModule,
        LoaderModule, ListRefDataModule, GridModule, ClsSharedCommonModule, FileUploaderModule, CounterpartyDetailsModule
    ],
    declarations: [
        ReferenceDataComponent, SingleDataUploadComponent
    ],
    providers: [ AuthenticationService, FileUploaderService ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ReferenceDataModule {
}
