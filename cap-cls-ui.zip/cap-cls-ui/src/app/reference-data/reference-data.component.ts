import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../login/authentication.service';

@Component({
    selector: 'app-reference-data',
    templateUrl: './reference-data.component.html',
    styleUrls: [ './reference-data.component.scss' ],
    providers: [ AuthenticationService ]
})

export class ReferenceDataComponent implements OnInit {
    referenceNameInParent: string;
    itemValueFromGrid: any;
    eventChangeValFromUploader: string;
    eventChangeValFromSingleUpload: string;
    showLoader: boolean = false;
    showYesNoPrompt: boolean = false;
    showGlobalMessage: boolean = false;
    referenceTypebjs: any;

    loginInfo: JSON;
    public sessionToken;

    messageFromParentToGlobalMessageComp: any;

    payload: any;
    eventChangeValFromSingleUploadForUpdate: any;
    globalMessageEventChangeValFromUploader: any;

    constructor( private authenticationservice: AuthenticationService ) {
    }

    ngOnInit() {

    }

    onNotify( message: string ): void {
        this.referenceNameInParent = message;
    }

    onEventChangeForListFromUploader( eventChangeFromUploader: string ): void {
        this.eventChangeValFromUploader = eventChangeFromUploader;
    }

    onEventChangeForListFromSingleUploader( eventChangeFromSingleUpload: string ): void {
        this.eventChangeValFromSingleUpload = eventChangeFromSingleUpload;
    }

    onEventChangeForListFromSingleUploaderForUpdate( eventChangeFromSingleUpload: any ): void {
        this.eventChangeValFromSingleUploadForUpdate = eventChangeFromSingleUpload;
    }

    getValueFromAutoForParentRefToRefData( $event ) {
        this.referenceTypebjs = $event;
    }

    onSelectRowValue( message: any[] ): void {
        this.itemValueFromGrid = message;

        if (message[ 0 ][ 'OP_CODE' ] === 'DELETE') {
            this.showYesNoPrompt = true;
        }
    }

    onRowEditEventFromList( item: any ) {
        this.showYesNoPrompt = true;
    }

    confirmationFromYesNo( dlgPayload: any[] ) {
        if ((dlgPayload[ 2 ][ 'DLG_STATUS' ] === 'no') || (dlgPayload[ 2 ][ 'DLG_STATUS' ] === 'cancel')) {
            this.showYesNoPrompt = false;
        }
        else {
            this.showYesNoPrompt = false;
            this.payload = dlgPayload;// hide the yesNo Prompt

        }
    }

    closeEventGlobalMessage() {
        this.showGlobalMessage = false;
    }

    globalMessageEventFromListForParent( $event ): void {
        this.messageFromParentToGlobalMessageComp = $event;
        this.showGlobalMessage = !this.showGlobalMessage;
    }


    closeEventFromGlobalMessage() {
        this.showGlobalMessage = false;
    }

    onEventChangeForGlobalMessageFromUploader( globalMessageEventChangeFromUploader ): void {
        this.messageFromParentToGlobalMessageComp = globalMessageEventChangeFromUploader;
        this.showGlobalMessage = !this.showGlobalMessage;
    }

    receiveEventAddSingleUpdate( valueFromAddSingleUpdateEvent ) {
        this.messageFromParentToGlobalMessageComp = valueFromAddSingleUpdateEvent;
        this.showGlobalMessage = !this.showGlobalMessage;
    }

}