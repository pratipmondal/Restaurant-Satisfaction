import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { ClsSharedModule, OauthService } from '../shared';

import { LOGIN_ROUTE, LoginComponent } from './';


@NgModule({
    imports: [
        ClsSharedModule,
        RouterModule.forChild([ LOGIN_ROUTE ])
    ],
    declarations: [
        LoginComponent,
    ],
    entryComponents: [],
    providers: [ OauthService ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ClsLoginModule {
}
