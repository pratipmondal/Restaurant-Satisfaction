import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CSTButtonModule, CSTTextfieldModule } from 'ng2-cst-ui-components';

import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
    let component: LoginComponent;
    let fixture: ComponentFixture<LoginComponent>;

    let usernameField: CSTTextfieldModule;
    let passwordField: CSTTextfieldModule;
    let loginButton: CSTButtonModule;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                LoginComponent
            ],
            imports: [
                ReactiveFormsModule,
                HttpModule,
                RouterTestingModule,
                CSTTextfieldModule,
                CSTButtonModule
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LoginComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        usernameField = new CSTTextfieldModule();
    });

    /*it('should create', () => {
     expect(component).toBeTruthy();
     });

     it('should have a title', async(() => {
     const fixture = TestBed.createComponent(LoginComponent);
     const app = fixture.debugElement.componentInstance;
     expect(app.title).toEqual('CAP-CLS-UI Demo');
     }));

     it('should render title in a h1 tag', async(() => {
     const fixture = TestBed.createComponent(LoginComponent);
     fixture.detectChanges();
     const compiled = fixture.debugElement.nativeElement;
     expect(compiled.querySelector('h1').textContent).toContain('CAP-CLS-UI Demo');
     }));

     it('prepopulated data for CSTTextfieldModule', async(() => {
     const fixture = TestBed.createComponent(LoginComponent);
     fixture.detectChanges();
     const compiled = fixture.debugElement.nativeElement;
     expect(compiled.querySelector('h1').textContent).toContain('CAP-CLS-UI Demo');
     }));
     */
    /*it('username should be text type', async(() => {
     const fixture = TestBed.createComponent(LoginComponent);
     fixture.detectChanges();
     expect(usernameField.type).toEqual('text');
     }));*/

});
