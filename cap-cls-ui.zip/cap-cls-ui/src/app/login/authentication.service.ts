import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';

@Injectable()

export class AuthenticationService {
    private domainUrl = 'https://cap-cls-service.dev.apps.cs.sgp.dbs.com';
    private LoginUrl = this.domainUrl + '/cls/api/v1/login';

    constructor( private http: Http ) {
    }

    public login( data: JSON ) {
        let headers = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers});

        return this.http.post(this.LoginUrl, data, options)
            .toPromise()
            .then(( response ) => response.json())
            .catch(this.handleError);
    }

    private handleError( error: any ): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }

}
