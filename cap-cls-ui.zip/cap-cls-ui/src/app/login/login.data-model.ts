import { LoginModel } from './login.model';

export const pageTitle = {
    title: 'CAP-CLS-UI Demo'
}
export const demoLogin: LoginModel = {
    username: 'demoadmin',
    password: 'demoadmin'
};

export const validationMessages = {
    username: {
        required: 'Username is required.',
        minlength: 'Username must be at least 4 characters long.'
    },
    password: {
        required: 'Password is required.'
    }
};
