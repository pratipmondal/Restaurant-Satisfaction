import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { pageTitle } from './login.data-model';

import { LoginService, OauthService } from '../shared';

@Component({
    selector: 'cls-login',
    templateUrl: './login.component.html',
    styleUrls: [
        'login.scss', './login.component.scss'
    ],
    providers: [ AuthenticationService ]
})

export class LoginComponent implements OnInit {
    private title: string = pageTitle.title;

    constructor( private loginService: LoginService,
                 private router: Router,
                 private oauthService: OauthService, ) {

    }

    ngOnInit() {
    }

    public logoff() {
        this.oauthService.logout();
    }
}

