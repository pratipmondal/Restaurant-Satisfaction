import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Http, RequestOptions, XHRBackend } from '@angular/http';
import { OAuthModule } from 'angular-oauth2-oidc';

import { routing } from './app.routes';
import { ReferenceDataModule } from './reference-data/';
import { CollateralModule } from './collateral/';
import { SequenceGeneratorModule } from './sequence-generator/sequence-generator.module';
import { ClsMainComponent, HeaderModule } from './layouts';
import { ClsSharedModule, LoginService, SeqGenService, UserRouteAccessService } from './shared';
import { HttpInterceptor } from './shared/httpapi/http-interceptor.servie';
import { ClsHomeModule } from './home';
import { ClsLoginModule } from './login';
import { CollateralSummaryModule } from './collateral/collateral-summary/collateral-summary.module';
import { CollateralsListModule } from './collateral/collaterals-list/collaterals-list.module';
import { RegisterModule } from './register/register.module';
import { SearchUserModule } from './search-user/search-user.module';

export function getHttpInterceptor( backend: XHRBackend, defaultOptions: RequestOptions ) {
    return new HttpInterceptor(backend, defaultOptions);
}

@NgModule({
    declarations: [
        ClsMainComponent
    ],
    imports: [
        BrowserModule,
        ClsLoginModule,
        ClsSharedModule,
        HeaderModule,
        SequenceGeneratorModule,
        CollateralModule,
        ReferenceDataModule,
        RegisterModule,
        SearchUserModule,
        CollateralSummaryModule,
        CollateralsListModule,
        ClsHomeModule,
        routing,
        OAuthModule.forRoot()
    ],
    providers: [ {
        provide: Http,
        useFactory: getHttpInterceptor,
        deps: [ XHRBackend, RequestOptions ]
    }, SeqGenService, LoginService,
        UserRouteAccessService, ClsSharedModule,
    ],
    bootstrap: [ ClsMainComponent ]
})


export class AppModule {
}
