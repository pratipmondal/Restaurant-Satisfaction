import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { routing } from '../app.routes';

let LAYOUT_ROUTES = [
    routing
];

@NgModule({
    imports: [
        RouterModule.forRoot(LAYOUT_ROUTES, {useHash: true})
    ],
    exports: [
        RouterModule
    ]
})
export class LayoutRoutingModule {
}
