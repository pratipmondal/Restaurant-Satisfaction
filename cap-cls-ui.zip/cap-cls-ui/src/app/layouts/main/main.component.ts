import { Component, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, NavigationEnd, Router, RoutesRecognized } from '@angular/router';
import { Title } from '@angular/platform-browser';

import { OauthService } from '../../shared';

@Component({
    selector: 'cls-main',
    templateUrl: './main.component.html',
    styleUrls: [ './main.scss' ]
})
export class ClsMainComponent implements OnInit {
    public isLoggedIn: Boolean = false;

    constructor( private titleService: Title,
                 private router: Router,
                 public oauthService: OauthService ) {
    }

    private getPageTitle( routeSnapshot: ActivatedRouteSnapshot ) {
        let title: string = (routeSnapshot.data && routeSnapshot.data[ 'pageTitle' ]) ? routeSnapshot.data[ 'pageTitle' ] : 'CLS';
        if (routeSnapshot.firstChild) {
            title = this.getPageTitle(routeSnapshot.firstChild) || title;
        }
        return title;
    }

    ngOnInit() {
        // if (this.oauthService.isAuthorized()) {
        //     this.oauthService.getUserInfo();
        //     this.router.navigateByUrl('/');
        // } else {
        //     this.oauthService.triggerOAuth();
        // }
        this.router.events.subscribe(( event ) => {
            if (event instanceof NavigationEnd) {
                this.titleService.setTitle(this.getPageTitle(this.router.routerState.snapshot.root));
            }
            if (event instanceof RoutesRecognized) {
                let params = {};
                let destinationData = {};
                let destinationName = '';
                const destinationEvent = event.state.root.firstChild.children[ 0 ];
                if (destinationEvent !== undefined) {
                    params = destinationEvent.params;
                    destinationData = destinationEvent.data;
                    destinationName = destinationEvent.url[ 0 ].path;
                }
            }
        });

        this.oauthService.userLoggedIn$.subscribe(( userInfo: any ) => {
            if (userInfo) {
                this.isLoggedIn = true;
            } else {
                this.isLoggedIn = false;
            }
        });
    }

    public logout() {
        this.oauthService.logout();
    }
}
