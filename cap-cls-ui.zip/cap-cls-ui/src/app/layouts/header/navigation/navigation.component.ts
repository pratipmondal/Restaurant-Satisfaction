import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { LoginService, OauthService, Principal } from '../../../shared';

@Component({
    selector: 'cst-navigation',
    templateUrl: './navigation.component.html',
    styleUrls: [ './navigation.component.scss' ]
})
export class NavigationComponent implements OnInit {
    mySideNavWidth: number;

    constructor( private loginService: LoginService,
                 private principal: Principal,
                 private router: Router,
                 private oauthService: OauthService ) {
    }

    openNav() {
        this.mySideNavWidth = 225;

    }

    closeNav() {
        this.mySideNavWidth = 0;
    }

    isAuthenticated() {
        return this.oauthService.isAuthorized();
    }

    login() {
    }

    logout() {
        this.loginService.logout();
        this.router.navigate([ '' ]);
    }

    ngOnInit() {
    }

}
