import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { HeaderComponent } from './header.component';
import { NavigationComponent } from './navigation/navigation.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { CounterPartyListComponent } from 'app/common/counterparty-details/counterparty-list/counterparty-list.component';
import { CounterPartySearchComponent } from 'app/common/counterparty-details/counterparty-search/counterparty-search.component';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';
import { HighLightPipe } from 'app/common/counterparty-details/searh-highlight';

@NgModule({
    imports: [
        CommonModule, RouterModule, FormsModule
    ],
    declarations: [ HeaderComponent, NavigationComponent, BreadcrumbComponent, CounterPartySearchComponent, CounterPartyListComponent, HighLightPipe ],
    providers:[CounterPartyDetailsService],
    exports: [ HeaderComponent, NavigationComponent, BreadcrumbComponent, HighLightPipe ]
})
export class HeaderModule {
}
