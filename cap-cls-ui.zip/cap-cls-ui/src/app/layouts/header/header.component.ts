import { Component, OnInit } from '@angular/core';

import { dataHeader } from './header.data-model';

@Component({
    selector: 'cst-header',
    templateUrl: './header.component.html',
    styleUrls: [ './header.component.scss' ]
})
export class HeaderComponent implements OnInit {

    private cstDbsLogoUrl: string = dataHeader.cstDbsLogoUrl;
    private cstAppTitle: string = dataHeader.cstAppTitle;

    constructor() {
    }

    ngOnInit() {
    }

}
