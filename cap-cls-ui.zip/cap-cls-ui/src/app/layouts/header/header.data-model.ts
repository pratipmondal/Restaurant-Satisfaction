export const dataHeader = {
    cstDbsLogoUrl: '../assets/images/DBSLogo.svg',
    cstAppTitle: 'Central Liabilities System'
}