import { Component, OnInit } from '@angular/core';

import { Account, LoginService, Principal } from '../shared';
@Component({
    selector: 'cls-home',
    templateUrl: './home.component.html',
    styleUrls: [
        'home.scss'
    ]

})
export class HomeComponent implements OnInit {
    account: Account;

    constructor( private loginService: LoginService, private principal: Principal, ) {
    }

    ngOnInit() {
    }

    isAuthenticated() {
        return this.principal.isAuthenticated();
    }
}
