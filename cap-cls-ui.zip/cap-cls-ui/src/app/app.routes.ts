import { HeaderComponent } from './layouts/header/header.component';
import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { ReferenceDataComponent } from './reference-data/reference-data.component';
import { RegisterComponent } from './register/register.component';
import { SearchUserComponent } from './search-user/search-user.component';
import { SequenceGeneratorComponent } from './sequence-generator/sequence-generator.component';
//import { UserRouteAccessService } from './app/shared';

const headerRoute: Routes = [
    {
        path: '',
        component: HeaderComponent,
        outlet: 'header',
        //canActivate: [ UserRouteAccessService ],
        children: [
            {
                path: 'ref-data',
                component: ReferenceDataComponent,
                data: {
                    breadcrumb: 'Reference Data'
                }
            },
            {
                path: 'seq-gen',
                component: SequenceGeneratorComponent,
                data: {
                    breadcrumb: 'Sequence Generator'
                }
            },
            {
                path: 'register',
                component: RegisterComponent,
                data: {
                    breadcrumb: 'Register User'
                }
            },
            {
                path: 'search-user',
                component: SearchUserComponent,
                data: {
                    breadcrumb: 'Search User'
                }
            }
        ]
    },
];

export const routing: ModuleWithProviders = RouterModule.forRoot(headerRoute);

/*  import { Routes } from '@angular/router';

 import { AppComponent } from './app.component';
 import { ReferenceDataComponent } from './reference-data/reference-data.component';
 import { LoginComponent } from "./login/login.component";

 export const ROUTES: Routes = [
 //{ path:  '',  component: LoginComponent },
 { path:  '',  component: ReferenceDataComponent },
 { path: 'reference', component: ReferenceDataComponent },
 { path: '**', component: AppComponent }
 ];*/
