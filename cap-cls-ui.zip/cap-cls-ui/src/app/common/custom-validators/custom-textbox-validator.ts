import { AbstractControl } from '@angular/forms';
export class TextboxValidator {
	private static suffix: string = ' is a mandatory field. Please enter the amount';
	private static prefix_drop_down: string = 'Please select ';

	static required(c: AbstractControl) {
		return c.value ? null : {
			required: TextboxValidator.getMessage(c) // the custom message you wish to display
		};
	}

	static requiredDropDown(c: AbstractControl) {
		if (!c.value) {
			return {required: TextboxValidator.getMessage(c)};
		}
		return c.value['code'] ? null : {
			required: TextboxValidator.getMessage(c) // the custom message you wish to display
		};
	}

	static getMessage(c: AbstractControl): string {
		if (c['type'] === 'text') {
			return (c['label'] ? c['label'] + this.suffix : this.suffix);
		}
		if (c['type'] === 'dropdown') {
			return (c['label'] ? this.prefix_drop_down + c['label'] : this.prefix_drop_down);
		}
	}


}
