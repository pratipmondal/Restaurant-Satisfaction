import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ToggleButtonComponent } from './toggle-button.component';

@NgModule({
	imports: [
		CommonModule, BrowserModule, ButtonsModule
	],
	declarations: [ToggleButtonComponent],
	exports: [ToggleButtonComponent]
})
export class ToggleButtonModule {
}
