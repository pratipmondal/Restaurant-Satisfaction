import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { ToggleButtonComponent } from './toggle-button.component';
import { By } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

describe('ToggleButtonComponent', () => {
	let component: ToggleButtonComponent;
	let fixture: ComponentFixture<ToggleButtonComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [ButtonsModule],
			declarations: [ToggleButtonComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ToggleButtonComponent);
		component = fixture.componentInstance;
		component.value1 = 'Yes';
		component.value2 = 'No';
		component.selected = 'value1';
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should have the correct selected on init', () => {
		expect(component.selected).toEqual('value1');
	});

	it('should have the correct selected on init', () => {
		component.value2 = 'Yes';
		component.value1 = 'No';
		component.selected = 'value2';
		expect(component.selected).toEqual('value2');
	});

	it('should have the correct selected item when a button is clicked', () => {
		const buttons = fixture.debugElement.queryAll(By.css('.k-button-group'));
		const lastButton = buttons[buttons.length - 1];
		const lastButtonContent = lastButton.query(By.css('.k-group-end'));
		expect(lastButton.nativeElement.classList).not.toContain('.k-state-active');
		lastButtonContent.nativeElement.click();
		fixture.detectChanges();
		expect(lastButtonContent.nativeElement.textContent).toContain('No');
	});

});
