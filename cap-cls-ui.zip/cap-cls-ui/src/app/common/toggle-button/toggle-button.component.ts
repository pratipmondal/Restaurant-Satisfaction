import { Component, OnInit, forwardRef, Input, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
	selector: 'cls-toggle-button',
	templateUrl: './toggle-button.component.html',
	styleUrls: ['./toggle-button.component.scss']
})
export class ToggleButtonComponent implements OnInit {
	toggleStatus: boolean = true;
	@Output()
	toggleEventBtnGroup: EventEmitter<any> = new EventEmitter<any>();
	@Input()
	selectedValue: string;
	@Input()
	value1: any;
	@Input()
	value2: any;
	@Input()
	name: any;
	@Input()
	selected: string = '';
	private selectedSecond: boolean;
	private selectedFirst: boolean = true;

	constructor() {
	}

	ngOnInit() {
		this.toggleButtonOnVal();
	}

	toggleButton(event) {
		const target = event.target || event.srcElement || event.currentTarget;
		const valueAttr = target.attributes.value;
		const value = valueAttr.nodeValue;
		this.toggleEventBtnGroup.emit(value);
	}

	private toggleButtonOnVal() {
		if (this.selected === 'value1') {
			this.selectedFirst = true;
			this.selectedSecond = false;
		} else {
			this.selectedFirst = false;
			this.selectedSecond = true;
		}
	}
}
