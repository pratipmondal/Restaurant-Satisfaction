import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CurrencyDropdownComponent } from './currency-dropdown.component';
import { CurrencyDropdownService } from './currency-dropdown.service';
import { Observable } from 'rxjs/Rx';
import { FormControl, FormGroup } from '@angular/forms';
import { isUndefined } from 'util';
import createSpy = jasmine.createSpy;
import createSpyObj = jasmine.createSpyObj;

class MockCurrencyDropdownService {
	getCurrencies() {
		return Observable.of([{'code': 'INR'}, {'code': 'SGD'}]);
	}
}
describe('CurrencyDropdownComponent', () => {
	let component: CurrencyDropdownComponent;
	let fixture: ComponentFixture<CurrencyDropdownComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CurrencyDropdownComponent],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [{provide: CurrencyDropdownService, useClass: MockCurrencyDropdownService}]
		})
			.compileComponents();

	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CurrencyDropdownComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		component.currAmountName = 'currAmountName';
		component.currTypeName = 'currTypeName';
		component.detailGroup = new FormGroup({
			currAmountName: new FormControl(2.0),
			currTypeName: new FormControl('INR')
		});
	});

	it('should create CurrencyDropdownComponent', () => {
		expect(component).toBeTruthy();
	});

	it('amountFormatter should return formatted string', () => {
		expect(component.amountFormatter('')).toEqual('');
		expect(component.amountFormatter('1k')).toEqual('1,000.00');
		expect(component.amountFormatter('1B')).toEqual('1,000,000,000.00');
		expect(component.amountFormatter('0.234m')).toEqual('234,000.00');

	});

	it('amountFormatter should not return unformatted data', () => {
		expect(component.amountFormatter('')).toEqual('');
		expect(component.amountFormatter('1k')).not.toEqual('100.00');
		expect(component.amountFormatter('1B')).not.toEqual('1,000,000.00');
		expect(component.amountFormatter('0.234m')).toEqual('234,000.00');
	});
	it('convertToNumber should return empty string if value is null', () => {
		const mockEvent = {'target': {'value': null}};
		component.convertToNumber(mockEvent);
		expect(component.amount).toEqual('');
	});
	it('convertToNumber should return formatted number string', () => {
		const mockEvent = {'target': {'value': '123'}};
		component.convertToNumber(mockEvent);
		expect(component.amount).toEqual('123.00');
	});

	it('convertToNumber should not return empty value', () => {
		const mockEvent = {'target': {'value': '123'}};
		component.convertToNumber(mockEvent);
		expect(component.amount).not.toEqual('');
	});

	it('populateCurrencies should set currency values', () => {
		component.populateCurrencies();
		expect(component.currencies[0].code).toEqual('INR');
	});

	it('revertMinimumFractionDigits should return unformated number', () => {
		expect(component.revertMinimumFractionDigits('12,000')).toEqual('12000');
		expect(component.revertMinimumFractionDigits('12.3')).toEqual('12.3');
		expect(component.revertMinimumFractionDigits(undefined)).toEqual(undefined);
	});
});
