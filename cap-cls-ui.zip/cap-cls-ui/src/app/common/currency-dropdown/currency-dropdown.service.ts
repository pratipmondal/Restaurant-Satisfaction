import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response, Http, URLSearchParams } from '@angular/http';
import { ErrorResponse } from '../../sequence-generator/model/error-response';
import { environment } from '../../../environments/environment';

export class Currency {
	code: string;
	description: string;
}

@Injectable()
export class CurrencyDropdownService {
	constructor(private _http: Http) {
	}

	getToken() {
		return null;
	}

	errorResponse(error: any) {
		const ErrorResponse = <ErrorResponse>error;
		return Observable.throw(<ErrorResponse>ErrorResponse);
	}

	getCurrencies(filter?: any): Observable<any> {
		const params: URLSearchParams = new URLSearchParams();
		params.set('access_token', this.getToken());
		if (filter) {
			params.set('filter', JSON.stringify(filter));
		}
		return this._http.get(environment.apiBaseUrl + 'currency', {
			'search': params
		})
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponse(error));

		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

}
