import { Component, HostBinding, Input, OnInit } from '@angular/core';
import { isUndefined } from 'util';
import { CurrencyDropdownService } from './currency-dropdown.service';
import { FormControl, FormGroup } from '@angular/forms';
import { AotSummaryResolverHost } from '@angular/compiler';

@Component({
	selector: 'currency-dropdown',
	templateUrl: 'currency-dropdown.component.html',
	styleUrls: ['currency-dropdown.component.scss']
})

/*Usage :
 currency-dropdown #ccy [detailGroup]='collateralDetailsForm' [currTypeName]=''currencyType''
 [currAmountName]="'amount'" [placeholder]="'Enter CCY amount'" (focusout)="validateAmount(ccy)"></currency-dropdown>

 input amount: {{ccy.amount}}
 input currency: {{ccy.currency}}
 */

export class CurrencyDropdownComponent implements OnInit {

	amount: string;
	currencies: any[];
	regex: RegExp = new RegExp(/^(\d+|(\d+\.\d{1,3})|\.\d{1,3}|(\d+\.))([MBKmbk])?$/);
	currency = 'SGD';

	@Input()
	disabled: boolean;

	@Input()
	placeholder: string;

	@Input()
	detailGroup: FormGroup;
	@Input()
	currTypeName: string;

	@Input()
	currAmountName: string;

	@Input()
	validateCurrencyDropDown: boolean;

	constructor(private currencyDropdownService: CurrencyDropdownService) {
		this.populateCurrencies();
		this.amount = '';
		this.disabled = false;
		this.validateCurrencyDropDown = false;
		this.currency = 'SGD';

	}

	populateCurrencies() {
		this.currencyDropdownService.getCurrencies().subscribe(data => {
			this.currencies = data;
		});
	}

	ngOnInit() {
		if (this.detailGroup && this.detailGroup.get(this.currAmountName).value) {
			this.amount = this.amountFormatter(this.detailGroup.get(this.currAmountName).value);
		}
		if (this.detailGroup && this.detailGroup.get(this.currTypeName).value) {
			this.currency = this.detailGroup.get(this.currTypeName).value;
		}
	}

	convertToNumber(event: any): string {
		if (!(event || event.target || event.target.value)) {
			console.log('Event value is empty, returning.');
			return;
		}
		const amount: string = event.target.value;
		if (this.regex.test(amount)) {
			event.target.value = this.amountFormatter(amount.trim());
			this.amount = event.target.value;
		} else {
			this.amount = '';
			this.detailGroup.get(this.currAmountName).setValue('');
		}
	}

	amountFormatter(amount: any): string {
		let value: number;
		if (!amount) {
			this.detailGroup.get(this.currAmountName).setValue('');
			return '';
		}
		if (typeof (amount) !== 'string') {
			amount = amount.toString();
		}
		if (amount.endsWith('K') || amount.endsWith('k')) {
			amount = amount.substring(0, amount.length - 1);
			value = Number(amount) * 1000.00;
		} else if (amount.endsWith('M') || amount.endsWith('m')) {
			amount = amount.substring(0, amount.length - 1);
			value = Number(amount) * 1000000.00;
		} else if (amount.endsWith('B') || amount.endsWith('b')) {
			amount = amount.substring(0, amount.length - 1);
			value = Number(amount) * 1000000000.00;
		} else {
			value = Number(this.revertMinimumFractionDigits(amount));
		}
		if (!Number(value)) {
			value = 0.00;
		}
		value = Number(value.toFixed(3));
		this.detailGroup.get(this.currAmountName).setValue(value);
		return value.toLocaleString(undefined, {
			minimumFractionDigits: 2
		}).toString();
	}

	revertMinimumFractionDigits(amount: string): string {
		if (!amount) {
			return amount;
		}
		return amount.replace(/\,/g, '');
	}
}

