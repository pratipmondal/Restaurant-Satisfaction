import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { WarningPanelComponent } from './warning-panel.component';
import { By } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, ElementRef } from '@angular/core';

describe('Warning Panel Component Test Cases', () => {
	let component: WarningPanelComponent;
	let fixture: ComponentFixture<WarningPanelComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [WarningPanelComponent],
			providers: []

		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(WarningPanelComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});
	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
