import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { WarningPanelComponent } from './warning-panel.component';

@NgModule({
	imports: [CommonModule, BrowserModule, LoaderModule],
	declarations: [WarningPanelComponent],
	exports: [WarningPanelComponent]
})

export class WarningPanelModule {
	public static forRoot(): ModuleWithProviders {
		return {ngModule: WarningPanelModule, providers: []};
	}
}
