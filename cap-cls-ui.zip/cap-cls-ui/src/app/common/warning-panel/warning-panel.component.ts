import { Component, OnInit, Input } from '@angular/core';

@Component({
	selector: 'warning-panel',
	templateUrl: './warning-panel.component.html',
	styleUrls: ['./warning-panel.component.scss']
})
export class WarningPanelComponent implements OnInit {
	constructor() {
	}
	ngOnInit() {
	}

}
