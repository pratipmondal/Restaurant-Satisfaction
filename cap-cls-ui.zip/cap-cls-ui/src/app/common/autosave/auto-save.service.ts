import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';

import { Collateral } from 'app/collateral/model/collateral.model';
import { SaveInProgress } from 'app/common/models/types';

@Injectable()
export class AutoSaveService {
	saveStateObservable: BehaviorSubject<SaveInProgress>;
	form: FormGroup;
	formSubscriber: Subscription;

	constructor() {
	}

	setup(form: FormGroup, saveStateObservable: BehaviorSubject<SaveInProgress>) {
		this.form = form;
		this.saveStateObservable = saveStateObservable;
		this.subscribeToFormChanges();
	}

	saveCollateral(data: any) {
		this.saveStateObservable.next(true);
		setTimeout(() => {
			let collateral: Collateral;
			collateral = <Collateral>data;
			console.log('make a save call to backend  ' + JSON.stringify(collateral));
			this.saveStateObservable.next(false);
		}, 100);
	}

	subscribeToFormChanges() {
		if (this.formSubscriber) {
			return;
		}

		this.formSubscriber = this.form.valueChanges
			.map(data1 => data1)
			.debounceTime(2000)
			.distinctUntilChanged()
			.subscribe(data => {
				this.saveCollateral(data);
			});
	}

	unsubscribeToFormChanges() {
		if (!this.formSubscriber) {
			return;
		}

		this.formSubscriber.unsubscribe();
		this.formSubscriber = null;
	}
}
