import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
	selector: 'commentBox',
	templateUrl: 'commentBox.component.html',
	styleUrls: ['commentBox.component.scss']
})

export class CommentBoxComponent implements OnInit {
	@Input()
	addMessage: string = 'Add Comment';

	@Input()
	limit: number;

	@Input()
	form: FormGroup;

	@Input()
	name: string;

	@Input()
	addOptional: string = '';

	visible: boolean;

	addTitle: string = '';

	ngOnInit() {
		this.addTitle = this.addMessage;
		this.form.valueChanges
			.first()
			.subscribe(() => this.visible = this.anyComment());
	}

	showComment() {
		this.visible = true;
	}

	private anyComment() {
		const control = this.form.controls[this.name];
		return !!control.value;
	}
}
