import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { CommentBoxComponent } from './commentBox.component';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { CommentTextAreaComponent } from '../commentTextArea/commentTextArea.component';

xdescribe('CommentBoxComponent', () => {
	let comp: CommentBoxComponent;
	let fixture: ComponentFixture<CommentBoxComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CommentBoxComponent, CommentTextAreaComponent],
			imports: [ReactiveFormsModule]
		})
			.compileComponents()
			.then(() => {
				fixture = TestBed.createComponent(CommentBoxComponent);

				comp = fixture.componentInstance;
				comp.form = new FormGroup({comment: new FormControl('')});
				comp.name = 'comment';
				comp.limit = 10;

				fixture.autoDetectChanges();

			});
	}));

	it('should have an add comment button label', () => {
		const el: HTMLElement = fixture.nativeElement;
		expect(el.innerText).toContain('Add Comment');
	});

	it('displays the comment box if comment was entered previously', () => {
		comp.form.controls['comment'].setValue('some comment');
		comp.ngOnInit();
		fixture.detectChanges();

	});

	describe('when label is clicked', () => {
		let commentBoxLabel: HTMLElement;

		it('hides label and shows text area', () => {
			commentBoxLabel = getHTMLElementByCssClass('commentBox__label');
			expect(commentBoxLabel.innerText).toContain('Add Comment');
			showComment();
		});
	});

	function getHTMLElementByCssClass(className: string): HTMLElement {
		return fixture.debugElement.query(By.css('.' + className)).nativeElement;
	}

	function showComment() {
		getHTMLElementByCssClass('commentBox__label').click();
	}
});
