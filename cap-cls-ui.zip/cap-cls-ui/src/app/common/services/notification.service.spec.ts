import { NotificationMessage, NotificationService } from './notification.service';

describe('NotificationService', () => {
	const noteService = new NotificationService();

	it('saves message on notify', () => {
		const messagesReceived: NotificationMessage[] = [];
		noteService.notifications.subscribe((msg) => messagesReceived.push(msg));

		noteService.notify({msg1: 'message 1'});
		expect(messagesReceived.length).toBe(1);
		expect(messagesReceived[0]['msg1']).toBe('message 1');
	});

});
