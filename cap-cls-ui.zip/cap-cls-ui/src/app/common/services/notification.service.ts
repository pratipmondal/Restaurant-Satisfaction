import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export class NotificationMessage {
	[key: string]: string

	constructor(namespace: string, message: string) {
		return {[namespace]: message};
	}
}

@Injectable()
export class NotificationService {
	notifications: Subject<NotificationMessage>;

	constructor() {
		this.notifications = new Subject<NotificationMessage>();
	}

	notify(message: NotificationMessage) {
		this.notifications.next(message);
	}

	clear(namespace: string) {
		this.notifications.next(new NotificationMessage(namespace, ' '));
	}
}
