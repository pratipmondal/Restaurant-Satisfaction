// import { Component, Input, Output, EventEmitter, OnInit, forwardRef } from '@angular/core';
// import { FormGroup } from '@angular/forms';

import { Component, Input, forwardRef, OnInit, EventEmitter, Output } from '@angular/core';
import { Directive, ElementRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { isUndefined } from "util";

const noop: any = () => {
    // nothing here
};

@Component({
    selector: 'prefix-suffix-textbox',
    templateUrl: 'prefix-suffix-textbox.component.html',
    styleUrls: ['prefix-suffix-textbox.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => PrefixSuffixTextBoxComponent),
            multi: true
        }
    ]
})
export class PrefixSuffixTextBoxComponent implements OnInit, ControlValueAccessor {
    @Input() prefix: string;
    @Input() suffix: string;
    @Input() textdirection: string;
    @Input() _textvalue = '';
    @Input() customId: string;
    @Input() placeholder: string = '';
    @Input() checkType: string = 'PERCENTAGE_RANGE';
    @Input() textRightAlignFlg: boolean = false;
    @Output()
    focus?: EventEmitter<any> = new EventEmitter<any>();

    percentageError: boolean = false;
    onPasteValidationFlg: boolean = false;

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;
    oldVal: string = this.modelvalue;
    constructor(private _elRef: ElementRef) {
    }

    ngOnInit(): any {
        this.oldVal = this.modelvalue;
    }

    writeValue(value: any) {
        if (value !== undefined) {
            this._textvalue = value;
        }
    }

    public propagateChange = (_: any) => { };

    registerOnChange(fn) {
        this.propagateChange = fn;
    }

    registerOnTouched() { }

    get modelvalue() {
        return this._textvalue;
    }

    set modelvalue(val) {
        this._textvalue = val.trim();
        this.propagateChange(val);
        this.onChangeCallback(val);
    }

    onBlur(): void {
        this.onTouchedCallback();
    }

    getCSSInputClasses(flag: string) {
        let cssClasses;
        if (flag === 'left-align') {
            cssClasses = {
                'text-align': 'left',
            };
        } else {
            cssClasses = {
                'text-align': 'right',
            };
        }
        return cssClasses;
    }

    keyboardInput(event: any, value: any) {
        const current: string = isUndefined(value) ? '' : value;
        const next: string = current + event.key;
        if (this.checkType === 'PERCENTAGE_RANGE') {
            return this.processPercentageCheck(next, current);
        }
        else {
            return true;
        }
    }

    processPercentageCheck(next: string, current: string): boolean {
        if (isNaN(Number(next))) {
            this.percentageError = true;
            return false;
        }
        else
            if (this.percentageRangeCheck(next)) {
                this.percentageError = false;
                return true;
            }
            else {
                this.modelvalue = current;
                this.percentageError = true;
                return false;
            }
    }

    percentageRangeCheck(arg: string): boolean {
        if ((Number(arg) >= 0.000) && (Number(arg) <= 100.000)) {
            if (arg.indexOf('.', 0) > 0) {
                if (arg.split('.')[1].length > 3)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    outFocusValidation(event: any): string {
        if (!(event || event.target || event.target.value)) {
            return;
        }

        if (this.checkType === 'PERCENTAGE_RANGE') {
            if (this.percentageRangeCheck(String(event.target.value)) === true) {
                this.modelvalue = event.target.value;
                this.percentageError = false;
                this.oldVal = this.modelvalue;
            }
            else {
                this.modelvalue = '';
                this.percentageError = true;
            }
        }
    }

    resetText(event: any) {
        if ((this.percentageError === true))
        {
            this.modelvalue = this.oldVal;
        }
		this.focus.emit(event);
    }
}
