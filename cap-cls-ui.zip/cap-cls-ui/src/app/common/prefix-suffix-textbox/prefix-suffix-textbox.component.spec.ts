import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, EventEmitter } from '@angular/core';
import { PrefixSuffixTextBoxComponent } from './prefix-suffix-textbox.component';
import { isUndefined } from 'util';

describe('Prefix Suffix TextBox Component', () => {
	let component: PrefixSuffixTextBoxComponent;
	let fixture: ComponentFixture<PrefixSuffixTextBoxComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [PrefixSuffixTextBoxComponent],
			schemas: [NO_ERRORS_SCHEMA]
		})
			.compileComponents()
			.then(() => {
				fixture = TestBed.createComponent(PrefixSuffixTextBoxComponent);
				component = fixture.componentInstance;
				fixture.detectChanges();
			});
	}));

	it('should create PrefixSuffixTextBoxComponent',
		async(() => {
			fixture.detectChanges();
			expect(component).toBeTruthy();
		}));

	it('should processPercentageCheck with valid',
		async(() => {
			fixture.detectChanges();
			component.processPercentageCheck('3', '31');
			expect(component.percentageError).toBe(false);
		}));

	it('processPercentageCheck Numeric & precision should be valid',
		async(() => {
			fixture.detectChanges();
			component.processPercentageCheck('32.1', '32.11');
			expect(component.percentageError).toBe(false);
		}));

	it('processPercentageCheck should be invalid',
		async(() => {
			fixture.detectChanges();
			component.processPercentageCheck('132.1', '132.11');
			expect(component.percentageError).toBe(true);
		}));

	it('processPercentageCheck should be invalid numbers',
		async(() => {
			fixture.detectChanges();
			component.processPercentageCheck('@3.12', '32.1234');
			expect(component.percentageError).toBe(true);
		}));

	it('getCSSInputClasses should return the valid style', async(() => {
		const cssClasses = {
			'text-align': 'left'
		};
		fixture.detectChanges();
		const style = component.getCSSInputClasses('left-align');
		expect(style).toEqual(cssClasses);
	}));

	it('getCSSInputClasses should return the right align style', async(() => {
		const cssClasses = {
			'text-align': 'right'
		};
		fixture.detectChanges();
		const style = component.getCSSInputClasses('');
		expect(style).toEqual(cssClasses);
	}));

});
