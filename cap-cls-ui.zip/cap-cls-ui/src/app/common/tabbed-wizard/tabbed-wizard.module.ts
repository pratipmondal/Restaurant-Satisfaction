import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { NgModule, ModuleWithProviders } from "@angular/core";
import { LoaderModule } from "../../shared/progression/loader/loader.module";
import { TabbedWizardComponent } from "./tabbed-wizard.component";
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from "app/shared";

@NgModule({
    imports: [CommonModule, BrowserModule, LoaderModule, ButtonsModule, ClsSharedCommonModule],
    declarations: [TabbedWizardComponent],
    exports: [TabbedWizardComponent]
})

export class TabbedWizardModule {
}