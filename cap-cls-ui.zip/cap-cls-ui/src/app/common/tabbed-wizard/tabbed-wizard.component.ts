import {
	Component, NgZone, OnInit, Output, EventEmitter, Input, SimpleChanges,
	OnChanges, ElementRef, ViewChild, HostListener
} from '@angular/core';
import { CollateralService } from '../../collateral/collateral.service';
import { JsonConvert } from 'json2typescript';
import { Collateral } from '../../collateral/model/collateral';
import { ErrorResponse } from '../../shared';
import { ToastsComponent } from '../../shared/toasts/toasts.component';
import { FormGroup } from '@angular/forms';
import { FormMaps } from '../../collateral/model/formMaps.map';
const $ = require('jquery');

@Component({
	selector: 'tabbed-wizard',
	templateUrl: './tabbed-wizard.component.html',
	styleUrls: ['./tabbed-wizard.component.scss']
})
export class TabbedWizardComponent implements OnInit, OnChanges {
	public tabVal: string;
	enableSavingDiv: boolean = false;
	@Input() public showSavingDiv: any;
	@Input() public recieveJson: any[] = [];
	@Input()
	public tabs: Array<String> = [];
	@Output()
	tabSelection: EventEmitter<string> = new EventEmitter<string>();
	toastsComponent: ToastsComponent = new ToastsComponent();
	argToastMessageObject: any;
	globalMsg: boolean = false;
	jsonMsgType: string;
	jsonMsgBody: string[];
	statusObject: {} = {
		'msg_type': this.jsonMsgType,
		'msg_body': this.jsonMsgBody
	};
	errorResponse: ErrorResponse = null;
	failMsg: any[];
	// error panel code
	currentForm: FormGroup; // for the current Form validation error messages
	entireForms: FormGroup; // for entire group of Forms , check Invalid on each form to get the error Tabs list
	// error panel code
	tabsMap = new Map(); // Hold the tabs with the order
	scrollBarWidths = 40;
	public selectedCollateral: string;
	@ViewChild('tabHome') tabHome: ElementRef;
	@ViewChild('wrapper') wrapper: ElementRef;
	@ViewChild('tabLists') tabLists: ElementRef;

	constructor(private collateralService: CollateralService) {
	}

	ngOnChanges(changes: SimpleChanges) {
		if (changes['showSavingDiv']) {
			this.enableSavingDiv = this.showSavingDiv;
		}
	}

	ngOnInit() {
		this.createTabsArray();
		this.tabVal = 'Collateral Details';
// error panel code
		this.collateralService.getErrorsModel().subscribe(data => {
			if (data.errorForm) {
				this.currentForm = data.errorForm;
				this.entireForms = data.entireForm;
			}
		});
		if (this.collateralService.selectedTab) {
			this.selectedTab(this.collateralService.selectedTab);
		} else {
			this.selectedTab(this.tabVal);

		}
		this.selectedCollateral = this.collateralService.selectedCollateralType;

		this.collateralService.getMessage().subscribe(message => {
			this.tabVal = message;
		});
// error panel code
	}

	// error panel code
	isErrorTabs(tab?: string) {
		let notFound = true;
		this.collateralService.errorTabs.forEach(element => {
			if (notFound) {
				if (element.tabText && element.tabText === tab) {
					notFound = false;
				}
			}
		});
		return !notFound;
	}

	// error panel code

	// error panel code
	private checkErrorPanel() {
		const errorTabs: any[] = [];
		this.collateralService.formSubmitClicked = true;
		if (this.entireForms && this.entireForms instanceof FormGroup) {
			this.collateralService.errorTabs = []; // re-initialize everytime form is submitted

			// iterate through each tab/ Formgroup and check if valid
			Object.keys(this.entireForms.controls).forEach(form => {
				if (this.entireForms.controls[form].invalid) {
					const mapKey = this.findKeyFromMap(form);
					errorTabs.push({tabText: mapKey, tabValue: form});
					this.collateralService.errorTabs.push({tabText: mapKey, tabValue: form});
				}
			});

		}

		// set errors for error panel
		this.collateralService.setErrorsModel({
			errorForm: this.entireForms.controls[this.findKeyFromMap(this.tabVal)],
			entireForm: this.entireForms,
			currentFormName: this.tabVal
		});

		// emit the tab selection If any error tabs and return, No back end calls
		if (errorTabs.length > 0) {
			this.tabSelection.emit(this.tabVal);
			return true;
		}
		return false;
	}

	// error panel code

	// error panel code
	findKeyFromMap(val?: string) {
		let k = '';
		let found = false;
		Object.keys(FormMaps.map).forEach(key => {
			if (!found) {
				if (val === FormMaps.map[key]) {
					k = key;
					found = true;
				}
			}
		});
		return k;
	}

	// error panel code

	public selectedTab(selectedTabVal: string) {
		this.tabVal = selectedTabVal;
		this.tabSelection.emit(this.tabVal);
		if (this.getTabIndex(this.tabVal) < 4) {
			this.moveScrollForPrev();
		}
		else {
			this.moveScrollForNext();
		}
	}

	public submitFullData() {
		// error panel code
		if (this.checkErrorPanel()) {
			return;
		}
		// error panel code

		this.collateralService.submitCollateral().subscribe(data => {
				this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(data), Collateral);
				this.globalMsg = true;
				this.statusObject['msg_type'] = 'SUCCESS';
				this.statusObject['msg_body'] = ['Collateral submitted succesfully!!'];
			}, error => {
				this.errorResponse = <ErrorResponse>error;
				this.globalMsg = true;
				this.failMsg = this.getErrorsList(this.errorResponse, this.failMsg);
				this.statusObject['msg_type'] = 'FAILURE';
				this.statusObject['msg_body'] = this.failMsg;
			}
		);
	}

	getErrorsList(errorResponse, failMsg): any[] {
		failMsg = [];
		const errorBody = JSON.parse(errorResponse._body);
		for (let i = 0; i < errorBody['errors'].length; i++) {
			const error = errorBody['errors'][i];
			failMsg.push((error.path) ? error.path.slice(6) + ' : ' + error.message : error.code + ' : ' + error.message);
		}
		return failMsg;
	}

	closeStatusObject() {
		this.globalMsg = false;
	}

	/* Tab navigation user story #2255
	 Tabs array to be maintained in order to get next visible tab for the given collateral */
	createTabsArray() {
		this.tabsMap.set(0, 'Collateral Details');
		this.tabsMap.set(1, 'Specific Details');
		this.tabsMap.set(2, 'Beneficiary & Facility Linkage');
		this.tabsMap.set(3, 'Ownership');
		this.tabsMap.set(4, 'Charge');
		this.tabsMap.set(5, 'Document');
		this.tabsMap.set(6, 'Valuation');
		this.tabsMap.set(7, 'Summary');
	}

	/*
	 @HostListener('document:keydown', ['$event'])
	 handleKeyboardEvent(event: KeyboardEvent) {
	 event.stopImmediatePropagation();
	 if (event.keyCode === 37) { // Left arrow click
	 this.prevClick();
	 } else if (event.keyCode === 39) { // Right arrow click
	 this.nextClick();
	 }
	 }*/

	public nextClick() {
		this.navigateTo('next');
		this.moveScrollForNext();
	}

	moveScrollForNext() {
		if (this.widthOfHidden() >= 0) {
			return;
		}
		if (this.getTabIndex(this.tabVal) > 3 && this.widthOfHidden() < 0) {
			$('.tabLists').animate({left: '+=' + this.widthOfHidden() + 'px'},
				{
					queue: false, speed: 'slow', easing: 'linear',
					complete: this.onSuccess()
				});
		}
	}

	public prevClick() {
		this.navigateTo('prev');
		this.moveScrollForPrev();
	}

	moveScrollForPrev() {
		if (this.getLeftPosi() >= 0) {
			return;
		}
		if (this.getTabIndex(this.tabVal) < 4) { // move the scroll to left only if the tab index is < 4
			if (this.getLeftPosi() < 0) {
				$('.tabLists').animate({left: '-=' + (this.getLeftPosi()) + 'px'},
					{
						queue: false, speed: 'slow', easing: 'linear', complete: this.onSuccess()
					});
			}
		}
	}

	onSuccess() {
		// animation completed
	}

	public navigateTo(navAction: string) {
		let focusTab: string = '';
		if (navAction === 'prev') {
			// to get the focus tab.
			focusTab = this.getPrevTab(this.tabVal);
			this.selectedTab(focusTab);
		} else if (navAction === 'next') {
			// to get the focus tab.
			focusTab = this.getNextTab(this.tabVal);
			this.selectedTab(focusTab);
		}
	}

	getTabIndex(currentTab: string) {
		let index: number = 1;
		this.tabsMap.forEach(function (value, key) {
			if (currentTab === value) {
				index = key;
			}
		});
		return index;
	}

	getFirstTab() {
		return this.tabsMap.get(0);
	}

	getLastTab() {
		return this.tabsMap.get(this.tabsMap.entries.length - 1);
	}

	getPrevTab(currentTab: string) {
		let prevKey: number;
		this.tabsMap.forEach(function (value, key) {
			if (currentTab === value) {
				prevKey = key - 1;
			}
		});
		const prevTabValue = this.tabsMap.get(prevKey);
		const backEndprevTabValue = this.mapTabNames(prevTabValue);

		if (prevTabValue !== undefined) {
			// check the prevTab is loaded in JSON
			return this.tabs.indexOf(backEndprevTabValue) > 0 ? prevTabValue : this.getPrevTab(prevTabValue);
		}
		return this.tabs.indexOf(backEndprevTabValue) > 0 ? prevTabValue : currentTab;
	}

	getNextTab(currentTab: string) {
		let nextKey: number = 0;
		this.tabsMap.forEach(function (value, key) {
			if (currentTab === value) {
				nextKey = key + 1;
			}
		});
		const nextTabValue = this.tabsMap.get(nextKey);
		const backEndnextTabValue = this.mapTabNames(nextTabValue);
		if (nextTabValue !== undefined) {
			// check the prevTab is loaded in JSON
			return this.tabs.indexOf(backEndnextTabValue) > 0 ? nextTabValue : this.getNextTab(nextTabValue);
		}
		return this.tabs.indexOf(backEndnextTabValue) > 0 ? nextTabValue : currentTab;
	}

	mapTabNames(tabName) {
		if (tabName === 'Collateral Details') {
			return 'CollateralCodeLinkageDetail';
		} else if (tabName === 'Beneficiary & Facility Linkage') {
			return 'LodgeBeneficiaryDetail';
		} else if (tabName === 'Document') {
			return 'LodgeDocumentationDetail';
		} else if (tabName === 'Ownership') {
			return 'LodgeOwnerShipDetail';
		} else if (tabName === 'Specific Details') {
			return 'LodgeCollateralTypeSpecificDetail';
		} else if (tabName === 'Charge') {
			return 'LodgeChargeDetail';
		} else if (tabName === 'Valuation') {
			return 'CollateralValuationDetail';
		} else if (tabName === 'Summary') {
			return 'Summary';
		}
	}

	public widthOfList() {
		let itemsWidth = 0;
		$('.wrapper span').each(function () {
			const itemWidth = $(this).outerWidth();
			itemsWidth += itemWidth;
		});
		return itemsWidth;
	}

	public widthOfHidden() {
		return (this.wrapper.nativeElement.offsetWidth - this.widthOfList() - this.getLeftPosi()) - this.scrollBarWidths;
	}

	public getLeftPosi() {
		return this.tabLists.nativeElement.offsetLeft;
	}
}
