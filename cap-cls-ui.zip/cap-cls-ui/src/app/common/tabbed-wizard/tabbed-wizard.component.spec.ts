import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { TabbedWizardComponent } from './tabbed-wizard.component';
import { BrowserModule, By } from '@angular/platform-browser';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from 'app/shared';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { CollateralService } from '../../collateral/collateral.service';
import { Collateral } from '../../collateral/model/collateral';
import { Headers, Http, RequestOptions, URLSearchParams, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { CollateralReponse } from '../../collateral/collateralData';
import { collateralData, collateralResData } from '../../collateral/new-collateral/new-collateral.data';
export const errors =
	{
		'errors': [{'error': 'error 1', 'formControl': 'amount'},
			{'error': 'error 2', 'formControl': 'amount2'}]
	}

class MockCollateralService {
	globalMsg: boolean = false;
	errorTabs: any[] = [];
	collateral: any;
	jsonMsgType: string;
	jsonMsgBody: string[];
	statusObject: {} = {
		'msg_type': this.jsonMsgType,
		'msg_body': this.jsonMsgBody
	};

	getCollateral() {
		return new Collateral();
	}

	getErrorsModel() {
		return Observable.of(errors);
	}

	submitCollateral() {
		
		this.globalMsg = true;
		this.statusObject['msg_type'] = 'SUCCESS';
		this.statusObject['msg_body'] = ['Collateral submitted succesfully!!'];
		return Observable.of(collateralData);
	}
}

describe('TabbedWizardComponent', () => {
	let component: TabbedWizardComponent;
	let fixture: ComponentFixture<TabbedWizardComponent>;

	beforeEach(async(() => {
		window['jasmine'].DEFAULT_TIMEOUT_INTERVAL = 100000;
		TestBed.configureTestingModule({
			imports: [ButtonsModule, LoaderModule, HttpModule, FormsModule],
			declarations: [TabbedWizardComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [{provide: CollateralService, useClass: MockCollateralService}]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TabbedWizardComponent);
		component = fixture.componentInstance;
		//let collateralService: CollateralService;
		//collateralService = TestBed.get(CollateralService);
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('can submit the collateral data', () => {
		spyOn(component, 'submitFullData').and.returnValue('Collateral submitted succesfully!!');
		expect(component.submitFullData()).toBeTruthy();
		expect(component.submitFullData).toHaveBeenCalled();
	});

	xit('can submit the collateral service method', () => {
		let mockCollateralService: CollateralService;
		mockCollateralService = TestBed.get(CollateralService);
		//spyOn(mockCollateralService, 'submitCollateral').and.returnValue(Observable.of(Collateral));
		component.submitFullData();
		expect(mockCollateralService.collateral.collateralCode).toBe('code03');
		//expect(mockCollateralService.submitCollateral).toHaveBeenCalled();
	});

	it('should select tab', async(() => {
		component.selectedTab('Collateral Details');
		expect(component.tabVal).toBe('Collateral Details');
	}));

	it('should scroll horizonally right', async(() => {
		fixture.detectChanges();
		spyOn(component, 'nextClick');
		component.selectedTab('Summary');
		const btn = fixture.debugElement.query(By.css('.tab-navigation-next'));
		//    btn.nativeElement.click();
		btn.triggerEventHandler('click', 'nextClick');
		fixture.detectChanges();
		expect(component.tabLists.nativeElement.offsetLeft).toBeLessThanOrEqual(0);
	}));

	it('should scroll horizonally left', async(() => {
		fixture.detectChanges();
		spyOn(component, 'prevClick');
		component.selectedTab('Summary');
		const btn = fixture.debugElement.query(By.css('.tab-navigation-prev'));
		btn.nativeElement.click();
		fixture.detectChanges();
		expect(component.tabLists.nativeElement.offsetLeft).toBe(0);
	}));

});
