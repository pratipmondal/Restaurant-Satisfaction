import { Observable } from 'rxjs/Observable';

export type SaveInProgress = boolean | Observable<Boolean>;
