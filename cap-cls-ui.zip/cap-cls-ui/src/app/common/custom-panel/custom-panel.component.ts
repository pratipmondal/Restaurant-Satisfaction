import { Component, OnInit, Input, Directive, ElementRef, Renderer } from '@angular/core';

@Component({
	selector: 'custom-panel',
	templateUrl: './custom-panel.component.html',
	styleUrls: ['./custom-panel.component.scss']
})
export class CustomPanelComponent implements OnInit {
	@Input()
	public header: string;
	@Input()
	public collapsible: boolean = true;
	public expanded: boolean = true;

	constructor(private _displayContent: ElementRef) {
	}

	ngOnInit() {
	}

	public collapseClicked(): void {
		this.expanded = !this.expanded;
		if (!this.expanded) {
			this._displayContent.nativeElement.querySelector('.panel-body').style.display = 'none';
		} else {
			this._displayContent.nativeElement.querySelector('.panel-body').style.display = 'block';

		}
	}

}
