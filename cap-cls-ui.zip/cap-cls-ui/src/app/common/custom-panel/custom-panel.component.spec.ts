import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomPanelComponent } from './custom-panel.component';
import { ElementRef } from '@angular/core';

class MockElementRef implements ElementRef {
	nativeElement = {};
}

describe('Custom Panel Component Test cases', () => {
	let component: CustomPanelComponent;
	let fixture: ComponentFixture<CustomPanelComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CustomPanelComponent],
			providers: [{provide: ElementRef, useValue: new MockElementRef()}]

		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CustomPanelComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', async(() => {
		fixture.detectChanges();
		expect(component).toBeTruthy();
	}));

	it('collapsible icon clicked to expand', async(() => {
		component.collapsible = true;
		const mockEleRef = new MockElementRef();
		const  div = {};
		mockEleRef.nativeElement = {
			querySelector: (v) => v === 'div'
		};
		spyOn(component, 'collapseClicked').and.returnValue(mockEleRef.nativeElement);
		component.collapseClicked();
		fixture.detectChanges();
		expect(component.expanded).toBeTruthy();
	}));
});

