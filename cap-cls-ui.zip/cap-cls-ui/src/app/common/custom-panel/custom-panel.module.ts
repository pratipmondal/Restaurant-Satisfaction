import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { CustomPanelComponent } from './custom-panel.component';

@NgModule({
	imports: [CommonModule, BrowserModule, LoaderModule],
	declarations: [CustomPanelComponent],
	exports: [CustomPanelComponent]
})

export class CustomPanelModule {
	public static forRoot(): ModuleWithProviders {
		return {ngModule: CustomPanelModule, providers: []};
	}
}
