import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {NgModule, ModuleWithProviders} from '@angular/core';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {HeadErrorPanelComponent} from './head-error-panel.component';

@NgModule({
    imports: [CommonModule, BrowserModule, LoaderModule ],
    declarations: [HeadErrorPanelComponent],
    exports: [HeadErrorPanelComponent]
})

export class HeadErrorPanelModule {
    public static forRoot(): ModuleWithProviders {
        return {ngModule: HeadErrorPanelModule, providers: []};
    }
}