import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule, ElementRef, OnInit} from '@angular/core';
import {HeadErrorPanelComponent} from './head-error-panel.component';
import {CollateralService} from '../../collateral/collateral.service';

class MockElementRef implements ElementRef {
    nativeElement = {};

}

class MockCollateralService {
}

describe('HeadErrorPanelComponent', () => {
    let component: HeadErrorPanelComponent;
    let fixture: ComponentFixture<HeadErrorPanelComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [HeadErrorPanelComponent],
            providers: [{provide: ElementRef, useValue: new MockElementRef()},
                {provide: CollateralService, useClass: MockCollateralService}]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HeadErrorPanelComponent);
        component = fixture.componentInstance;
        spyOn(component, "ngOnInit");
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
