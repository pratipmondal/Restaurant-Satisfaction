import { Component, OnInit, OnDestroy, EventEmitter, Input, Output, Directive, ElementRef, Renderer } from '@angular/core';
import { CollateralService } from '../../collateral/collateral.service';
import { Subscription } from 'rxjs/Subscription';
import { FormGroup } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { FormMaps } from '../../collateral/model/formMaps.map';

@Component({
    selector: 'head-error-panel',
    templateUrl: './head-error-panel.component.html',
    styleUrls: ['./head-error-panel.component.scss']
})
export class HeadErrorPanelComponent implements OnInit, OnDestroy {


    showHeadErrorPanel: boolean = false;
    displayErrorSet: string[] = [];
    errors: any[] = [];
    errorTabs: any[] = [];
    subscriptions: Subscription[] = [];

    // added code
    @Input()
    subscriptionService: Observable<any>;
    @Output()
    errorHandler?: EventEmitter<any[]> = new EventEmitter<any[]>();
    @Output()
    focusHandler?: EventEmitter<any> = new EventEmitter<any>();
    // added code


    constructor(private collateralService: CollateralService, private _displayContent: ElementRef) {
    }


    // error panel code
    setErrorsFromService(data?: any) {
        this.errors = [];
        this.displayErrorSet = [];
        this.showHeadErrorPanel = false;
        if (!this.collateralService.formSubmitClicked) {
            return;
        }

        const errs: any[] = [];
        const errorTabs: any[] = [];

        if (data.errorForm && data.errorForm.controls) {
            if (data.errorForm.invalid) {
                Object.keys(data.errorForm.controls).forEach(key => {
                    // if (data.errorForm.controls[key].errors) {
                    // Object.keys(data.errorForm.controls[key].errors).forEach(errorKey => {
                    // {error:'error 1', formControl: 'amount'},{error:'error 2', formControl: 'amount2'}
                    const ctrl = data.errorForm.controls[key];
                    const ctrl_errs = ctrl.errors;
                    if (ctrl_errs && ctrl.invalid === true) {
                        Object.keys(ctrl_errs).forEach(errorKey => {
                            errs.push({ formControl: ctrl, error: (ctrl_errs[errorKey] ? ctrl_errs[errorKey] : ctrl.label + ' is ' + errorKey), name: key.toString(), label: ctrl.label ? ctrl.label : key });
                        });
                    }
                    // });
                    // }
                });
            }
        }
        if (data.entireForm && data.entireForm instanceof FormGroup) {
            this.collateralService.errorTabs = [];
            Object.keys(data.entireForm.controls).forEach(form => {
                if (data.entireForm.controls[form].invalid) {
                    const mapKey = this.findKeyFromMap(form);
                    errorTabs.push({ tabText: mapKey, tabValue: form });
                    this.collateralService.errorTabs.push({ tabText: mapKey, tabValue: form });
                }
            });
        }

        if (errs.length > 0) {
            this.showHeadErrorPanel = true;
            this.errors = errs;
            this.errorTabs = errorTabs;
        }
    }
    // error panel code

    findKeyFromMap(val?: string) {
        let k = '';
        let found = false;
        Object.keys(FormMaps.map).forEach(key => {
            if (!found) {
                if (val === FormMaps.map[key]) {
                    k = key;
                    found = true;
                }
            }
        });
        return k;
    }

    sendControl(formControl: string) {
        // logic to focus the form input/ componenet which has the error
        this.focusHandler.emit(formControl);
    }

    ngOnInit() {

        this.subscriptions.push(this.subscriptionService.subscribe(data => {
            this.setErrorsFromService(data);
            this.errorHandler.emit(data);
        }));
    }

    ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscriptions.forEach(sub => {
            sub.unsubscribe();
        });
    }
}
