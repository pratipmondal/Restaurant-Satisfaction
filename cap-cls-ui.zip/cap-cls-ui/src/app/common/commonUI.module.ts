import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {CurrencyDropdownComponent} from '../common/currency-dropdown/currency-dropdown.component';
import {CurrencyDropdownService} from '../common/currency-dropdown/currency-dropdown.service' ;
import { Http, RequestOptions, XHRBackend } from '@angular/http';
import { HttpInterceptor } from '../shared/httpapi/http-interceptor.servie';
import { ClsSharedCommonModule } from '../shared/shared-common.module';
import { CommentBoxComponent } from './commentbox/commentBox.component';
import { CommentTextAreaComponent } from './commentTextArea/commentTextArea.component';

import { PrefixSuffixTextBoxComponent } from './prefix-suffix-textbox/prefix-suffix-textbox.component';
import {DropDownsModule, ComboBoxModule} from '@progress/kendo-angular-dropdowns';

import { HeadErrorPanelModule} from "./head-error-panel/head-error-panel.module";

export function getHttpInterceptor( backend: XHRBackend, defaultOptions: RequestOptions ) {
    return new HttpInterceptor(backend, defaultOptions);
}
let components = [
    CommentBoxComponent,
    CommentTextAreaComponent,
    PrefixSuffixTextBoxComponent,
    CurrencyDropdownComponent
];


@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        DropDownsModule,
        ComboBoxModule,
        
    ],
    declarations: components,
    exports: components,
    providers: [{
        provide: Http,
        useFactory: getHttpInterceptor,
        deps: [ XHRBackend, RequestOptions ]
    },CurrencyDropdownService]
})

export class CommonUIModule {

}
