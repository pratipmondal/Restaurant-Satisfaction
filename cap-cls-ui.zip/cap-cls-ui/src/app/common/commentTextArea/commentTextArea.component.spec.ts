import { ComponentFixture, async, TestBed } from '@angular/core/testing';
import { CommentTextAreaComponent } from './commentTextArea.component';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { By } from '@angular/platform-browser';

describe('CommentTextAreaComponent', () => {
	let comp: CommentTextAreaComponent;
	let fixture: ComponentFixture<CommentTextAreaComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CommentTextAreaComponent],
			imports: [ReactiveFormsModule]
		})
			.compileComponents()
			.then(() => {
				fixture = TestBed.createComponent(CommentTextAreaComponent);
				comp = fixture.componentInstance;
				comp.form = new FormGroup({comment: new FormControl('')});
				comp.name = 'comment';
				comp.limit = 10;
				fixture.autoDetectChanges();
			});
	}));

	it('should create', () => {
		expect(comp).toBeTruthy();
	});

	it('set the comment', () => {
		setComment('Test 123');
	});

	function setComment(comment: string) {
		fixture.componentInstance.form.controls['comment'].setValue(comment);
		fixture.detectChanges();
	}

	it('shows remaining characters as 9 / 10 in the label', () => {
		let commentBoxLabel: HTMLElement;
		setComment('Test 1234');
		commentBoxLabel = getHTMLElementByCssClass('commentTextArea__charactersUsed');
		expect(commentBoxLabel.innerText).toContain('9 / 10 characters');
	});

	it('should not show remaining characters as 4 / 10 in the label', () => {
		let commentBoxLabel: HTMLElement;
		setComment('Test');
		commentBoxLabel = getHTMLElementByCssClass('commentTextArea__charactersUsed');
		expect(commentBoxLabel.innerText).toContain('4 / 10 characters');
	});

	function getHTMLElementByCssClass(className: string): HTMLElement {
		return fixture.debugElement.query(By.css('.' + className)).nativeElement;
	}
});
