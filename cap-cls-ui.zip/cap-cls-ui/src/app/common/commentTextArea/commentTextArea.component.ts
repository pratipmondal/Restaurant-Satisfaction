import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
	selector: 'commentTextArea',
	templateUrl: 'commentTextArea.component.html',
	styleUrls: ['commentTextArea.component.scss']
})
export class CommentTextAreaComponent {
	@Input()
	limit: number;

	@Input()
	form: FormGroup;

	@Input()
	name: string;

	@Input()
	title: string;

	@Input()
	optional: string = '';

	@Input()
	placeholder: string = '';

	counterDisplay(): string {
		const control = this.form.controls[this.name];
		const textLength = Boolean(control.value) ? control.value.length : 0;
		return `${textLength} / ${this.limit} characters`;
	}
}
