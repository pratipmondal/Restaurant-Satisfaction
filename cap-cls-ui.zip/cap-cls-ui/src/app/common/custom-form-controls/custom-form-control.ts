import { FormControl } from '@angular/forms';
export class CustomFormControl extends FormControl {
    label: string = '';
    type: string = '';
}
