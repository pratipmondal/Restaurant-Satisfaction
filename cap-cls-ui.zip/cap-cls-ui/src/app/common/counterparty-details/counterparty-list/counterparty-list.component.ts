import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { ErrorResponse } from 'app/shared';
import { Observable } from 'rxjs/Observable';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';

@Component({
	selector: 'cp-list',
	templateUrl: 'counterparty-list.component.html',
	styleUrls: ['./counterparty-list.component.scss']
})
export class CounterPartyListComponent implements OnInit {
	@Input()
	public searchData: Array<any> = [];
	@Input()
	public searchParam: string = '';
	@Input()
	public groupView: boolean[];
	@Output()
	public onCPSelect: EventEmitter<any> = new EventEmitter<any>();
	public pluralMappings: Map<String, String> = new Map<String, String>();

	constructor(private counterPartyDetailsService: CounterPartyDetailsService, private router: Router) {
	}

	ngOnInit() {
		this.pluralMappings.set('COUNTERPARTY', 'Counterparties');
		this.pluralMappings.set('DOA', 'DOAs');
		this.pluralMappings.set('COUNTRY', 'Countries');
		this.pluralMappings.set('MAS639 GROUP', 'MAS639 Groups');
		// this.counterPartyDetailsService.subscribeToCPDetails({
		//           next: (value) => console.log(value),
		//           error: (value) => console.log(value),
		//           complete: () => { }
		//     });
	}

	private getViewText(index: number): string {
		const length = this.searchData[index].topSearchResult.length;
		let groups = this.searchData[index].groupLabel;
		if (length < 3) {
			return '';
		}
		if (this.pluralMappings.has(groups)) {
			groups = this.pluralMappings.get(groups);
		}
		return `View All (${length}) ${groups}`;
	}

	private isViewall(index: number): boolean {
		return this.groupView[index];
	}

	public onViewAll(index: number) {
		this.groupView.fill(true, index, index + 1);
	}

	private onCounterPartySelect(cp: any) {
		this.counterPartyDetailsService.publicCounterPartyDetails(cp);
		this.onCPSelect.emit(cp);
		this.router.navigate(['/collateral'])
	}

}
