import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject, Observer } from 'rxjs';

@Injectable()
export class CounterPartyDetailsService {
	cpDetailsObservable: BehaviorSubject<any>;

	constructor() {
		this.cpDetailsObservable = new BehaviorSubject({
			'label': 'Personal Leadership Centre Pte.Ltd',
			'value': 'GCIN0000000'
		});
	}

	public subscribeToCPDetails(listner: Observer<any>) {
		this.cpDetailsObservable.subscribe(listner);
	}

	public publicCounterPartyDetails(cp: any) {
		this.cpDetailsObservable.next(cp);
	}

}
