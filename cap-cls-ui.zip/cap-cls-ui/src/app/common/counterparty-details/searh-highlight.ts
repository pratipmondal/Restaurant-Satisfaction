import { PipeTransform, Pipe } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({ name: 'highlight' })
export class HighLightPipe implements PipeTransform {
  constructor(private sanitized: DomSanitizer) { }
  transform(text: string, search) {
    const regex: RegExp = new RegExp(search, 'gi');
    let result = [];
    result = regex.exec(text);
    if ( !result ) {
      return text;
    }
    result = Array.from(new Set(result.map((itemInArray) => itemInArray)));
    result.forEach(value => {
      text = text.replace(new RegExp(value, 'gi'), `<span class="cp-desp" style="font-family.: OpenSans;font-weight:bold;font-size=14px;color:black;">${value}</span>`);
    });
    return this.sanitized.bypassSecurityTrustHtml(text);
  }
}
