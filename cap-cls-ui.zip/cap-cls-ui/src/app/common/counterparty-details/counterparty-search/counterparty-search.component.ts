import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { ErrorResponse } from 'app/shared';
import { Observable } from 'rxjs/Observable';

import { environment } from '../../../../environments/environment';

@Component({
	selector: 'cp-search',
	templateUrl: 'counterparty-search.component.html',
	styleUrls: ['./counterparty-search.component.scss']
})
export class CounterPartySearchComponent implements OnInit {
	public searchData: Array<any>[] = [];
	public groupView: Array<boolean> = [];
	public showList: Boolean = false;
	public searchText = '';

	constructor(private http: Http) {
	}

	ngOnInit() {
	}

	getCounterPartyDetails(): any {

	}

	onCancel() {
		this.searchData = [];
		this.groupView = [];
		this.showList = false;
		this.searchText = '';
	}

	public onCounterPartySelect(cp: any) {
		this.onCancel();
	}

	onSearchChnage(search: any) {
		if (search.value.length < 3) {
			this.showList = false;
			return;
		}
		// this.searchText = search.value;
		const searchKeyword = {'searchKeyword': search.value};
		const url = environment.apiBaseUrl + environment.apientitysearch;
		this.http.post(url, searchKeyword)
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error)).subscribe(data => {
				this.searchData = data.searchResult.searchResults;
				this.searchData.forEach(element => {
					this.groupView.push(false);
					this.showList = true;
				}, this);
			},
			error => {
			}
		);
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	errorResponseFunction(error: any) {
		const ErrorResponse = <ErrorResponse>error;
		return Observable.throw(<ErrorResponse>ErrorResponse);
	}
}
