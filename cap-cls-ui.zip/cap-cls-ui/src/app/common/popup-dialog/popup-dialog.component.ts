import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
	selector: 'cls-popup-dialog',
	templateUrl: './popup-dialog.component.html',
	styleUrls: ['./popup-dialog.component.scss']
})
export class PopupDialogComponent implements OnInit {

	public opened: boolean;

	@Output()
	argFromClosePopupDialogPopup: EventEmitter<any> = new EventEmitter<any>();
	@Input()
	argFromParent: any;
	@Input()
	dialogTitle: string;

	constructor() {
	}

	ngOnInit() {
	}

	ngOnChanges(changes: SimpleChanges) {
		if (changes['argFromParent']) {
			this.opened = true;
		}
	}

	public close(status) {
		this.argFromClosePopupDialogPopup.emit(false);
		this.opened = false;
	}

	public cancelForm() {
		this.opened = false;
	}

}
