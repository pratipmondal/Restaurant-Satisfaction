import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PopupDialogComponent } from './popup-dialog.component';
import { DialogModule } from '@progress/kendo-angular-dialog';

describe('PopupDialogComponent', () => {
	let component: PopupDialogComponent;
	let fixture: ComponentFixture<PopupDialogComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [DialogModule],
			declarations: [PopupDialogComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(PopupDialogComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('PopDialog box should be close  onclick of close  button',
		async(() => {
			fixture.detectChanges();
			component.opened = true;
			component.close(false);
			expect(component.opened).toBe(false);
		}));
});
