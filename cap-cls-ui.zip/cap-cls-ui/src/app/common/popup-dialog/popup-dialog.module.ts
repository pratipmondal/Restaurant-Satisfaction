import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopupDialogComponent } from './popup-dialog.component';
import { BrowserModule } from '@angular/platform-browser';
import { DialogModule } from '@progress/kendo-angular-dialog';

@NgModule({
	imports: [
		CommonModule, BrowserModule, DialogModule
	],
	declarations: [PopupDialogComponent],
	exports: [PopupDialogComponent]
})
export class PopupDialogModule {
}
