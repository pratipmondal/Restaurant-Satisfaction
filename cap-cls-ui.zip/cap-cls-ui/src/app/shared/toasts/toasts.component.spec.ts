import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';

import { ToastsComponent } from './toasts.component';

describe('ToastsComponent', () => {
	let component: ToastsComponent;
	let fixture: ComponentFixture<ToastsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [RouterTestingModule],
			declarations: [ToastsComponent]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ToastsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();

		component.toastMessageObject = {
			type: 'Warning',
			message: '<strong>Message!</strong> This is a message.',
			linkUrl: '/link-url',
			linkText: 'Link'
		};
		component.toastMessageObject['type'] = 'warning';

		component.showToast();
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('Toast type', () => {
		component.toastMessageObject = {
			type: 'Warning',
			message: '<strong>Message!</strong> This is a message.',
			linkUrl: '/link-url',
			linkText: 'Link'
		};
		spyOn(component, 'showToast');
		expect(component.toastType).toBe('warning');
	});
	it('Toast showing', () => {
		expect(component.toastOpen).toBeTruthy();
	});
	it('Toast message', () => {
		let msg = fixture.debugElement.query(By.css('.toast__msg'));
		expect(msg.nativeElement.textContent).toBe('Message! This is a message.');
	});
	it('Has link', () => {
		expect(component.isHaveLink).toBeTruthy();
	});
	it('Toast link URL', () => {
		expect(component.toastLinkUrl).toBe('/link-url');
	});
	/*it('Toast link text', () => {
	 let linktxt = fixture.debugElement.query(By.css('.toast__link'));
	 console.log('linktxt' + linktxt);
	 expect(linktxt.nativeElement.textContent).toBe('Link');
	 });*/
	it('Toast close click', () => {
		let close = fixture.debugElement.query(By.css('.toast__close'));
		close.triggerEventHandler('click', 'close');
		expect(component.toastOpen).toBeFalsy();
		expect(component.toastMessage).toBe('');
	});
});
