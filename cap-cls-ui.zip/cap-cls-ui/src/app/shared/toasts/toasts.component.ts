import { Component, Input, OnInit, SimpleChanges } from '@angular/core';

@Component({
	selector: 'toasts-message',
	templateUrl: './toasts.component.html',
	styleUrls: ['./toasts.component.scss']
})
export class ToastsComponent implements OnInit {

	@Input() toastMessageObject: any = [];
	@Input() selfCloseTimeOut: number = 3000;

	toastOpen: boolean = false;
	toastWarning: boolean = false;
	toastError: boolean = false;
	toastSuccess: boolean = false;
	isHaveLink: boolean = false;
	toastMessage: string;
	toastLinkUrl: string;
	toastLinkText: string;
	toastType: string;

	constructor() {
	}

	ngOnInit() {

	}

	ngOnChanges(changes: SimpleChanges) {

		if (!(typeof this.toastMessageObject === 'undefined')) {
			this.showToast();

			setTimeout(function () {
				this.toastOpen = false;
			}.bind(this), this.selfCloseTimeOut);

		}

	}

	showToast(): void {

		if (typeof this.toastMessageObject !== 'undefined') {
			this.toastType = this.toastMessageObject['type'];
			switch (this.toastType) {
				case 'error': {
					this.toastError = true;
					this.toastOpen = true;
					break;
				}
				case 'success': {
					this.toastSuccess = true;
					this.toastOpen = true;
					break;
				}
				case 'warning': {
					this.toastWarning = true;
					this.toastOpen = true;
					break;
				}
				default: {
					this.toastClose();
					break;
				}
			}

			this.toastMessage = this.toastMessageObject['message'];
			if (typeof this.toastMessageObject['linkUrl'] != 'undefined') {
				this.isHaveLink = true;
				this.toastLinkUrl = this.toastMessageObject['linkUrl'];
				this.toastLinkText = this.toastMessageObject['linkText'];
			}
		}
	}

	toastClose(): any {
		this.toastOpen = false;
		this.toastWarning = false;
		this.toastError = false;
		this.toastSuccess = false;
		this.isHaveLink = false;
		this.toastMessage = '';
		this.toastLinkUrl = '';
		this.toastLinkText = '';
		this.toastType = '';
	}

	buildToastMessageObject(toastType: string, toastMsgBody: string, toastLinkURL: string, toastLinkText: string): any {
		return {
			'type': toastType,
			'message': toastMsgBody,
			'linkUrl': toastLinkURL,
			'linkText': toastLinkText
		};
	}

}
