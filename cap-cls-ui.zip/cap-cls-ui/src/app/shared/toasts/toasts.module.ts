import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ToastsComponent } from './toasts.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule
    ],
    declarations: [ToastsComponent],
    exports: [ToastsComponent]
})
export class ToastsModule {
}
