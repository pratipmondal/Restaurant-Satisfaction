import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { YesNoPromptComponent } from './yesno.component';

describe('Component : YesNoPromptComponent  ', () => {
	let component: YesNoPromptComponent;
	let fixture: ComponentFixture<YesNoPromptComponent>;
	var testPayload = [];

	beforeEach(async(() => {
		TestBed.configureTestingModule({

			imports: [CommonModule, BrowserModule, DialogModule, ButtonsModule, BrowserAnimationsModule],
			declarations: [YesNoPromptComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(YesNoPromptComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create ', () => {
		expect(component).toBeTruthy();
	});

	it('should render prompt text', async(() => {
		//console.log(' inside render test');
		fixture.detectChanges();
		let compiled = fixture.debugElement.nativeElement;
		//console.log(compiled.querySelector('p').textContent);
		expect(compiled.querySelector('p').textContent).toContain('Are you sure you want to continue?');
	}));

	it(' Close method should works    ', () => {
		testPayload.push({'DLG_STATUS': 'no'});
		component.payLoad = testPayload;
		component.close('no');
		expect(!component.opened).toBeTruthy();
	});

	it('should emit event for NO', (done) => {
		let comp = new YesNoPromptComponent();
		comp.argFromYesNoComp.subscribe(g => {
			expect(g).toEqual([{'DLG_STATUS': 'no'}]);
			done();
		});
		testPayload.length = 0;

		comp.payLoad = testPayload;
		comp.close('no');  // this function emits
	});

	it('should emit event for Yes', (done) => {
		let comp = new YesNoPromptComponent();
		comp.argFromYesNoComp.subscribe(g => {
			expect(g).toEqual([{'DLG_STATUS': 'yes'}]);
			done();
		});
		testPayload.length = 0;

		comp.payLoad = testPayload;
		comp.close('yes');  // this function emits
	});

	it('should emit event for Cancel', (done) => {
		let comp = new YesNoPromptComponent();
		comp.argFromYesNoComp.subscribe(g => {
			expect(g).toEqual([{'DLG_STATUS': 'cancel'}]);
			done();
		});
		testPayload.length = 0;

		comp.payLoad = testPayload;
		comp.close('cancel');  // this function emts
	});

});
