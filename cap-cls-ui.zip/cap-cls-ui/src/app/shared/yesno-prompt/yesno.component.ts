import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
    selector: 'yesno-prompt',
    templateUrl: './yesno.component.html',
    styleUrls: [ './yesno.component.scss' ]
})
export class YesNoPromptComponent implements OnInit {

    @Input() argfromParent: any;
    @Output() argFromYesNoComp: EventEmitter<any> = new EventEmitter<any>();

    public opened: boolean = true;
    public showDialog: boolean = false;
    public payLoad: any[];

    constructor() {
    }

    public close( status ) {
        //console.log(`Dialog result: ${status}`);
        this.opened = false;
        this.payLoad.push({'DLG_STATUS': status});
        //console.log('This is from close ..' + this.payLoad);
        //console.log(this.payLoad);
        this.argFromYesNoComp.emit(this.payLoad);

    }

    public open() {
        this.opened = true;
    }

    ngOnInit() {
        //console.log('inside init of yesno prompt')
    }

    recieveDataFromParent( argIn: any ) {

        //console.log('inside recieveDataFromParent of yesno prompt')
        //console.log(argIn);
        this.payLoad = argIn;
        //console.log(this.payLoad[ 0 ]);

    }

    ngOnChanges( changes: SimpleChanges ) {
        if (changes[ 'argfromParent' ]) {
            //console.log('Value changes to ===> ' + this.argfromParent);
            this.recieveDataFromParent(this.argfromParent);
            this.showDialog = true;

        }
    }
}