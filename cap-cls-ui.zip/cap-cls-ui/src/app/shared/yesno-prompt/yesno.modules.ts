import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';


import { YesNoPromptComponent } from './yesno.component';

@NgModule({
    imports: [ CommonModule, BrowserModule, DialogModule, ButtonsModule ],
    declarations: [ YesNoPromptComponent ],
    exports: [ YesNoPromptComponent ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class YesNoPromptModule {
}
