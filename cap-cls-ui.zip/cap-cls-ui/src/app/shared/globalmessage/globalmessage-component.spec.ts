import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { LoaderModule } from '../progression/loader/loader.module';
import { GlobalMessageComponent } from './globalmessage-component';

describe('Component : GlobalMessageComponent : ', () => {
    let component: GlobalMessageComponent;
    let fixture: ComponentFixture<GlobalMessageComponent>;
    var testAlertObj = [];

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ CommonModule, BrowserModule, LoaderModule, DialogModule, ButtonsModule ],
            declarations: [ GlobalMessageComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GlobalMessageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should display meesage passed in for success', () => {
        testAlertObj.length = 0;
        testAlertObj.push('[{\'msg_type\' : \'SUCCESS\'}]');
        testAlertObj.push('[{\'msg_body\' : \'SUCCESS_MSG_BODY\'}]');
        component.alertObject = testAlertObj;
        fixture.detectChanges();
        expect(component.ShowSuccessMessage).toBeFalsy();

    });

    it('should display meesage passed in for Failure', () => {
        testAlertObj.length = 0;
        testAlertObj.push('[{\'msg_type\' : \'FAILURE\'}]');
        testAlertObj.push('[{\'msg_body\' : \'FAILURE_MSG_BODY\'}]');
        component.alertObject = testAlertObj;
        fixture.detectChanges();
        expect(component.ShowErrorMessage).toBeFalsy();

    });
});
