import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

import { LoaderModule } from '../progression/loader/loader.module';
import { GlobalMessageComponent } from './globalmessage-component';

@NgModule({
    imports: [ CommonModule, BrowserModule, LoaderModule, DialogModule, ButtonsModule,
    ],
    declarations: [ GlobalMessageComponent ],
    exports: [ GlobalMessageComponent ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class GlobalMessageModule {
}
