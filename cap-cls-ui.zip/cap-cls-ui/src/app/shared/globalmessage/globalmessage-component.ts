import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';


@Component({
    selector: 'global-message',
    templateUrl: './globalmessage-component.html',
    styleUrls: [ './globalmessage-component.scss' ]
})
export class GlobalMessageComponent implements OnInit {
    @Input() alertObject: any[];
    @Output() argFromGlobalMessageComp: EventEmitter<any> = new EventEmitter<any>();


    ShowSuccessMessage: boolean = false;
    ShowErrorMessage: boolean = false;
    MessageBody: string[];
    backgroundColor: string;
    public tempArray: any[];
    showGlobalMessageDiv: boolean = false;

    constructor() {
    }

    public opened: boolean = true;

    public close( status ) {
        this.showGlobalMessageDiv = false;
        this.opened = false;
        this.argFromGlobalMessageComp.emit(status);
    }


    public open() {
        this.opened = true;
    }

    ngOnInit() {

    }

    ngOnChanges( changes: SimpleChanges ) {
        if (changes[ 'alertObject' ]) {
            this.showGlobalMessage();
        }
    }

    showGlobalMessage() {
        if (typeof this.alertObject !== 'undefined') {
            this.showGlobalMessageDiv = true;
            if (this.alertObject[ 'msg_type' ] === 'SUCCESS') {
                this.ShowSuccessMessage = true;
                this.ShowErrorMessage = false;
            }
            else {
                this.ShowErrorMessage = true;
                this.ShowSuccessMessage = false;
            }
            this.MessageBody = this.alertObject[ 'msg_body' ];
        }
    }
}