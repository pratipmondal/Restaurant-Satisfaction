export * from './globalmessage-component';
