import { NgModule } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { GlobalMessageComponent } from './globalmessage/';
import { YesNoPromptComponent } from './yesno-prompt/yesno.component';
import { FileUploaderModule } from '../reference-data/file-uploader/';
import { ClsSharedLibsModule } from './';
import { CurrencyFormatModule } from '../shared/currency-pipe/currency-pipe.module';
import { NoRecordComponent }  from './no-record-found/no-record.component';
import { ToastsComponent }  from './toasts/toasts.component';

@NgModule({
    imports: [
        ClsSharedLibsModule, FileUploaderModule
    ],
    declarations: [
        GlobalMessageComponent, YesNoPromptComponent, NoRecordComponent,ToastsComponent
    ],
    providers: [
        Title
    ],
    exports: [
        ClsSharedLibsModule, FileUploaderModule, GlobalMessageComponent, 
        YesNoPromptComponent,CurrencyFormatModule, NoRecordComponent, ToastsComponent
    ]
})
export class ClsSharedCommonModule {
}
