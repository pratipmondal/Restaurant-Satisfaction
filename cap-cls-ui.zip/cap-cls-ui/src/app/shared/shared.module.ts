import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';

import { ClsSharedCommonModule, ClsSharedLibsModule, Principal, TokenServerProvider } from './';

@NgModule({
    imports: [
        ClsSharedLibsModule,
        ClsSharedCommonModule,
    ],
    declarations: [],
    providers: [
        Principal,
        TokenServerProvider,
        DatePipe
    ],
    exports: [
        ClsSharedCommonModule,
        DatePipe
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]

})
export class ClsSharedModule {
}
