import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { LoaderComponent } from './loader.component';
@NgModule({
    imports: [ CommonModule, BrowserModule ],
    declarations: [ LoaderComponent ],
    exports: [ LoaderComponent ]
})
export class LoaderModule {
    // public static forRoot(): ModuleWithProviders {
    //     return {ngModule: LoaderModule, providers: []};
    // }
}
