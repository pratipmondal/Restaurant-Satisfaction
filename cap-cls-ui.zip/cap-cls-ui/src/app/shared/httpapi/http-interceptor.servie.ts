import { Injectable } from '@angular/core';
import { ConnectionBackend, Headers, Http, Request, RequestOptions, RequestOptionsArgs, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import { OAuthService } from 'angular-oauth2-oidc';

@Injectable()
export class HttpInterceptor extends Http {
    oAuthServ: OAuthService;

    constructor( backend: ConnectionBackend, defaultoptions: RequestOptions ) {
        super(backend, defaultoptions);
    }

    request( url: string | Request, options: RequestOptionsArgs ): Observable<Response> {
        return super.request(url, this.setOptions(options, url));
    }

    get( url: string, options: RequestOptionsArgs ): Observable<Response> {
        return super.get(url, this.setOptions(options, url));
    }

    post( url: string, body: any, options: RequestOptionsArgs ): Observable<Response> {
        return super.post(url, body, this.setOptions(options, url));
    }

    put( url: string, body: any, options: RequestOptionsArgs ): Observable<Response> {
        return super.put(url, body, this.setOptions(options, url));
    }

    private setOptions( options: RequestOptionsArgs, url ) {
        options = options || {};
        //set authorization header
        if (!options.headers) {
            options.headers = new Headers();
        }
        options.headers.append('Authorization', this.getAccessToken());
        return options;
    }

    private getAccessToken() {
        return 'Bearer ' + sessionStorage.getItem('access_token');
    }
}
