import { async, getTestBed, inject, TestBed } from '@angular/core/testing';
import {
    BaseRequestOptions,
    Http,
    HttpModule,
    RequestMethod,
    Response,
    ResponseOptions,
    XHRBackend
} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { SeqGenService } from './seq-gen.service';
import { RouterTestingModule } from '@angular/router/testing';
import { SEQ_GEN_CONFIG, SeqGenConfig } from '../../sequence-generator/sequence-generator.config';
import { environment } from '../../../environments/environment';
import { ErrorResponse } from '../../shared';

describe('SeqGenService (Mocked)', () => {
    let mockBackend: MockBackend;
    let _seqGenService: SeqGenService;
    let validSeqGenerator: any;
    let validPrefixSuffixType: any;
    let validPrefixSuffixCode: any;
    let validUiMetaModel: any;

    function setApiResponse( caseUrl: string, responseBody: any ) {
        mockBackend.connections.subscribe(
            ( connection: MockConnection ) => {
                expect(caseUrl).toMatch(connection.request.url);
                connection.mockRespond(
                    new Response(
                        new ResponseOptions({
                            body: responseBody,
                        }))
                );
            }
        );
    }

    function setApiResponseError( caseUrl: string ) {
        mockBackend.connections.subscribe(
            ( connection: MockConnection ) => {
                expect(caseUrl).toMatch(connection.request.url);
                connection.mockError(new Error('Service Not Available'));
            }
        );
    }

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                SeqGenService,
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: ( backend: XHRBackend, defaultOptions: BaseRequestOptions ) => new Http(backend, defaultOptions),
                    deps: [ MockBackend, BaseRequestOptions ]
                },
                {provide: SEQ_GEN_CONFIG, useValue: SeqGenConfig}
            ],
            imports: [
                HttpModule,
                RouterTestingModule
            ]
        });
        mockBackend = getTestBed().get(MockBackend);
        _seqGenService = TestBed.get(SeqGenService);
        TestBed.compileComponents();

        validSeqGenerator = {
            'sequenceType': 'Limit',
            'sequenceCode': 'LIMIT',
            'startNum': 1,
            'endNum': 8888888,
            'zeroFill': 'Y',
            'fieldLength': 12,
            'prefixSuffixGrid': [
                {
                    'prefixSuffix': 'P',
                    'prefixSuffixType': 'UD',
                    'userDefinedValue': 'LIM',
                    'from': 1,
                    'to': 3,
                    'newSeries': 'N',
                    '_isDeleted': false
                }
            ],
            'id': '58d345645d848b0600e0825e',
            '_type': 'Nntm',
            '_createdBy': 'upload',
            '_modifiedBy': 'user3',
            '_createdOn': '2017-03-23T03:47:47.995Z',
            '_modifiedOn': '2017-03-28T01:02:30.507Z',
            '_version': '606f0449-55f6-428a-83a1-f42406eb7c72',
            '_isDeleted': false
        };

        validPrefixSuffixType = {
            'code': 'TK',
            'description': 'Tokiyo',
            'id': '58e49d3d53fdaf07006aa1e2',
            '_type': 'PrefixSuffixType',
            '_createdBy': 'demoadmin',
            '_modifiedBy': 'demoadmin',
            '_createdOn': '2017-04-05T07:31:09.757Z',
            '_modifiedOn': '2017-04-05T07:31:09.757Z',
            '_version': 'f5547e98-9adf-4b31-9868-334992d165bf',
            '_isDeleted': false
        };


        validPrefixSuffixCode = {
            'code': 'WRT',
            'description': 'WRT',
            'parentRefType': '',
            'parentRefCode': '',
            'id': '58e3985453fdaf07006a1f65',
            '_type': 'PrefixSuffixCode',
            '_createdBy': 'demoadmin',
            '_modifiedBy': 'demoadmin',
            '_createdOn': '2017-04-04T12:57:56.209Z',
            '_modifiedOn': '2017-04-04T12:57:56.209Z',
            '_version': '03943f26-dee9-4935-b88b-2d36bd2e3820',
            '_isDeleted': false
        };

        validUiMetaModel = {
            componentName: 'Sequence-Generator',
            elements: null,
            modelName: 'modelName',
            modelAlias: 'modelAlias',
            metadata: null,
            autoInjectFields: false
        };

    });


    afterEach(() => {
        _seqGenService = null;
        mockBackend = null;
    });

    it('should construct Service', async(inject(
        [ SeqGenService, MockBackend ], ( service ) => {
            expect(service).toBeDefined();
        })));


    it('should getPrefixSuffixTypes() get Prefix Suffix Types', async(() => {
        let _seqGenService: SeqGenService = TestBed.get(SeqGenService);
        setApiResponse(environment.apiBaseUrl + 'prefix-suffix-type', validPrefixSuffixType);
        _seqGenService.getPrefixSuffixTypes().subscribe(
            ( PrefixSuffixGrid ) => {
                expect(PrefixSuffixGrid.code).toBe('TK');
                expect(PrefixSuffixGrid._type).toBe('PrefixSuffixType');
            },
        );
    }));

    it('should getPrefixSuffixTypes() throw Error when Service unvailable', async(() => {
        setApiResponseError(environment.apiBaseUrl + 'prefix-suffix-type');
        _seqGenService.getPrefixSuffixTypes().subscribe(
            ( data ) => {
                expect(data).toBeUndefined();
            },
            ( error ) => {
                this.errorResponse = <ErrorResponse>error;
                expect(this.errorResponse.message).toBe('Service Not Available');
            }
        );
    }));

    it('should getPrefixSuffixCodes get prefix Suffix Codes', async(() => {
        let _seqGenService: SeqGenService = TestBed.get(SeqGenService);
        setApiResponse(environment.apiBaseUrl + 'prefix-suffix-code', validPrefixSuffixCode);
        _seqGenService.getPrefixSuffixCodes().subscribe(
            ( PrefixSuffixGrid ) => {
                expect(PrefixSuffixGrid.code).toBe('WRT');
                expect(PrefixSuffixGrid._type).toBe('PrefixSuffixCode');
            }
        );
    }));

    it('should getPrefixSuffixCodes() throw Error when Service unvailable', async(() => {
        setApiResponseError(environment.apiBaseUrl + 'prefix-suffix-code');
        _seqGenService.getPrefixSuffixCodes().subscribe(
            ( data ) => {
                expect(data).toBeUndefined();
            },
            ( error ) => {
                this.errorResponse = <ErrorResponse>error;
                expect(this.errorResponse.message).toBe('Service Not Available');
            }
        );
    }));

    it('should getSequence() get sequence', async(() => {
        setApiResponse(environment.apiBaseUrl + 'sequence', validSeqGenerator);
        _seqGenService.getSequence().subscribe(
            (( resp ) => {
                expect(resp.sequenceType).toBe('Limit');
                expect(resp.sequenceCode).toBe('LIMIT');
            }));

    }));

    it('should getSequence()  throw Error when Service unvailable', async(() => {
        setApiResponseError(environment.apiBaseUrl + 'sequence');
        _seqGenService.getSequence().subscribe(
            ( data ) => {
                expect(data).toBeUndefined();
            },
            ( error ) => {
                this.errorResponse = <ErrorResponse>error;
                expect(this.errorResponse.message).toBe('Service Not Available');
            }
        );
    }));


    it('should getUiMetaModel() get uiMetaModel', async(() => {
        setApiResponse(environment.apiBaseUrl + 'UIComponent/modelmeta/sequence-generator', validUiMetaModel);
        _seqGenService.getUiMetaModel().subscribe(
            (( resp ) => {
                expect(resp.componentName).toBe('Sequence-Generator');
                expect(resp.autoInjectFields).toBe(false);
            }));

    }));

    it('should getUiMetaModel() throw Error when Service unvailable', async(() => {
        setApiResponseError(environment.apiBaseUrl + 'UIComponent/modelmeta/sequence-generator');
        _seqGenService.getUiMetaModel().subscribe(
            ( data ) => {
                expect(data).toBeUndefined();
            },
            ( error ) => {
                this.errorResponse = <ErrorResponse>error;
                expect(this.errorResponse.message).toBe('Service Not Available');
            }
        );
    }));


    it('should addSequence() calls the backend to save the Sequence', async(() => {
        mockBackend.connections.subscribe(( connection: MockConnection ) => {
            expect(connection.request.method).toBe(RequestMethod.Post);
            expect(connection.request.getBody()).toContain('prefixSuffixGrid');
        });
        _seqGenService.addSequence(validSeqGenerator)
            .subscribe(( res ) => {
                expect(res.status).toEqual(201);
                expect(res.sequenceType).toBe('Limit');
            });

    }));

    it('should addSequence() throw Error when Service unvailable', async(() => {
        setApiResponseError(environment.apiBaseUrl + 'sequence');
        _seqGenService.addSequence({}).subscribe(
            ( data ) => {
                expect(data).toBeUndefined();
            },
            ( error ) => {
                this.errorResponse = <ErrorResponse>error;
                expect(this.errorResponse.message).toBe('Service Not Available');
            }
        );
    }));

    it('should updateSequence() calls the backend to update the Sequence', async(() => {
        mockBackend.connections.subscribe(( connection: MockConnection ) => {
            expect(connection.request.method).toBe(RequestMethod.Put);
            expect(connection.request.getBody()).toContain('prefixSuffixGrid');
        });
        _seqGenService.updateSequence(validSeqGenerator)
            .subscribe(( res ) => {
                expect(res.status).toEqual(200);
                expect(res.sequenceType).toBe('Limit');
            });

    }));

    it('should updateSequence()  throw Error when Service unvailable', async(() => {
        setApiResponseError(environment.apiBaseUrl + 'sequence');
        _seqGenService.updateSequence({}).subscribe(
            ( data ) => {
                expect(data).toBeUndefined();
            },
            ( error ) => {
                this.errorResponse = <ErrorResponse>error;
                expect(this.errorResponse.message).toBe('Service Not Available');
            }
        );
    }));
});


