import { Inject, Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { ErrorResponse } from '../../shared';
import { SEQ_GEN_CONFIG } from '../../sequence-generator/sequence-generator.config';
import { SQConfig } from '../../sequence-generator/model/sequence-configmodel';

@Injectable()
export class SeqGenService {

    constructor( @Inject(Http) private http: Http,
                 @Inject(SEQ_GEN_CONFIG) private config: SQConfig ) {
    }

    getToken() {
        return localStorage.getItem('accesstoken');
    }

    errorResponseFunction( error: any ) {
        const ErrorResponse = <ErrorResponse>error;
        return Observable.throw(<ErrorResponse>ErrorResponse);
    }

    getUiMetaModel(): Observable<any> {
        return this.http.get(this.config.uiMeta)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));

        function onSuccessSuccess( resp: Response ) {
            return (resp.json());
        }
    }

    addSequence( sequence: any ): Observable<any> {
        return this.http.post(this.config.sequence, sequence)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));
        function onSuccessSuccess( resp: Response ) {
            return (resp.json());
        }
    }

    updateSequence( sequence: any ): Observable<any> {
        return this.http.put(this.config.sequence, sequence)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));
        function onSuccessSuccess( resp: Response ) {
            return (resp.json());
        }
    }


    getSequence( filter?: any ): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        params.set('filter', JSON.stringify(filter));
        return this.http.get(this.config.sequence, {
            'search': params
        })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));
        ;

        function onSuccessSuccess( resp: Response ) {
            return (resp.json());
        }
    }

    getPrefixSuffixCodes( filter?: any ): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(this.config.prefixSuffixCodes, {
            'search': params
        })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));
        ;

        function onSuccessSuccess( resp: Response ) {
            return (resp.json());
        }
    }

    getPrefixSuffixTypes( filter?: any ): Observable<any> {
        const params: URLSearchParams = new URLSearchParams();
        if (filter) {
            params.set('filter', JSON.stringify(filter));
        }
        return this.http.get(this.config.prefixSuffixTypes, {
            'search': params
        })
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));
        ;

        function onSuccessSuccess( resp: Response ) {
            return (resp.json());
        }
    }

    getSequenceTypes(): Observable<any> {
        return this.http.get(this.config.sequenceTypes)
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));
        function onSuccessSuccess( resp: Response ) {
            return (resp.json());
        }
    }

}
