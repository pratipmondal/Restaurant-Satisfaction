import { Inject, Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { Account } from '../user/account.model';
import { SEQ_GEN_CONFIG } from '../../sequence-generator/sequence-generator.config';
import { SQConfig } from '../../sequence-generator/model/sequence-configmodel';

@Injectable()
export class TokenServerProvider {
    private account: Account;

    constructor( private http: Http,
                 @Inject(SEQ_GEN_CONFIG) private config: SQConfig ) {
    }

    getToken() {
        return localStorage.getItem('accesstoken');
    }

    login( credentials ): Observable<any> {
        if (this.getToken() !== null) {
            return Observable.create(() => {
                return this.account;
            });
        }
        const data = {
            username: credentials.username,
            password: credentials.password
        };
        return this.http.post(this.config.login, data).map(authenticateSuccess.bind(this));

        function authenticateSuccess( resp: Response ) {
            this.account = <Account>(resp.json());
            this.storeaccesstoken(this.account.id);
            this.storeaccount(this.account);
            return this.account;
        }
    }

    storeaccesstoken( accesstoken ) {
        localStorage.setItem('accesstoken', accesstoken);
    }

    storeaccount( account ) {
        localStorage.setItem('account', account);
    }

    logout(): Observable<any> {
        return new Observable(observer => {
            localStorage.removeItem('accesstoken');
            localStorage.removeItem('account');
            observer.complete();
        });
    }
}
