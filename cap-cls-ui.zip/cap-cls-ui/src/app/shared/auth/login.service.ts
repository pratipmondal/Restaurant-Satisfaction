import { Injectable } from '@angular/core';

import { Principal, TokenServerProvider } from '../../shared';

@Injectable()
export class LoginService {

    constructor( private principal: Principal,
                 private tokenServerProvider: TokenServerProvider ) {
    }

    login( credentials, callback? ) {
        let cb = callback || function () {
            };

        return new Promise(( resolve, reject ) => {
            this.tokenServerProvider.login(credentials).subscribe(data => {
                this.principal.authenticate(data);
                resolve(data);
                return cb();
            }, err => {
                this.logout();
                reject(err);
                return cb(err);
            });
        });
    }

    logout() {
        this.tokenServerProvider.logout().subscribe();
        this.principal.authenticate(null);
    }
}
