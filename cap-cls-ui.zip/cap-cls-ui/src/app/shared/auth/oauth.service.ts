import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { OAuthService } from 'angular-oauth2-oidc';
import { environment } from '../../../environments/environment';


@Injectable()
export class OauthService {
    private static loginUrl = environment.oauthUrl; // Id-Provider?
    private static clientId = environment.clientid;
    private static oidc = false;
    private static issuer = environment.oauthIssuer;
    userLoggedIn = new ReplaySubject(); // publisher
    userLoggedIn$ = this.userLoggedIn.asObservable();   // subscriber


    constructor( private http: Http, private oauthService: OAuthService ) {
        this.oauthService.loginUrl = OauthService.loginUrl;
        this.oauthService.redirectUri = window.location.origin;
        this.oauthService.clientId = OauthService.clientId;
        this.oauthService.oidc = OauthService.oidc;
        this.oauthService.setStorage(sessionStorage);
        this.oauthService.issuer = OauthService.issuer;
        // TODO: use when logout is implemented
        // this.oauthService.logoutUrl = "https://*/endsession?id_token={{id_token}}";
    }

    public triggerOAuth( redirectUrl: string ): Observable<any> {
        if (this.isAuthInitiated()) {
            return;
        }
        this.oauthService.redirectUri = window.location.origin + redirectUrl;
        sessionStorage.setItem('AuthInitiated', 'true');
        this.oauthService.initImplicitFlow();

    }

    public tryLogin(): Observable<any> {
        this.oauthService.tryLogin({});
        if (this.oauthService.getAccessToken() !== null) {
            sessionStorage.removeItem('AuthInitiated');
            sessionStorage.setItem('IsAuthorized', 'true');
            this.getUserInfo();
            return this.userLoggedIn$;
        } else {
            return this.userLoggedIn$;
        }
    }

    checkUserLoggedIn() {
        /*if (sessionStorage.getItem('AuthInitiated') === 'true') {
            this.oauthService.tryLogin({});
            if (this.oauthService.getAccessToken() !== null) {
                sessionStorage.removeItem('AuthInitiated');
                sessionStorage.setItem('IsAuthorized', 'true');
                this.getUserInfo();
                return true;
            } else {
                return false;
            }
        } else {
            if (sessionStorage.getItem('IsAuthorized') === 'true') {
                this.getUserInfo();
                return true;
            } else {
                return false;
            }
        }*/
      return true;
      //}
    }

    getUserInfo() {
        setTimeout(() => {
            const user = {
                name: 'JUNDENG'
            };
            this.userLoggedIn.next(user);
        });
    }

    logout() {
        this.userLoggedIn.next(false);
        this.oauthService.logOut();
        sessionStorage.removeItem('AuthInitiated');
        sessionStorage.removeItem('IsAuthorized');
    }

    isAuthInitiated() {
        //return sessionStorage.getItem('AuthInitiated') === 'true';
        return true;
    }

    isAuthorized() {
        //return sessionStorage.getItem('IsAuthorized') === 'true';
        return true;
    }
}