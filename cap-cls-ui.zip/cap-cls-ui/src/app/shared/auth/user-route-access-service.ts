import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { OauthService } from '../';

@Injectable()
export class UserRouteAccessService implements CanActivate {

    constructor( private router: Router, private oauthService: OauthService ) {
    }

    canActivate( route: ActivatedRouteSnapshot, state: RouterStateSnapshot ) {
        if (this.oauthService.isAuthorized()) {
            return true;
        }
        this.oauthService.triggerOAuth(state.url);
        return this.oauthService.tryLogin().map(e => {
            if (e) {
                return true;
            }
        }).catch(() => {
            this.router.navigate([ '/login' ]);
            return Observable.of(false);
        });
    }
}
