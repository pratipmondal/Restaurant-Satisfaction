import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CurrencyFormatPipe } from './currency-pipe';
import { isUndefined } from 'util';
import createSpy = jasmine.createSpy;
import createSpyObj = jasmine.createSpyObj;

describe('CurrencyFormatPipe', () => {
// tslint:disable-next-line:typedef-whitespace
	let pipe: CurrencyFormatPipe;

	beforeEach(() => {
		pipe = new CurrencyFormatPipe();
	});

	it('transforms 35000 to SGD 35000.00', () => {
		expect(pipe.transform(35000, 2, 'SGD')).toBe('SGD 35,000.00');
	});

	it('transforms -1235000 to INR -1,235,000.00', () => {
		expect(pipe.transform(-1235000, 2, 'INR')).toBe('INR -1,235,000.00');
	});

});


