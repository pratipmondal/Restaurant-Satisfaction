import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'currencyformat'})
export class CurrencyFormatPipe implements PipeTransform {
	transform(value: number, decimalDigit: number, currencySymbol: string): string {
		return currencySymbol + ' ' + value.toFixed(decimalDigit).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
	}
}
