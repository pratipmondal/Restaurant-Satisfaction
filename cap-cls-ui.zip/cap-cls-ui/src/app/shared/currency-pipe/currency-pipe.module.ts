import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { CurrencyFormatPipe } from './currency-pipe';

@NgModule({
	imports: [
		BrowserModule, CommonModule
	],
	declarations: [CurrencyFormatPipe],
	exports: [CurrencyFormatPipe],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CurrencyFormatModule {
}
