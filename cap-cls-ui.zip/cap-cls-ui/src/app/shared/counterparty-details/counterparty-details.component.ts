import { Component, OnInit, Input } from '@angular/core';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';
@Component({
	selector: 'counterparty-details',
	templateUrl: './counterparty-details.component.html',
	styleUrls: ['./counterparty-details.component.scss']
})
export class CounterpartyDetailsComponent implements OnInit {
    public collapsible: boolean = true;
	showCounterPartyHeaderDiv: boolean = true;
	counterparty: any;
	@Input()
	public gcin;
	constructor(private counterPartyDetailsService: CounterPartyDetailsService) {
		this.counterparty = {'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000'};
	}
	ngOnInit() {
		if (this.gcin) {
			this.counterparty = this.gcin;
		} else {
			this.counterPartyDetailsService.subscribeToCPDetails({
				next: (value) => this.counterparty = value,
				error: (value) => console.log(value),
				complete: () => {
				}
			});
		}
	}
}
