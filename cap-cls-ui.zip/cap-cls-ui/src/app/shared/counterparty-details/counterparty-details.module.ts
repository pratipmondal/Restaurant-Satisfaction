import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CounterpartyDetailsComponent } from './counterparty-details.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [ CounterpartyDetailsComponent ],
    exports: [ CounterpartyDetailsComponent ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class CounterpartyDetailsModule {
}
