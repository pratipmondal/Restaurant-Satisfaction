import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CounterpartyDetailsComponent } from './counterparty-details.component';
import { CounterPartyDetailsService } from '../../common/counterparty-details/counterparty.service';

describe('CounterpartyDetailsComponent', () => {
	let component: CounterpartyDetailsComponent;
	let fixture: ComponentFixture<CounterpartyDetailsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CounterpartyDetailsComponent],
			providers: [CounterPartyDetailsService]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CounterpartyDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
