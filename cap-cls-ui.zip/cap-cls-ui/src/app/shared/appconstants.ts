//  export const AppConstants = Object.freeze({
//      BASE_API_URL: 'http://localhost:8080/cls/api/v1/',
//  });