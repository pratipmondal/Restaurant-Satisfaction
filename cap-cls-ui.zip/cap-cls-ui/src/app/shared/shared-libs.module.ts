import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { DialogModule } from '@progress/kendo-angular-dialog';

@NgModule({
    imports: [],
    declarations: [],
    exports: [
        FormsModule,
        HttpModule,
        CommonModule,
        ReactiveFormsModule,
        GridModule,
        ButtonsModule,
        DialogModule,
        AutoCompleteModule,
        BrowserAnimationsModule
    ]
})
export class ClsSharedLibsModule {
}
