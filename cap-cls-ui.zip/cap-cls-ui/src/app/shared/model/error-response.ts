export interface Headers {
    'Content- Type': string[];
}


export interface ErrorResponse {
    _body: string;
    status: number;
    ok: boolean;
    statusText: string;
    headers: Headers;
    type: number;
    url: string;
}