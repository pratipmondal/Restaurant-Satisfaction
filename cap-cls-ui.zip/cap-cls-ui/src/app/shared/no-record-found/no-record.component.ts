import { Component, Input, Output, EventEmitter, OnInit } from "@angular/core";

@Component({
    selector: 'no-record-comp',
    templateUrl: './no-record.component.html',
    styleUrls: ['./no-record.component.scss']
})
export class NoRecordComponent implements OnInit{
    @Input()
    public clickableLabel: string;
    @Input()
    public headerMsg: string
    @Input()
    public label: string;
    private status : string;

    
    ngOnInit(){
    }

    @Output() onLabelCliked : EventEmitter<any> = new EventEmitter();

    constructor() {
    }

    public getStatus(){
       return this.status;
    }

    public labelClick(evt: Event) {
        this.status = "clicked";
        console.log('emit some function that would open up a pop up form for the corresponding Tab Model');
        this.onLabelCliked.emit(evt); // emit a function to the parent caller
    }
}