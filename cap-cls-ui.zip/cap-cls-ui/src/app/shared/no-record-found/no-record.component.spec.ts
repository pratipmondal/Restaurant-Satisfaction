import {async, ComponentFixture, TestBed} from "@angular/core/testing";
import {CommonModule} from "@angular/common";
import {BrowserModule} from "@angular/platform-browser";
import {DialogModule} from "@progress/kendo-angular-dialog";
import {ButtonsModule} from "@progress/kendo-angular-buttons";
import {LoaderModule} from "../progression/loader/loader.module";
import {NoRecordComponent} from "./no-record.component";


describe('Component : NoRecordComponent : ', () => {
    let component: NoRecordComponent;
    let fixture: ComponentFixture<NoRecordComponent>;
    let evt : any;
 
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, BrowserModule, LoaderModule, DialogModule, ButtonsModule],
            declarations: [NoRecordComponent]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NoRecordComponent);
        component = fixture.componentInstance;
        component.headerMsg="some header";
        component.label="some label";
        component.clickableLabel = "some clickable Link text";
        evt = {};
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
        console.log("Component : NoRecordComponent -- should create -- PASSED");
    });
    
    it('should display labels and headerMsg', () => { 
        fixture.detectChanges();
        expect(component.headerMsg).toBe("some header");
        expect(component.clickableLabel).toBe("some clickable Link text");
        expect(component.label).toBe("some label");
        console.log("Component : NoRecordComponent -- should display labels and headerMsg passed in for suucess -- PASSED")
    });

    it('should return status clicked', () => {
        fixture.detectChanges();
        component.labelClick(evt);
        expect(component.getStatus()).toBe("clicked");
        console.log("Component : NoRecordComponent -- should return status clicked passed in for suucess -- PASSED")
    });
});