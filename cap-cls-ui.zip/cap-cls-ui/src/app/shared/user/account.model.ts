export class Account {
    constructor( public tenantId: string,
                 public roles: string[],
                 public username: string,
                 public userTenantId: string,
                 public userId: string,
                 public id: string, //access token
                 public created: Date,
                 public ttl: number ) {
    }
}
