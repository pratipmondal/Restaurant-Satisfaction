import {ComponentFixture, tick} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {DebugElement} from '@angular/core';

export class SpecHelper<T> {

    constructor(private fixture: ComponentFixture<T>) {}

    clickElement(selector: string) {
        this.fixture.debugElement.query(By.css(selector)).nativeElement.click();
    }   

    $(selector: string): DebugElement {
        return this.fixture.debugElement.query(By.css(selector));
    }

    $$(selector: string): DebugElement[] {
        return this.findAll(selector);
    }

    findAll(selector: string): DebugElement[] {
        return this.fixture.debugElement.queryAll(By.css(selector));
    }

    expectElementCount(selector: string, count: number, failMessage = "didn't find the right number of elements") {
        expect(this.findAll(selector).length).toEqual(count, failMessage);
    }

    expectNoElement(selector: string, failMessage = `found the unexpected element "${selector}"`) {
        expect(this.findAll(selector).length)
            .toEqual(0, failMessage);
    }

    expectElement(selector: string, failMessage = `cannot find element ${selector}`) {
        expect(this.findAll(selector).length >= 1)
            .toBeTruthy(failMessage);
    }

    expectContent(selector: string, expectedContent: string, exact = false, message = `content did not match for "${selector}"`) {
        this.expectElement(selector);
        const textContent = this.fixture.debugElement.query(By.css(selector)).nativeElement.textContent;

        if (exact === true) {
            expect(textContent.trim()).toEqual(expectedContent, message);
        } else {
            expect(textContent).toContain(expectedContent, message);
        }
    }

    expectNoContent(selector: string, unexpectedContent: string, message = `content matched for "${selector}"`) {
        this.expectElement(selector);
        const textContent = this.$(selector).nativeElement.textContent;

        expect(textContent).not.toContain(unexpectedContent, message);
    }

    expectEmptyContent(selector: string, message = 'content is not empty') {
        this.expectElement(selector);
        const textContent = this.fixture.debugElement.query(By.css(selector)).nativeElement.textContent;

        expect(textContent).toBe("", message);
    }

    expectValue(selector: string, expectedValue: string, exact = false, message = `value did not match for "${selector}"`) {
        this.expectElement(selector);
        const value = this.fixture.debugElement.query(By.css(selector)).nativeElement.value;

        if (exact === true) {
            expect(value.trim()).toEqual(expectedValue, message);
        } else {
            expect(value).toContain(expectedValue, message);
        }
    }

    expectElementToBeChecked(selector: string) {
        this.expectElement(selector);
         expect(this.fixture.debugElement.queryAll(By.css(selector+':checked')).length).toEqual(1, "Expected element "+selector+' to be checked');
    }

    expectElementToNotBeChecked(selector: string) {
        this.expectElement(selector);
        expect(this.fixture.debugElement.queryAll(By.css(selector+':checked')).length).toEqual(0, "Expected element "+selector+' not to be checked');
    }

    expectAttributeContent(selector: string, attribute: string, expectedValue: string, index = 0) {
        expect(this.fixture.debugElement.queryAll(By.css(selector))[index].nativeElement.attributes[attribute].value)
            .toContain(expectedValue);
    }

    tickForFormAutosave() {
        tick();
        tick(2000);
    }

    tickForShowModal() {
        // The backdrop transition duration is 150ms and
        // the modal transition duration is another 300ms.
        tick();
        tick(450);
    }
}

