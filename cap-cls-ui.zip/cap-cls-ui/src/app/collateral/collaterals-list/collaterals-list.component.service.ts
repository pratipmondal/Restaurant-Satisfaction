import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Headers, Http, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ErrorResponse } from 'app/shared';

@Injectable()
export class CollateralsListService {

	public ratesUrl = environment.apiBaseUrl + environment.apiToGetRates;
	public currencyUrl = environment.apiBaseUrl + environment.apiToGetCurrencyList;
	public urlToGetCollateralsUsingCounterPartyID = 'mock';
	public baseURLForCollateralCRUD = environment.apiBaseUrl;
	public collateralApi = '';

	constructor(private http: Http) {

	}

	public getCurrency(): Observable<any> {
		return this.http.get(this.currencyUrl)
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}

	private extractData(res: Response) {
		const body = res.json();
		return body;
	}

	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}

	getCollateralsByCounterPartyGCID(counterpartyGCID: string) {
		return this.http.get(this.urlToGetCollateralsUsingCounterPartyID)
			.map(this.extractData)
			.catch(error => this.handleError(error));

	}

	getRateValues(fromCurreny: string, toCurrency: string): Observable<any> {
		const params: URLSearchParams = new URLSearchParams();
		const filter = '{"where":{"fromCurrency": "' + fromCurreny + '","toCurrency": "' + toCurrency + '"}}';
		params.set('filter', filter);
		return this.http.get(this.ratesUrl, {search: params})
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}

	getCollateralsInfo(collateralType: string, collateralId?: string): Observable<any> {
		let urlToGetCollateralsByTypeLocalVar = '';
		switch (collateralType) {
			case 'GUARN':
				this.collateralApi = environment.apiGuarnCollaterals;
				break;
			case 'DEPOS':
				this.collateralApi = environment.apiDeposCollaterals;
				break;
			default:
				return Observable.throw('Invalid Collateral Type');
		}

		if (!collateralId) {
			urlToGetCollateralsByTypeLocalVar = this.baseURLForCollateralCRUD + this.collateralApi;
		} else {
			urlToGetCollateralsByTypeLocalVar = this.baseURLForCollateralCRUD + this.collateralApi + '/' + collateralId;
		}

		return this.http.get(urlToGetCollateralsByTypeLocalVar)
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}
	getCollateralTypes(filter?: any): Observable<any> {
			// TODO: we need to use search filter
			const url = environment.apiBaseUrl + environment.apiGetcollateralTypes;
			const params: URLSearchParams = new URLSearchParams();
			if (filter) {
				params.set('filter', JSON.stringify(filter));
			}
			return this.http.get(url, {search: params})
				.map(onSuccessSuccess.bind(this))
				.catch(error => this.errorResponseFunction(error));
			function onSuccessSuccess(resp: Response) {
				return (resp.json());
			}
		}
	withdrawCollateral(collateralID: string, reasonCode: string, collateralType: string): Observable<any> {
		const headers = new Headers({'Content-Type': 'application/json'});
		const options = new RequestOptions({headers: headers});
		let collateralAPIToWithdraw = '';
		let urlToWithdrawCollateral = '';
		switch (collateralType) {
			case 'GUARN':
				collateralAPIToWithdraw = environment.apiToWithdrawGuarnCollateral;
				break;
			case 'DEPOS':
				collateralAPIToWithdraw = environment.apiToWithdrawDeposCollateral;
				break;
			default:
				return Observable.throw('Invalid Collateral Type');
		}
		urlToWithdrawCollateral = this.baseURLForCollateralCRUD + collateralAPIToWithdraw.replace('{id}', collateralID);
		const todayDate = new Date();
		const isoCurrentDate = todayDate.toISOString();
		const bodyData = {
			'withdraw': true,
			'reasonCode': reasonCode,
			'withdrawalDate': isoCurrentDate
		};
		return this.http.put(urlToWithdrawCollateral, bodyData, options)
			.map(res => res.json())
			.catch(error => this.handleError(error));
	}
	errorResponseFunction(error: any) {
			const ErrorResponse = <ErrorResponse>error;
			return Observable.throw(<ErrorResponse>ErrorResponse);
		}
}
