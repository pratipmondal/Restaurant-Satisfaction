import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { CollateralsListService } from './collaterals-list.component.service';
import { CommonModule } from '@angular/common';
import { GridModule } from '@progress/kendo-angular-grid';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { CommonUIModule } from '../../common/commonUI.module';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { ToggleButtonModule } from '../../common/toggle-button/toggle-button.module';
import { IntlModule } from '@progress/kendo-angular-intl';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { CollateralsListComponent } from './collaterals-list.component';
import { Router } from '@angular/router';
import { CounterpartyDetailsModule } from '../../shared/counterparty-details/counterparty-details.module';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Observable } from 'rxjs/Rx';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';
import { CollateralSummaryService } from '../collateral-summary/collateral-summary.service';
import { CollateralService } from '../collateral.service';
import { MockCollateralData } from '../collateral-summary/collateral-summary-mock-data';
import { DEPOS_TYPE_COLLATERALS, GUARN_TYPE_COLLATERALS } from './collaterals-list.data';

class MockPartyDetailsService {
	temp = new Observable(observer => {
		observer.next({ 'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000' });
	});

	subscribeToCPDetails(temp) {
		return Observable.of({ label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000' });
	}
}

class MockCollateralsListService {
	getRateValues(from: string, to: string) {
		if (from === '' && to === '') {
			return Observable.throw({ status: 404 });
		} else {
			const data = [{ 'rate': 10 }];
			return Observable.of(data);
		}
	}

	getCurrency() {
		const data = [{ code: 'INR' }, { code: 'SGD' }, { code: 'USD' }];
		return Observable.of(data);
	}

	getCollateralsInfo(collateralType: string, collateralId?: string): Observable<any> {
		switch (collateralType) {
			case 'GUARN':
				return Observable.of(GUARN_TYPE_COLLATERALS);
			case 'DEPOS':
				return Observable.throw(DEPOS_TYPE_COLLATERALS);
			default:
				return Observable.throw('Invalid Collateral Type');
		}
	}

	withdrawCollateral(collateralID: string, reasonCode: string, collateralType: string): Observable<any> {
		return Observable.of('success');
	}

	getCollateralTypes() {
		const collateralCodesTypesData = [{
			'collateralType': 'GUARN',
			'collateralTypeDesc': 'Guarantee Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': false
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': false
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': false
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': false
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': true
						},
						{
							'subSections': [],
							'LodgeOtherDetail': false
						},
						{
							'subSections': [],
							'LodgeDepositDetail': false
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': '6efaad55-52ac-495f-b635-97063ac008c2',
			'_version': 'a066669d-c5cf-4345-ba0b-42209465b307',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		},
		{
			'collateralType': 'OTHRS',
			'collateralTypeDesc': 'Others Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': true
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': true
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': true
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': false
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': false
						},
						{
							'subSections': [],
							'LodgeOtherDetail': true
						},
						{
							'subSections': [],
							'LodgeDepositDetail': false
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': '879a67e4-d8b4-4174-b842-6c82d16929df',
			'_version': '8a8071e1-7111-4e99-972f-b2757db12876',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		},
		{
			'collateralType': 'DEPOS',
			'collateralTypeDesc': 'Deposit Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': false
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': false
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': false
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': false
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': false
						},
						{
							'subSections': [],
							'LodgeOtherDetail': false
						},
						{
							'subSections': [],
							'LodgeDepositDetail': true
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': '889604e4-5583-4826-8753-0c6d9646bf8b',
			'_version': 'b2bf8f0c-3f40-4767-9bf5-55cd37050a3f',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		},
		{
			'collateralType': 'BASKT',
			'collateralTypeDesc': 'Basket Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': true
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': false
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': true
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': true
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': false
						},
						{
							'subSections': [],
							'LodgeOtherDetail': false
						},
						{
							'subSections': [],
							'LodgeDepositDetail': false
						},
						{
							'subSections': [],
							'LodgeBasketDetail': true
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': 'bf4aabd1-d08e-4ed6-b5cb-32862172fa19',
			'_version': 'f0c824ed-5c60-434c-8ff9-ebfa74ab3996',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		}
		];
		return Observable.of(collateralCodesTypesData);
	}
}

class MockCollateralSummaryService {
	guarnCollateralDataFromService: any;
	deposCollateralDataFromService: any;
	selectedCollateral: any;
	selectedCollateralType: any;


	rateConversionArray = [
		{ 'from': 'SGD', 'to': 'INR', 'rate': '48.7923883874116' },
		{ 'from': 'SGD', 'to': 'RUB', 'rate': '46.3951006773685' },
		{ 'from': 'SGD', 'to': 'PKR', 'rate': '76.5990042129452' },
		{ 'from': 'SGD', 'to': 'BOB', 'rate': '5.07598753337462' },
		{ 'from': 'SGD', 'to': 'SGD', 'rate': '1' }
	];



	getStoredCurrencyRate(argFrom: string, argTo: string) {
		if (argFrom === '' && argTo === '') {
			return Observable.throw({ status: 404 });

		} else {
			const tempRate = [{ 'rate': 1 }];
			return Observable.of(tempRate);
		}
	}

	getCurrency() {
		const data = [{ code: 'INR' }, { code: 'SGD' }, { code: 'USD' }];
		return Observable.of(data);
	}

	getCollateralSummaryData() {
		return Observable.of(MockCollateralData);
	}

	getRateValues(from: string, to: string) {
		if (from === '' && to === '') {
			return Observable.throw({ status: 404 });
		} else {
			let data = [{ 'rate': 10 }];
			return Observable.of(data);
		}
	}
}

class MockCollateralService {
	getCollateralTypes() {
		const collateralCodesTypesData = [{
			'collateralType': 'GUARN',
			'collateralTypeDesc': 'Guarantee Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': false
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': false
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': false
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': false
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': true
						},
						{
							'subSections': [],
							'LodgeOtherDetail': false
						},
						{
							'subSections': [],
							'LodgeDepositDetail': false
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': '6efaad55-52ac-495f-b635-97063ac008c2',
			'_version': 'a066669d-c5cf-4345-ba0b-42209465b307',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		},
		{
			'collateralType': 'OTHRS',
			'collateralTypeDesc': 'Others Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': true
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': true
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': true
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': false
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': false
						},
						{
							'subSections': [],
							'LodgeOtherDetail': true
						},
						{
							'subSections': [],
							'LodgeDepositDetail': false
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': '879a67e4-d8b4-4174-b842-6c82d16929df',
			'_version': '8a8071e1-7111-4e99-972f-b2757db12876',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		},
		{
			'collateralType': 'DEPOS',
			'collateralTypeDesc': 'Deposit Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': false
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': false
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': false
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': false
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': false
						},
						{
							'subSections': [],
							'LodgeOtherDetail': false
						},
						{
							'subSections': [],
							'LodgeDepositDetail': true
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': '889604e4-5583-4826-8753-0c6d9646bf8b',
			'_version': 'b2bf8f0c-3f40-4767-9bf5-55cd37050a3f',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		},
		{
			'collateralType': 'BASKT',
			'collateralTypeDesc': 'Basket Collateral Type',
			'sections': {
				'code': {
					'sections': [{
						'subSections': [],
						'CollateralCodeLinkageDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeAlertEventDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeSecurityDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeAdditionalDetail': true
					},
					{
						'subSections': [],
						'CollateralCodeUnitValueDetail': false
					},
					{
						'subSections': [],
						'CollateralCodeDetailsInAltLang': true
					},
					{
						'subSections': [],
						'CollateralCodeCompanyDetail': false
					}
					]
				},
				'lodge': {
					'sections': [{
						'subSections': [],
						'LodgeChargeDetail': true
					},
					{
						'subSections': [],
						'LodgeReceiptAndPayment': true
					},
					{
						'subSections': [],
						'LodgeInspectionAndAppraisal': false
					},
					{
						'subSections': [],
						'LodgeDocumentationDetail': true
					},
					{
						'subSections': [],
						'LodgeBeneficiaryDetail': true
					},
					{
						'subSections': [],
						'LodgeInsuranceDetail': true
					},
					{
						'subSections': [],
						'CollateralValuationDetail': true
					},
					{
						'subSections': [],
						'LodgeDynamicSection': true
					},
					{
						'subSections': [],
						'LodgeSalesNotesDetail': false
					},
					{
						'subSections': [{
							'subSections': [],
							'OwnerShipDetail': true
						},
						{
							'subSections': [],
							'LodgeTenancyDetail': false
						}
						],
						'LodgeOwnerShipDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'LodgeGuaranteeDetail': false
						},
						{
							'subSections': [],
							'LodgeOtherDetail': false
						},
						{
							'subSections': [],
							'LodgeDepositDetail': false
						},
						{
							'subSections': [],
							'LodgeBasketDetail': true
						}
						],
						'LodgeCollateralTypeSpecificDetail': true
					},
					{
						'subSections': [{
							'subSections': [],
							'ForeClosureDetail': false
						},
						{
							'subSections': [],
							'RepossessionDetail': false
						}
						],
						'LodgeNonPerformanceDetail': false
					}
					]
				},
				'common': {
					'sections': [{
						'FeeDetail': true,
						'subSections': []
					},
					{
						'subSections': [{
							'subSections': [],
							'CalculationMethod': true
						}],
						'CollateralValueDetail': true
					}
					]
				}
			},
			'id': 'bf4aabd1-d08e-4ed6-b5cb-32862172fa19',
			'_version': 'f0c824ed-5c60-434c-8ff9-ebfa74ab3996',
			'_createdBy': 'upload',
			'_modifiedBy': 'upload'
		}
		];
		return Observable.of(collateralCodesTypesData);
	}
}

describe('Collateral List Component Test Cases', () => {

	const MockCashCollateralsList = [{
		'beneficiaryID': '-',
		'collateralCode': '',
		'code02': 'collateralId',
		'collateralId': 'COLL2312',
		'convertedCollateralValue': '90000',
		'originalCollateralValue': '90000',
		'originalCurrency': 'SGD',
		'owner': '-',
		'remarks': 'Deposit'
	}];

	let collateralsListComponent: CollateralsListComponent;
	let fixture: ComponentFixture<CollateralsListComponent>;
	const router = {
		navigate: jasmine.createSpy('navigate')
	};
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [CommonModule, BrowserModule, GridModule, DialogModule,
				ButtonsModule, InputsModule, ReactiveFormsModule, AutoCompleteModule,
				DateInputsModule, CommonUIModule, PopupDialogModule, ToggleButtonModule,
				IntlModule, ClsSharedCommonModule, DropDownsModule, CounterpartyDetailsModule, CustomPanelModule, BrowserAnimationsModule],
			declarations: [CollateralsListComponent],
			providers: [{ provide: CounterPartyDetailsService, useClass: MockPartyDetailsService },
			{ provide: CollateralSummaryService, useClass: MockCollateralSummaryService },
			{ provide: CollateralsListService, useClass: MockCollateralsListService },
			{ provide: CollateralService, useClass: MockCollateralService },
			{ provide: Router, useValue: router }]
		}).compileComponents();
	}));
	beforeEach(async(() => {
		fixture = TestBed.createComponent(CollateralsListComponent);
		collateralsListComponent = fixture.componentInstance;
		fixture.detectChanges();
	}));

	it('should create', async(() => {
		expect(collateralsListComponent).toBeTruthy();
	}));

	it('should setUpCollateralsListPage on init', async(() => {
		collateralsListComponent.collateralSummaryService.deposCollateralDataFromService = DEPOS_TYPE_COLLATERALS;
		collateralsListComponent.collateralSummaryService.guarnCollateralDataFromService = GUARN_TYPE_COLLATERALS;
		spyOn(collateralsListComponent, 'getCurrencyList');
		spyOn(collateralsListComponent, 'getCollateralsList');
		collateralsListComponent.setUpCollateralsListPage();
		expect(collateralsListComponent.getCurrencyList).toHaveBeenCalled();
		expect(collateralsListComponent.getCollateralsList).toHaveBeenCalled();
	}));

	it('should Withdraw DEPOS  Collateral when Remove icon clicked and confirmed ', async(() => {
		collateralsListComponent.collateralSummaryService.deposCollateralDataFromService = DEPOS_TYPE_COLLATERALS;
		collateralsListComponent.collateralSummaryService.guarnCollateralDataFromService = GUARN_TYPE_COLLATERALS;
		collateralsListComponent.setUpCollateralsListPage();
		let selectedCollateral: any = undefined;
		let index: number = -1;
		let collateralType: string = 'OTWER';
		// negative check
		expect(collateralsListComponent.removeCollateralItem(selectedCollateral, index, collateralType)).toBeUndefined();
		selectedCollateral = DEPOS_TYPE_COLLATERALS[0];
		index = 0;
		collateralType = 'DEPOS';
		// Postive check  from DEPOS
		spyOn(collateralsListComponent, 'removeCollateralFromGrid');
		collateralsListComponent.removeCollateralItem(selectedCollateral, index, collateralType);
		expect(collateralsListComponent.showPopupDialogForRemoveConfirmation).toBeTruthy();
		collateralsListComponent.selectedCollateral = selectedCollateral;
		collateralsListComponent.withdrawReason = 'Not Applicable';
		collateralsListComponent.confirmCollateralRemoval();
		expect(collateralsListComponent.removeCollateralFromGrid).toHaveBeenCalled();
		expect(collateralsListComponent.showPopupDialogForRemoveConfirmation).toBeFalsy();
	}));

	it('should Withdraw GUARN  Collateral when Remove icon clicked and confirmed ', async(() => {
		collateralsListComponent.collateralSummaryService.deposCollateralDataFromService = DEPOS_TYPE_COLLATERALS;
		collateralsListComponent.collateralSummaryService.guarnCollateralDataFromService = GUARN_TYPE_COLLATERALS;
		collateralsListComponent.setUpCollateralsListPage();
		let selectedCollateral: any = undefined;
		let index: number = -1;
		let collateralType: string = 'OTHER';
		// negative check
		expect(collateralsListComponent.removeCollateralItem(selectedCollateral, index, collateralType)).toBeUndefined();
		// POstive check  from GURAN item removal
		spyOn(collateralsListComponent, 'removeCollateralFromGrid');
		selectedCollateral = GUARN_TYPE_COLLATERALS[0];
		index = 0;
		collateralType = 'GUARN';
		collateralsListComponent.removeCollateralItem(selectedCollateral, index, collateralType);
		expect(collateralsListComponent.showPopupDialogForRemoveConfirmation).toBeTruthy();
		collateralsListComponent.selectedCollateral = selectedCollateral;
		collateralsListComponent.withdrawReason = 'Not Applicable';
		collateralsListComponent.confirmCollateralRemoval();
		expect(collateralsListComponent.removeCollateralFromGrid).toHaveBeenCalled();
		expect(collateralsListComponent.showPopupDialogForRemoveConfirmation).toBeFalsy();
	}));

	// Collateral Edit workflow initaitions
	it('should start Edit workflow based on Collateral type DEPOS when Edit Icon clicked', async(() => {
		// setup data
		collateralsListComponent.collateralSummaryService.deposCollateralDataFromService = DEPOS_TYPE_COLLATERALS;
		collateralsListComponent.collateralSummaryService.guarnCollateralDataFromService = GUARN_TYPE_COLLATERALS;
		collateralsListComponent.setUpCollateralsListPage();
		let selectedCollateral: any = undefined;
		let index: number = -1;
		let collateralType: string = 'OTHER';
		// negative check
		expect(collateralsListComponent.editCollateralItem(selectedCollateral, index, collateralType)).toBeUndefined();
		// Postive check  from DEPOS
		selectedCollateral = DEPOS_TYPE_COLLATERALS[0];
		index = 0;
		collateralType = 'DEPOS';
		collateralsListComponent.editCollateralItem(selectedCollateral, index, collateralType);
		expect(collateralsListComponent.collateralSummaryService.selectedCollateralType).toBe('DEPOS');
		expect(collateralsListComponent.collateralSummaryService.selectedCollateral).toBeDefined();
		expect(router.navigate).toHaveBeenCalledWith(['/newcollateral']);
	}));

	it('should start Edit workflow based on Collateral type GUARN when Edit Icon clicked', async(() => {
		// setup data
		collateralsListComponent.collateralSummaryService.deposCollateralDataFromService = DEPOS_TYPE_COLLATERALS;
		collateralsListComponent.collateralSummaryService.guarnCollateralDataFromService = GUARN_TYPE_COLLATERALS;
		collateralsListComponent.setUpCollateralsListPage();
		let selectedCollateral: any = undefined;
		let index: number = -1;
		let collateralType: string = 'OTHER';
		// negative check
		expect(collateralsListComponent.editCollateralItem(selectedCollateral, index, collateralType)).toBeUndefined();
		// Postive check  from GUARN
		selectedCollateral = GUARN_TYPE_COLLATERALS[0];
		index = 0;
		collateralType = 'GUARN';
		collateralsListComponent.editCollateralItem(selectedCollateral, index, collateralType);
		expect(collateralsListComponent.collateralSummaryService.selectedCollateralType).toBe('GUARN');
		expect(collateralsListComponent.collateralSummaryService.selectedCollateral).toBeDefined();
		expect(router.navigate).toHaveBeenCalledWith(['/newcollateral']);
	}));
	
});
