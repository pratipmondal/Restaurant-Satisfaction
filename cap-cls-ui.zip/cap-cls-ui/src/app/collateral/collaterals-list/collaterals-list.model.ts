import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject
export class GeneralDetail {
	collateralDesc: string = '';
	globalCollateral: boolean = false;
	businessLocation: string = '';
	collateralClass: string = '';
	collateralGrp: string = '';
	collateralCreationDate: String = null;
	collateralExpiryDate: String = null;
	currencyCode: string = '';
	BASELEligible: boolean = false;
	method: string = '';
	solicitorName: string = '';
	collateralStatus: string = '';
	remarks: string = '';
	country: string = '';
}

@JsonObject
export class WithdrawalDetail {
	withdraw: boolean = false;
	reasonCode: string = '';
	withdrawalDate: Date = null;
}

@JsonObject
export class ExternalChargeAmt {
	value: number;
	ccy: string = '';
}

@JsonObject
export class CollateralValue {
	value: number;
	ccy: string = '';
}

@JsonObject
export class FinalCollateralValue {
	value: number;
	ccy: string = '';
}

@JsonObject
export class TotalApportionedValue {
	value: number;
	ccy: string = '';
}

@JsonObject
export class BalanceApportionableAmt {
	value: number;
	ccy: string = '';
}

@JsonObject
export class CollateralValuationDetail {
	loanToValuePcnt: number;
	externalChargeAmt: ExternalChargeAmt = new ExternalChargeAmt();
	collateralValue: CollateralValue = new CollateralValue();
	finalCollateralValue: FinalCollateralValue = new FinalCollateralValue();
	totalApportionedValue: TotalApportionedValue = new TotalApportionedValue();
	balanceApportionableAmt: BalanceApportionableAmt = new BalanceApportionableAmt();
}

@JsonObject
export class GUARNCollateral {
	collateralId: string = '';
	collateralCode: string = '';
	collateralType: string = '';
	generalDetail: GeneralDetail = new GeneralDetail();
	withdrawalDetail: WithdrawalDetail = new WithdrawalDetail();
	CollateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail();
}

@JsonObject
export class DEPOSCollateral {
	collateralId: string = '';
	collateralCode: string = '';
	collateralType: string = '';
	generalDetail: GeneralDetail = new GeneralDetail();
	withdrawalDetail: WithdrawalDetail = new WithdrawalDetail();
	collateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail();
}
