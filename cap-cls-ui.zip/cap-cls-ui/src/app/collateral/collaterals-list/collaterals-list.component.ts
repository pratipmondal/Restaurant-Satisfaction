import { Component, OnInit } from '@angular/core';
import { CollateralsListService } from './collaterals-list.component.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ToastsComponent } from '../../shared/toasts/toasts.component';
import { CollateralSummaryService } from '../collateral-summary/collateral-summary.service';
import { CollateralService } from '../collateral.service';

@Component({
	selector: 'app-collaterals-list',
	templateUrl: './collaterals-list.component.html',
	styleUrls: ['./collaterals-list.component.scss']
})
export class CollateralsListComponent implements OnInit {
	private currencyValues: any;
	private errorMsg: boolean;
	public presentCurrencyFormat: string = 'SGD';
	public previousCurrencyFormat: string = 'SGD';
	public presentCurrencyUnit: string = 'Units';
	public oldCurrencyUnit: string = 'Units';
	public listItems: any[] = ['Units', 'Thousands', 'Millions'];
	public cashCollateralsList: any;
	private counterpartyGCID: string;
	private sumOfConvertedCollateralAmountValueForCash: number = 0;
	private sumOfConvertedCollateralAmountValueForGuarantee: number = 0;
	private sumOfConvertedCollateralAmountValueForOtherIntagible: number = 0;
	private guaranteeCollateralsList: any;
	private otherIntangibleCollateralsList: any;
	private fullJSONOfDeposTypeCollaterals: any;
	private fullJSONOfGuarnTypeCollaterals: any;

	private argToastMessageObject: any;

	showPopupDialogForRemoveConfirmation: boolean = false;
	private dialogTitleNameConfirmation: string = '';

	selectedCollateral: any;
	private selectedCollateralIndex: number;

	private errMsg: boolean = false;
	private errorMessage: string;

	private toastsComponent: ToastsComponent = new ToastsComponent();
	private selectedCollateralType: string;
	public withdrawReason: any = 'Not Applicable';
	public withdrawReasons: any[] = ['Not Applicable', 'Form B delink'];

	divForCashCollateral: boolean = true;
	divForGuaranteeCollateral: boolean = true;
	divForOtherIntangibleCollateral: boolean = true;
	checkDeposTypeCol: boolean = false;
	checkGuarnTypeCol: boolean = false;

	constructor(public collateralsListService: CollateralsListService, 
				private  router: Router, 
				public collateralSummaryService: CollateralSummaryService) {
	}

	ngOnInit() {
		this.setUpCollateralsListPage();
	}

	setUpCollateralsListPage() {
		if (this.collateralSummaryService.deposCollateralDataFromService || this.collateralSummaryService.guarnCollateralDataFromService) {
			this.getCurrencyList();
			this.getCollateralsList();
		} else {
			this.router.navigate(['/collateral']);
		}
	}

	getCurrencyList() {
		this.collateralsListService.getCurrency().subscribe(data => {
			this.currencyValues = data;
		}, error => {
			this.errorMsg = true;
			this.returnError(error);
		});
	}

	selectionUnitChange(amountFormat: any) {
		const duplicateArrayForGurantee = this.guaranteeCollateralsList;
		const duplicateArrayForIntagible = this.otherIntangibleCollateralsList;
		this.oldCurrencyUnit = this.presentCurrencyUnit;
		this.presentCurrencyUnit = amountFormat;
		if (this.presentCurrencyUnit === 'Millions') {
			this.unitConverter(this.cashCollateralsList, 1.0e+6, this.presentCurrencyFormat);
			this.unitConverter(duplicateArrayForGurantee, 1.0e+6, this.presentCurrencyFormat);
			this.unitConverter(duplicateArrayForIntagible, 1.0e+6, this.presentCurrencyFormat);
		} else if (this.presentCurrencyUnit === 'Thousands') {
			this.unitConverter(this.cashCollateralsList, 1.0e+3, this.presentCurrencyFormat);
			this.unitConverter(duplicateArrayForGurantee, 1.0e+3, this.presentCurrencyFormat);
			this.unitConverter(duplicateArrayForIntagible, 1.0e+3, this.presentCurrencyFormat);
		} else if (this.presentCurrencyUnit === 'Units') {
			this.unitConverter(this.cashCollateralsList, 1, this.presentCurrencyFormat);
			this.unitConverter(duplicateArrayForGurantee, 1, this.presentCurrencyFormat);
			this.unitConverter(duplicateArrayForIntagible, 1, this.presentCurrencyFormat);
		}
	}

	unitConverter(list: any[], currencyDivider: any, toCurrency: string) {
		for (const key in list) {
			if (list !== undefined) {
				const rate = this.getStoredCurrencyRate(list[key]['originalCurrency'], toCurrency);
				if (rate !== undefined) {
					list[key]['convertedCollateralValue'] = (Math.abs(Number((list[key]['originalCollateralValue'])) * rate) / currencyDivider);
					list[key]['displayOriginalCollateralValue'] = (Math.abs(Number((list[key]['originalCollateralValue']))) / currencyDivider);
					this.populateAndAddSummaryRowToList();
				} else {
					return list;
				}
			}
		}
		return list;
	}

	getStoredCurrencyRate(argFrom: string, argTo: string) {
		const tempRate = this.collateralSummaryService.rateConversionArray.find(item => item.from === argFrom && item.to === argTo);
		if (tempRate !== undefined) {
			return tempRate['rate'];
		} else {
			return undefined;
		}
	}

	selectionCurrencyChange(currencyFormat: any) {
		if (typeof currencyFormat !== 'object') {
			this.presentCurrencyFormat = currencyFormat;
			if (this.presentCurrencyUnit === 'Millions') {
				this.currencyConverter(this.cashCollateralsList, 1.0e+6, this.presentCurrencyFormat);
				this.currencyConverter(this.guaranteeCollateralsList, 1.0e+6, this.presentCurrencyFormat);
				this.currencyConverter(this.otherIntangibleCollateralsList, 1.0e+6, this.presentCurrencyFormat);
			} else if (this.presentCurrencyUnit === 'Thousands') {
				this.currencyConverter(this.cashCollateralsList, 1.0e+3, this.presentCurrencyFormat);
				this.currencyConverter(this.guaranteeCollateralsList, 1.0e+3, this.presentCurrencyFormat);
				this.currencyConverter(this.otherIntangibleCollateralsList, 1.0e+3, this.presentCurrencyFormat);
			} else if (this.presentCurrencyUnit === 'Units') {
				this.currencyConverter(this.cashCollateralsList, 1, this.presentCurrencyFormat);
				this.currencyConverter(this.guaranteeCollateralsList, 1, this.presentCurrencyFormat);
				this.currencyConverter(this.otherIntangibleCollateralsList, 1, this.presentCurrencyFormat);
			}
		}
	}

	getCurrencyRates(from: string, to: string): Observable<any> {
		let rate: any;
		this.collateralsListService.getRateValues(from, to).subscribe(
			data => {
				if (data.length > 0) {
					if (data[0]['rate'] !== undefined) {
						rate = data[0]['rate'];
					}
				}
			}, error => {
				this.errorMsg = true;
				this.returnError(error);
			}, () => {
			});
		return rate;
	}

	private populateAndAddSummaryRowToList() {
		this.populateTotalConvertedCollateralAmountValue(this.cashCollateralsList, 'cash', 'other');
		this.populateTotalConvertedCollateralAmountValue(this.guaranteeCollateralsList, 'guarantee', 'other');
		// this.populateTotalConvertedCollateralAmountValue(this.otherIntangibleCollateralsList, 'other intangible', 'other');
		this.addSummaryRowForConvertedCollateralValue(this.cashCollateralsList, 'cash');
		this.addSummaryRowForConvertedCollateralValue(this.guaranteeCollateralsList, 'guarantee');
		// this.addSummaryRowForConvertedCollateralValue(this.otherIntangibleCollateralsList, 'other intangible');
	}

	private returnError(error: any) {
		if (error.status === 500) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 400) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 409) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 404) {
			return Observable.throw(new Error(error.status));
		}
	}

	/*Function to Add New Collateral*/
	redirectToAddNewCollateral() {
		this.collateralSummaryService.collateralOperation = 'ADD';
		this.router.navigate(['/newcollateral']);
	}

	getCollateralsList() {
		this.getCollateralsForDeposType();
		this.getCollateralsForGuaranteeType();
		this.getCollateralsForOtherIntagibleType();
	}

	private populateTotalConvertedCollateralAmountValue(list: any, type: string, condition?: string) {
		if (list !== undefined) {
			let localConvertedCollateralAmountCounter = 0;
			for (let i = 0; i < list.length; i++) {
				if (condition === 'other' && i === list.length - 1) {
					if (type === 'cash') {
						this.sumOfConvertedCollateralAmountValueForCash = localConvertedCollateralAmountCounter;
					} else if (type === 'guarantee') {
						this.sumOfConvertedCollateralAmountValueForGuarantee = localConvertedCollateralAmountCounter;
					} else {
						this.sumOfConvertedCollateralAmountValueForOtherIntagible = localConvertedCollateralAmountCounter;
					}
				} else {
					localConvertedCollateralAmountCounter = localConvertedCollateralAmountCounter
						+ parseFloat(list[i]['convertedCollateralValue']);
				}
			}
			if (type === 'cash') {
				this.sumOfConvertedCollateralAmountValueForCash = localConvertedCollateralAmountCounter;
			} else if (type === 'guarantee') {
				this.sumOfConvertedCollateralAmountValueForGuarantee = localConvertedCollateralAmountCounter;
			} else {
				this.sumOfConvertedCollateralAmountValueForOtherIntagible = localConvertedCollateralAmountCounter;
			}
			return list;
		}
	}

	addSummaryRowForConvertedCollateralValue(list: any, type: string) {
		if (list !== undefined) {
			if (list[list.length - 1]['checkboxId'] === 'Total') {
				if (type === 'cash') {
					list[list.length - 1]['convertedCollateralValue'] =
						this.sumOfConvertedCollateralAmountValueForCash;
				} else if (type === 'guarantee') {
					list[list.length - 1]['convertedCollateralValue'] =
						this.sumOfConvertedCollateralAmountValueForGuarantee;
				} else {
					list[list.length - 1]['convertedCollateralValue'] =
						this.sumOfConvertedCollateralAmountValueForOtherIntagible;
				}

			} else {
				if (list.length !== 0) {
					const tempJson = {
						'checkboxId': 'Total',
						'collateralId': '',
						'collateralCode': '',
						'owner': '',
						'originalCurrency': '',
						'beneficiaryID': '',
						'remarks': ''
					};
					if (type === 'cash') {
						tempJson['convertedCollateralValue'] = this.sumOfConvertedCollateralAmountValueForCash;
					} else if (type === 'guarantee') {
						tempJson['convertedCollateralValue'] = this.sumOfConvertedCollateralAmountValueForGuarantee;
					} else {
						tempJson['convertedCollateralValue'] = this.sumOfConvertedCollateralAmountValueForOtherIntagible;
					}
					list.push(tempJson);
				}
			}
			return list;
		}
	}

	currencyConverter(list: any, currencyDivider: any, toCurrency: string) {
		for (const key in list) {
			if (list !== undefined) {
				const rate = this.getStoredCurrencyRate(list[key]['originalCurrency'], toCurrency);
				if (rate !== undefined) {
					list[key]['convertedCollateralValue'] = (Math.abs(Number((list[key]['originalCollateralValue'])) * rate) / currencyDivider);
					this.populateAndAddSummaryRowToList();
				} else {
					let newRate;
					this.collateralsListService.getRateValues(list[key]['originalCurrency'], this.presentCurrencyFormat).subscribe(
						data => {
							if (data.length > 0) {
								if (data[0]['rate'] !== undefined) {
									newRate = data[0]['rate'];
									list[key]['convertedCollateralValue'] = (Math.abs(Number((list[key]['originalCollateralValue'])) * newRate) / currencyDivider);
									this.collateralSummaryService.rateConversionArray.push({
										from: list[key]['originalCurrency'],
										to: this.presentCurrencyFormat,
										rate: newRate,
									});
								}
							}
						}, error => {
							this.errorMsg = true;
							this.returnError(error);
						}, () => {
							this.populateAndAddSummaryRowToList();
						});
				}
			}
		}
		return list;
	}

	private getCollateralsForDeposType() {
		if (this.collateralSummaryService.deposCollateralDataFromService) {
			this.cashCollateralsList = this.getUsableCollateralsData(this.collateralSummaryService.deposCollateralDataFromService, 'DEPOS');
			this.setUpGrids('DEPOS');
			this.currencyConverter(this.cashCollateralsList, 1, this.presentCurrencyFormat);
			this.populateTotalConvertedCollateralAmountValue(this.cashCollateralsList, 'cash');
			this.addSummaryRowForConvertedCollateralValue(this.cashCollateralsList, 'cash');
		} else {
			this.divForCashCollateral = false;
		}
	}

	private getCollateralsForGuaranteeType() {
		if (this.collateralSummaryService.guarnCollateralDataFromService) {
			this.guaranteeCollateralsList = this.getUsableCollateralsData(this.collateralSummaryService.guarnCollateralDataFromService, 'GUARN');
			this.setUpGrids('GUARN');
			this.currencyConverter(this.guaranteeCollateralsList, 1, this.presentCurrencyFormat);
			this.populateTotalConvertedCollateralAmountValue(this.guaranteeCollateralsList, 'guarantee');
			this.addSummaryRowForConvertedCollateralValue(this.guaranteeCollateralsList, 'guarantee');
		} else {
			this.divForGuaranteeCollateral = false;
		}
	}

	/*TODO when Other intangible collateral type data will be available as of now commenting*/
	private getCollateralsForOtherIntagibleType() {
		this.collateralsListService.getCollateralsInfo('').subscribe(data => {
			// TODO when API is ready remove this mocked data
			this.otherIntangibleCollateralsList = [];
			this.setUpGrids('OTHER INTANGIBLE');
			// this.currencyConvert(this.otherIntangibleCollateralsList);
			// this.populateTotalConvertedCollateralAmountValue(this.otherIntangibleCollateralsList, 'other intangible');
			// this.addSummaryRowForConvertedCollateralValue(this.otherIntangibleCollateralsList, 'other intangible');
		}, error => {
			this.otherIntangibleCollateralsList = [];
			this.setUpGrids('OTHER INTANGIBLE');
			// TODO when API is ready remove this mocked data
			// this.currencyConvert(this.otherIntangibleCollateralsList);
			// this.populateTotalConvertedCollateralAmountValue(this.otherIntangibleCollateralsList, 'other intangible');
			// this.addSummaryRowForConvertedCollateralValue(this.otherIntangibleCollateralsList, 'other intangible');
			// this.returnError(error);
		});
	}

	private getUsableCollateralsData(fullJSONOfCollaterals: any, collateralType: string) {
		const list = [];
		for (const key in fullJSONOfCollaterals) {
			/* TODO Logic to map json to Object using JSON deserialize */
			if (fullJSONOfCollaterals[key].withdrawalDetail === null || !(fullJSONOfCollaterals[key].withdrawalDetail.withdraw)) {
				const temporaryJSONObj = {
					'collateralId': (fullJSONOfCollaterals[key].collateralId === undefined) ? '-' : fullJSONOfCollaterals[key].collateralId,
					'collateralCode': (fullJSONOfCollaterals[key].collateralCode === undefined) ? '-' : fullJSONOfCollaterals[key].collateralCode,
					'owner': '-',
					'originalCurrency': (fullJSONOfCollaterals[key].CollateralValuationDetail.collateralValue.ccy === undefined || fullJSONOfCollaterals[key].CollateralValuationDetail.collateralValue.ccy === '') ? 'SGD' :
						fullJSONOfCollaterals[key].CollateralValuationDetail.collateralValue.ccy,
					'originalCollateralValue': fullJSONOfCollaterals[key].CollateralValuationDetail.collateralValue.value,
					'displayOriginalCollateralValue': fullJSONOfCollaterals[key].CollateralValuationDetail.collateralValue.value,
					'convertedCollateralValue': fullJSONOfCollaterals[key].CollateralValuationDetail.collateralValue.value,
					'beneficiaryID': '-',
					'remarks': (fullJSONOfCollaterals[key].generalDetail.remarks === undefined || fullJSONOfCollaterals[key].generalDetail.remarks === '') ? '-' : fullJSONOfCollaterals[key].generalDetail.remarks
				};
				list.push(temporaryJSONObj);
			}
		}
		return list;
	}

	removeCollateralItem(selectedCollateral: any, index: number, collateralType: string) {
		if ((selectedCollateral === undefined) || (index < 0)) {
			return;
		}
		this.selectedCollateral = selectedCollateral;
		this.selectedCollateralIndex = index;
		this.selectedCollateralType = collateralType;
		this.showPopupDialogForRemoveConfirmation = true;
		this.dialogTitleNameConfirmation = 'Confirm Collateral Withdrawal';
	}

	closeEventFromRemoveCollateralPopupDialog() {
		this.showPopupDialogForRemoveConfirmation = false;
	}

	confirmCollateralRemoval() {
		//  call service to  remove item
		const collateralID = this.selectedCollateral['collateralId'];
		const collateralCode = this.selectedCollateral['collateralCode'];
		const collateralType = this.selectedCollateralType;
		if (this.withdrawReason !== undefined) {
			let reasonCode = '';
			if (this.withdrawReason === 'Not Applicable') {
				reasonCode = '01';
			} else {
				reasonCode = 'Other';
			}
			this.collateralsListService.withdrawCollateral(collateralID, reasonCode, collateralType).subscribe(data => {
				if (data) {
					// if we get success remove from Grids
					this.removeCollateralFromGrid(this.selectedCollateralIndex, collateralType);
					this.closeEventFromRemoveCollateralPopupDialog();   // uncomment later when service works
				}
			},
				error => {
					/*TODO Remove this logic when API will be available*/
					this.removeCollateralFromGrid(this.selectedCollateralIndex, collateralType);
					this.closeEventFromRemoveCollateralPopupDialog();
					// this.errMsg = true;
					// this.errorMessage = 'Oops! something went wrong.    ' + error._body;
				}
			);

			this.closeEventFromRemoveCollateralPopupDialog();    // TBD remove later
		} else {
			return;
		}
	}

	removeCollateralFromGrid(selectedCollateralIndex: number, collateralType: string) {
		// based on the  Collateral Type remove teh record from Grid
		//  TBD change the Collateraltype as per Actual JSON from Service <OTHER_TANGBLE> to be changed

		switch (collateralType) {
			case 'DEPOS':
				this.cashCollateralsList.splice(this.selectedCollateralIndex, 1);
				this.populateAndAddSummaryRowToList();
				this.setUpGrids('DEPOS');
				this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
					'A record of Deposit Collateral has been successfully withdrawn.',
					'', '');
				break;
			case 'GUARN':
				this.guaranteeCollateralsList.splice(this.selectedCollateralIndex, 1);
				this.populateAndAddSummaryRowToList();
				this.setUpGrids('GUARN');
				this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
					'A record of Guarantee Collateral has been successfully withdrawn.',
					'', '');
				break;
			case 'OTHER_TANGIBLE':
				this.otherIntangibleCollateralsList.splice(this.selectedCollateralIndex, 1);
				this.populateAndAddSummaryRowToList();
				this.setUpGrids('OTHER INTANGIBLE');
				this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
					'A record of Other Tangible Collateral has been successfully withdrawn.',
					'', '');
				break;
			default:
				return;
		}
	}

	selectionChangeEventForWithdrawSelect(reason: any) {
		this.withdrawReason = reason;
	}

	private setUpGrids(collateralType?: string) {

		if (collateralType === 'DEPOS') {
			if (this.cashCollateralsList.length === 0 || this.cashCollateralsList[0]['checkboxId'] === 'Total') {
				this.divForCashCollateral = false;
			}
		}
		if (collateralType === 'GUARN') {
			if (this.guaranteeCollateralsList.length === 0 || this.guaranteeCollateralsList[0]['checkboxId'] === 'Total') {
				this.divForGuaranteeCollateral = false;
			}
		}

		if (collateralType === 'OTHER INTANGIBLE') {
			if (this.otherIntangibleCollateralsList.length === 0 || this.otherIntangibleCollateralsList[0]['checkboxId'] === 'Total') {
				this.divForOtherIntangibleCollateral = false;
			}
		}
	}

	editCollateralItem(selectedCollateral: any, index: number, collateralType: string) {
		this.collateralSummaryService.collateralOperation = 'EDIT';
		if (!selectedCollateral) {
			return;
		}
		const selectedCollateralId = selectedCollateral.collateralId;
		let deposTypeCollateralToEdit;
		let guarnTypeCollateralToEdit;
		switch (collateralType) {
			case 'DEPOS':
				const deposCollateralJson = this.collateralSummaryService.deposCollateralDataFromService;
				if (deposCollateralJson) {
					for (const key in deposCollateralJson) {
						if (deposCollateralJson[key].collateralId === selectedCollateralId) {
							deposTypeCollateralToEdit = deposCollateralJson[key];
						}
					}
				}
				this.collateralSummaryService.selectedCollateral = deposTypeCollateralToEdit;
				this.collateralSummaryService.selectedCollateralType = collateralType;
				break;
			case 'GUARN':
				const guarnCollateralJson = this.collateralSummaryService.guarnCollateralDataFromService;
				if (guarnCollateralJson) {
					for (const key in guarnCollateralJson) {
						if (guarnCollateralJson[key].collateralId === selectedCollateralId) {
							guarnTypeCollateralToEdit = guarnCollateralJson[key];
						}
					}
				}
				this.collateralSummaryService.selectedCollateral = guarnTypeCollateralToEdit;
				this.collateralSummaryService.selectedCollateralType = collateralType;
				break;
			default:
				return;
		}
		const filter = {where: {collateralType: collateralType }};
		this.collateralsListService.getCollateralTypes(filter).subscribe(data => {
				this.collateralSummaryService.collateralTypes = data;
				this.router.navigate(['/newcollateral']);
			},
			error => {
			}
		);
	}

	toggleCheckBox(typeOfCollateral: string, $event: any) {
		if ($event.target.checked) {
			switch (typeOfCollateral) {
				case 'DEPOS':
					this.checkDeposTypeCol = true;
					break;
				case 'GUARN':
					this.checkGuarnTypeCol = true;
					break;
				default:
					return;
			}
		} else {
			switch (typeOfCollateral) {
				case 'DEPOS':
					this.checkDeposTypeCol = false;
					break;
				case 'GUARN':
					this.checkGuarnTypeCol = false;
					break;
				default:
					return;
			}
		}
	}

	getData(type: any, data: any, event: any) {
		/*TODO Click event when user clicks on checkbox - design and functionality not yet defined*/
	}
}
