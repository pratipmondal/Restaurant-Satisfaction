import { CollateralsListService } from './collaterals-list.component.service';
import { environment } from '../../../environments/environment';
import { MockCollateralData } from '../collateral-summary/collateral-summary-mock-data';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod } from '@angular/http';
import { fakeAsync, inject, TestBed } from '@angular/core/testing';

describe('CollateralsListService', () => {

	let collateralsListService: CollateralsListService = null;
	const ratesUrl = environment.apiBaseUrl + environment.apiToGetRates;
	const currencyUrl = environment.apiBaseUrl + environment.apiToGetCurrencyList;
	let mockBackend: MockBackend = null;
	const data = MockCollateralData;
	const currencyDropdownList = [{code: 'INR'}, {code: 'SGD'}, {code: 'USD'}];
	const mockRateValues = [{rate: 10}, {rate: 17}, {rate: 18}];
	const currencyRateValue = environment.apiBaseUrl + 'rate';

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				CollateralsListService
			],
			imports: [HttpModule]
		});
	});

	beforeEach(
		inject([CollateralsListService, MockBackend], (service: CollateralsListService, backend: MockBackend) => {
			collateralsListService = service;
			mockBackend = backend;
		})
	);

	it('should Create Collaterals List service ', inject([CollateralsListService], (service: CollateralsListService) => {
		expect(service).toBeTruthy();
	}));

	it('Should connect API for currency dropdownlist', fakeAsync(() => {
		spyOn(collateralsListService, 'getCurrency');
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(currencyUrl);
		});
	}));

	it('Should connect API for currency rates', fakeAsync(() => {
		spyOn(collateralsListService, 'getRateValues');
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(ratesUrl);
		});
	}));
	it('should get response from currency API ', () => {
		spyOn(collateralsListService, 'getCurrency').and.callFake(function () {
			return currencyDropdownList;
		});
		expect(collateralsListService.getCurrency()).toEqual(currencyDropdownList);
	});

	it('should get response from rates API ', () => {
		spyOn(collateralsListService, 'getRateValues').and.callFake(function () {
			return mockRateValues;
		});
		expect(collateralsListService.getRateValues('SGD', 'INR')).toEqual(mockRateValues);
	});

	it('should get response from withdraw of collateral from Collateral list service', () => {
		spyOn(collateralsListService, 'withdrawCollateral').and.callFake(function () {
			return 'success';
		});
		expect(collateralsListService.withdrawCollateral('COLL3158', '01', 'GUARN')).toEqual('success');
	});
});
