import { CUSTOM_ELEMENTS_SCHEMA, ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { GridModule } from '@progress/kendo-angular-grid';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { CommonUIModule } from '../../common/commonUI.module';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { ToggleButtonModule } from '../../common/toggle-button/toggle-button.module';
import { IntlModule } from '@progress/kendo-angular-intl';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { CollateralsListComponent } from './collaterals-list.component';
import { CollateralsListService } from './collaterals-list.component.service';
import { RouterModule } from '@angular/router';
import { UserRouteAccessService } from '../../shared/auth/user-route-access-service';
import { CounterpartyDetailsModule } from '../../shared/counterparty-details/counterparty-details.module';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
	imports: [RouterModule.forChild([{
		path: 'viewcollaterals',
		component: CollateralsListComponent,
		canActivate: [UserRouteAccessService]
	}]),
		CommonModule, BrowserModule, GridModule, DialogModule,
		ButtonsModule, InputsModule, ReactiveFormsModule, AutoCompleteModule,
		DateInputsModule, CommonUIModule, PopupDialogModule, ToggleButtonModule,
		IntlModule, ClsSharedCommonModule, DropDownsModule, CounterpartyDetailsModule, CustomPanelModule, BrowserAnimationsModule],
	declarations: [CollateralsListComponent],
	providers: [CollateralsListService],
	exports: [CollateralsListComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class CollateralsListModule {
	public static forRoot(): ModuleWithProviders {
		return {ngModule: CollateralsListModule, providers: []};
	}
}
