import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import * as _ from 'underscore';
import { NewCollateralService } from 'app/collateral/new-collateral/new-collateral.service';
import { CollateralService } from 'app/collateral/collateral.service';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { FacilityLinkageDataService } from 'app/collateral/facility-linkage-data/facility-linkage-data.service';
import { Params } from '@angular/router';
import { CollateralSummaryService } from 'app/collateral/collateral-summary/collateral-summary.service';

@Component({
	selector: 'facility-linkage-data',
	templateUrl: './facility-linkage-data.html',
	styleUrls: ['./facility-linkage.scss']
})
export class FacilityLinkageDataComponent implements OnInit {
	limitsData: any[];
	limitsForm: FormGroup;
	selectedData: any[] = [];
	parsedData: any[] = [];
	keys: string[];
	checkedKeys: any = [];
	checkedSelectedKeys: any = [];
	totalValues: any[] = [];
	@Input()
	gcin: { label?: any, value?: any }= {};

	constructor(private route: ActivatedRoute, private _fb: FormBuilder, private newCollateralService: NewCollateralService, private  collateralService: CollateralService, private facilityLinkageDataService: FacilityLinkageDataService, private router: Router, private collateralSummaryService: CollateralSummaryService) {
		this.limitsForm = this._fb.group({checkLimits: new FormControl(null)});
		this.route.queryParams.subscribe((params: Params) => {
			 this.gcin.label = params['gcinLabel'];
			 this.gcin.value = params['gcinValue'];
			console.log(this.gcin);
		});
	}

	ngOnInit() {

		// this.gcin.label = this.route.queryParamMap.map(params => params.get('gcinLabel'));
		// this.gcin.value = this.route.queryParamMap.map(params => params.get('gcinValue'));

		this.collateralService.getLimitsByLimitTypeId({where: {limitTypeId: this.gcin.value}}).subscribe(data => {
				this.PrepareData(data);
			},
			error => {
			}
		);
	}

	PrepareData(limitData: any) {
		this.limitsData = limitData;

		this.limitsData = _.map(this.limitsData, function (obj) {
			return ({
				limitId: obj.limitId,
				limitName: obj.description,
				riskTaker: obj.riskTaker,
				approved: obj.approvedLimit.value,
				activated: obj.activatedLimit.value,
				totalExposure: obj.totalExposure,
				facilityRiskRating: obj.facilityRiskRating,
				tenor: obj.tenorYears,
				remarks: obj.remarks,
				riskType: obj.riskType,
				limitTypeId: obj.limitTypeId
			});
		});
		this.limitsData = _.groupBy(this.limitsData, function (obj) {
			return obj.riskType;
		});

		this.keys = Object.keys(this.limitsData);
		this.checkedKeys = _.map(this.keys, function (key) {
			return false;
		});
		this.checkedSelectedKeys = _.map(this.keys, function (key) {
			return false;
		});
		;
		const totalValues: any[] = [];

		this.totalValues = _.map(this.limitsData, function (element, index, list) {
			if (element.length > 1) {
				return _.reduce(element, function (mem, ele) {
					return {
						activated: mem.activated + ele.activated,
						approved: mem.approved + ele.approved,
						totalExposure: mem.totalExposure + ele.totalExposure
					};
				});
			} else {
				return {
					activated: element[0].activated,
					approved: element[0].approved,
					totalExposure: element[0].totalExposure
				};
			}
		});
	}

	linkCollateral() {
		/*
		 const facilityForm = <FormGroup> this.collateralService.getCollateralForm().controls['facilityLinkage'];
		 facilityForm.get('facilityLinkage').setValue(this.selectedData);
		 this.newCollateralService.setFacilityLinkageStatus(true);*/
		/*const navigationExtras: NavigationExtras = {
		 relativeTo: this.route

		 };*/
		// this.collateralService.getnewCollateralForm.value.
		// this.router.navigate(['../'], navigationExtras );
		// console.log(this.limitsForm.get('checkLimits').value);
	this.facilityLinkageDataService.linkageData = 'Test';
		this.facilityLinkageDataService.setLinkages(this.selectedData);

		const navigationExtras: NavigationExtras = {
			queryParams: {'gcin': this.gcin.value}
		};
		this.collateralSummaryService.collateralOperation = 'FACILITY LINKAGE';
		this.router.navigate(['./newcollateral'], navigationExtras);

	}

	getData(index: any, data: any, event: any) {

		if (event.target.checked) {
			this.selectedData.push(data);
		} else {
			this.selectedData.splice(this.selectedData.indexOf(data), 1);
			if (this.checkedSelectedKeys[index]) {
				this.checkedSelectedKeys[index] = false;
			}
		}
		console.log(this.selectedData);
	}

	toggleCheckBox(i: any, event: any) {
		this.checkedKeys[i] = event.target.checked;
		if (event.target.checked) {
			this.limitsData[this.keys[i]].forEach(element => {
				if (this.selectedData.indexOf(element) === -1) {
					this.selectedData.push(element);
				}
			});
		} else {
			this.limitsData[this.keys[i]].forEach(element => {
				if (this.selectedData.indexOf(element) !== -1) {
					this.selectedData.splice(this.selectedData.indexOf(element), 1);
				}
			});
		}
		console.log(this.selectedData);
	}
	navigateBack()
	{
		this.collateralSummaryService.collateralOperation = 'FACILITY LINKAGE';
		this.router.navigate(['./newcollateral']);
	}
}

