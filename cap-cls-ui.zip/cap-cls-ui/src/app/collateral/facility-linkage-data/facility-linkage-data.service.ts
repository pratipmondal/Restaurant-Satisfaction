import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class FacilityLinkageDataService {

	private linkages: any = [];
	linkageData: any;

	setLinkages(linkageData: any) {
		this.linkages = [];
		this.linkages = linkageData;
	}

	getLinkages(): any {
		return this.linkages;
	}
}
