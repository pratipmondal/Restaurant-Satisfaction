import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CurrencyDropdownComponent } from '../../common/currency-dropdown/currency-dropdown.component';
import { CollateralService } from '../collateral.service';
import { CollateralValuationDetail } from '../model/collateral';
import { CurrencyFormatPipe } from '../../shared/currency-pipe/currency-pipe';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'collateral-valuation',
    templateUrl: 'valuation.html',
    styleUrls: [
        './valuation.component.scss'
    ]
})
export class ValuationComponent implements OnInit {

    // forms
    @Input()
    public valuationForm: FormGroup;

    // form Objects
    valuationObj: any;
    private chargeObj: any;
    private valueFromSelectedButton: any;
    private evt: any;
    collateralType: string;
    private formatter = new CurrencyFormatPipe();

    // formControl Names
    private extChrgAmt_Amt: string = 'extChrgAmt_Amt';
    private extChrgAmt_Ccy: string = 'extChrgAmt_Ccy';
    private collValAmt_Amt: string = 'collValAmt_Amt';
    private collValAmt_Ccy: string = 'collValAmt_Ccy';
    private finalCollAmt_Amt: string = 'finalCollAmt_Amt';
    private finalCollAmt_Ccy: string = 'finalCollAmt_Ccy';
    private totApporVal_Amt: string = 'totApporVal_Amt';
    private totApporVal_Ccy: string = 'totApporVal_Ccy';
    private balApporAmt_Amt: string = 'balApporAmt_Amt';
    private balApporAmt_Ccy: string = 'balApporAmt_Ccy';
    private apportionMethod: string = 'value1'; // default TYPE amount

    message: any;
    subscription: Subscription;

    ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscription.unsubscribe();
    }

    constructor(private _fb: FormBuilder, private collateralService: CollateralService) {
        this.subscription = this.collateralService.getMessage().subscribe(message => { this.message = message; });
    }

    ngOnInit() {
        this.initvaluationForm();
        this.collateralType = this.collateralService.selectedCollateralType;
        // init apportion Object
        this.initvaluationObj();
        // external Charge Amount
        this.populateExternalChargeAmount();
        // Collateral value
        this.populateCollateralValue();
        // Final Collateral value
        this.populateFinalCollateralValue();
        // total apportoion value
        this.populateTotalApportionValue();
        // Balance Apportion Amount
        this.populateBalanceApportionAmount();
        // apportioning method
        this.populateApportionMethod();
    }

    /**
     * initialize the form
     */
    initvaluationForm() {
        if (!this.valuationForm) {
            this.valuationForm = this._fb.group({});
        }
    }

    /**
     * initialize the Apportion Objcet from which to populate the Controls/ Components
     */
    initvaluationObj() {
        this.valuationObj = this.collateralService.getCollateral().CollateralValuationDetail;
        if (!this.valuationObj) {
            this.valuationObj = new CollateralValuationDetail();
        }
    }

    /**
     * set the values for balance apportioning value currency and amount
     */
    populateBalanceApportionAmount() {
        if (this.valuationForm.controls[this.balApporAmt_Ccy]) {
            this.valuationForm.controls[this.balApporAmt_Ccy].setValue(this.valuationObj.balanceApportionableAmt.ccy);
        }
        if (!this.valuationForm.controls[this.balApporAmt_Ccy]) {
            this.valuationForm.addControl(this.balApporAmt_Ccy, new FormControl(this.valuationObj.balanceApportionableAmt.ccy));
        }
        if (this.valuationForm.controls[this.balApporAmt_Amt]) {
            this.valuationForm.controls[this.balApporAmt_Amt].setValue(this.valuationObj.balanceApportionableAmt.value.toString());
        }
        if (!this.valuationForm.controls[this.balApporAmt_Amt]) {
            this.valuationForm.addControl(this.balApporAmt_Amt, new FormControl({ value: this.valuationObj.balanceApportionableAmt.value.toString(), disabled: true }));
        }
    }

    /**
     * set the value for apportioning method
     */
    populateApportionMethod() {
        if (this.valuationObj.apportioningMethod && this.valuationObj.apportioningMethod.toUpperCase() === 'A') {
            this.apportionMethod = 'value1';
        }
        if (this.valuationObj.apportioningMethod && this.valuationObj.apportioningMethod.toUpperCase() === 'P') {
            this.apportionMethod = 'value2';
        }
        this.valuationForm.addControl(this.apportionMethod, new FormControl({ value: this.valuationObj.apportioningMethod, disabled: true }));
    }

    /**
     * set the values for total apportioned value currency and amount
     */
    populateTotalApportionValue() {
        if (this.valuationForm.controls[this.totApporVal_Ccy]) {
            this.valuationForm.controls[this.totApporVal_Ccy].setValue(this.valuationObj.totalApportionedValue.ccy);
        }
        if (!this.valuationForm.controls[this.totApporVal_Ccy]) {
            this.valuationForm.addControl(this.totApporVal_Ccy, new FormControl(this.valuationObj.totalApportionedValue.ccy));
        }
        if (this.valuationForm.controls[this.totApporVal_Amt]) {
            this.valuationForm.controls[this.totApporVal_Amt].setValue(this.valuationObj.totalApportionedValue.value.toString());
        }
        if (!this.valuationForm.controls[this.totApporVal_Amt]) {
            this.valuationForm.addControl(this.totApporVal_Amt, new FormControl({ value: this.valuationObj.totalApportionedValue.value.toString(), disabled: true }));
        }
    }

    /**
     * set the values for final collateral value currency and amount
     */
    populateFinalCollateralValue() {
        if (this.valuationForm.controls[this.finalCollAmt_Ccy]) {
            this.valuationForm.controls[this.finalCollAmt_Ccy].setValue(this.valuationObj.finalCollateralValue.ccy);
        }
        if (!this.valuationForm.controls[this.finalCollAmt_Ccy]) {
            this.valuationForm.addControl(this.finalCollAmt_Ccy, new FormControl(this.valuationObj.finalCollateralValue.ccy));
        }
        if (this.valuationForm.controls[this.finalCollAmt_Amt]) {
            this.valuationForm.controls[this.finalCollAmt_Amt].setValue(this.valuationObj.finalCollateralValue.value.toString());
        }
        if (!this.valuationForm.controls[this.finalCollAmt_Amt]) {
            this.valuationForm.addControl(this.finalCollAmt_Amt, new FormControl({ value: this.valuationObj.finalCollateralValue.value.toString(), disabled: true }));
        }
    }

    /**
     * set the values for collateral value currency and amount
     */
    populateCollateralValue() {
        if (this.valuationForm.controls[this.collValAmt_Ccy]) {
            this.valuationForm.controls[this.collValAmt_Ccy].setValue(this.valuationObj.collateralValue.ccy);
        }
        if (!this.valuationForm.controls[this.collValAmt_Ccy]) {
            this.valuationForm.addControl(this.collValAmt_Ccy, new FormControl(this.valuationObj.collateralValue.ccy));
        }
        if (this.valuationForm.controls[this.collValAmt_Amt]) {
            this.valuationForm.controls[this.collValAmt_Amt].setValue(this.valuationObj.collateralValue.value.toString());
        }
        if (!this.valuationForm.controls[this.collValAmt_Amt]) {
            this.valuationForm.addControl(this.collValAmt_Amt, new FormControl({ value: this.valuationObj.collateralValue.value.toString(), disabled: true }));
        }
    }

    /**
     * set the values for external charge value currency and amount
     */
    populateExternalChargeAmount() {
        if (this.collateralType === 'GUARN') {
            return;
        }
        if (this.valuationForm.controls[this.extChrgAmt_Ccy]) {
            this.valuationForm.controls[this.extChrgAmt_Ccy].setValue(this.valuationObj.externalChargeAmt.ccy);
        }
        if (!this.valuationForm.controls[this.extChrgAmt_Ccy]) {
            this.valuationForm.addControl(this.extChrgAmt_Ccy, new FormControl({ value: this.valuationObj.externalChargeAmt.ccy, disabled: true }));
        }
        if (this.valuationForm.controls[this.extChrgAmt_Amt]) {
            this.valuationForm.controls[this.extChrgAmt_Amt].setValue(this.valuationObj.externalChargeAmt.value.toString());
        }
        if (!this.valuationForm.controls[this.extChrgAmt_Amt]) {
            this.valuationForm.addControl(this.extChrgAmt_Amt, new FormControl({ value: this.valuationObj.externalChargeAmt.value.toString(), disabled: true }));
        }
    }

    /**
     * sets the value coming from toggle button into the underlying apportioning method
     * @param valueFromSelectedButton the value of change in toggle button
     */
    eventFromToggleButton(valueFromSelectedButton: any) {
        if (valueFromSelectedButton) {
            this.valuationForm.get(this.apportionMethod).setValue(valueFromSelectedButton === 'value1' ? 'A' : 'P');
        }
    }

    editValueAmt($event){
        this.collateralService.sendMessage('Collateral Details');
        console.log('Routing to General Details for editing collateral Value');
    }
}
