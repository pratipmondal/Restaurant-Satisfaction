import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { GridModule } from '@progress/kendo-angular-grid';
import { ValuationComponent } from './valuation.component';
import {LoaderModule} from '../../shared/progression/loader/loader.module';
import {RouterModule} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {ButtonsModule} from '@progress/kendo-angular-buttons';
import {ClsSharedCommonModule} from '../../shared/shared-common.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
// import {BeneficiaryItemModel} from './beneficiary.model';
import { CurrencyDropdownComponent } from '../../common/currency-dropdown/currency-dropdown.component';
import { ToggleButtonComponent } from '../../common/toggle-button/toggle-button.component';
import { ToggleButtonModule } from '../../common/toggle-button/toggle-button.module';
import { CommonUIModule } from '../../common/commonUI.module';

@NgModule({
    imports: [   CommonModule,
        BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
        BrowserAnimationsModule, DropDownsModule, AutoCompleteModule, CommonUIModule,
        LoaderModule, GridModule, ClsSharedCommonModule, PopupDialogModule,
        ToggleButtonModule,
    ],
    declarations: [
        ValuationComponent
    ],
    exports: [ ValuationComponent, ToggleButtonComponent ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ValuationModule {
}
