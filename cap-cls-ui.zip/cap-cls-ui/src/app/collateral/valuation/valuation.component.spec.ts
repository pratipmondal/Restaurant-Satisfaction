import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CollateralService } from '../collateral.service';
import { CollateralValuationDetail } from '../model/collateral';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { GridModule } from '@progress/kendo-angular-grid';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { CurrencyDropdownComponent } from '../../common/currency-dropdown/currency-dropdown.component';
import { ToggleButtonComponent } from '../../common/toggle-button/toggle-button.component';
import { ToggleButtonModule } from '../../common/toggle-button/toggle-button.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { ValuationComponent } from './valuation.component';
import { Response, ResponseOptions, ResponseType } from '@angular/http';
import { CurrencyDropdownService } from '../../common/currency-dropdown/currency-dropdown.service';
import { Collateral, ExternalChargeAmt, CollateralValue, FinalCollateralValue, TotalApportionedValue, BalanceApportionableAmt } from '../model/collateral';
class MockCollateralService {
    selectedCollateralType = 'GUARN';
    getCollateral() {
        const collateral = new Collateral();
        collateral.CollateralValuationDetail = {
            loanToValuePcnt: 0,
            externalChargeAmt: {
                value: 0,
                ccy: 'SGD'
            },
            collateralValue: {
                value: 100,
                ccy: 'SGD'
            },
            finalCollateralValue: {
                value: 100,
                ccy: 'SGD'
            },
            apportioningMethod: 'A',
            totalApportionedValue: {
                value: 10,
                ccy: 'SGD'
            },
            balanceApportionableAmt: {
                value: 90,
                ccy: 'SGD'
            }
        };
        return collateral;
    }
}

class MockCurrencyService {
    getCurrencies(filter?: any) {
        return {
            body: [
                {
                    'code': 'SGD',
                    'description': 'SGD Currency',
                    'id': '5f30e506-a276-4865-95aa-210667ded1a8'
                },
                {
                    'code': 'EUR',
                    'description': 'EUR Currency',
                    'id': '6acc19da-6c8a-441d-ba8b-7d41efbe9ab9'
                }],
            subscribe: function (data?: any) {
            }
        };
    }
}

describe('Component : ApportionComp', () => {
    let apportionComp: ValuationComponent;
    let fixture: ComponentFixture<ValuationComponent>;

    beforeEach(async(() => {
        window['jasmine'].DEFAULT_TIMEOUT_INTERVAL = 10000;
        TestBed.configureTestingModule({
            imports: [CommonModule,
                BrowserModule, FormsModule, ReactiveFormsModule, ButtonsModule,
                BrowserAnimationsModule, DropDownsModule, AutoCompleteModule, CommonUIModule,
                LoaderModule, GridModule, ClsSharedCommonModule, PopupDialogModule,
                ToggleButtonModule
            ],
            declarations: [
                ValuationComponent
            ],
            providers: [{ provide: CollateralService, useClass: MockCollateralService }, { provide: CurrencyDropdownService, useClass: MockCurrencyService }],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents().then(() => {
                fixture = TestBed.createComponent(ValuationComponent);
                apportionComp = fixture.componentInstance;
                apportionComp.ngOnInit();
                fixture.detectChanges();
            });
    }));

    // should create component
    it('should create the apportion component', async(() => {
        fixture.detectChanges();
        expect(apportionComp).toBeTruthy();
    }));

    // initvaluationForm
    it('should init the valuationForm', async(() => {
        apportionComp.initvaluationForm();
        expect(apportionComp.valuationForm).toBeTruthy();
    }));

    // initvaluationObj
    it('should init the apportion Object', async(() => {
        apportionComp.initvaluationObj();
        expect(apportionComp.valuationObj).toBeTruthy();
    }));

    // populateBalanceApportionAmount
    it('should populate balance apportion Amount', async(() => {
        apportionComp.valuationForm = undefined;
        apportionComp.initvaluationForm();
        apportionComp.populateBalanceApportionAmount();
        expect(apportionComp.valuationForm.controls['balApporAmt_Ccy']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['balApporAmt_Amt']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['balApporAmt_Ccy'].value).toBe('SGD');
        expect(apportionComp.valuationForm.controls['balApporAmt_Amt'].value.toString()).toBe('90');
    }));

    // populateApportionMethod: A
    it('should populate apportioning method: A', async(() => {
        apportionComp.populateApportionMethod();
        expect(apportionComp.valuationForm.controls['value1']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['value1'].value).toBe('A');
    }));

    // populateApportionMethod: P
    it('should populate apportioning method: P', async(() => {
        apportionComp.valuationObj.apportioningMethod = 'P';
        apportionComp.populateApportionMethod();
        expect(apportionComp.valuationForm.controls['value2']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['value2'].value).toBe('P');
    }));

    // populateTotalApportionValue
    it('should populate apportion Value', async(() => {
        apportionComp.valuationForm = undefined;
        apportionComp.initvaluationForm();
        apportionComp.populateTotalApportionValue();
        expect(apportionComp.valuationForm.controls['totApporVal_Ccy']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['totApporVal_Amt']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['totApporVal_Ccy'].value).toBe('SGD');
        expect(apportionComp.valuationForm.controls['totApporVal_Amt'].value.toString()).toBe('10');
    }));

    // populateFinalCollateralValue
    it('should populate final collateral Value', async(() => {
        apportionComp.valuationForm = undefined;
        apportionComp.initvaluationForm();
        apportionComp.populateFinalCollateralValue();
        expect(apportionComp.valuationForm.controls['finalCollAmt_Ccy']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['finalCollAmt_Amt']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['finalCollAmt_Ccy'].value).toBe('SGD');
        expect(apportionComp.valuationForm.controls['finalCollAmt_Amt'].value.toString()).toBe('100');
    }));

    // populateCollateralValue
    it('should populate collateral Value', async(() => {
        apportionComp.valuationForm = undefined;
        apportionComp.initvaluationForm();
        apportionComp.populateCollateralValue();
        expect(apportionComp.valuationForm.controls['collValAmt_Ccy']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['collValAmt_Amt']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['collValAmt_Ccy'].value).toBe('SGD');
        expect(apportionComp.valuationForm.controls['collValAmt_Amt'].value.toString()).toBe('100');
    }));

    // populateExternalChargeAmount : DEPOS
    it('should populate external charge Value:DEPOS', async(() => {
        apportionComp.collateralType = 'DEPOS';
        apportionComp.valuationForm = undefined;
        apportionComp.initvaluationForm();
        apportionComp.populateExternalChargeAmount();
        expect(apportionComp.valuationForm.controls['extChrgAmt_Ccy']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['extChrgAmt_Amt']).toBeTruthy();
        expect(apportionComp.valuationForm.controls['extChrgAmt_Ccy'].value).toBe('SGD');
        expect(apportionComp.valuationForm.controls['extChrgAmt_Amt'].value.toString()).toBe('0');
    }));

    // populateExternalChargeAmount : GUARN
    it('should NOT populate external charge Value:GUARN', async(() => {
        apportionComp.collateralType = 'GUARN';
        apportionComp.valuationForm = undefined;
        apportionComp.initvaluationForm();
        apportionComp.populateExternalChargeAmount();
        expect(apportionComp.valuationForm.controls['extChrgAmt_Ccy']).toBeUndefined();
        expect(apportionComp.valuationForm.controls['extChrgAmt_Amt']).toBeUndefined();
    }));

    // eventFromToggleButton
    it('should set/modify value in apportioning method', async(() => {
        apportionComp.eventFromToggleButton('value2');
        expect(apportionComp.valuationForm.controls['value1'].value).toBe('P');
    }));

    // eventFromToggleButton
    it('should NOT set/modify value in apportioning method', async(() => {
        apportionComp.eventFromToggleButton(null);
        expect(apportionComp.valuationForm.controls['value1'].value).toBe('A');
    }));

});
