import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { OauthService } from '../shared';
import { CollateralReponse } from './collateralData';
import { CollateralService } from "./collateral.service";
import { NewCollateralComponent } from './new-collateral/new-collateral.component';

@Component({
    selector: 'collateral',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './collateral.html',
    styleUrls: ['./collateral.component.scss']

})
export class CollateralComponent implements OnInit {

    public newCollateralForm: FormGroup;
    constructor(private oauthService: OauthService) {
    }

    ngOnInit(): void {


        console.log('Colleteral response', CollateralReponse.GUARN);
    }

}
