import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { DropDownsModule, ComboBoxModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { ClsSharedCommonModule } from '../../shared/';
import { CounterpartyDetailsModule } from '../../shared/counterparty-details/counterparty-details.module';

import { NewCollateralComponent } from './new-collateral.component';
import { NEWCOLLATERAL_DATA_ROUTE } from './new-collateral.route';
import { SpecificDetailsModule } from '../specific-details/specific-details.module';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';

import { BeneficiaryModule } from '../beneficiary/beneficiary.module';
import { DocumentModule } from '../document/document.module';
import { OwnershipModule } from '../ownership/ownership.module';
import { ChargeModule } from '../charge/charge.module';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { HeadErrorPanelModule } from '../../common/head-error-panel/head-error-panel.module';
import { TabbedWizardModule } from '../../common/tabbed-wizard/tabbed-wizard.module';
import { CollateralService } from '../collateral.service';
import { AutoSaveService } from '../../common/autosave/auto-save.service';
import { CommonUIModule } from '../../common/commonUI.module';
import { CollateralSummaryModule } from '../collateral-summary/collateral-summary.module';
import { SummaryModule } from '../summary/summary.module';
import { SummarySubsectionModule } from '../summary/summary-subsection/summary-subsection.module';
import { CollateralDetailsComponent } from '../collateral-details/collateral-details.component';
import { CollateralIDComponent } from '../collateral-id/collateral-id.component';
import { GeneralDetailsComponent } from '../collateral-details/general-details/general-details.component';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { ValuationModule } from '../valuation/valuation.module';
import { ToggleButtonModule } from 'app/common/toggle-button/toggle-button.module';
import { FacilityLinkageDataService } from '../facility-linkage-data/facility-linkage-data.service';
import { FacilityLinkageDataComponent } from '../facility-linkage-data/facility-linkage-data.component';
import { NewCollateralService } from './new-collateral.service';
import { CollateralGuarantorModule } from '../collateral-guarantor/collateral-guarantor.module';

@NgModule({
	imports: [
		RouterModule.forChild(NEWCOLLATERAL_DATA_ROUTE),
		CommonModule, ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
		DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule, ValuationModule,
		ClsSharedCommonModule, CounterpartyDetailsModule, CommonUIModule, PopupDialogModule, SpecificDetailsModule,
		BeneficiaryModule, DocumentModule, OwnershipModule, ChargeModule, CustomPanelModule, TabbedWizardModule,
		SummaryModule, SummarySubsectionModule, DateInputsModule, ToggleButtonModule, CollateralSummaryModule,
		HeadErrorPanelModule, CollateralGuarantorModule

	],
	declarations: [NewCollateralComponent, CollateralDetailsComponent, CollateralIDComponent, GeneralDetailsComponent, FacilityLinkageDataComponent],
	providers: [CollateralService, NewCollateralService, FacilityLinkageDataService],
	exports: [NewCollateralComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class NewCollateralModule {
}
