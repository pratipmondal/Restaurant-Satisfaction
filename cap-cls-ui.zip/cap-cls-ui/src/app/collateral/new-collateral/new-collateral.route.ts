import { Routes } from '@angular/router';
import { NewCollateralComponent } from './new-collateral.component';
import { UserRouteAccessService } from '../../shared';
import { FacilityLinkageDataComponent } from '../facility-linkage-data/facility-linkage-data.component';
export const NEWCOLLATERAL_DATA_ROUTE: Routes = [{
	path: 'newcollateral',
	component: NewCollateralComponent,
	canActivate: [UserRouteAccessService]
},
	{path: 'facilityLinkage',
		component: FacilityLinkageDataComponent,
		canActivate: [UserRouteAccessService]}
];
