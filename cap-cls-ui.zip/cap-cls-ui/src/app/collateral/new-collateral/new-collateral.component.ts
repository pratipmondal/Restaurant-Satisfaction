import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { CollateralService } from '../collateral.service';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { CollateralReponse } from '../collateralData';
import { Observable } from 'rxjs/Observable';
import { CollateralType, CollateralCode } from '../model';
import { evJson } from '../mainData';
import { AutoSaveService } from '../../common/autosave/auto-save.service';
import { NewCollateralService } from './new-collateral.service';
import { Subscription } from 'rxjs/Subscription';
import {
	Collateral,
	DeposLodgeCollateralTypeSpecificDetail,
	LodgeDocumentationDetail,
	LodgeBeneficiaryDetail,
	LodgeOwnerShipDetail,
	ApplicationDetail,
	GeneralDetail,
	CollateralValueDetail,
	SolicitorDetails
} from '../model/collateral';
import { JsonConvert } from 'json2typescript';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';
import { BeneficiaryList } from '../model/collateral';

import { FormMaps } from '../model/formMaps.map';

import * as _ from 'underscore';
import { FacilityLinkageDataService } from '../facility-linkage-data/facility-linkage-data.service';
import { CollateralSummaryService } from '../collateral-summary/collateral-summary.service';

@Component({
	selector: 'new-collateral',
	templateUrl: './new-collateral.component.html',
	encapsulation: ViewEncapsulation.Emulated,
	styleUrls: ['./new-collateral.component.scss'],
	providers: [NewCollateralService]
})
export class NewCollateralComponent implements OnInit, OnDestroy {
	selectedTabValue: string;
	collateralTypes: Array<CollateralType> = [];
	collateralCodes: Array<CollateralCode> = [];
	tempCollateralTypes: Array<CollateralType> = [];
	codeCollateralType: CollateralType;
	public newCollateralForm: FormGroup;
	public savingVar: boolean | Observable<boolean>;
	isCollateralCreated: boolean = false;
	showPopupDialog: boolean;
	type: string;
	currency: string = 'SGD';
	defaultValution = { value: 0, ccy: this.currency };
	public title = 'Add New Collateral';
	public fullCollateralFormJson: any;
	selectedItem: CollateralType;
	selectedCode: CollateralCode;
	codePresent: boolean;
	typePresent: boolean;
	public counterPartyDetails: any;
	public tabSections: Array<String> = [];
	linkageValue: any = [];
	public selectedCollateralTypeValue: any;
	// error panel code
	private currentForm: FormGroup;
	// error panel code
	constructor(private collateralService: CollateralService, private autosave: AutoSaveService, private route: ActivatedRoute,
		private newCollateralService: NewCollateralService, private facilityLinkageService: FacilityLinkageDataService,
		private router: Router, private counterPartyDetailsService: CounterPartyDetailsService,
		private collateralSummaryService: CollateralSummaryService) {
		this.showPopupDialog = true;
		this.codePresent = false;
		this.typePresent = false;
	}

	ngOnInit() {
		this.selectedTabValue = 'Collateral Details';
		this.suscribeToSelectedTab();
		if (this.collateralSummaryService.collateralOperation && this.collateralSummaryService.collateralOperation === 'EDIT') {
			console.log((this.collateralSummaryService.selectedCollateral));
			this.collateralService.selectedTab = this.selectedTabValue;
			this.onEditCollateral();
		} else if (this.collateralSummaryService.collateralOperation && this.collateralSummaryService.collateralOperation === 'FACILITY LINKAGE') {
			this.linkageValue = this.facilityLinkageService.getLinkages();
			const collateralId = this.collateralService.collateral.collateralId;
			let gcin: string;
			this.route.queryParams.subscribe((params: Params) => {
				gcin = params['gcin'];
			});
			if (gcin) {
				if (this.linkageValue && this.linkageValue.length > 0) {
					this.collateralService.limitDataBeneficiary[gcin] = _.map(this.linkageValue, function (element, index, list) {
						return { limitId: element.limitId, collateralId: collateralId };
					});
				}
				else {
					delete this.collateralService.limitDataBeneficiary[gcin];
				}
			}
			this.showPopupDialog = false;
			this.newCollateralForm = this.collateralService.getCollateralForm();
			this.tabSections = this.collateralService.tabSections;
			this.selectedTabValue = this.collateralService.selectedTab;
		} else if (this.collateralSummaryService.collateralOperation && this.collateralSummaryService.collateralOperation === 'ADD') {
			this.collateralService.selectedTab = this.selectedTabValue;
			this.showPopupDialog = true;
		}


		if (this.collateralService.selectedCollateralType) {
			this.selectedCollateralTypeValue = this.collateralService.selectedCollateralType;
		}
		this.initTypes();
		this.initCodes();
		this.subscribeCounterPartyDetail();
	}

	suscribeToSelectedTab() {
		this.collateralService.getMessage().subscribe(message => {
			this.selectedTabValue = message;
		});
	}

	subscribeCounterPartyDetail() {
		this.counterPartyDetailsService.subscribeToCPDetails({
			next: (value) => this.counterPartyDetails = value,
			error: (value) => console.log(value),
			complete: () => {
			}
		});

	}

	initTypes() {
		this.collateralService.getCollateralTypes().subscribe(data => {
			this.tempCollateralTypes = data;
			this.collateralTypes = data;
		},
			error => {
			}
		);
	}

	initCodes() {
		this.collateralService.getCollateralCodes().subscribe(data => {
			this.collateralCodes = data;
		},
			error => {
			}
		);
	}

	// error panel code
	getErrorsModel(): Observable<any[]> {
		return this.collateralService.getErrorsModel();
	}

	handleErrors(errorsModel?: any) {
		// logic on how you would like to handle the error model, If any
	}

	// error panel code

	// error panel code
	focusControl($event) {
		const control = $event;
		const ele = document.getElementById(control);
		if (ele) {
			this.recursiveFocus(ele);
		}
	}

	// focus any child that is focusable
	private recursiveFocus(root?: HTMLElement) {
		let x = root.focus();
		if (!x) {
			for (let index = 0; index < root.children.length; index++) {
				const elemnt = root.children.item(index);
				x = (<HTMLElement>elemnt).focus();
				if (x) {
					break;
				}
				this.recursiveFocus(<HTMLElement>elemnt);
			}
		}
	}

	// error panel code

	typeChange(event) {
		if (event === undefined) {
			return this.collateralService.getCollateralCodes().subscribe(data => {
				this.collateralCodes = data;
				this.typePresent = true;
				this.collateralTypes = this.tempCollateralTypes;
			},
				error => {
				}
			);
		}
		if (event.collateralType) {
			this.type = event.collateralType;
			this.collateralService.getCollateralCodes(this.type).subscribe(data => {
				this.selectedCode = <CollateralCode>{};
				this.collateralCodes = data;
				this.typePresent = false;
			},
				error => {
				}
			);
		}
	}

	codeChange(event) {
		if (event === undefined) {
			this.collateralService.getCollateralTypes().subscribe(data => {
				this.tempCollateralTypes = data;
				this.collateralTypes = data;
				this.codePresent = true;
			},
				error => {
				}
			);
		}
		if (event) {
			this.collateralTypes = [];
			this.codeCollateralType = this.tempCollateralTypes.find(CollateralType => CollateralType.collateralType === event.collateralType);
			this.collateralTypes.push(this.codeCollateralType);
			this.selectedItem = this.collateralTypes[0];
			this.codePresent = false;
			this.typePresent = false;
		}

	}

	public tabSelection(valueFromTab: string) {
		this.selectedTabValue = valueFromTab;
		this.collateralService.selectedTab = valueFromTab;
		// error panel code
		this.prepareErrorPanel();
		// error panel code
	}

	private prepareErrorPanel() {
		const formName = FormMaps.map[this.selectedTabValue];
		this.currentForm = <FormGroup>this.newCollateralForm.controls[formName];
		this.collateralService.setErrorsModel({
			errorForm: this.currentForm,
			entireForm: this.newCollateralForm,
			currentFormName: formName
		});
	}

	onProceed(type: any, code: any) {

		const request = '';
		if (code.value !== undefined) {
			this.codePresent = false;
		} else {
			this.codePresent = true;
		}

		if (type.value !== undefined) {
			this.typePresent = false;
		} else {
			this.typePresent = true;
		}
		const tabSections = [];
		populateTabSections(_.pick(type.value, 'sections'));
		this.tabSections = tabSections;
		if (code.value !== undefined && type.value !== undefined) {
			this.collateralService.selectedCollateralType = type.value.collateralType;
			this.collateralService.tabSections = tabSections;
			const data = new BeneficiaryList();
			const tempArr = [];
			data.beneficiaryId = this.counterPartyDetails.value;
			data.beneficiaryName = this.counterPartyDetails.label;
			tempArr.push(data);

			const collateral = this.populateDefaultRequestData(code.value);
			collateral.LodgeBeneficiaryDetail.beneficiaryList = tempArr;
			this.createCollateral(collateral);
			this.selectedCollateralTypeValue = type.value.collateralType;
		}

		function populateTabSections(obj) {
			_.each(obj, function (element, index, list) {
				if (_.isObject(element)) {
					populateTabSections(element);
				} else {
					if (element) {
						tabSections.push(index);
					}
				}
			});
		}
	}

	populateDefaultRequestData(code): Collateral {
		const collateral = new Collateral();
		collateral.collateralCode = code.collateralCode;
		collateral.generalDetail.currencyCode = this.currency;
		// collateral.generalDetail.country = 'USA';
		collateral.generalDetail.collateralCreationDate = (new Date()).toISOString();

		if (this.collateralService.selectedCollateralType === 'DEPOS') {
			collateral.LodgeCollateralTypeSpecificDetail = new DeposLodgeCollateralTypeSpecificDetail();
		}
		// collateral.generalDetail.collateralExpiryDate = '2018-06-08T12:33:43.707Z';
		collateral.CollateralValuationDetail.externalChargeAmt = this.defaultValution;
		collateral.CollateralValuationDetail.collateralValue = this.defaultValution;
		collateral.CollateralValuationDetail.finalCollateralValue = this.defaultValution;
		collateral.CollateralValuationDetail.totalApportionedValue = this.defaultValution;
		collateral.CollateralValuationDetail.balanceApportionableAmt = this.defaultValution;
		collateral.CollateralValuationDetail.apportioningMethod = 'P';
		return collateral;
	}

	isDisabled(type: any, code: any) {
		if (code.value !== undefined && type.value !== undefined && code.value.collateralCode && type.value.collateralType) {
			return false;
		} else {
			return true;
		}
	}

	createCollateral(collateral: any) {
		this.collateralService.postCollateral(collateral).subscribe(data => {
			this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(data), Collateral);
			// this.collateralService.limitDataBeneficiary = this.collateralService.getLinkagesByCollateral(data.collateralId);
			this.newCollateralForm = this.collateralService.getCollateralForm();
			this.collateralService.setupAutoSave(this.newCollateralForm, {
				next: (value) => {
					this.savingVar = value;
					(!this.isCollateralCreated) ? this.isCollateralCreated = true : this.getFullFormData();
				},
				error: (value) => console.log(value),
				complete: () => {
				}
			});
			this.showPopupDialog = false;
		},
			error => {
			}
		);
	}

	openPopDialog() {
		this.showPopupDialog = true;
	}

	onCancel() {
		this.showPopupDialog = false;
		this.router.navigate(['/collateral']);
	}

	getFullFormData(data?: any) {
		if (this.collateralService.modifiedForm === 'document') {
			if (!this.collateralService.collateral.LodgeDocumentationDetail) {
				this.collateralService.collateral.LodgeDocumentationDetail = new LodgeDocumentationDetail();
			}
			this.collateralService.collateral.LodgeDocumentationDetail.document = [];
			if (this.newCollateralForm.value.document.documentidList != null) {
				this.collateralService.collateral.LodgeDocumentationDetail.document = this.newCollateralForm.value.document.documentidList;
			}
		}

		if (this.collateralService.modifiedForm === 'beneficiary') {
			if (!this.collateralService.collateral.LodgeBeneficiaryDetail) {
				this.collateralService.collateral.LodgeBeneficiaryDetail = new LodgeBeneficiaryDetail();
			}
			this.collateralService.collateral.LodgeBeneficiaryDetail.beneficiaryList = [];
			if (this.newCollateralForm.value.beneficiary.beneficiaryList != null) {
				this.collateralService.collateral.LodgeBeneficiaryDetail.beneficiaryList = this.newCollateralForm.value.beneficiary.beneficiaryList;
			}
		}

		if (this.collateralService.modifiedForm === 'ownership') {
			if (!this.collateralService.collateral.LodgeOwnerShipDetail) {
				this.collateralService.collateral.LodgeOwnerShipDetail = new LodgeOwnerShipDetail();
			}
			this.collateralService.collateral.LodgeOwnerShipDetail.ownerShipList = [];
			if (this.newCollateralForm.value.ownership.ownershipid != null) {
				this.collateralService.collateral.LodgeOwnerShipDetail.ownerShipList = this.newCollateralForm.value.ownership.ownershipid;
			}
		}

		if (this.collateralService.modifiedForm === 'details') {
			if (!this.collateralService.collateral.generalDetail.applicationDetail) {
				this.collateralService.collateral.generalDetail.applicationDetail = new ApplicationDetail();
			}
			this.collateralService.collateral.generalDetail.applicationDetail.formNo = this.newCollateralForm.value.details.formNo;
			this.collateralService.collateral.generalDetail.applicationDetail.receivedDate = this.newCollateralForm.value.details.recievedDate;
			this.collateralService.collateral.generalDetail.applicationDetail.reviewDate = this.newCollateralForm.value.details.reviewDate;
			this.collateralService.collateral.generalDetail.applicationDetail.signingDate = this.newCollateralForm.value.details.signingDate;
			this.collateralService.collateral.generalDetail.applicationDetail.executionDate = this.newCollateralForm.value.details.executionDate;
			this.collateralService.collateral.generalDetail.applicationDetail.comments = this.newCollateralForm.value.details.applicationDetailsRemarks;
			this.collateralService.collateral.generalDetail.applicationDetail.nextReviewDate = this.newCollateralForm.value.details.nextReviewDate;
			this.collateralService.collateral.generalDetail.collateralExpiryDate = this.newCollateralForm.value.details.expiryDate;
			this.collateralService.collateral.generalDetail.remarks = this.newCollateralForm.value.details.generalDetailsRemarks;
			this.collateralService.collateral.generalDetail.BASELEligible = this.newCollateralForm.value.details.baselEligible;
			this.collateralService.collateral.generalDetail.method = this.newCollateralForm.value.details.method;
			if (!this.collateralService.collateral.generalDetail.SolicitorDetails) {
				this.collateralService.collateral.generalDetail.SolicitorDetails = new SolicitorDetails();
			}
			this.collateralService.collateral.generalDetail.SolicitorDetails.solicitorName = this.newCollateralForm.value.details.solicitorName;
			this.collateralService.collateral.generalDetail.currencyCode = this.newCollateralForm.value.details.currencyType;
			this.collateralService.collateral.CollateralValuationDetail.loanToValuePcnt = this.newCollateralForm.value.details.loanValuePcnt;
			if (this.newCollateralForm.value.details.locationControl) {
				this.collateralService.collateral.generalDetail.country = this.newCollateralForm.value.details.locationControl.code;
			}
		}
	}

	private onEditCollateral() {
		if (!this.collateralSummaryService.selectedCollateral) {
			return;
		}
		this.showPopupDialog = false;
		console.log(this.collateralSummaryService.selectedCollateral);
		let type: any;
		type = this.collateralSummaryService.collateralTypes[0];
		switch (this.collateralSummaryService.selectedCollateralType) {
			case 'GUARN':
				this.collateralService.selectedCollateralType = 'GUARN';
				this.selectedCollateralTypeValue = this.collateralService.selectedCollateralType;
				break;
			case 'DEPOS':
				this.collateralService.selectedCollateralType = 'DEPOS';
				this.selectedCollateralTypeValue = this.collateralService.selectedCollateralType;
				break;
			default:
				return Observable.throw('Invalid Collateral Type');
		}

		this.collateralService.collateral = JsonConvert.deserializeString(JSON.stringify(this.collateralSummaryService.selectedCollateral), Collateral);
		this.newCollateralForm = this.collateralService.getCollateralForm();
		this.collateralService.getLinkages(this.collateralService.collateral.collateralId);
		this.collateralService.setupAutoSave(this.newCollateralForm, {
			next: (value) => {
				this.savingVar = value;
				(!this.isCollateralCreated) ? this.isCollateralCreated = true : this.getFullFormData();
			},
			error: (value) => console.log(value),
			complete: () => {
			}
		});

		const tabSections = [];
		populateTabSections(_.pick(type, 'sections'));
		this.tabSections = tabSections;
		this.collateralService.tabSections = tabSections;
		function populateTabSections(obj) {
			_.each(obj, function (element, index, list) {
				if (_.isObject(element)) {
					populateTabSections(element);
				} else {
					if (element) {
						tabSections.push(index);
					}
				}
			});
		}
	}

	ngOnDestroy()
	{
// 		this.collateralService.unSubscribeToSaveState();
	}
}

