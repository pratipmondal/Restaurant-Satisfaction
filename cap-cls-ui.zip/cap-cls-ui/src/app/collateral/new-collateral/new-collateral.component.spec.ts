import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { DropDownsModule, ComboBoxModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { ClsSharedCommonModule } from '../../shared/';
import { CounterpartyDetailsModule } from '../../shared/counterparty-details/counterparty-details.module';
import { NewCollateralComponent } from './new-collateral.component';
import { NEWCOLLATERAL_DATA_ROUTE } from './new-collateral.route';
import { SpecificDetailsModule } from '../specific-details/specific-details.module';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';

import { BeneficiaryModule } from '../beneficiary/beneficiary.module';
import { DocumentModule } from '../document/document.module';
import { OwnershipModule } from '../ownership/ownership.module';
import { ChargeModule } from '../charge/charge.module';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { HeadErrorPanelModule } from '../../common/head-error-panel/head-error-panel.module';
import { TabbedWizardModule } from '../../common/tabbed-wizard/tabbed-wizard.module';
import { CollateralService } from '../collateral.service';
import { AutoSaveService } from '../../common/autosave/auto-save.service';
import { CommonUIModule } from '../../common/commonUI.module';
import { SummaryModule } from '../summary/summary.module';
import { SummarySubsectionModule } from '../summary/summary-subsection/summary-subsection.module';
import { CollateralType, CollateralCode } from '../model';
import { CollateralDetailsComponent } from '../collateral-details/collateral-details.component';
import { CollateralIDComponent } from '../collateral-id/collateral-id.component';
import { GeneralDetailsComponent } from '../collateral-details/general-details/general-details.component';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { ValuationModule } from '../valuation/valuation.module';
import { ToggleButtonModule } from 'app/common/toggle-button/toggle-button.module';
import { NewCollateralService } from './new-collateral.service';
import { Router } from '@angular/router';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormBuilder, FormGroup } from '@angular/forms';
import {CollateralGuarantorModule} from '../collateral-guarantor/collateral-guarantor.module';
import { collateralCodesData, collateralCodesDataFilter, collateralCodesTypesData, collateralData, collateralResData } from './new-collateral.data';
import { Collateral, LodgeDocumentationDetail, LodgeBeneficiaryDetail, LodgeOwnerShipDetail, ApplicationDetail, GeneralDetail, CollateralValueDetail } from '../model/collateral';

class MockCollateralService {
  _fb: FormBuilder = new FormBuilder();
  collateral: Collateral = new Collateral();
  getCollateralCodes(filter: any) {
    if (filter === undefined) {
      return Observable.of(collateralCodesData);
    } else {
      return Observable.of(collateralCodesDataFilter);
    }
  }

  getDetailsForm() {
    return this._fb.group({
      collateralid: ['']
    });
  }

  getParticularsForm() {
    return this._fb.group({
      particularsList: ['']
    });
  }

  getBeneficiaryForm() {
    return this._fb.group({
      beneficiaryList: [this.collateral.LodgeBeneficiaryDetail.beneficiaryList]
    });
  }
  getCollateral() {
    return this.collateral;
  }

  getDocumentForm(document?: Document) {
    return this._fb.group({
      documentidList: []
    });
  }

  getChargeForm() {
    return this._fb.group({
      chargeList: ['']
    });
  }

  getApportionForm() {
    return this._fb.group({
      // apportionList: [CollateralReponse.CollateralValuationDetail, [Validators.required]]
    });
  }


  getOwnershipForm() {
    return this._fb.group({
      ownershipid: []
    });
  }

  getCollateralTypes() {
    return Observable.of(collateralCodesTypesData);
  }

  postCollateral(collateral) {
    return Observable.of(collateralData);
  }
  getCollateralForm() {
    return this._fb.group({
      details: this.getDetailsForm(),
      beneficiary: this.getBeneficiaryForm(),
      charge: this.getChargeForm(),
      valuation: this.getApportionForm(),
      document: this.getDocumentForm(),
      ownership: this.getOwnershipForm(),
      particulars: this.getParticularsForm()
    });
  }
}

class MockAutoSaveService {

}
class MockNewCollateralService {

}
class MockPartyDetailsService {
  temp = new Observable(observer => {
    observer.next({ 'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000' });
  });
  subscribeToCPDetails(temp) {
    return Observable.of({ label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000' });
  }

}
class MyRouter {

}

describe('NewCollateralComponent', () => {
  let component: NewCollateralComponent;
  let fixture: ComponentFixture<NewCollateralComponent>;
  let evt: any;
  const typesArr: Array<any> = [];
  const router = {
    navigate: jasmine.createSpy('navigate')
  };
  const _fb: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    window['jasmine'].DEFAULT_TIMEOUT_INTERVAL = 10000;
    TestBed.configureTestingModule({
      imports: [
        RouterModule.forChild([NEWCOLLATERAL_DATA_ROUTE]),
        CommonModule, ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
        DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule, ValuationModule,
        CounterpartyDetailsModule, CommonUIModule, PopupDialogModule, SpecificDetailsModule,
        BeneficiaryModule, DocumentModule, OwnershipModule, ChargeModule, CustomPanelModule,
        SummaryModule, SummarySubsectionModule, DateInputsModule, ToggleButtonModule, RouterTestingModule,
        HeadErrorPanelModule,CollateralGuarantorModule
      ],
      declarations: [NewCollateralComponent, CollateralDetailsComponent, CollateralIDComponent, GeneralDetailsComponent],
      providers: [{ provide: CollateralService, useClass: MockCollateralService }, { provide: AutoSaveService, useClass: MockAutoSaveService },
      { provide: NewCollateralService, useClass: MockNewCollateralService }, { provide: Router, useValue: router }, { provide: CounterPartyDetailsService, useClass: MockPartyDetailsService }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents().then(() => {
        fixture = TestBed.createComponent(NewCollateralComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });
  }));

 it('should create the new collateral component', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should select tab', async(() => {
    spyOn(component,"prepareErrorPanel");
    component.tabSelection('Collateral Details');
    expect(component.selectedTabValue).toBe('Collateral Details');
    console.log('Component : NewCollateralComponent -- tab selection -- PASSED');
  }));

 it('on Type change undefined event', async(() => {
    evt = undefined;
    component.typeChange(evt);
    expect(component.collateralCodes[0].collateralCode).toBe('code01');
  }));

 it('on code change undefined event', async(() => {
    evt = undefined;
    component.codeChange(evt);
    expect(component.collateralTypes[0].collateralType).toBe('GUARN');
  }));

 it('on Type change valid event', async(() => {
    evt = { collateralType: 'GUARN' };
    component.typeChange(evt);
    console.log(component.collateralCodes[0]);
    expect(component.collateralCodes[0].collateralCode).toBe('code03');
  }));

 it('on code change valid event', async(() => {
    evt = { collateralCode: 'code03', collateralType: 'GUARN', parentModel: 'GUARNColtrlCode', _type: 'CollateralCodeMaster' };
    component.tempCollateralTypes = component.collateralTypes;
    component.codeChange(evt);
    expect(component.selectedItem.collateralType).toBe('GUARN');
  }));

 it('open popUp dialog', async(() => {
    component.openPopDialog();
    expect(component.showPopupDialog).toBe(true);
  }));

 it('cancel popUp dialog', async(() => {
    component.onCancel();
    expect(component.showPopupDialog).toBe(false);
    expect(router.navigate).toHaveBeenCalledWith(['/collateral']);
  }));

 it('isDisabled called should disable', async(() => {
    const retVal: boolean = component.isDisabled({ value: { collateralType: 'someValue' } }, { value: { collateralCode: 'somValue' } });
    expect(retVal).toBe(false);
  }));

 it('isDisabled called should NOT disable', async(() => {
    const retVal: boolean = component.isDisabled({}, {});
    expect(retVal).toBe(true);
  }));

 it('on proceed for undefined type and code', fakeAsync(() => {
    component.onProceed({}, {});
    console.log(component.codePresent);
    expect(component.codePresent).toBe(true);
    expect(component.typePresent).toBe(true);
  }));

 it('on proceed for valid type and code', fakeAsync(() => {
    const type = { value: { collateralType: 'GUARN' } };
    const code = { value: { collateralCode: 'code03', collateralType: 'GUARN' } };
    component.counterPartyDetails = { 'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000' };
    spyOn(component, 'createCollateral').and.returnValue(0);
    component.onProceed(type, code);
    expect(component.codePresent).toBe(false);
    // expect(inxitRequest.collateralCode).toBe('code03');
    expect(component.typePresent).toBe(false);
    // expect(inxitRequest.collateralType).toBe('GUARN');
  }));

 it('on call formFullData should set the data', fakeAsync(() => {
    const data = collateralData;
    component.newCollateralForm = _fb.group(collateralResData);
    component.getFullFormData(data);
  }));
});
