export const collateralCodesData = [{
    'collateralCode': 'code01',
    'collateralType': 'OTHRS',
    'parentModel': 'OTHRSColtrlCode',
    '_type': 'CollateralCodeMaster',
    '_createdBy': 'cmsadmin',
    '_modifiedBy': 'cmsadmin',
    '_createdOn': '2017-06-20T07:49:09.044Z',
    '_modifiedOn': '2017-06-20T07:49:09.044Z',
    'scope': null,
    '_isDeleted': false,
    '_oldVersion': null,
    '_version': '69bcb1a3-2bc4-4458-8de8-70039c7d30fa',
    '_requestId': null,
    '_newVersion': null
},
    {
        'collateralCode': 'code02',
        'collateralType': 'DEPOS',
        'parentModel': 'DEPOSColtrlCode',
        '_type': 'CollateralCodeMaster',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T07:48:23.267Z',
        '_modifiedOn': '2017-06-20T07:48:23.267Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': 'ff734893-2a84-41bc-a664-0e662ce3dfce',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'collateralCode': 'code03',
        'collateralType': 'GUARN',
        'parentModel': 'GUARNColtrlCode',
        '_type': 'CollateralCodeMaster',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T07:48:42.562Z',
        '_modifiedOn': '2017-06-20T07:48:42.562Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '36ba3ebc-17b9-4ccd-b8dc-d919565c297a',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'collateralCode': 'code04',
        'collateralType': 'BASKT',
        'parentModel': 'BASKTColtrlCode',
        '_type': 'CollateralCodeMaster',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T07:47:29.384Z',
        '_modifiedOn': '2017-06-20T07:47:29.384Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '369ad287-0f51-4361-b980-7ae19582e307',
        '_requestId': null,
        '_newVersion': null
    },
    {
        'collateralCode': 'GAUCODE',
        'collateralType': 'GUARN',
        'parentModel': 'GUARNColtrlCode',
        '_type': 'CollateralCodeMaster',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T11:00:38.370Z',
        '_modifiedOn': '2017-06-20T11:00:38.370Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '538aaaa5-8a4f-4c9e-8544-b54c3413a39e',
        '_requestId': null,
        '_newVersion': null
    }];

export const collateralCodesDataFilter = [{
    'collateralCode': 'code03',
    'collateralType': 'GUARN',
    'parentModel': 'GUARNColtrlCode',
    '_type': 'CollateralCodeMaster',
    '_createdBy': 'cmsadmin',
    '_modifiedBy': 'cmsadmin',
    '_createdOn': '2017-06-20T07:48:42.562Z',
    '_modifiedOn': '2017-06-20T07:48:42.562Z',
    'scope': null,
    '_isDeleted': false,
    '_oldVersion': null,
    '_version': '36ba3ebc-17b9-4ccd-b8dc-d919565c297a',
    '_requestId': null,
    '_newVersion': null
},
    {
        'collateralCode': 'GAUCODE',
        'collateralType': 'GUARN',
        'parentModel': 'GUARNColtrlCode',
        '_type': 'CollateralCodeMaster',
        '_createdBy': 'cmsadmin',
        '_modifiedBy': 'cmsadmin',
        '_createdOn': '2017-06-20T11:00:38.370Z',
        '_modifiedOn': '2017-06-20T11:00:38.370Z',
        'scope': null,
        '_isDeleted': false,
        '_oldVersion': null,
        '_version': '538aaaa5-8a4f-4c9e-8544-b54c3413a39e',
        '_requestId': null,
        '_newVersion': null
    }];


export const collateralCodesTypesData = [{
    'collateralType': 'GUARN',
    'collateralTypeDesc': 'Guarantee Collateral Type',
    'sections': {
        'code': {
            'sections': [{
                'subSections': [],
                'CollateralCodeLinkageDetail': true
            },
                {
                    'subSections': [],
                    'CollateralCodeAlertEventDetail': true
                },
                {
                    'subSections': [],
                    'CollateralCodeSecurityDetail': false
                },
                {
                    'subSections': [],
                    'CollateralCodeAdditionalDetail': true
                },
                {
                    'subSections': [],
                    'CollateralCodeUnitValueDetail': false
                },
                {
                    'subSections': [],
                    'CollateralCodeDetailsInAltLang': true
                },
                {
                    'subSections': [],
                    'CollateralCodeCompanyDetail': false
                }
            ]
        },
        'lodge': {
            'sections': [{
                'subSections': [],
                'LodgeChargeDetail': false
            },
                {
                    'subSections': [],
                    'LodgeReceiptAndPayment': true
                },
                {
                    'subSections': [],
                    'LodgeInspectionAndAppraisal': false
                },
                {
                    'subSections': [],
                    'LodgeDocumentationDetail': true
                },
                {
                    'subSections': [],
                    'LodgeBeneficiaryDetail': true
                },
                {
                    'subSections': [],
                    'LodgeInsuranceDetail': false
                },
                {
                    'subSections': [],
                    'CollateralValuationDetail': true
                },
                {
                    'subSections': [],
                    'LodgeDynamicSection': false
                },
                {
                    'subSections': [],
                    'LodgeSalesNotesDetail': false
                },
                {
                    'subSections': [{
                        'subSections': [],
                        'OwnerShipDetail': true
                    },
                        {
                            'subSections': [],
                            'LodgeTenancyDetail': false
                        }
                    ],
                    'LodgeOwnerShipDetail': true
                },
                {
                    'subSections': [{
                        'subSections': [],
                        'LodgeGuaranteeDetail': true
                    },
                        {
                            'subSections': [],
                            'LodgeOtherDetail': false
                        },
                        {
                            'subSections': [],
                            'LodgeDepositDetail': false
                        }
                    ],
                    'LodgeCollateralTypeSpecificDetail': true
                },
                {
                    'subSections': [{
                        'subSections': [],
                        'ForeClosureDetail': false
                    },
                        {
                            'subSections': [],
                            'RepossessionDetail': false
                        }
                    ],
                    'LodgeNonPerformanceDetail': false
                }
            ]
        },
        'common': {
            'sections': [{
                'FeeDetail': true,
                'subSections': []
            },
                {
                    'subSections': [{
                        'subSections': [],
                        'CalculationMethod': true
                    }],
                    'CollateralValueDetail': true
                }
            ]
        }
    },
    'id': '6efaad55-52ac-495f-b635-97063ac008c2',
    '_version': 'a066669d-c5cf-4345-ba0b-42209465b307',
    '_createdBy': 'upload',
    '_modifiedBy': 'upload'
},
    {
        'collateralType': 'OTHRS',
        'collateralTypeDesc': 'Others Collateral Type',
        'sections': {
            'code': {
                'sections': [{
                    'subSections': [],
                    'CollateralCodeLinkageDetail': true
                },
                    {
                        'subSections': [],
                        'CollateralCodeAlertEventDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeSecurityDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeAdditionalDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeUnitValueDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeDetailsInAltLang': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeCompanyDetail': false
                    }
                ]
            },
            'lodge': {
                'sections': [{
                    'subSections': [],
                    'LodgeChargeDetail': true
                },
                    {
                        'subSections': [],
                        'LodgeReceiptAndPayment': true
                    },
                    {
                        'subSections': [],
                        'LodgeInspectionAndAppraisal': true
                    },
                    {
                        'subSections': [],
                        'LodgeDocumentationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeBeneficiaryDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeInsuranceDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralValuationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeDynamicSection': false
                    },
                    {
                        'subSections': [],
                        'LodgeSalesNotesDetail': false
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'OwnerShipDetail': true
                        },
                            {
                                'subSections': [],
                                'LodgeTenancyDetail': false
                            }
                        ],
                        'LodgeOwnerShipDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'LodgeGuaranteeDetail': false
                        },
                            {
                                'subSections': [],
                                'LodgeOtherDetail': true
                            },
                            {
                                'subSections': [],
                                'LodgeDepositDetail': false
                            }
                        ],
                        'LodgeCollateralTypeSpecificDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'ForeClosureDetail': false
                        },
                            {
                                'subSections': [],
                                'RepossessionDetail': false
                            }
                        ],
                        'LodgeNonPerformanceDetail': false
                    }
                ]
            },
            'common': {
                'sections': [{
                    'FeeDetail': true,
                    'subSections': []
                },
                    {
                        'subSections': [{
                            'subSections': [],
                            'CalculationMethod': true
                        }],
                        'CollateralValueDetail': true
                    }
                ]
            }
        },
        'id': '879a67e4-d8b4-4174-b842-6c82d16929df',
        '_version': '8a8071e1-7111-4e99-972f-b2757db12876',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload'
    },
    {
        'collateralType': 'DEPOS',
        'collateralTypeDesc': 'Deposit Collateral Type',
        'sections': {
            'code': {
                'sections': [{
                    'subSections': [],
                    'CollateralCodeLinkageDetail': true
                },
                    {
                        'subSections': [],
                        'CollateralCodeAlertEventDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeSecurityDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeAdditionalDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeUnitValueDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeDetailsInAltLang': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeCompanyDetail': false
                    }
                ]
            },
            'lodge': {
                'sections': [{
                    'subSections': [],
                    'LodgeChargeDetail': false
                },
                    {
                        'subSections': [],
                        'LodgeReceiptAndPayment': true
                    },
                    {
                        'subSections': [],
                        'LodgeInspectionAndAppraisal': false
                    },
                    {
                        'subSections': [],
                        'LodgeDocumentationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeBeneficiaryDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeInsuranceDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralValuationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeDynamicSection': false
                    },
                    {
                        'subSections': [],
                        'LodgeSalesNotesDetail': false
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'OwnerShipDetail': true
                        },
                            {
                                'subSections': [],
                                'LodgeTenancyDetail': false
                            }
                        ],
                        'LodgeOwnerShipDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'LodgeGuaranteeDetail': false
                        },
                            {
                                'subSections': [],
                                'LodgeOtherDetail': false
                            },
                            {
                                'subSections': [],
                                'LodgeDepositDetail': true
                            }
                        ],
                        'LodgeCollateralTypeSpecificDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'ForeClosureDetail': false
                        },
                            {
                                'subSections': [],
                                'RepossessionDetail': false
                            }
                        ],
                        'LodgeNonPerformanceDetail': false
                    }
                ]
            },
            'common': {
                'sections': [{
                    'FeeDetail': true,
                    'subSections': []
                },
                    {
                        'subSections': [{
                            'subSections': [],
                            'CalculationMethod': true
                        }],
                        'CollateralValueDetail': true
                    }
                ]
            }
        },
        'id': '889604e4-5583-4826-8753-0c6d9646bf8b',
        '_version': 'b2bf8f0c-3f40-4767-9bf5-55cd37050a3f',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload'
    },
    {
        'collateralType': 'BASKT',
        'collateralTypeDesc': 'Basket Collateral Type',
        'sections': {
            'code': {
                'sections': [{
                    'subSections': [],
                    'CollateralCodeLinkageDetail': true
                },
                    {
                        'subSections': [],
                        'CollateralCodeAlertEventDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeSecurityDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeAdditionalDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeUnitValueDetail': false
                    },
                    {
                        'subSections': [],
                        'CollateralCodeDetailsInAltLang': true
                    },
                    {
                        'subSections': [],
                        'CollateralCodeCompanyDetail': false
                    }
                ]
            },
            'lodge': {
                'sections': [{
                    'subSections': [],
                    'LodgeChargeDetail': true
                },
                    {
                        'subSections': [],
                        'LodgeReceiptAndPayment': true
                    },
                    {
                        'subSections': [],
                        'LodgeInspectionAndAppraisal': false
                    },
                    {
                        'subSections': [],
                        'LodgeDocumentationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeBeneficiaryDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeInsuranceDetail': true
                    },
                    {
                        'subSections': [],
                        'CollateralValuationDetail': true
                    },
                    {
                        'subSections': [],
                        'LodgeDynamicSection': true
                    },
                    {
                        'subSections': [],
                        'LodgeSalesNotesDetail': false
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'OwnerShipDetail': true
                        },
                            {
                                'subSections': [],
                                'LodgeTenancyDetail': false
                            }
                        ],
                        'LodgeOwnerShipDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'LodgeGuaranteeDetail': false
                        },
                            {
                                'subSections': [],
                                'LodgeOtherDetail': false
                            },
                            {
                                'subSections': [],
                                'LodgeDepositDetail': false
                            },
                            {
                                'subSections': [],
                                'LodgeBasketDetail': true
                            }
                        ],
                        'LodgeCollateralTypeSpecificDetail': true
                    },
                    {
                        'subSections': [{
                            'subSections': [],
                            'ForeClosureDetail': false
                        },
                            {
                                'subSections': [],
                                'RepossessionDetail': false
                            }
                        ],
                        'LodgeNonPerformanceDetail': false
                    }
                ]
            },
            'common': {
                'sections': [{
                    'FeeDetail': true,
                    'subSections': []
                },
                    {
                        'subSections': [{
                            'subSections': [],
                            'CalculationMethod': true
                        }],
                        'CollateralValueDetail': true
                    }
                ]
            }
        },
        'id': 'bf4aabd1-d08e-4ed6-b5cb-32862172fa19',
        '_version': 'f0c824ed-5c60-434c-8ff9-ebfa74ab3996',
        '_createdBy': 'upload',
        '_modifiedBy': 'upload'
    }
];


export const collateralData = {
    'LodgeBeneficiaryDetail': {
        'beneficiaryList': [
            {
                'beneficiaryName': 'Personal Leadership Centre Pte.Ltd',
                'cifId': '',
                'beneficiaryIdType': '',
                'beneficiaryId': 'GCIN0000000',
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': '',
                'delete': false
            }
        ]
    },
    'CollateralValuationDetail': {
        'externalChargeAmt': {
            'value': 0,
            'ccy': 'SGD',
            '_isDeleted': false
        },
        'collateralValue': {
            'value': 0,
            'ccy': 'SGD',
            '_isDeleted': false
        },
        'finalCollateralValue': {
            'value': 0,
            'ccy': 'SGD',
            '_isDeleted': false
        },
        'apportioningMethod': 'P',
        'totalApportionedValue': {
            'value': 0,
            'ccy': 'SGD',
            '_isDeleted': false
        },
        'balanceApportionableAmt': {
            'value': 0,
            'ccy': 'SGD',
            '_isDeleted': false
        }
    },
    'LodgeOwnerShipDetail': {
        'ownerShipList': []
    },
    'LodgeCollateralTypeSpecificDetail': {
        'supportingCollateralsHeld': false,
        'guaranteeAmt': {
            '_isDeleted': false
        }
    },
    'collateralId': 'COLL903',
    'collateralCode': 'code03',
    'draft': false,
    'generalDetail': {
        'globalCollateral': false,
        'businessLocation': 'USA',
        'collateralCreationDate': '2017-07-04T10:02:15.068Z',
        'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
        'currencyCode': 'SGD',
        'BASELEligible': false
    },
    '_type': 'GUARNCollateral',
    '_createdBy': 'cmsadmin',
    '_modifiedBy': 'cmsadmin',
    '_createdOn': '2017-07-04T10:33:48.869Z',
    '_modifiedOn': '2017-07-04T10:33:48.869Z',
    '_isDeleted': false,
    '_version': '95598dc5-d8d2-4157-a29b-eaf72fc99cfd'
};

export const collateralResData = {
    'collateralCode': 'code03',
    'collateralType': 'GUARN',
    'details': {
        'formNo': 'asd',
        'recievedDate': 'asd',
        'reviewDate': '',
        'signingDate': '',
        'executionDate': '',
        'applicationDetailsRemarks': '',
        'loanValuePcnt': '',
        'nextReviewDate': '',
        'expiryDate': '',
        'generalDetailsRemarks': '',

    },
    'generalDetail': {
        'currencyCode': 'SGD',
        'businessLocation': 'USA',
        'collateralCreationDate': '2017-07-04T10:02:15.068Z',
        'collateralExpiryDate': '2018-06-08T12:33:43.707Z'
    },
    'LodgeBeneficiaryDetail': {
        'beneficiaryList': [
            {
                'beneficiaryName': 'Personal Leadership Centre Pte.Ltd',
                'cifId': '',
                'beneficiaryIdType': '',
                'beneficiaryId': 'GCIN0000000',
                'addressLine1': '',
                'addressLine2': '',
                'addressLine3': '',
                'city': '',
                'state': '',
                'country': '',
                'postalCode': '',
                'phoneNo': '',
                'emailAddress': '',
                'telexNo': '',
                'faxNo': '',
                'delete': false,
                'rank': '',
                'capAmount': 0,
                'capAmountType': ''
            }
        ]
    },
    'CollateralValuationDetail': {
        'externalChargeAmt': {
            'value': 0,
            'ccy': 'SGD'
        },
        'collateralValue': {
            'value': 0,
            'ccy': 'SGD'
        },
        'finalCollateralValue': {
            'value': 0,
            'ccy': 'SGD'
        },
        'totalApportionedValue': {
            'value': 0,
            'ccy': 'SGD'
        },
        'balanceApportionableAmt': {
            'value': 0,
            'ccy': 'SGD'
        },
        'apportioningMethod': 'P'
    },
    'document': {
        'documentidList': []
    },
    'beneficiary': {
        'beneficiaryList': []
    },
    'ownership': {
        'ownershipid': []
    },
    'LodgeOwnerShipDetail': {
        'ownerShipList': []
    },
    'LodgeCollateralTypeSpecificDetail': {
        'guaranteeAmt': {}
    }
};
