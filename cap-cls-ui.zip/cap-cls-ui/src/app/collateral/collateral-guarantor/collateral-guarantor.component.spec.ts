import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule,FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { IntlModule } from '@progress/kendo-angular-intl';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { AutoCompleteModule, ComboBoxModule } from '@progress/kendo-angular-dropdowns';
import { CollateralGuarantorComponent } from './collateral-guarantor.component';
import { GcinData, GuarantorData } from './gcin-mock-data';
import { CollateralGuarantorService } from './collateral-guarantor.service';
import { Collateral } from '../model/collateral';
import { CollateralService } from '../collateral.service';
import { CustomFormControl } from '../../common/custom-form-controls/custom-form-control';
class MockGuaratorService {
	getGuarantorIdDataService(data) {
		if (data.searchKeyword.length > 3) {
			return Observable.of(GcinData);
		} else {
			return Observable.throw({status: 404});
		}
	}

	getGuarantorData(data: any) {
		return data;
	}
}
class MockCollateralService {
	getCollateral() {
		return new Collateral();
	}
}
class MockFormBuilder extends FormBuilder {
	getBlankForm() {
		const formBuilder = new FormBuilder;
		const formGroup = formBuilder.group({
			guarantorId: [''],
			guarantorDescription: [''],
			guarantorType: [''],
			gurantorName: [''],
			guaranteePercentage: ['']
		});
		return formGroup;
	}

	getAddForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			guarantorId: ['GC0001045992'],
			guarantorDescription: ['16R2A GCIN4NF CN006 (GC0001045992)'],
			guarantorType: ['COUNTERPARTY'],
			gurantorName: [''],
			guaranteePercentage: ['100']
		});
		return formGroup;
	}
	getMainForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			ownershipid: ['']
		});
		return formGroup;
	}

	setMainForm(data: any) {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			ownershipid: [data]
		});
		return formGroup;
	}
}

describe('CollateralGuarantorComponent', () => {
	let component: CollateralGuarantorComponent;
	let fixture: ComponentFixture<CollateralGuarantorComponent>;
	const guarantorData = {
		'guarantorId': 'GC0001045992',
		'guarantorDescription': '16R2A GCIN4NF CN006 (GC0001045992)',
		'guarantorType': 'COUNTERPARTY',
		'gurantorName': '',
		'guaranteePercentage': '100'
	};
	const mockGuarantorData = GuarantorData;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				CommonModule,
				BrowserModule, FormsModule, ReactiveFormsModule,
				ButtonsModule, BrowserAnimationsModule,
				LoaderModule, GridModule, ClsSharedCommonModule, IntlModule, AutoCompleteModule
				, PopupDialogModule, CommonUIModule, ComboBoxModule
			],
			declarations: [CollateralGuarantorComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [
				{provide: CollateralService, useClass: MockCollateralService},
				{provide: CollateralGuarantorService, useClass: MockGuaratorService},
				{provide: FormBuilder, useClass: MockFormBuilder}
			]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CollateralGuarantorComponent);
		component = fixture.componentInstance;
		component.collateralGuarantorForm = new FormGroup({}, );
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('should show normalgrid on init', (async () => {
		component.divForNormalGrid = true;
		component.showSummaryGrid = false;
		expect(component.divForNormalGrid).toBe(true);
		component.customizeGuarantorGridForSummaryComp();
		if (component.showSummaryGrid) {
			expect(component.divForNormalGrid).toBe(false);
		} else {
			expect(component.divForNormalGrid).toBe(true);
		}
	}));
	it('PopDialog box should be close  onclick of Close button',
		async(() => {
			fixture.detectChanges();
			component.closeEventFromPopupDialog(true);
			expect(component.showPopupDialog).toBe(true);
		}));
	it('PopDialog box should be open  onclick of Add Guarantor button',
		async(() => {
			fixture.detectChanges();
			component.addGuarantor();
			expect(component.showPopupDialog).toBe(true);
			expect(component.saveData).toBe(true);
			expect(component.disableGCINCIF).toBe(false);
		}));
	it('should disable Add Guarantor button on init component',
		async(() => {
			fixture.detectChanges();
			expect(component.addGuarantorDisable).toBe(true);
		}));

	it('should Enable Add Guarantor button once select guarantor from dropdown ',
		async(() => {
			fixture.detectChanges();
			component.guarantorSelectedValueOld = '';
			component.guarantorSelectedValueNew = '';
			component.guarantorGridData = [];
			component.guarantorSelect('several');
			fixture.detectChanges();
			expect(component.addGuarantorDisable).toBe(false);
			expect(component.configureChangeAlertToastEnable).toBe(false);
			expect(component.gridDisable).toBe(false);
		}));
	it('should Disable Add Guarantor button if value undefined or empty from guarantor dropdown list ',
		async(() => {
			fixture.detectChanges();
			component.guarantorSelectedValueOld = '';
			component.guarantorSelectedValueNew = '';
			component.guarantorGridData = [guarantorData];
			component.addGuarantorDisable = false;
			component.guarantorSelect('');
			fixture.detectChanges();
			expect(component.addGuarantorDisable).toBe(true);
		}));
	it('should update selected values on selected guarantor values from dropdown ',
		async(() => {
			fixture.detectChanges();
			component.guarantorSelectedValueOld = '';
			component.guarantorSelectedValueNew = '';
			component.guarantorGridData = [];
			component.addGuarantorDisable = false;
			component.guarantorSelect('several');
			fixture.detectChanges();
			expect(component.guarantorSelectedValueOld).toEqual('several');
			expect(component.guarantorSelectedValueNew).toEqual('several');
		}));
	it('should confirmation popdialog open on click of Guarantor Configuration Button if conditions true  ',
		async(() => {
			fixture.detectChanges();
			component.guarantorGridData = [guarantorData];
			component.validateSelectedChangeValue = true;
			component.configureChangeAlertToastEnable = true;
			component.guarantorConfigure();
			expect(component.showPopupDialogForConfirmation).toBe(true);
		}));
	it('should revert back selected value on click of revert back option  ',
		async(() => {
			fixture.detectChanges();
			component.guarantorSelectedValueOld = 'several';
			component.revertBackChangesForSelected();
			expect(component.selectedGuarantorValue).toBe('several');
		}));
	it('should alert toast message hide  on click of revert back option  ',
		async(() => {
			fixture.detectChanges();
			component.guarantorSelectedValueOld = 'several';
			component.revertBackChangesForSelected();
			expect(component.configureChangeAlertToastEnable).toBe(false);
		}));
	it('Guarantor form should be defined onclick of ADD Guarantor button',
		async(() => {
			fixture.detectChanges();
			const mockForm = new MockFormBuilder();
			component.guarantorForm = mockForm.getBlankForm();
			component.showPopupDialog = false;
			component.addGuarantor();
			expect(component.guarantorForm).toBeDefined();
		}));
	it('Data should add to grid on click of save button from guarantor dialog box',
		async(() => {
			fixture.detectChanges();
			expect(component.guarantorGridData.length).toBe(0);
			component.showPopupDialog = false;
			component.guarantorForm = null;
			component.percentageValidationCheck = false;
			const mockForm = new MockFormBuilder();
			component.guarantorForm = mockForm.getBlankForm();
			component.addGuarantor();
			expect(component.showPopupDialog).toBe(true);
			component.collateralGuarantorForm = mockForm.getMainForm();
			component.guarantorForm = mockForm.getAddForm();
			const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
			component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
			component.submitGuarantorForm(mockGuarantorData[0]);
			expect(component.guarantorGridData.length).toBeGreaterThan(0);
			expect(component.saveData).toBe(true);
			expect(component.showPopupDialog).toBe(false);
			expect(component.noDataFound).toBe(true);
		}));
	it('should Dalete guarantor data from Grid onClick of delete icon',
		async(() => {
			fixture.detectChanges();
			component.guarantorGridData = [];
			expect(component.guarantorGridData.length).toBe(0);
			component.showPopupDialog = false;
			component.guarantorForm = null;
			component.percentageValidationCheck = false;
			const mockForm = new MockFormBuilder();
			component.guarantorForm = mockForm.getBlankForm();
			component.addGuarantor();
			expect(component.showPopupDialog).toBe(true);
			component.collateralGuarantorForm = mockForm.getMainForm();
			component.guarantorForm = mockForm.getAddForm();
			const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
			component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
			component.submitGuarantorForm(mockGuarantorData[0]);
			expect(component.guarantorGridData.length).toBeGreaterThan(0);
			component.gaurantorRemoveItem(0);
			expect(component.guarantorGridData.length).toBe(0);
		}));
	it('should Data Populate on Dialog box on click of Edit icon',
		async(() => {
			fixture.detectChanges();
			component.guarantorGridData = [];
			expect(component.guarantorGridData.length).toBe(0);
			component.showPopupDialog = false;
			component.guarantorForm = null;
			component.percentageValidationCheck = false;
			const mockForm = new MockFormBuilder();
			component.guarantorForm = mockForm.getBlankForm();
			component.addGuarantor();
			expect(component.showPopupDialog).toBe(true);
			component.collateralGuarantorForm = mockForm.getMainForm();
			component.guarantorForm = mockForm.getAddForm();
			const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
			component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
			component.submitGuarantorForm(mockGuarantorData[0]);
			expect(component.guarantorGridData.length).toBeGreaterThan(0);
			component.guarantorEditFunc(GcinData[0], 0);
			expect(component.saveData).toBe(false);
			expect(component.showPopupDialog).toBe(true);
			expect(component.disableGCINCIF).toBe(true);
			expect(component.dialogTitleName).toEqual('Update Guarantor');
			component.dataForEdit(GcinData[0]);
			fixture.detectChanges();
			expect(component.saveData).toBe(false);
		}));
	it('should update data into grid  onclick of update button ',
		async(() => {
			fixture.detectChanges();
			component.guarantorGridData = [];
			expect(component.guarantorGridData.length).toBe(0);
			component.showPopupDialog = false;
			component.guarantorForm = null;
			component.percentageValidationCheck = false;
			const mockForm = new MockFormBuilder();
			component.collateralGuarantorForm = mockForm.getMainForm();
			component.guarantorForm = mockForm.getBlankForm();
			component.selectedGuarantorValue = 'Several';
			component.addGuarantor();
			expect(component.showPopupDialog).toBe(true);
			component.guarantorForm = mockForm.getAddForm();
			const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
			component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
			component.submitGuarantorForm(mockGuarantorData[0]);
			expect(component.guarantorGridData.length).toBeGreaterThan(0);
			component.guarantorEditFunc(GcinData[0], 0);
			expect(component.saveData).toBe(false);
			expect(component.showPopupDialog).toBe(true);
			expect(component.disableGCINCIF).toBe(true);
			expect(component.dialogTitleName).toEqual('Update Guarantor');
			component.dataForEdit(GcinData[0]);
			const updatedData = {
				'guarantorId': 'GC0001045991',
				'guarantorDescription': '16R2A GCIN4NF CN004 (GC0001045991)',
				'guarantorType': 'COUNTERPARTY',
				'gurantorName': null,
				'guaranteePercentage': '25'
			};
			component.updateGuarantorValue(updatedData);
			expect(component.sumOfPercentage).toEqual(25);
		}));
	it('should check validation on click of save button for invalid data ', async(() => {
		fixture.detectChanges();
		const mockForm = new MockFormBuilder();
		component.collateralGuarantorForm = mockForm.getMainForm();
		component.guarantorForm = mockForm.getAddForm();
		const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
		component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
		const invalidData = {
			'guarantorId': 'GC0001045991',
			'guarantorDescription': '',
			'guarantorType': 'COUNTERPARTY',
			'gurantorName': null,
			'guaranteePercentage': '1'
		};
		expect(component.validationCheck(invalidData)).toBe(false);
	}));
	it('should check validation for percentage if invalid entry ', async(() => {
		fixture.detectChanges();
		const mockForm = new MockFormBuilder();
		component.collateralGuarantorForm = mockForm.getMainForm();
		component.guarantorForm = mockForm.getAddForm();
		const mockBeneficiaryService: MockGuaratorService = new MockGuaratorService();
		component.idList = mockBeneficiaryService.getGuarantorData(GcinData);
		const invalidData = {
			'guarantorId': 'GC0001045991',
			'guarantorDescription': '',
			'guarantorType': 'COUNTERPARTY',
			'gurantorName': null,
			'guaranteePercentage': ''
		};
		expect(component.validationCheck(invalidData)).toBe(false);
	}));
	it('should validations reset on call of validation reset function ', async(() => {
		fixture.detectChanges();
		component.guarantorIdInvalid = true;
		component.validationReset();
		expect(component.guarantorIdInvalid).toBe(false);
	}));
	it('should not allowed to add sum of percentage greater than 100 if selected value severals ', async(() => {
		fixture.detectChanges();
		component.guarantorGridData = GcinData;
		component.sumOfPercentage = 48;
		component.selectedGuarantorValue = 'Several';
		component.percentageChange('89');
		expect(component.guarantorPercentageValid).toBe(true);
		expect(component.errorValidatorMessageForPercentage).toEqual('Total Percentage should not be exceed 100');
	}));
	it('should not allowed to add /update data without entering percentage in dialogBox', async(() => {
		fixture.detectChanges();
		component.guarantorGridData = GcinData;
		component.sumOfPercentage = 48;
		component.selectedGuarantorValue = 'Several';
		component.percentageChange('');
		expect(component.guarantorPercentageValid).toBe(false);
		expect(component.percentageValidationCheck).toBe(false);
		fixture.detectChanges();
		component.guarantorGridData = [];
		component.sumOfPercentage = 48;
		component.selectedGuarantorValue = 'Several';
		component.percentageChange('34');
		expect(component.guarantorPercentageValid).toBe(false);
	}));
	it('should get sum of percentage of gridData', async(() => {
		fixture.detectChanges();
		component.guarantorGridData = GcinData;
		expect(component.getGridPercentageSum()).toEqual(48);
	}));
	it('Error should get from backend when something wrong is entered in beneficiary id field',
		async(() => {
			fixture.detectChanges();
			component.idList = [];
			expect(component.idList.length).toBe(0);
			component.searchByGCINCIF('gfx');
			expect(component.errorMessage).toBe(true);
		}));
});
