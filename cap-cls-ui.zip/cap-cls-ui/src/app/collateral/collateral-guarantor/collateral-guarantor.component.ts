import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { CollateralGuarantorService } from './collateral-guarantor.service';
import { GcinData } from './gcin-mock-data';
import { GuarantorItemModel } from './guarantor.model';
import { ToastsComponent } from '../../shared/toasts/toasts.component';
import { CollateralService } from '../collateral.service';
import { Observable } from 'rxjs/Observable';
import { AbstractControl } from '@angular/forms';
import { TotalPercentageValidator } from './total-percentage-validator';
import { CustomFormControl } from '../../common/custom-form-controls/custom-form-control';
@Component({
	selector: 'collateral-guarantor',
	templateUrl: './collateral-guarantor.component.html',
	styleUrls: ['./collateral-guarantor.component.scss']
})
export class CollateralGuarantorComponent implements OnInit {

	public allowCustom: boolean = true;
	public addGuarantorDisable: boolean = true;
	public listItems: Array<string> = ['Several', 'Joint', 'Several & Joint'];
	public showPopupDialog: boolean = false;
	public dialogTitleName: string = 'Add Guarantor Details';
	public guarantorForm: FormGroup;
	public gaurantorTypeInvalid: boolean = false;
	public idList: any[] = [];
	public divForNormalGrid: boolean = true;
	public guarantorGridData: any[] = [];
	public guarantorList: GuarantorItemModel[] = [];
	public rowIndex: number;
	saveData: boolean = true;
	public sumOfPercentage: number = 0.00;
	public gridDisable: boolean = false;
	public showPopupDialogForConfirmation = false;
	public configureChangeAlertToastEnable: boolean = false;
	public dialogTitleNameConfirmation: string = 'Are You Sure To Reconfigure?';
	public guarantorSelectedValueNew: string = '';
	public guarantorSelectedValueOld: string = '';
	public guarantorIdInvalid: boolean = false;
	public guarantorValueErrDiv: boolean = false;
	public selectedGuarantorValue: string = '';
	@Input() showSummaryGrid: boolean = false;
	@Input() public collateralGuarantorForm: FormGroup;
	@Input() public showAddGuarantorBtn: boolean = true;
	public validateSelectedChangeValue: boolean = false;
	public onchangeSelectedValue: string = '';
	public errorValidatorMessage: string = 'Please make a selection';
	public errorValidatorMessageForPercentage: string = 'Please Enter Percentage';
	public guarantorPercentageValid: boolean = false;
	public percentageValidationCheck: boolean = false;
	public submitted: boolean = false;
	public argToastMessageObject: any;
	public disableGCINCIF: boolean = false;
	public duplicateValueCheck: any;
	public noDataFound: boolean = false;
	public errorMessage: boolean;
	toastsComponent: ToastsComponent = new ToastsComponent();

	constructor(private _fb: FormBuilder, private collateralGuarantorService: CollateralGuarantorService, private collateralService: CollateralService) {

	}

	ngOnInit() {
		this.intializeGuarantorForm();
		this.customizeGuarantorGridForSummaryComp();
		this.validationReset();
	}

	intializeGuarantorForm() {
		this.guarantorForm = this._fb.group({
			guarantorId: [''],
			guarantorDescription: [''],
			guarantorType: [''],
			gurantorName: [''],
			guaranteePercentage: ['']
		});
			this.collateralGuarantorForm.addControl('totalPercentageSum', new CustomFormControl('0.00', [TotalPercentageValidator.required]));
					(<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).type = 'text';
					(<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).label = 'Total Percentage';

		if (this.collateralService.getCollateral().LodgeOwnerShipDetail.ownerShipList) {
			this.guarantorGridData = this.collateralService.getCollateral().LodgeOwnerShipDetail.ownerShipList;
			if (this.guarantorGridData.length > 0) {
				this.selectedGuarantorValue = this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType;
				this.guarantorSelectedValueNew = this.selectedGuarantorValue;
				this.guarantorSelectedValueOld = this.selectedGuarantorValue;
				this.noDataFound = true;
				this.processFormItems();
				this.addGuarantorDisable = false;
			}
		} else {
			this.guarantorGridData = [];
		}
	}

	guarantorChange(value: any) {

	}

	guarantorSelect(value: any) {
		if (value !== undefined && value !== '') {
			this.onchangeSelectedValue = value;
			if (value !== this.guarantorSelectedValueOld && !(this.guarantorSelectedValueNew === '') && (this.guarantorGridData.length > 0)) {
				this.addGuarantorDisable = true;
				this.configureChangeAlertToastEnable = true;
				this.gridDisable = true;
				this.validateSelectedChangeValue = true;
			} else {
				this.addGuarantorDisable = false;
				this.configureChangeAlertToastEnable = false;
				this.gridDisable = false;
				if (this.guarantorSelectedValueNew !== undefined) {
					this.guarantorSelectedValueOld = value;
					this.guarantorSelectedValueNew = value;
				}
			}
		} else {
			this.addGuarantorDisable = true;
		}
	}

	addGuarantor() {
		this.showPopupDialog = true;
		this.saveData = true;
		this.validationReset();
		this.guarantorForm.reset();
		this.disableGCINCIF = false;
		if (this.selectedGuarantorValue === 'Several') {
			this.collateralGuarantorForm.addControl('totalPercentageSum', new CustomFormControl(this.sumOfPercentage, [TotalPercentageValidator.required]));
					(<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).type = 'text';
					(<CustomFormControl>this.collateralGuarantorForm.controls['totalPercentageSum']).label = 'Total Percentage';

		} else {
			(<FormControl>this.collateralGuarantorForm.controls['totalPercentageSum'])
			.setValue(100.00);
		}
	}

	guarantorConfigure() {
		if ((this.guarantorGridData.length > 0) && (this.validateSelectedChangeValue) && (this.configureChangeAlertToastEnable)) {
			this.showPopupDialogForConfirmation = true;
		}
	}

	guarantorEditFunc(item: any, index: number): void {
		this.saveData = false;
		this.showPopupDialog = true;
		this.disableGCINCIF = true;
		this.dialogTitleName = 'Update Guarantor';
		this.errorValidatorMessageForPercentage = 'Please Enter Percentage';
		this.rowIndex = index;
		this.validationReset();
		this.searchByGCINCIF(item.cifId);
		setTimeout(() => this.dataForEdit(item), 1000);
	}

	dataForEdit(item: any) {
		this.sumOfPercentage = this.sumOfPercentage - item['collateralGuarantorPcnt'];
		this.saveData = false;
		this.showPopupDialog = true;
		if (this.idList !== undefined) {
			this.guarantorForm = this._fb.group({
				guarantorId: [item.cifId],
				guarantorDescription: [this.idList[0]['description']],
				guarantorType: [item.idType],
				gurantorName: [item.name],
				guaranteePercentage: [item.collateralGuarantorPcnt]
			});
			this.duplicateValueCheck = this.guarantorForm.value;
		}
	}

	gaurantorRemoveItem(index: number) {
		this.guarantorGridData.splice(index, 1);
		this.processFormItems();
		this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
			'A record of Guarantor details has been successfully deleted.',
			'', '');
		this.collateralGuarantorForm.get('ownershipid').setValue(this.guarantorGridData);
		if (this.guarantorGridData.length === 0) {
			this.configureChangeAlertToastEnable = false;
			this.selectedGuarantorValue = '';
			this.guarantorSelectedValueNew = '';
			this.guarantorSelectedValueOld = '';
			this.noDataFound = false;
			this.addGuarantorDisable = true;
			this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = '';
		}
	}

	closeEventFromPopupDialog(showPopupDialog: boolean) {
		this.showPopupDialog = showPopupDialog;
		this.saveData = true;
		this.guarantorForm.reset();
	}

	searchByGCINCIF(searchValue: string) {
		const bodyData = { 'searchKeyword': searchValue };
		if (searchValue.length > 2) {
			this.idList = [];
			this.collateralGuarantorService.getGuarantorIdDataService(bodyData).subscribe(
				response => {
					setTimeout(() => {
					}, 1000);
					this.idList = response;
				},
				error => {
					this.errorMessage = true;
					if (error.status === 500) {
						return Observable.throw(new Error(error.status));
					} else if (error.status === 400) {
						return Observable.throw(new Error(error.status));
					} else if (error.status === 409) {
						return Observable.throw(new Error(error.status));
					} else if (error.status === 404) {
						return Observable.throw(new Error(error.status));
					}
				}
			);
		}
	}

	onSearchGCIDCIFSelect(event) {
		const dataObj = this.idList.find(item => item.description === event);
		if (!(dataObj === undefined)) {
			this.guarantorIdInvalid = false;
			this.guarantorForm.controls['guarantorType'].setValue(dataObj.idType);
			this.guarantorForm.controls['guarantorId'].setValue(dataObj.cifId);
		} else {
			this.guarantorIdInvalid = true;
		}
	}

	submitGuarantorForm(data: any) {
		this.submitted = true;
		this.divForNormalGrid = true;
		this.errorValidatorMessage = 'Please make a selection';
		const errorFlag = this.validationCheck(data);
		if (errorFlag && !this.percentageValidationCheck) {
			this.updateGuarantorData(data, 'Save');
		}
	}

	updateGuarantorValue(data: any) {
		this.errorValidatorMessage = 'Please make a selection';
		const errorFlag = this.validationCheck(data, 'Update');
		if (errorFlag === true) {
			if (JSON.stringify(this.duplicateValueCheck) === JSON.stringify(data)) {
				this.guarantorIdInvalid = true;
			} else {
				if (this.duplicateValueCheck.guarantorDescription !== data.guarantorDescription) {
					const dataObj = this.guarantorGridData.find(item => item.description === data.guarantorDescription);
					if (!(dataObj === undefined)) {
						this.guarantorIdInvalid = true;
					} else {
						this.updateGuarantorData(data, 'Update');
					}
				} else {
					this.updateGuarantorData(data, 'Update');
				}
			}
		}
	}

	updateGuarantorData(data, functionType?: any) {
		const modifiedName = this.modifiedNameFunc(data.guarantorDescription, data.guarantorId);
		const guarantorItemModel = new GuarantorItemModel();
		guarantorItemModel.cifId = data['guarantorId'];
		guarantorItemModel.idType = data['guarantorType'];
		guarantorItemModel.name = modifiedName;
		// guarantorItemModel.guarantorType = this.selectedGuarantorValue;
		guarantorItemModel.collateralGuarantorPcnt = data['guaranteePercentage'];
		if (functionType === 'Update') {
			this.guarantorGridData[this.rowIndex] = guarantorItemModel;
			this.processFormItems();
			this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
				'A record of Guarantor details has been successfully Updated.',
				'', '');
			this.showPopupDialog = false;
			this.collateralGuarantorForm.get('ownershipid').setValue(this.guarantorGridData);
			this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = this.selectedGuarantorValue;
		}
		if (functionType === 'Save') {
			this.guarantorIdInvalid = false;
			this.guarantorGridData.push(guarantorItemModel);
			this.processFormItems();
			this.collateralGuarantorForm.get('ownershipid').setValue(this.guarantorGridData);
			this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
				'A record of Guarantor details has been successfully Added.',
				'', '');
			this.showPopupDialog = false;
			this.guarantorForm.reset();
			this.noDataFound = true;
			this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = this.selectedGuarantorValue;
		}
	}

	private modifiedNameFunc(description: string, gcin: string): string {
		let tempName = description.replace(gcin, '');
		tempName = tempName.replace('()', '');
		return tempName;
	}

	getGridPercentageSum(): number {
		let gridSumOfGuarantorPercentage: number = 0.0;
		for (let i = 0; i < this.guarantorGridData.length; i++) {
			gridSumOfGuarantorPercentage += parseFloat(this.guarantorGridData[i]['collateralGuarantorPcnt']);
		}
		gridSumOfGuarantorPercentage = this.roundNumber(gridSumOfGuarantorPercentage, 12);
		return gridSumOfGuarantorPercentage;
	}

	roundNumber(number, decimals): number {
		const newnumber = new Number(number + '').toFixed(parseInt(decimals));
		return parseFloat(newnumber);
	}

	processFormItems() {
		this.sumOfPercentage = 0.000;
		for (let i = 0; i < this.guarantorGridData.length; i++) {
			this.sumOfPercentage = this.sumOfPercentage + parseFloat(this.guarantorGridData[i]['collateralGuarantorPcnt']);
		}
		this.sumOfPercentage = this.roundNumber(this.sumOfPercentage, 12);
		if (this.selectedGuarantorValue === 'Several') {
(<FormControl>this.collateralGuarantorForm.controls['totalPercentageSum'])
			.setValue(this.sumOfPercentage);
		}
	}

	revertBackChangesForSelected() {
		this.addGuarantorDisable = false;
		this.selectedGuarantorValue = undefined;
		this.selectedGuarantorValue = this.guarantorSelectedValueOld;
		this.configureChangeAlertToastEnable = false;
		this.gridDisable = false;

	}

	closeEventFromPopupDialogForConfirmation() {
		this.showPopupDialogForConfirmation = false;

	}

	revertBackChangesFromPopDialog() {
		this.showPopupDialogForConfirmation = false;
		this.configureChangeAlertToastEnable = false;
		this.selectedGuarantorValue = undefined;
		this.guarantorSelectedValueNew = this.guarantorSelectedValueOld;
		this.selectedGuarantorValue = this.guarantorSelectedValueOld;
		this.gridDisable = false;
		this.addGuarantorDisable = false;
	}

	confirmConfigureChanges() {
		this.showPopupDialogForConfirmation = false;
		this.configureChangeAlertToastEnable = false;
		this.selectedGuarantorValue = this.onchangeSelectedValue;
		this.guarantorSelectedValueOld = this.selectedGuarantorValue;
		this.guarantorSelectedValueNew = this.selectedGuarantorValue;
		this.guarantorGridData = [];
		this.addGuarantorDisable = false;
		this.sumOfPercentage = null;
		this.gridDisable = false;
		this.noDataFound = false;
		this.collateralGuarantorForm.get('ownershipid').setValue(this.guarantorGridData);
		this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.guaranteeType = '';
	}

	validationCheck(data?: any, functionType?: any) {
		let valid = true;
		this.guarantorIdInvalid = false;
		this.guarantorPercentageValid = false;
		const guaratorIdCheck = this.guarantorGridData.find(item => item.cifId === data.guarantorId);
		const dataObj = this.idList.find(item => item.description === data.guarantorDescription);
		if (((data.guarantorDescription === '') || (data.guarantorDescription === null)) || (dataObj === undefined) || (guaratorIdCheck !== undefined && (this.guarantorGridData.length > 0) && (functionType !== 'Update'))) {
			this.guarantorIdInvalid = true;
			this.guarantorValueErrDiv = false;
			if (guaratorIdCheck !== undefined && (this.guarantorGridData.length > 0) && (functionType !== 'Update')) {
				this.errorValidatorMessage = 'Duplicate Values are not allowed';
			}
			valid = false;
		}
		if (((data.guaranteePercentage === '') || (data.guaranteePercentage === null)) || (this.percentageValidationCheck)) {
			this.guarantorPercentageValid = true;
			valid = false;
		}
		return valid;
	}

	customizeGuarantorGridForSummaryComp() {
		if (this.guarantorGridData.length > 0) {
			this.divForNormalGrid = !this.showSummaryGrid;
		}
	}

	validationReset() {
		this.guarantorIdInvalid = false;
		this.guarantorPercentageValid = false;
		this.submitted = false;
	}

	percentageChange(event: any) {
		this.percentageValidationCheck = false;
		if (event && this.sumOfPercentage && (this.guarantorGridData.length > 0) && (this.selectedGuarantorValue === 'Several')) {
			const percentageSum = this.sumOfPercentage;
			const total = percentageSum + (parseInt(event));
			if (total > 100) {
				this.guarantorPercentageValid = true;
				this.percentageValidationCheck = true;
				this.errorValidatorMessageForPercentage = 'Total Percentage should not be exceed 100';
			} else {
				this.guarantorPercentageValid = false;
				this.errorValidatorMessageForPercentage = 'Please make a selection';
				this.percentageValidationCheck = false;
			}
		}
		if ((event !== undefined) && (this.guarantorGridData.length === 0)) {
			this.guarantorPercentageValid = false;
		}
	}
}


