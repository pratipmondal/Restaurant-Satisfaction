import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Headers, Http, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';

@Injectable()
export class CollateralGuarantorService {

	constructor(private http: Http) {
	}

	public getGuarantorIdDataService(data: any): Observable<any> {
		const urlToGetBeneficiaryId = environment.apiBaseUrl + environment.apiToGetCifId;
		const headers = new Headers({'Content-Type': 'application/json'});
		const options = new RequestOptions({headers: headers});
		return this.http.post(urlToGetBeneficiaryId, data, options)
			.map(
				res => res.json()
			)
			.catch(
				error => this.handleError(error)
			);
	}

	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}

}
