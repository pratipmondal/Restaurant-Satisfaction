import { AbstractControl } from '@angular/forms';
export class TotalPercentageValidator {
    private static message: string = '  Make sure that total sum of guarantee percentage should be 100';
    static required(c: AbstractControl,typeGuarantee?:string) {
        return c.value ? TotalPercentageValidator.checkTotal(c.value) ? null : {
			required: TotalPercentageValidator.getMessage(c) // the custom message you wish to display
		} : {
            required: 'cannot be null'
        };
    }
    static getMessage(c: AbstractControl): string {
        return this.message; 
    }

    static checkTotal(val): boolean {
        if(val  === 100){
            return true;
        }
        return false;
    }
}

