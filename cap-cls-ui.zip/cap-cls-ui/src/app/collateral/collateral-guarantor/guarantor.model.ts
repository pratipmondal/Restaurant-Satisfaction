export class GuarantorItemModel {
	cifId: string;
	idType: string;
	idNo: string;
	name: string;
	guarantorType: string;
	collateralGuarantorPcnt: number;
	addressLine1: string;
	addressLine2: string;
	addressLine3: string;
	city: string;
	state: string;
	country: string;
	postalCode: string;
	phoneNo: string;
	emailAddress: string;
	telexNo: string;
	faxNo: string;
	delete: boolean;

	constructor() {
		this.cifId = '';
		this.idType = '';
		this.idNo = '';
		this.name = '';
		this.collateralGuarantorPcnt = null;
		this.addressLine1 = '';
		this.addressLine2 = '';
		this.addressLine3 = '';
		this.city = '';
		this.state = '';
		this.country = '';
		this.postalCode = '';
		this.phoneNo = '';
		this.emailAddress = '';
		this.telexNo = '';
		this.faxNo = '';
		this.delete = false;
	}
}