import { TestBed, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { CollateralGuarantorService } from './collateral-guarantor.service';
import { GcinData } from './gcin-mock-data';
import { environment } from '../../../environments/environment';
class MockGuaratorService {
	getGuarantorIdDataService(data) {
		if (data.searchKeyword.length > 3) {
			return Observable.of(GcinData);
		} else {
			return Observable.throw({status: 404});
		}
	}
}
describe('CollateralGuarantorService', () => {
	let collateralGuarantorService: CollateralGuarantorService;
	let mockBackend: MockBackend;
	const urlToGetGuarantorID = environment.apiBaseUrl + environment.apiToGetCifId;
	const urlToGuarantor = environment.apiBaseUrl + 'collaterals/customers';
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				{provide: CollateralGuarantorService, useClass: MockGuaratorService}
			],
			imports: [HttpModule]
		});
	});
	beforeEach(
		inject([CollateralGuarantorService, MockBackend], (service: CollateralGuarantorService, backend: MockBackend) => {
			collateralGuarantorService = service;
			mockBackend = backend;
		})
	);

	it('should ...', inject([CollateralGuarantorService], (service: CollateralGuarantorService) => {
		expect(service).toBeTruthy();
	}));
	it('collateralGuarantor service should be defined', () => {
		expect(collateralGuarantorService).toBeDefined();
	});
	it('should call getGuarantorIdDataService API from service', () => {
		const filterData = 'GCIN';
		spyOn(collateralGuarantorService, 'getGuarantorIdDataService').and.callFake(function ({'searchKeyword': filterData}) {
			return GcinData;
		});
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Post);
			expect(connection.request.url).toBe(urlToGetGuarantorID);
		});
		expect(collateralGuarantorService.getGuarantorIdDataService({'searchKeyword': 'GCIN'})).toEqual(GcinData);
	});

});
