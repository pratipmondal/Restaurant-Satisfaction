import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { DropDownsModule, ComboBoxModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { ClsSharedCommonModule } from '../shared/';
import { COLLATERAL_ROUTE, CollateralComponent } from './';
import { CounterpartyDetailsModule } from '../shared/counterparty-details/counterparty-details.module';
import { SpecificDetailsModule } from '../collateral/specific-details/specific-details.module';
import { PopupDialogModule } from '../common/popup-dialog/popup-dialog.module';
import { CommonUIModule } from '../common/commonUI.module';
import { BeneficiaryModule } from './beneficiary/beneficiary.module';
import { CustomPanelModule } from '../common/custom-panel/custom-panel.module';
import { TabbedWizardModule } from '../common/tabbed-wizard/tabbed-wizard.module';
import { NewCollateralComponent } from './new-collateral/new-collateral.component';
import { CollateralService } from './collateral.service';
import { AutoSaveService } from '../common/autosave/auto-save.service';
import { ChargeModule } from './charge/charge.module';
import { SummaryModule } from './summary/summary.module';
import { OwnershipModule } from './ownership/ownership.module';
import { DocumentModule } from './document/document.module';
import { NewCollateralModule } from './new-collateral/new-collateral.module';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { ValuationModule } from '../collateral/valuation/valuation.module';
import { CollateralSummaryModule } from './collateral-summary/collateral-summary.module';
import { CollateralsListModule } from './collaterals-list/collaterals-list.module';
import { FacilityLinkageDataService } from './facility-linkage-data/facility-linkage-data.service';
import {CollateralGuarantorModule} from './collateral-guarantor/collateral-guarantor.module';
import { CollateralSummaryService } from './collateral-summary/collateral-summary.service';
@NgModule({
	imports: [
		CommonModule, ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
		DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule,
		ClsSharedCommonModule, CounterpartyDetailsModule, CommonUIModule, PopupDialogModule, SpecificDetailsModule,
		BeneficiaryModule, CustomPanelModule, TabbedWizardModule, ChargeModule, SummaryModule,
		OwnershipModule, DocumentModule, NewCollateralModule, DateInputsModule,  CollateralGuarantorModule
	],
	declarations: [

	],
	entryComponents: [],
	providers: [CollateralService, AutoSaveService, CounterPartyDetailsService, FacilityLinkageDataService, CollateralSummaryService
	],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CollateralModule {
}
