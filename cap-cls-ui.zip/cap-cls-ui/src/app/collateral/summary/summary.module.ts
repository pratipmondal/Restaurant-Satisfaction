import { ModuleWithProviders, NgModule } from '@angular/core';
import { SummaryComponent } from './summary.component';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { SummarySubsectionModule } from './summary-subsection/summary-subsection.module';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { ChargeModule } from '../charge/charge.module';
import { OwnershipModule } from '../ownership/ownership.module';
import { DocumentModule } from '../document/document.module';
import { SpecificDetailsModule } from '../specific-details/specific-details.module';
import { BeneficiaryModule } from '../beneficiary/beneficiary.module';
import {CollateralGuarantorModule} from '../collateral-guarantor/collateral-guarantor.module';
@NgModule({
	imports: [CommonModule, BrowserModule, LoaderModule, GridModule, ButtonsModule,
		InputsModule, SummarySubsectionModule, CustomPanelModule, ChargeModule,
		OwnershipModule, DocumentModule, SpecificDetailsModule, BeneficiaryModule,CollateralGuarantorModule],
	declarations: [SummaryComponent],
	exports: [SummaryComponent]
})

export class SummaryModule {
	public static forRoot(): ModuleWithProviders {
		return {ngModule: SummaryModule, providers: []};
	}
}
