import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SummaryComponent } from './summary.component';
import { BeneficiaryModule } from '../beneficiary/beneficiary.module';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { SummarySubsectionModule } from './summary-subsection/summary-subsection.module';
import { ChargeModule } from '../charge/charge.module';
import { SpecificDetailsModule } from '../specific-details/specific-details.module';
import { DocumentModule } from '../document/document.module';
import { OwnershipModule } from '../ownership/ownership.module';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CollateralService } from '../collateral.service';
import { Collateral, CollateralValuationDetail } from '../model/collateral';
import { FormBuilder } from '@angular/forms';
import {CollateralGuarantorModule} from '../collateral-guarantor/collateral-guarantor.module';
class MockCollateralService {
	getCollateral() {
		return new Collateral();
	}

	getCollateralForm() {
		const formBuilder = new FormBuilder;
		const formGroup = formBuilder.group({
			details: this.getDetailsForm(),
			beneficiary: this.getBeneficiaryForm(),
			charge: this.getChargeForm(),
			apportion: this.getApportionForm(),
			document: this.getDocumentForm(),
			ownership: this.getOwnershipForm(),
			particulars: this.getParticularsForm()
		});
		return formGroup;
	}

	private getDetailsForm() {
		const formBuilder = new FormBuilder;
		return formBuilder.group({
			collateralid: ['']
		});
	}

	private getBeneficiaryForm() {
		const formBuilder = new FormBuilder;
		return formBuilder.group({
			beneficiaryList: ['']
		});
	}

	private getChargeForm() {
		const formBuilder = new FormBuilder;
		return formBuilder.group({
			chargeList: ['']
		});
	}

	private getApportionForm() {
		const formBuilder = new FormBuilder;
		return formBuilder.group({});
	}

	private getDocumentForm() {
		const formBuilder = new FormBuilder;
		return formBuilder.group({
			documentidList: []
		});
	}

	private getOwnershipForm() {
		const formBuilder = new FormBuilder;
		return formBuilder.group({
			ownershipid: []
		});
	}

	private getParticularsForm() {
		const formBuilder = new FormBuilder;
		return formBuilder.group({
			particularsList: ['']
		});
	}
}

describe('SummaryComponent', () => {
	let summaryComponent: SummaryComponent;
	let fixture: ComponentFixture<SummaryComponent>;
	let counterForSpy = 0;

	beforeEach(async(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
		TestBed.configureTestingModule({
			imports: [CommonModule, BrowserModule, CommonModule, BrowserModule, LoaderModule, GridModule, ButtonsModule,
				InputsModule, SummarySubsectionModule, CustomPanelModule, ChargeModule,
				OwnershipModule, DocumentModule, SpecificDetailsModule, BeneficiaryModule,CollateralGuarantorModule],
			declarations: [SummaryComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [
				{provide: CollateralService, useClass: MockCollateralService}
			]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		if (counterForSpy === 0) {
			fixture = TestBed.createComponent(SummaryComponent);
			summaryComponent = fixture.componentInstance;
			let collateralService: CollateralService;
			collateralService = TestBed.get(CollateralService);
			summaryComponent.newCollateralForm = collateralService.getCollateralForm();
			spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
			fixture.detectChanges();
		}

	});

	it('should create', () => {
		expect(summaryComponent).toBeDefined();
		counterForSpy++;
	});

	it('should show charge data in charge summary grid', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockChargeList = [{
			natureOfCharge: 'CHARGENAT2',
			chargeRank: '1DBS',
			chargeAmount: 10000.00,
			filingDate: '2017-05-12T07:06:17.302Z',
			receiptDate: '2017-05-12T07:06:17.302Z',
			solicitorName: 'Stevan Tan',
			registrationAuthInfo: '-',
			currencyType: 'SGD',
			externalCharge: 'No'
		}];
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.charge.chargeList = mockChargeList;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		expect(summaryComponent.divForChargeComponent).toBe(true);
	});

	it('should not show charge panel', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockChargeList = '';
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.charge.chargeList = mockChargeList;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		expect(summaryComponent.divForChargeComponent).toBe(false);
	});

	it('should show beneficiary data in beneficiary summary grid', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockBeneficiaryList = [{
			beneficiaryId: 'GC0001045990',
			beneficiaryIdType: 'COUNTERPARTY1',
			beneficiaryName: '16R2A GCIN4NF CN002',
			cifId: 'ABCD',
			addressLine1: '',
			addressLine2: '',
			addressLine3: '',
			city: '',
			state: '',
			country: '',
			postalCode: '',
			phoneNo: '',
			emailAddress: '',
			telexNo: '',
			faxNo: '',
			delete: false,
			rank: '',
			capAmount: 0,
			capAmountType: ''
		}];
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		const collateral: Collateral = new Collateral;
		collateral.LodgeBeneficiaryDetail.beneficiaryList = mockBeneficiaryList;
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		expect(summaryComponent.divForBeneficiaryComponent).toBe(true);
	});

	it('should not show beneficiary panel ', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockBeneficiaryList = [];
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.beneficiary.beneficiaryList = mockBeneficiaryList;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		expect(summaryComponent.divForBeneficiaryComponent).toBe(false);
	});

	it('should show document data in document summary grid', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockDocumentList = [{
			documentCode: 'Document01',
			comments: '-',
			dueDate: null,
			documentDate: new Date('2017-05-12T07:06:17.255Z'),
			documentExpirationDate: null,
			documentReceivedDate: null,
			documentStatus: 'status01',
			documentId: '',
			delete: false
		}];

		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		const collateral: Collateral = new Collateral;
		collateral.LodgeDocumentationDetail.document = mockDocumentList;
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		expect(summaryComponent.divForDocumentComponent).toBe(true);
	});

	it('should not show document panel', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockDocumentList = [];
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.document.documentidList = mockDocumentList;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		expect(summaryComponent.divForDocumentComponent).toBe(false);
	});

	it('should show ownership data in ownership summary grid', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockOwnershipList = [{
			cifId: 'ABC COMPANY OF INDIA (CFID_1)',
			idType: 'COUNTERPARTY',
			collateralOwnerShipPcnt: 30,
			name: 'ABC COMPANY OF INDIA',
			actualCFID: 'CFID_1',
			idNo: '',
			addressLine1: '',
			addressLine2: '',
			addressLine3: '',
			city: '',
			state: '',
			country: '',
			postalCode: '',
			phoneNo: '',
			emailAddress: '',
			telexNo: '',
			faxNo: '',
			delete: false
		}];
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		const collateral: Collateral = new Collateral;
		collateral.LodgeOwnerShipDetail.ownerShipList = mockOwnershipList;
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		expect(summaryComponent.divForOwnershipComponent).toBe(true);
	});

	it('should not show ownership panel', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockOwnershipList = [];
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.ownership.ownershipid = mockOwnershipList;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		expect(summaryComponent.divForOwnershipComponent).toBe(false);
	});

	it('should show particulars data in particulars summary grid', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockParticularsList = [{
			bankId: 'bank1',
			particularsDepositId: '123',
			principalAmount: 5000.00,
			availableBalance: 6000.00,
			accountBalance: 8000.00,
			maturityDate: '19Jun2018',
			term: 'Term 1',
			depositNum: 'DP1',
			facilityRef: 'DBS Singapore',
			plegorName: 'Yes',
			earmarkReason: 'Marissa',
			particularsComment: '-',
			principalAmntCcy: '-',
			availableBalanceCcy: '-',
			accountBalanceCcy: '-'
		}];
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.particulars.particularsList = mockParticularsList;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		expect(summaryComponent.divForSpecificDetailsComponent).toBe(true);
	});

	it('should not show particulars panel', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		summaryComponent = fixture.componentInstance;
		const mockParticularsList = '';
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.particulars.particularsList = mockParticularsList;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		expect(summaryComponent.divForSpecificDetailsComponent).toBe(false);
	});

	it('should show basic details data in collateral details panel', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		const mockGeneralDetailsData = {
			amount: 50000.00,
			generalDetailsRemarks: '-',
			loanValuePcnt: 20,
			currencyType: 'SGD'
		};
		summaryComponent = fixture.componentInstance;
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.details = mockGeneralDetailsData;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		const resultData = {
			'Method': undefined,
			'CCY Amount': 'SGD 50,000.00',
			'Expiry Date': '-',
			'Remarks': '-',
			'Loan to Value (%)': '20%',
			'Basel Eligible': 'No',
			'Location of Collateral': '-',
			'Solicitor Name': undefined
		};
		expect(summaryComponent.basicDetails).toEqual(resultData);
	});

	it('should show DBS % of collateral details data in collateral details panel', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		const mockDBSPerCollateralDetailsData = {
			collateralValuePcnt: 30
		};
		summaryComponent = fixture.componentInstance;
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.details = mockDBSPerCollateralDetailsData;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		const resultData = {
			'DBS % of Collateral Value': '30%',
			'DBS Sharing Basis': '-',
			'Max Cond': '-',
			'Subj. to DBS Fixed Max Amount': '-'
		};
		expect(summaryComponent.dbsPerOfCollateralValDetails).toEqual(resultData);
	});

	it('should show application details data in collateral details panel', () => {
		fixture = TestBed.createComponent(SummaryComponent);
		const mockApplicationDetailsData = {
			formNo: 'xyz',
			recievedDate: new Date('2017-05-13T07:06:17.255Z'),
			reviewDate: new Date('2017-05-14T07:06:17.255Z'),
			nextReviewDate: new Date('2017-05-15T07:06:17.255Z'),
			signingDate: new Date('2017-05-16T07:06:17.255Z'),
			executionDate: new Date('2017-05-17T07:06:17.255Z'),
			applicationDetailsRemarks: '-'
		};
		summaryComponent = fixture.componentInstance;
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.details = mockApplicationDetailsData;
		spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		fixture.detectChanges();
		const resultData = {
			'Form No.': 'xyz',
			'Received Date': '13 May 2017',
			'Review Date': '14 May 2017',
			'Next Review Date': '15 May 2017',
			'Signing Date': '16 May 2017',
			'Execution Date': '17 May 2017',
			'Remarks': '-'
		};
		expect(summaryComponent.applicationDetails).toEqual(resultData);
	});

	it('should show Valuation data in Collateral Value Details Section summary panel for DEPOSIT type ', async(() => {
		fixture = TestBed.createComponent(SummaryComponent);
		const mockApplicationDetailsData = {
			formNo: 'xyz',
			recievedDate: new Date('2017-05-13T07:06:17.255Z'),
			reviewDate: new Date('2017-05-14T07:06:17.255Z'),
			nextReviewDate: new Date('2017-05-15T07:06:17.255Z'),
			signingDate: new Date('2017-05-16T07:06:17.255Z'),
			executionDate: new Date('2017-05-17T07:06:17.255Z'),
			applicationDetailsRemarks: '-'
		};
		summaryComponent = fixture.componentInstance;
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.details = mockApplicationDetailsData;
		// spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		collateralService = TestBed.get(CollateralService);
		const collateral: Collateral = new Collateral;
		const collateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail;
		collateralValuationDetail.collateralValue.value = 5000.00;
		collateralValuationDetail.collateralValue.ccy = 'SGD';
		collateralValuationDetail.externalChargeAmt.value = 0.00;
		collateralValuationDetail.externalChargeAmt.ccy = 'SGD';
		collateralValuationDetail.loanToValuePcnt = 20;
		collateralValuationDetail.finalCollateralValue.value = 7000.00;
		collateralValuationDetail.finalCollateralValue.ccy = 'SGD';
		collateralValuationDetail.apportioningMethod = 'A';
		collateralValuationDetail.totalApportionedValue.value = 8000.00;
		collateralValuationDetail.totalApportionedValue.ccy = 'SGD';
		collateral.CollateralValuationDetail = collateralValuationDetail;

		collateralService.selectedCollateralType = 'DEPOS';
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		fixture.detectChanges();
		const resultData = {
			'External Charge Amount': 'SGD 0.00',
			'Collateral Value Amount': 'SGD 5,000.00',
			'Final Collateral Amount': 'SGD 7,000.00',
			'Apportioning Method': 'By Amount',
			'Total Apportioned Value': 'SGD 8,000.00',
			'Balance Apportionable Value': ' 0.00'
		};
		expect(summaryComponent.valuationDetails).toEqual(resultData);
		expect(summaryComponent.showValuationExternalChange).toEqual(true);

	}));

 it('should show Valuation data in Collateral Value Details Section summary panel for GUARANTEE type ', async(() => {
		fixture = TestBed.createComponent(SummaryComponent);
		const mockApplicationDetailsData = {
			formNo: 'xyz',
			recievedDate: new Date('2017-05-13T07:06:17.255Z'),
			reviewDate: new Date('2017-05-14T07:06:17.255Z'),
			nextReviewDate: new Date('2017-05-15T07:06:17.255Z'),
			signingDate: new Date('2017-05-16T07:06:17.255Z'),
			executionDate: new Date('2017-05-17T07:06:17.255Z'),
			applicationDetailsRemarks: '-'
		};
		summaryComponent = fixture.componentInstance;
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		summaryComponent.newCollateralForm = collateralService.getCollateralForm();
		summaryComponent.newCollateralForm.value.details = mockApplicationDetailsData;
		// spyOn(collateralService, 'getCollateralForm').and.returnValue(summaryComponent.newCollateralForm);
		collateralService = TestBed.get(CollateralService);
		const collateral: Collateral = new Collateral;
		const collateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail;
		collateralValuationDetail.collateralValue.value = 5000.00;
		collateralValuationDetail.collateralValue.ccy = 'SGD';
		collateralValuationDetail.externalChargeAmt.value = 0.00;
		collateralValuationDetail.externalChargeAmt.ccy = 'SGD';
		collateralValuationDetail.loanToValuePcnt = 20;
		collateralValuationDetail.finalCollateralValue.value = 7000.00;
		collateralValuationDetail.finalCollateralValue.ccy = 'SGD';
		collateralValuationDetail.apportioningMethod = 'A';
		collateralValuationDetail.totalApportionedValue.value = 8000.00;
		collateralValuationDetail.totalApportionedValue.ccy = 'SGD';
		collateral.CollateralValuationDetail = collateralValuationDetail;

		collateralService.selectedCollateralType = 'GUARN';
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		fixture.detectChanges();
		const resultData = {
			'External Charge Amount': 'SGD 0.00',
			'Collateral Value Amount': 'SGD 5,000.00',
			'Final Collateral Amount': 'SGD 7,000.00',
			'Apportioning Method': 'By Amount',
			'Total Apportioned Value': 'SGD 8,000.00',
			'Balance Apportionable Value': ' 0.00'
		};
		expect(summaryComponent.valuationDetails).toEqual(resultData);
		expect(summaryComponent.showValuationExternalChange).toEqual(false);

	}));


});
