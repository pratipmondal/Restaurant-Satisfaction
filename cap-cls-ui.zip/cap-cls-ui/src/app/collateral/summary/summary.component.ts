import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CollateralService } from '../collateral.service';
import { CurrencyFormatPipe } from '../../shared/currency-pipe/currency-pipe';
import { DatePipe } from '@angular/common';

@Component({
	selector: 'collateral-summary',
	templateUrl: './summary.component.html',
	styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {

	basicDetails: any;
	dbsPerOfCollateralValDetails: any;
	applicationDetails: any;
	valuationDetails: any;
	private apportion_method: string;
	divForChargeComponent: boolean = true;
	divForSpecificDetailsComponent: boolean = true;
	divForOwnershipComponent: boolean = true;
	divForDocumentComponent: boolean = true;
	divForBeneficiaryComponent: boolean = true;
	divForCollateralGuarantorComponent: boolean = true;

	showValuationExternalChange: boolean = false;

	jsonForValuationDetailsSummaryTab: any;

	@Input()
	newCollateralForm: FormGroup;
	private baselEligible: string = 'No';
	private method: string = 'Fixed Amount';

	constructor(private collateralService: CollateralService) {
	}

	ngOnInit() {
		this.setUpSummaryComponent();
	}

	private setUpSummaryComponent() {
		if (this.newCollateralForm !== undefined) {
			this.getComponentsToShow();
			const jsonArray = this.generateJSONsForSummaryPanel();
			this.basicDetails = jsonArray[0];
			this.dbsPerOfCollateralValDetails = jsonArray[1];
			this.applicationDetails = jsonArray[2];
			this.valuationDetails = jsonArray[3];
		}
	}

	private getComponentsToShow() {
		const collateralObj = this.collateralService.getCollateral();
		const selectedCollateralType = this.collateralService.selectedCollateralType;
		if (this.newCollateralForm.value.charge.chargeList.length === 0 || this.newCollateralForm.value.charge.chargeList === '' || this.newCollateralForm.value.charge.chargeList === null || this.newCollateralForm.value.charge.chargeList.length === undefined) {
			this.divForChargeComponent = false;
		}

		if (collateralObj.LodgeBeneficiaryDetail.beneficiaryList.length === 0) {
			this.divForBeneficiaryComponent = false;
		}

		if (collateralObj.LodgeDocumentationDetail.document.length === 0) {
			this.divForDocumentComponent = false;
		}

		if ((collateralObj.LodgeOwnerShipDetail.ownerShipList.length === 0) || (selectedCollateralType === 'GUARN')) {
			this.divForOwnershipComponent = false;
		}
		if (collateralObj.LodgeOwnerShipDetail.ownerShipList.length === 0 || (selectedCollateralType !== 'GUARN')) {
			this.divForCollateralGuarantorComponent = false;
		}

		switch (selectedCollateralType) {
			case 'GUARN':
				this.showValuationExternalChange = false;
				break;
			case 'DEPOS':
				this.showValuationExternalChange = true;
				break;
			default:
				this.showValuationExternalChange = false;
		}

		if (this.newCollateralForm.value.particulars.particularsList.length === 0 || this.newCollateralForm.value.particulars.particularsList === null || this.newCollateralForm.value.particulars.particularsList === '' || this.newCollateralForm.value.particulars.particularsList === undefined) {
			this.divForSpecificDetailsComponent = false;
		}

		if (this.newCollateralForm.value.particulars.particularsList.length === 0 || this.newCollateralForm.value.particulars.particularsList === null || this.newCollateralForm.value.particulars.particularsList === '' || this.newCollateralForm.value.particulars.particularsList === undefined) {
			this.divForSpecificDetailsComponent = false;
		}



	}

	private generateJSONsForSummaryPanel() {
		const selectedCollateralType = this.collateralService.selectedCollateralType;
		const currencyFormatPipe = new CurrencyFormatPipe();
		const datePipe = new DatePipe('en-US');
		if (this.newCollateralForm.value.details.baselEligible) {
			this.baselEligible = 'Yes';
		}
		const jsonForBasicDetailsSummaryTab = {
			'Method': this.newCollateralForm.value.details.method === '' ? this.method : this.newCollateralForm.value.details.method,
			'CCY Amount': (this.newCollateralForm.value.details.amount === undefined || this.newCollateralForm.value.details.amount === '' || this.newCollateralForm.value.details.amount === null) ? '-' :
				currencyFormatPipe.transform(this.newCollateralForm.value.details.amount, 2, this.newCollateralForm.value.details.currencyType),
			'Expiry Date': (this.newCollateralForm.value.details.expiryDate === undefined || this.newCollateralForm.value.details.expiryDate === null) ? '-' :
				datePipe.transform(this.newCollateralForm.value.details.expiryDate, 'dd MMM yyyy'),
			'Remarks': (this.newCollateralForm.value.details.generalDetailsRemarks === undefined || this.newCollateralForm.value.details.generalDetailsRemarks === '' || this.newCollateralForm.value.details.generalDetailsRemarks === null) ? '-' :
				this.newCollateralForm.value.details.generalDetailsRemarks,
			'Loan to Value (%)': (this.newCollateralForm.value.details.loanValuePcnt === undefined || this.newCollateralForm.value.details.loanValuePcnt === '' || this.newCollateralForm.value.details.loanValuePcnt === null) ? '-' :
				this.newCollateralForm.value.details.loanValuePcnt + '%',
			'Basel Eligible': this.baselEligible,
			'Location of Collateral': (this.newCollateralForm.value.details.location === undefined || this.newCollateralForm.value.details.location === '' || this.newCollateralForm.value.details.location === null) ? '-' :
				this.newCollateralForm.value.details.location,
			/*TODO for Solicitor Status dependency on Story No CSTCAPP2-2256 */
			'Solicitor Name': this.newCollateralForm.value.details.solicitorName === '' ? '-' : this.newCollateralForm.value.details.solicitorName
		};

		switch(selectedCollateralType){
			case 'DEPOS' : delete jsonForBasicDetailsSummaryTab['Method'];
						break;
			case 'GUARN':
			default :
		}


		const jsonForDBSPerCollateralDetailsSummaryTab = {
			'DBS % of Collateral Value': (this.newCollateralForm.value.details.collateralValuePcnt === undefined || this.newCollateralForm.value.details.collateralValuePcnt === '' || this.newCollateralForm.value.details.collateralValuePcnt === null) ? '-' :
				this.newCollateralForm.value.details.collateralValuePcnt + '%',
			'DBS Sharing Basis': (this.newCollateralForm.value.details.sharingBasis === undefined || this.newCollateralForm.value.details.sharingBasis === '' || this.newCollateralForm.value.details.sharingBasis === null) ? '-' :
				this.newCollateralForm.value.details.sharingBasis,
			'Max Cond': (this.newCollateralForm.value.details.maxCondition === undefined || this.newCollateralForm.value.details.maxCondition === '' || this.newCollateralForm.value.details.maxCondition === null) ? '-' :
				this.newCollateralForm.value.details.maxCondition,
			'Subj. to DBS Fixed Max Amount': (this.newCollateralForm.value.details.maxAmount === undefined || this.newCollateralForm.value.details.maxAmount === '' || this.newCollateralForm.value.details.maxAmount === null) ? '-' :
				currencyFormatPipe.transform(this.newCollateralForm.value.details.maxAmount, 2, this.newCollateralForm.value.details.maxAmountCurrencyType) /*TODO get default value*/
		};

		const jsonForApplicationDetailsSummaryTab = {
			'Form No.': (this.newCollateralForm.value.details.formNo === undefined || this.newCollateralForm.value.details.formNo === '' || this.newCollateralForm.value.details.formNo === null) ? '-' :
				this.newCollateralForm.value.details.formNo,
			'Received Date': (this.newCollateralForm.value.details.recievedDate === undefined || this.newCollateralForm.value.details.recievedDate === '' || this.newCollateralForm.value.details.recievedDate === null) ? '-' :
				datePipe.transform(this.newCollateralForm.value.details.recievedDate, 'dd MMM yyyy'),
			'Review Date': (this.newCollateralForm.value.details.reviewDate === undefined || this.newCollateralForm.value.details.reviewDate === '' || this.newCollateralForm.value.details.reviewDate === null) ? '-' :
				datePipe.transform(this.newCollateralForm.value.details.reviewDate, 'dd MMM yyyy'),
			'Next Review Date': (this.newCollateralForm.value.details.nextReviewDate === undefined || this.newCollateralForm.value.details.nextReviewDate === '' || this.newCollateralForm.value.details.nextReviewDate === null) ? '-' :
				datePipe.transform(this.newCollateralForm.value.details.nextReviewDate, 'dd MMM yyyy'),
			'Signing Date': (this.newCollateralForm.value.details.signingDate === undefined || this.newCollateralForm.value.details.signingDate === '' || this.newCollateralForm.value.details.signingDate === null) ? '-' :
				datePipe.transform(this.newCollateralForm.value.details.signingDate, 'dd MMM yyyy'),
			'Execution Date': (this.newCollateralForm.value.details.executionDate === undefined || this.newCollateralForm.value.details.executionDate === '' || this.newCollateralForm.value.details.executionDate === null) ? '-' :
				datePipe.transform(this.newCollateralForm.value.details.executionDate, 'dd MMM yyyy'),
			'Remarks': (this.newCollateralForm.value.details.applicationDetailsRemarks === undefined || this.newCollateralForm.value.details.applicationDetailsRemarks === '' || this.newCollateralForm.value.details.applicationDetailsRemarks === null) ? '-' :
				this.newCollateralForm.value.details.applicationDetailsRemarks
		};

		const valuationObj = this.collateralService.getCollateral().CollateralValuationDetail;

		if (valuationObj.apportioningMethod === 'P') {
			this.apportion_method = 'By Percentage';
		} else {
			this.apportion_method = 'By Amount';
		}

		this.jsonForValuationDetailsSummaryTab = {
			'External Charge Amount': (valuationObj.externalChargeAmt.value === undefined || valuationObj.externalChargeAmt.value === null || valuationObj.externalChargeAmt.value === 0) ? valuationObj.externalChargeAmt.ccy + ' 0.00' :
				currencyFormatPipe.transform(valuationObj.externalChargeAmt.value, 2, valuationObj.externalChargeAmt.ccy),
			'Collateral Value Amount': (valuationObj.collateralValue.value === undefined || valuationObj.collateralValue.value === null || valuationObj.collateralValue.value === 0) ? valuationObj.collateralValue.ccy + ' 0.00' :
				currencyFormatPipe.transform(valuationObj.collateralValue.value, 2, valuationObj.collateralValue.ccy),
			'Final Collateral Amount': (valuationObj.finalCollateralValue.value === undefined || valuationObj.finalCollateralValue.value === null || valuationObj.finalCollateralValue.value === 0) ? valuationObj.finalCollateralValue.ccy + ' 0.00' :
				currencyFormatPipe.transform(valuationObj.finalCollateralValue.value, 2, valuationObj.finalCollateralValue.ccy),
			'Apportioning Method': this.apportion_method,
			'Total Apportioned Value': (valuationObj.totalApportionedValue.value === undefined || valuationObj.totalApportionedValue.value === null || valuationObj.totalApportionedValue.value === 0) ? valuationObj.totalApportionedValue.ccy + ' 0.00' :
				currencyFormatPipe.transform(valuationObj.totalApportionedValue.value, 2, valuationObj.totalApportionedValue.ccy),
			'Balance Apportionable Value': (valuationObj.balanceApportionableAmt.value === undefined || valuationObj.balanceApportionableAmt.value === null || valuationObj.balanceApportionableAmt.value === 0) ? valuationObj.balanceApportionableAmt.ccy + ' 0.00' :
				currencyFormatPipe.transform(valuationObj.balanceApportionableAmt.value, 2, valuationObj.balanceApportionableAmt.ccy)
		};

		const jsonArray = [];
		jsonArray.push(jsonForBasicDetailsSummaryTab);
		jsonArray.push(jsonForDBSPerCollateralDetailsSummaryTab);
		jsonArray.push(jsonForApplicationDetailsSummaryTab);
		jsonArray.push(this.jsonForValuationDetailsSummaryTab);

		return jsonArray;
	}
}
