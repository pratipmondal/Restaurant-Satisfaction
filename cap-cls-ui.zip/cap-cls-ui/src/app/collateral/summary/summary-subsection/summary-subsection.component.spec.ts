import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SummarySubsectionComponent } from './summary-subsection.component';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { LoaderModule } from '../../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { KeysPipe } from './jsonpipe';

describe('SummarySubsectionComponent', () => {
	let summarySubsectionComponent: SummarySubsectionComponent;
	let fixture: ComponentFixture<SummarySubsectionComponent>;
	let counterForComponent = 0;

	beforeEach(async(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
		TestBed.configureTestingModule({
			imports: [CommonModule, BrowserModule, LoaderModule, GridModule, ButtonsModule, InputsModule],
			declarations: [SummarySubsectionComponent, KeysPipe],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		if (counterForComponent === 0) {
			fixture = TestBed.createComponent(SummarySubsectionComponent);
			summarySubsectionComponent = fixture.componentInstance;
			fixture.detectChanges();
		}
	});

	it('should create', () => {
		expect(summarySubsectionComponent).toBeTruthy();
		counterForComponent++;
	});

	it('should show right section header', async(() => {
		summarySubsectionComponent.subsection_right_header = 'Application Details';
		summarySubsectionComponent.ngOnInit();
		expect(summarySubsectionComponent.showSectionSubtextHeader).toBe(true);
	}));

	it('should not show right section header', () => {
		summarySubsectionComponent.subsection_right_header = '';
		summarySubsectionComponent.ngOnInit();
		expect(summarySubsectionComponent.showSectionSubtextHeader).toBe(false);
	});

	it('should not show section body', () => {
		summarySubsectionComponent.subsection_body = '';
		summarySubsectionComponent.ngOnInit();
		expect(summarySubsectionComponent.JSONData).toEqual('');
	});

	it('should show section body', () => {
		summarySubsectionComponent.subsection_body = {
			'Form No.': 'xyz',
			'Received Date': '13 May 2017',
			'Review Date': '14 May 2017',
			'Next Review Date': '15 May 2017',
			'Signing Date': '16 May 2017',
			'Execution Date': '17 May 2017',
			'Comments': '-'
		};
		const resultData = {
			'Form No.': 'xyz',
			'Received Date': '13 May 2017',
			'Review Date': '14 May 2017',
			'Next Review Date': '15 May 2017',
			'Signing Date': '16 May 2017',
			'Execution Date': '17 May 2017',
			'Comments': '-'
		};
		summarySubsectionComponent.ngOnInit();
		expect(summarySubsectionComponent.JSONData).toEqual(resultData);
	});

});
