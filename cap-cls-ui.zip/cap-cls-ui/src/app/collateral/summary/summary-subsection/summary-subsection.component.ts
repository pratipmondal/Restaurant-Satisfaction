import { Component, Input, OnInit } from '@angular/core';

@Component({
	selector: 'summary-subsection',
	templateUrl: './summary-subsection.component.html',
	styleUrls: ['./summary-subsection.component.scss']
})
export class SummarySubsectionComponent implements OnInit {

	@Input()
	subsection_header: string = '';

	@Input()
	subsection_body: any;

	@Input()
	subsection_right_header: string = '';

	showSectionSubtextHeader: boolean = false;

	JSONData: any;

	constructor() {
	}

	ngOnInit() {
		this.setUpSummarySubsectionComponent();
	}

	private setUpSummarySubsectionComponent() {
		this.showDivForSectionSubTextHeader();
		this.JSONData = '';
		if (this.subsection_body !== '' && (this.subsection_body !== undefined || this.subsection_body !== null)) {
			this.JSONData = this.subsection_body;
		}
	}

	private showDivForSectionSubTextHeader() {
		this.showSectionSubtextHeader = (this.subsection_right_header !== '' && ( this.subsection_right_header !== undefined || this.subsection_right_header !== null));
	}
}
