import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { LoaderModule } from '../../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { SummarySubsectionComponent } from './summary-subsection.component';
import { KeysPipe } from './jsonpipe';
@NgModule({
	imports: [CommonModule, BrowserModule, LoaderModule, GridModule, ButtonsModule, InputsModule],
	declarations: [SummarySubsectionComponent, KeysPipe],
	exports: [SummarySubsectionComponent]
})

export class SummarySubsectionModule {
	public static forRoot(): ModuleWithProviders {
		return {ngModule: SummarySubsectionModule, providers: []};
	}
}
