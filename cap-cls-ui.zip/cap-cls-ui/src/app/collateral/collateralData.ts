export const CollateralReponse = {
    "collateralId": "",
    "collateralCode": "G01",
    "collateralType": "GUARN",
    "generalDetail": {
        "collateralDesc": "TEST",
        "collateralClass": "",
        "collateralGrp": "",
        "collateralCreationDate": "2017-03-07T12:40:36.355Z",
        "collateralExpiryDate": "2017-03-07T12:40:36.355Z",
        "currencyCode": "SGD",
        "collateralStatus": "",
        "applicationDetail": {
            "formNo": "",
            "receivedDate": "2017-03-07T12:40:36.355Z",
            "reviewDate": "2017-03-07T12:40:36.355Z",
            "nextReviewDate": "2017-03-07T12:40:36.355Z",
            "signingDate": "2017-03-07T12:40:36.355Z",
            "executionDate": "2017-03-07T12:40:36.355Z",
            "comments": ""
        }
    },
    "GUARN": {
        "LodgeReceiptAndPayment": {
            "receiptAndPayment": [
                {
                    "receiptType": "",
                    "receiptAmt": {
                        "value": 0,
                        "ccy": ""
                    },
                    "paymentType": "",
                    "paymentAmt": {
                        "value": 0,
                        "ccy": ""
                    },
                    "dueDate": "2017-03-07T12:40:36.355Z",
                    "paidOrReceivedDate": "2017-03-07T12:40:36.355Z",
                    "dateRange": "",
                    "proofVerifiedDate": "2017-03-07T12:40:36.355Z",
                    "paymentMode": "",
                    "notes": "",
                    "name": "",
                    "freeCode1": "",
                    "freeCode2": "",
                    "freeText": "",
                    "delete": false
                }
            ]
        },
        "LodgeDocumentationDetail": {
            "document": [
                {
                    "documentCode": "DOCCODE1",
                    "documentDate": "07 Mar 2017",
                    "documentId": "",
                    "dueDate": "07 Mar 2017",
                    "documentReceivedDate": "07 Mar 2017",
                    "documentExpirationDate": "07 Mar 2017",
                    "comments": "-",
                    "delete": false
                }
            ]
        },
        "LodgeBeneficiaryDetail": {
            "beneficiaryList": [
                {
                    "beneficiaryName": "Minera Corp",
                    "cifId": "CIF1",
                    "beneficiaryIdType": "Corporate",
                    "beneficiaryId": "GC0000330021",
                    "addressLine1": "",
                    "addressLine2": "",
                    "addressLine3": "",
                    "city": "",
                    "state": "",
                    "country": "",
                    "postalCode": "",
                    "phoneNo": "",
                    "emailAddress": "",
                    "telexNo": "",
                    "faxNo": "",
                    "delete": false
                },
                {
                    "beneficiaryName": "Personal Leadership center Pte Ltd",
                    "cifId": "CIF2",
                    "beneficiaryIdType": "Corporate",
                    "beneficiaryId": "GC0000330021",
                    "addressLine1": "",
                    "addressLine2": "",
                    "addressLine3": "",
                    "city": "",
                    "state": "",
                    "country": "",
                    "postalCode": "",
                    "phoneNo": "",
                    "emailAddress": "",
                    "telexNo": "",
                    "faxNo": "",
                    "delete": false
                }
            ]
        },
        "LodgeChargeDetail": {
            "chargeList": [
                {
                    'natureOfCharge': 'Fixed Charge',
                    'chargeRank': '1st',
                    'externalCharge': 'No',
                    'chargeAmount': 200000.00,
                    'filingDate': '21 Apr 2017',
                    'receiptDate': '20 Apr 2017',
                    'solicitor': {
                        'solicitorName': 'Tan Law Firm',
                        'solicitorStatus': 'Non-Approved'
                    },
                    'registrationAuthority': '-'
                },
                {
                    'natureOfCharge': 'Dummy',
                    'chargeRank': '1DBS',
                    'externalCharge': 'No',
                    'chargeAmount': 40000.01,
                    'filingDate': '21 Apr 2017',
                    'receiptDate': '20 Apr 2017',
                    'solicitor': {
                        'solicitorName': 'John Doe',
                        'solicitorStatus': 'Non-Approved'
                    },
                    'registrationAuthority': '-'
                }
            ]
        },
        "CollateralValuationDetail": {
            "loanToValuePcnt": 0,
            "externalChargeAmt": {
                "value": 0,
                "ccy": ""
            },
            "collateralValue": {
                "value": 11000,
                "ccy": "SGD"
            },
            "finalCollateralValue": {
                "value": 0,
                "ccy": "SGD"
            },
            "apportioningMethod": "P",
            "totalApportionedValue": {
                "value": 0,
                "ccy": "SGD"
            },
            "balanceApportionableAmt": {
                "value": 0,
                "ccy": "SGD"
            }
        },
        "LodgeOwnerShipDetail": {
            "collateralOwnerShipType": "",
            "ownerShipList": [
                {
                    "cifId": "CIF1",
                    "idType": "Type-1",
                    "idNo": 0,
                    "name": "Consultant",
                    "collateralOwnerShipPcnt": 0,
                    "addressLine1": "",
                    "addressLine2": "",
                    "addressLine3": "",
                    "city": "",
                    "state": "",
                    "country": "",
                    "postalCode": "",
                    "phoneNo": "",
                    "emailAddress": "",
                    "telexNo": "",
                    "faxNo": "",
                    "delete": false
                }
            ]
        },
        "LodgeCollateralTypeSpecificDetail": {
            "guaranteeType": "",
            "guarantorName": "",
            "guarantorCifId": "CIF1",
            "idType": "",
            "idNo": "",
            "guarantorType": "",
            "supportingCollateralsHeld": false,
            "guaranteePcnt": 10,
            "guaranteeAmt": {
                "value": 0,
                "ccy": ""
            },
            "addressLine1": "",
            "addressLine2": "",
            "addressLine3": "",
            "city": "",
            "state": "",
            "country": "",
            "postalCode": ""
        },
        "FeeDetail": {
            "feeDetailList": [
                {
                    "feeType": "FEE2",
                    "feeCode": "FEECODE",
                    "overrideFeeSetup": false,
                    "feeDistributable": false,
                    "multiple": false,
                    "frequency": "",
                    "nextAssessmentDate": "2017-03-07T12:40:36.356Z",
                    "maxNumberOfAssessements": 0,
                    "amortize": false,
                    "amortizationTerm": 0,
                    "method": "",
                    "scriptName": "",
                    "userEnteredAmt": {
                        "value": 0,
                        "ccy": ""
                    },
                    "userEnteredPcnt": 0,
                    "remarks": "",
                    "delete": false
                }
            ],
            "feeCollectionAccount": "",
            "computedAmount": {
                "value": 0,
                "ccy": ""
            },
            "collectableAmountPcnt": 0,
            "collectableAmount": {
                "value": 0,
                "ccy": ""
            }
        },
        "CollateralValueDetail": {
            "unitValueMethod": false,
            "directValueMethod": false,
            "netValueMethod": false,
            "derivedValueMethod": false,
            "itemBasedMethod": false,
            "customerDerivationMethod": false,
            "defaultValueMethod": false,
            "childCollateralMethod": false
        },
        "LodgeParticularsDetail": {
            "ParticularsList": [
                {
                    'particularsBankName': 'DBS Singapore',
                    'particularsBankId': '01234',
                    'particularsDepositName': 'John Doe',
                    'particularsDepositId': '4354535',
                    'principalAmount': 230000,
                    'availableBalance': 100000,
                    'accountBalance': 340000,
                    'maturityDate': '21 May 2017',
                    'term': 'Term 1',
                    'particularsComment': 'Test Comments'
                },
                {
                    'particularsBankName': 'DBS Singapore',
                    'particularsBankId': '223263',
                    'particularsDepositName': 'Steven Tan',
                    'particularsDepositId': '4587457',
                    'principalAmount': 540000,
                    'availableBalance': 870000,
                    'accountBalance': 870000,
                    'maturityDate': '24 May 2017',
                    'term': 'Term 2',
                    'particularsComment': 'Test Comments'
                }
            ]
        }
    },
    "withdrawalDetail": {
        "withdraw": false,
        "reasonCode": "",
        "withdrawalDate": null
    }
}
		