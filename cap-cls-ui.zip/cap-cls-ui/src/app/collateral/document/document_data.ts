export const DocRefValues = [{
	'documentCode': 'DOC1',
	'documentStatus': 'Status1',
	'documentDate': '18 Apr 2017',
	'dueDate': '30 Apr 2017',
	'documentReceivedDate': '21 Apr 2017',
	'documentExpirationDate': '27 Apr 2017',
	'comments': '--'
},
{
	'documentCode': 'DOC2',
	'documentStatus': 'Status1',
	'documentDate': '18 Apr 2017',
	'dueDate': '30 Apr 2017',
	'documentReceivedDate': '21 Apr 2017',
	'documentExpirationDate': '27 Apr 2017',
	'comments': '--'
}
];

export const documentCodes = [
	{ code: 'Document01', description: 'DocumentDescription' },
	{ code: 'Document02', description: 'DocumentDescription' }
];
export const documentStatus = [
	{ code: 'status01', description: 'statusDescription' },
	{ code: 'status02', description: 'statusDescription' }
]