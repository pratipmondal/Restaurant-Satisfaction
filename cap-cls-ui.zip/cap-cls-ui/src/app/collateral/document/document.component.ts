import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { DocumentService } from './document.service';
import { DocumentItemModel } from './document-model';
import { CollateralService } from '../collateral.service';
import { ToastsComponent } from '../../shared/toasts/toasts.component';
import { Observable } from 'rxjs/Observable';

@Component({
	selector: 'collateral-document',
	templateUrl: './document.component.html',
	styleUrls: ['./document.component.scss']
})
export class DocumentComponent implements OnInit {

	public gridData: any[] = [];
	public events: any[] = [];
	public saveData: boolean = true;
	public updateData: boolean = false;
	public dialogTitleName: string = 'Add Document Details';
	public rowIndex: number;
	public documentStatus: any;
	@Input() public documentForm: FormGroup;
	public addDocumentForm: FormGroup;
	public showPopupDialog: boolean = false;
	divForNormalGrid: boolean = true;
	@Input() showAddDocumentBtn: boolean = true;
	@Input() showSummaryGrid: boolean = false;
	public documentCodes: any;
	public noRecordsFlag: boolean = false;
	public argToastMessageObject: any;
	public documentCodeInvalid: boolean = false;
	public data: any[];
	public statusData: any[];
	public documentStatusInvalid: boolean = false;
	toastsComponent: ToastsComponent = new ToastsComponent();

	constructor(private _fb: FormBuilder, private documentService: DocumentService, private collateralService: CollateralService) {
	}

	ngOnInit() {
		this.intializeGridData();
		this.customizeDocumentGridForSummaryComp();
		this.initializeServices();
		this.noData();
		this.initializeForm();

	}

	intializeGridData() {
		if (this.collateralService.getCollateral().LodgeDocumentationDetail && this.collateralService.getCollateral().LodgeDocumentationDetail.document) {
			this.gridData = this.collateralService.getCollateral().LodgeDocumentationDetail.document;
		}

	}

	initializeForm() {
		this.addDocumentForm = this._fb.group({
			documentCode: ['', [Validators.required]],
			documentStatus: ['', [Validators.required]],
			dueDate: [null],
			documentReceivedDate: [null],
			documentExpirationDate: [null],
			documentDate: [null],
			comments: ['']
		});
		this.subscribeToFormChanges();
	}

	initializeServices() {
		this.documentService.getDocumentCodes().subscribe(
			response => {
				this.documentCodes = response;
			},
			error => {
				this.errorReturn(error);
			});

		this.documentService.getDocumentStatus([]).subscribe(
			response => {
				this.documentStatus = response;
			},
			error => {
				this.errorReturn(error);
			});

	}

	errorReturn(error: any) {
		if (error.status === 500) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 400) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 409) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 404) {
			return Observable.throw(new Error(error.status));
		}
	}

	addDocument() {
		this.dialogTitleName = 'Add Document Details';
		this.showPopupDialog = true;
		this.validationReset();
	}

	subscribeToFormChanges() {
		const addDocumentFormStatusChanges$ = this.addDocumentForm.statusChanges;
		const addDocumentFormValueChanges$ = this.addDocumentForm.valueChanges;
		addDocumentFormStatusChanges$.subscribe(x => this.events.push({event: 'STATUS_CHANGED', object: x}));
		addDocumentFormValueChanges$.subscribe(x => this.events.push({event: 'VALUE_CHANGED', object: x}));
	}

	closeEventFromPopupDialog(showPopupDialog: boolean) {
		this.showPopupDialog = showPopupDialog;
		this.updateData = false;
		this.saveData = true;
		this.addDocumentForm.reset();
	}

	addDocumentData(data: DocumentItemModel) {
		this.validationReset();
		const flagValue = this.validaionCheck(data);
		if (flagValue === true) {
			const documentItemModel = new DocumentItemModel();
			documentItemModel.documentCode = ((data.documentCode).split('--'))[0];
			documentItemModel.documentStatus = (data.documentStatus).split('--')[0];
			documentItemModel.dueDate = data.dueDate;
			documentItemModel.documentExpirationDate = data.documentExpirationDate;
			documentItemModel.documentReceivedDate = data.documentReceivedDate;
			documentItemModel.documentDate = data.documentDate;
			documentItemModel.comments = data.comments;
			documentItemModel['comments'] = this.checkForRemarksValue(documentItemModel['comments']);
			this.showPopupDialog = false;
			this.gridData.push(documentItemModel);
			this.noRecordsFlag = (this.gridData.length > 0);
			this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
				'A record of Document details has been successfully Added.',
				'', '');
			this.documentForm.controls['documentidList'].setValue(this.gridData);
			this.addDocumentForm.reset();
		}
	}

	cancelForm() {
		this.showPopupDialog = false;
		this.addDocumentForm.reset();
		this.validationReset();
	}

	updateDocument(data: DocumentItemModel) {
		this.validationReset();
		const flagValue = this.validaionCheck(data);
		if (flagValue === true) {
			const documentItemModel = new DocumentItemModel();
			documentItemModel.documentCode = ((data.documentCode).split('--'))[0];
			documentItemModel.documentStatus = ((data.documentStatus)).split('--')[0];
			documentItemModel.dueDate = data.dueDate;
			documentItemModel.documentExpirationDate = data.documentExpirationDate;
			documentItemModel.documentReceivedDate = data.documentReceivedDate;
			documentItemModel.documentDate = data.documentDate;
			documentItemModel.comments = data.comments;
			this.saveData = true;
			this.updateData = false;
			this.showPopupDialog = false;
			this.gridData[this.rowIndex] = documentItemModel;
			this.documentForm.controls['documentidList'].setValue(this.gridData);
			this.noRecordsFlag = (this.gridData.length > 0);
			this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
				'A record of Document details has been successfully Updated.',
				'', '');
			this.addDocumentForm.reset();
		}
	}

	public editFunc(item: DocumentItemModel, index: number): void {
		this.validationReset();
		this.dialogTitleName = 'Update Document';
		this.rowIndex = index;
		const elementPos = this.documentCodes.map(function (x) {
			return x.code;
		}).indexOf(item['documentCode']);
		const objectFound = this.documentCodes[elementPos];
		const elementPos1 = this.documentStatus.map(function (x) {
			return x.code;
		}).indexOf(item['documentStatus']);
		const objectFound1 = this.documentStatus[elementPos1];
		this.saveData = false;
		this.updateData = true;
		this.showPopupDialog = true;
		const code = objectFound['code'] + '--' + objectFound['description'];
		const status = objectFound1['code'] + '--' + objectFound1['description'];

		if (item !== undefined) {
			this.addDocumentForm = this._fb.group({
				documentCode: [code, [<any>Validators.required, <any>Validators.required]],
				documentStatus: [status, [<any>Validators.required, <any>Validators.required]],
				dueDate: [item['dueDate']],
				documentReceivedDate: [item['documentReceivedDate']],
				documentExpirationDate: [item['documentExpirationDate']],
				documentDate: [item['documentDate']],
				comments: [item['comments']]
			});
			this.subscribeToFormChanges();
		}

	}

	public removeItemFunc(itemIndex: number) {
		this.gridData.splice(itemIndex, 1);
		this.documentForm.controls['documentidList'].setValue(this.gridData);
		this.noRecordsFlag = (this.gridData.length > 0);
		this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
			'A record of Document details has been successfully deleted.',
			'', '');
	}

	customizeDocumentGridForSummaryComp() {
		this.divForNormalGrid = !this.showSummaryGrid;
	}

	noData() {
		this.noRecordsFlag = (this.gridData.length > 0);
	}

	onLabelClicked(e: Event) {
		this.validationReset();
		this.openPopDialog();
	}

	openPopDialog() {
		this.dialogTitleName = 'Add Document Details';
		this.showPopupDialog = true;
	}

	public checkForRemarksValue(data: string) {
		if (data === '' || data === null || data === 'undefined') {
			return '-';
		} else {
			return data;
		}
	}

	public codeChange(event) {
		if (this.documentCodes) {
			const codeExistInCodeList = this.documentCodes.find(item => (item.code + '--' + item.description) === event);
			if (((event !== 'undefined') || (event !== '')) && (codeExistInCodeList !== undefined)) {
				this.documentCodeInvalid = false;
			} else {
				this.documentCodeInvalid = true;
			}
		}
	}

	public statusChange(e) {
		if (this.documentStatus) {
			const statusExistInStatusList = this.documentStatus.find(item => (item.code + '--' + item.description) === e);
			if (((e !== 'undefined') || (e !== '')) && (statusExistInStatusList !== undefined)) {
				this.documentStatusInvalid = false;
			} else {
				this.documentStatusInvalid = true;
			}
		}
	}

	validaionCheck(data?: any) {
		let valid: boolean = true;
		if (this.documentStatus === undefined || this.documentCodes === undefined) {
			this.documentCodeInvalid = true;
			this.documentStatusInvalid = true;
			valid = false;
		}
		if (this.documentCodes !== undefined) {
			const codeExistInCodeList = this.documentCodes.find(item => (item.code + '--' + item.description) === data.documentCode);
			if (((data.documentCode === '') || (data.documentCode == null) || (data.documentCode === undefined)) || (codeExistInCodeList === undefined)) {
				this.documentCodeInvalid = true;
				valid = false;
			}
		}
		if (this.documentStatus !== undefined) {
			const statusExistInStatusList = this.documentStatus.find(item => (item.code + '--' + item.description) === data.documentStatus);
			if (((data.documentStatus === '') || (data.documentStatus == null) || (data.documentStatus === undefined)) || (statusExistInStatusList === undefined)) {
				this.documentStatusInvalid = true;
				valid = false;
			}
		}
		return valid;
	}

	validationReset() {
		this.documentCodeInvalid = false;
		this.documentStatusInvalid = false;
	}

	public filterChangeDocumentCode(filter: any): void {
		if (this.documentCodes) {
			const tempArr = this.documentCodes.map(function (item) {
				return item['code'] + '--' + item['description'];
			});
			this.data = tempArr.filter((s) => s.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
		}
	}

	public filterChangeStatus(filter: any): void {
		if (this.documentStatus) {
			const tempArrayStatus = this.documentStatus.map(function (item) {
				return item['code'] + '--' + item['description'];
			});
			this.statusData = tempArrayStatus.filter((s) => s.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
		}
	}
}
