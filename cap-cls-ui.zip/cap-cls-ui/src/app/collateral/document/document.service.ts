import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable()
export class DocumentService {

	constructor(private http: Http) {
	}

	public getDocumentCodes(): Observable<any> {
		const url = environment.apiBaseUrl + environment.documentCodes;
		return this.http.get(url)
			.map(this.extractData)
			.catch(error => this.handleError(error));
		function onSuccess(resp: Response) {
			return (resp.json());
		}
	}

	public getDocumentStatus(params: string[]): Observable<any> {
		const url = environment.apiBaseUrl + environment.apiDocumentStatus;
		return this.http.get(url)
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}

	private extractData(res: Response) {
		const body = res.json();
		return body;
	}

	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}
}