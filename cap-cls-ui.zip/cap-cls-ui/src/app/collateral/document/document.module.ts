import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { DocumentComponent } from './document.component';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { IntlModule } from '@progress/kendo-angular-intl';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { CommonUIModule } from '../../common/commonUI.module';
import 'hammerjs';
import { DocumentService } from './document.service';

@NgModule({
	imports: [
		CommonModule,
		BrowserModule, FormsModule, ReactiveFormsModule,
		ButtonsModule, BrowserAnimationsModule,
		LoaderModule, GridModule, ClsSharedCommonModule, DateInputsModule, IntlModule, AutoCompleteModule
		, PopupDialogModule, CommonUIModule
	],
	declarations: [
		DocumentComponent
	],
	providers: [DocumentService],
	exports: [DocumentComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DocumentModule {
}
