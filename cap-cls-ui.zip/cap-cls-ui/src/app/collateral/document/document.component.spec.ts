import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DocumentComponent } from './document.component';
import { DocRefValues, documentCodes, documentStatus } from './document_data';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { DocumentService } from './document.service';
import { CollateralService } from '../collateral.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Collateral } from '../../collateral/model/collateral';
import { Observable } from 'rxjs/Rx';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { IntlModule } from '@progress/kendo-angular-intl';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { DocumentItemModel } from './document-model';
import { LodgeDocumentationDetail, Document } from '../model/collateral';

class MockDocumentService {
	getData() {
		return [];
	}

	getDocumentCodes() {
		return Observable.of(documentCodes);
	}

	getDocumentStatus() {
		return Observable.of(documentStatus);
	}

	documentList(data: any) {
		const mockDocumentList = new Document();
		mockDocumentList.documentCode = data.documentCode;
		mockDocumentList.documentStatus = data.documentStatus;
		mockDocumentList.documentDate = data.documentDate;
		mockDocumentList.dueDate = data.dueDate;
		mockDocumentList.documentExpirationDate = data.documentExpirationDate;
		mockDocumentList.documentReceivedDate = data.documentReceivedDate;
		mockDocumentList.comments = data.comments;
		return mockDocumentList;
	}

}
class MockCollateralService {
	getCollateral() {
		return new Collateral();
	}
}
class MockFormBuilder extends FormBuilder {
	getBlankForm() {
		const formBuilder = new FormBuilder;
		const formGroup = formBuilder.group({
			documentCode: ['', [Validators.required]],
			documentStatus: ['', [Validators.required]],
			dueDate: [null],
			documentReceivedDate: [null],
			documentExpirationDate: [null],
			documentDate: [null],
			comments: ['']
		});
		return formGroup;
	}

	getAddForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			documentCode: [documentCodes[0].code + '--' + documentCodes[0].description, [Validators.required]],
			documentStatus: [documentStatus[0].code + '--' + documentStatus[0].description, [Validators.required]],
			dueDate: [''],
			documentReceivedDate: [''],
			documentExpirationDate: [null],
			documentDate: [null],
			comments: ['12']
		});
		return formGroup;
	}

	setMainForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			documentidList: ['', [Validators.required]]
		});
		return formGroup;
	}
}
describe('DocumentComponent test cases', () => {
	let component: DocumentComponent;
	let fixture: ComponentFixture<DocumentComponent>;
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				CommonModule,
				BrowserModule, FormsModule, ReactiveFormsModule,
				ButtonsModule, BrowserAnimationsModule,
				LoaderModule, GridModule, ClsSharedCommonModule, DateInputsModule, IntlModule, AutoCompleteModule
				, PopupDialogModule, CommonUIModule
			],
			declarations: [DocumentComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [{provide: CollateralService, useClass: MockCollateralService},
				{provide: DocumentService, useClass: MockDocumentService},
				{provide: FormBuilder, useClass: MockFormBuilder}
			]
		})
			.compileComponents();
	}));
	beforeEach(() => {
		fixture = TestBed.createComponent(DocumentComponent);
		component = fixture.componentInstance;
		const mockService = new MockDocumentService();
		component.documentCodes = mockService.getDocumentCodes();
		component.documentStatus = mockService.getDocumentStatus();
		fixture.detectChanges();
	});

	it('should create', async(() => {
		expect(component).toBeTruthy();
	}));
	it('PopDialog should be disabled',
		async(() => {
			expect(component.showPopupDialog).toBe(false);
		}));
	it('PopDialog box should open onclick of ADD DOCUMENT button',
		async(() => {
			fixture.detectChanges();
			component.showPopupDialog = false;
			component.addDocument();
			expect(component.showPopupDialog).toBe(true);
		}));
	it('PopDialog box should be close  onclick of Cancel button',
		async(() => {
			fixture.detectChanges();
			component.showPopupDialog = true;
			component.cancelForm();
			expect(component.showPopupDialog).toBe(false);
		}));
	it('PopDialog box should be close  onclick of close  button',
		async(() => {
			fixture.detectChanges();
			component.showPopupDialog = true;
			component.closeEventFromPopupDialog(false);
			expect(component.showPopupDialog).toBe(false);
		}));
	it('Data should display in grid when document loaded', async(() => {
		fixture.detectChanges();
		component.gridData = DocRefValues;
		expect(component.gridData).toBe(DocRefValues);
	}));
	it('Should show normalgrid on init', (async () => {
		component.divForNormalGrid = true;
		component.showSummaryGrid = false;
		expect(component.divForNormalGrid).toBe(true);
		component.customizeDocumentGridForSummaryComp();
		if (component.showSummaryGrid) {
			expect(component.divForNormalGrid).toBe(false);
		} else {
			expect(component.divForNormalGrid).toBe(true);
		}
	}));
	it('should show no-record component when no data available in grid', () => {
		const mockService = new MockDocumentService();
		component.gridData = mockService.getData();
		component.intializeGridData();
		expect(component.noRecordsFlag).toBe(false);
	});
	it('should not show no-record-component-found when data from service',
		async(() => {
			const mockFormBuilder = new MockFormBuilder();
			let collateralService: CollateralService;
			collateralService = TestBed.get(CollateralService);
			const collateral: Collateral = new Collateral;
			const lodgeDocumentationDetail: LodgeDocumentationDetail = new LodgeDocumentationDetail;
			const mockDocumentService = new MockDocumentService();
			lodgeDocumentationDetail.document = [mockDocumentService.documentList(DocRefValues[0])];
			collateral.LodgeDocumentationDetail = lodgeDocumentationDetail;
			spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
			component.ngOnInit();
			expect(component.noRecordsFlag).toBe(true);
		}));

	it('Data should add to grid on click of save button',
		async(() => {
			fixture.detectChanges();
			expect(component.gridData.length).toBe(0);
			component.showPopupDialog = false;
			component.addDocumentForm = null;
			const mockForm = new MockFormBuilder();
			const mockService = new MockDocumentService();
			component.documentForm = mockForm.setMainForm();
			component.addDocument();
			component.documentStatus = mockService.getDocumentStatus();
			component.documentCodes = mockService.getDocumentCodes();
			component.addDocumentForm = mockForm.getAddForm();
			component.addDocumentData(component.addDocumentForm.value);
			component.documentForm.get('documentidList').setValue(component.gridData);
			expect(component.gridData.length).toBeGreaterThan(0);
			expect(component.noRecordsFlag).toBe(true);
		}));

	it('Data should get displayed in Update Documment Dialog Box fields onclick of edit icon', async(() => {
		fixture.detectChanges();
		const mockUpdatedChargeData = {};
		const mockFormBuilder = new MockFormBuilder();
		component.addDocumentForm = mockFormBuilder.getAddForm();
		const mockUpdatedDocumentData = new DocumentItemModel();
		mockUpdatedDocumentData.documentCode = 'Document01';
		mockUpdatedDocumentData.comments = '-';
		mockUpdatedDocumentData.dueDate = null;
		mockUpdatedDocumentData.documentDate = new Date('2017-05-12T07:06:17.255Z');
		mockUpdatedDocumentData.documentExpirationDate = null;
		mockUpdatedDocumentData.documentReceivedDate = null;
		mockUpdatedDocumentData.documentStatus = 'status01';
		const rowIndex = 1;
		component.editFunc(mockUpdatedDocumentData, rowIndex);
		expect(component.addDocumentForm.controls['documentCode'].value).toBe('Document01--DocumentDescription');
		expect(component.dialogTitleName).toBe('Update Document');
	}));
	it('Data should get updated in Grid  onclick of update button', () => {
		fixture.detectChanges();
		const mockFormBuilder = new MockFormBuilder();
		const mockForm = new MockFormBuilder();
		component.addDocumentForm = mockFormBuilder.getAddForm();
		component.gridData.push(DocRefValues[0]);
		const mockUpdatedDocumentData = new DocumentItemModel();
		component.documentForm = mockForm.setMainForm();
		mockUpdatedDocumentData.documentCode = mockFormBuilder.getAddForm().controls['documentCode'].value;
		mockUpdatedDocumentData.documentStatus = mockFormBuilder.getAddForm().controls['documentStatus'].value;
		mockUpdatedDocumentData.documentExpirationDate = mockFormBuilder.getAddForm().controls['documentExpirationDate'].value;
		mockUpdatedDocumentData.documentReceivedDate = mockFormBuilder.getAddForm().controls['documentReceivedDate'].value;
		mockUpdatedDocumentData.comments = mockFormBuilder.getAddForm().controls['comments'].value;
		mockUpdatedDocumentData.dueDate = mockFormBuilder.getAddForm().controls['dueDate'].value;
		component.rowIndex = 1;
		component.updateDocument(mockUpdatedDocumentData);
		component.documentForm.get('documentidList').setValue(mockUpdatedDocumentData);
		expect(component.gridData[1].documentCode).toBe((mockUpdatedDocumentData.documentCode.split('--')[0]));
	});
	it('Data should delete from gridData on click of delete icon', () => {
		fixture.detectChanges();
		component.gridData.push(DocRefValues[0]);
		const mockForm = new MockFormBuilder();
		component.documentForm = mockForm.setMainForm();
		const rowIndex = 0;
		component.removeItemFunc(rowIndex);
		component.documentForm.get('documentidList').setValue(component.gridData);
		expect(component.gridData.length).toBe(0);
	});
	it('should validation check function return false if data invalid ', () => {
		fixture.detectChanges();
		const f = component.validaionCheck(DocRefValues[0]);
		expect(f).toBe(false);
	});
	it('Check DocumentCodes Filter change function when value was entered',
		async(() => {
			fixture.detectChanges();
			const tempArray = [documentCodes[0].code + '--' + documentCodes[0].description, documentCodes[1].code + '--' + documentCodes[1].description
			];
			component.filterChangeDocumentCode('D');
			expect(component.data).toEqual(tempArray);
		}));
	it('Check DocumentCodes Filter change function should return empty array when value was not matched',
		async(() => {
			fixture.detectChanges();
			component.filterChangeDocumentCode('xx');
			expect(component.data).toEqual([]);
		}));
	it('Check DocumentStatus Filter change function when value was entered',
		async(() => {
			fixture.detectChanges();
			const tempArray = [documentStatus[0].code + '--' + documentStatus[0].description, documentStatus[1].code + '--' + documentStatus[1].description
			];
			component.filterChangeStatus('s');
			expect(component.statusData).toEqual(tempArray);
		}));
	it('Check DocumentStatus Filter change function should return empty array when value was not matched',
		async(() => {
			fixture.detectChanges();
			component.filterChangeStatus('xx');
			expect(component.statusData).toEqual([]);
		}));
	it('should validations reset after calling validation reset function', () => {
		component.validationReset();
		expect(component.documentCodeInvalid).toBe(false);
		expect(component.documentStatusInvalid).toBe(false);
	});
	it('should return documentInvalid flag true if invalid entry in document code autoComplete input box', () => {
		component.codeChange('XYZ');
		expect(component.documentCodeInvalid).toBe(true);
	});
	it('should return documentInvalid flag false if valid entry in document code autoComplete input box', () => {
		component.codeChange(documentCodes[0].code + '--' + documentCodes[0].description);
		expect(component.documentCodeInvalid).toBe(false);
	});
	it('should return documentStatusInvalid flag true if invalid entry in document Status autoComplete input box', () => {
		component.statusChange('XYZ');
		expect(component.documentStatusInvalid).toBe(true);
	});
	it('should return documentStatusInvalid flag false if valid entry in document Status autoComplete input box', () => {
		component.statusChange(documentStatus[0].code + '--' + documentStatus[0].description);
		expect(component.documentStatusInvalid).toBe(false);
	});
	it('should retrurn remarks value(-) if there is no entry in remarks input box ', () => {
		expect(component.checkForRemarksValue('')).toBe('-');
	});
	it('should retrurn remarks value if there is any data  ', () => {
		expect(component.checkForRemarksValue('ABC')).toBe('ABC');
	});
});



