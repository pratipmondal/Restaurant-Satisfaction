import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { CollateralIDService } from './collateral-id.service';
import { Http, HttpModule, Response, URLSearchParams, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';

describe('CollateralID Service', () => {
    let service: CollateralIDService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [{ provide: XHRBackend, useClass: MockBackend }, CollateralIDService]
        });
    });

    beforeEach(inject([CollateralIDService], (mockService: CollateralIDService) => {
        service = mockService;
    }));

    // errorResponseFunction
    it('should create Collateral Id component', () => {
        const retVal = service.errorResponseFunction({
            _body: 'some err message',
            status: 404,
            ok: false,
            statusText: 'NOT_FOUND',
            headers: {},
            type: 4,
            url: 'http://some-url.com'
        });
        expect(retVal instanceof ErrorObservable).toBeTruthy();
        expect(retVal.error.status).toBe(404);
        expect(retVal.error.statusText).toBe('NOT_FOUND');
        expect(retVal.error._body).toBe('some err message');
        expect(retVal.error.ok).toBeFalsy();
    });
});
