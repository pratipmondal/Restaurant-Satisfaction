import { Component, OnInit } from '@angular/core';
import { CollateralService } from '../collateral.service';
import { ErrorResponse } from '../../shared';
import { isNullOrEmptyString, isDate } from '@progress/kendo-data-query/dist/es/utils';

@Component({
    selector: 'collateral-id',
    templateUrl: './collateral-id.component.html',
    styleUrls: ['./collateral-id.component.scss']
})
export class CollateralIDComponent {

    collapsible: boolean = true;
    today: number = Date.now();
    id: string;
    collateral: any;

    constructor(private collateralService: CollateralService) {
        this.populateCollateralID();
    }

    populateCollateralID() {
        this.collateral = {
            collateralID: this.collateralService.getCollateral().collateralId,
            collateralType: this.collateralService.selectedCollateralType,
            _type: this.collateralService.getCollateral()._type,
            collateralCode: this.collateralService.getCollateral().collateralCode,
            collateralCreationDate: this.collateralService.getCollateral().generalDetail.collateralCreationDate
        };
    }
}
