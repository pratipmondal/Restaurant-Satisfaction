import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CollateralService } from '../collateral.service';
import { CollateralIDComponent } from './collateral-id.component';

class MockCollateralService {
    selectedCollateralType = 'TYPE_A';
    getCollateral() {
        return {
            collateralId: 'CID-001',
            collateralCode: 'code001',
            collateralType: 'TYPE_A',
            _type: 'TYPE_A',
            generalDetail : {
                collateralCreationDate : Date.now()
            }
        };
    }
}

describe('CollateralIDComponent', () => {
    let component: CollateralIDComponent;
    let fixture: ComponentFixture<CollateralIDComponent>;

    const collateral = {
        collateralID: 'CID-001',
        collateralCode: 'code001',
        collateralType: 'TYPE_A',
        _type: 'TYPE_A',
        selectedCollateralType: 'Collateral Details'
    };

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CollateralIDComponent],
            providers: [{ provide: CollateralService, useClass: MockCollateralService }]
        })
            .compileComponents().then(() => {
                fixture = TestBed.createComponent(CollateralIDComponent);
                component = fixture.componentInstance;
                fixture.detectChanges();
            });
    }));

    it('should create Collateral Id component', () => {
        expect(component).toBeTruthy();
    });

    it('should CollateralIDComponent render title', async(() => {
        fixture.detectChanges();
        const compiled = fixture.debugElement.nativeElement;
        expect(compiled.querySelector('div').textContent).toContain('Collateral ID');
    }));

    // populateColaateralId
    it('should pupolate CollateralId Object', async(() => {
        fixture.detectChanges();
        component.populateCollateralID();
        expect(component.collateral.collateralID).toBe(collateral.collateralID);
        expect(component.collateral.collateralCode).toBe(collateral.collateralCode);
        expect(component.collateral.collateralType).toBe(collateral.collateralType);
        expect(component.collateral._type).toBe(collateral._type);
    }));
});
