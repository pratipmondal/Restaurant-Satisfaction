import {Injectable, Inject} from '@angular/core';
import {Http, Response, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Rx';

import {ErrorResponse} from '../../shared';


@Injectable()
export class CollateralIDService {

    constructor(@Inject(Http) private http: Http) {
    }

    errorResponseFunction(error: any) {
        const ErrorResponse = <ErrorResponse>error;
        return Observable.throw(<ErrorResponse>ErrorResponse);
    }

    // TODO: Incorporate the logic once BE is developed
    /*getCollateral(id: string): Observable<any> {
       return this.http.get('')
            .map(onSuccessSuccess.bind(this))
            .catch(error => this.errorResponseFunction(error));
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }*/
}
