import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ComboBoxModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { CollateralSummaryComponent } from './collateral-summary.component';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { CounterpartyDetailsComponent } from '../../shared/counterparty-details/counterparty-details.component';
import { CounterpartyDetailsModule } from '../../shared/counterparty-details/counterparty-details.module';
import { COLLATERAL_ROUTE } from './../collateral.route';
import { CollateralComponent } from 'app/collateral';
import { RouterModule } from '@angular/router';
import { ClsSharedCommonModule } from 'app/shared';

@NgModule({
	imports: [
		RouterModule.forChild([COLLATERAL_ROUTE]),
		CommonModule,
		ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
		DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule, BrowserAnimationsModule,
		CustomPanelModule, CommonUIModule, CounterpartyDetailsModule, ClsSharedCommonModule],
	declarations: [CollateralSummaryComponent, CollateralComponent],
	exports: [CollateralSummaryComponent]
})
export class CollateralSummaryModule {
}
