import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ComboBoxModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { CustomPanelModule } from '../../common/custom-panel/custom-panel.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { CollateralSummaryComponent } from './collateral-summary.component';
import { CollateralSummaryService } from './collateral-summary.service';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Rx';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { MockCollateralData, GUARN_TYPE_COLLATERALS, MockCollateralsMasterInqData, DEPOS_TYPE_COLLATERALS } from './collateral-summary-mock-data';
import { CounterPartyDetailsService } from 'app/common/counterparty-details/counterparty.service';
import { CounterpartyDetailsModule } from '../../shared/counterparty-details/counterparty-details.module';

class MockCollateralSummaryService {
	rateConversionArray: any = [];
	collateralOperation = 'Add';
	getCurrency() {
		const data = [{ code: 'INR' }, { code: 'SGD' }, { code: 'USD' }];
		return Observable.of(data);
	}

	getCollateralSummaryData() {
		return Observable.of(MockCollateralData);
	}

	getRateValues(from: string, to: string) {
		if (from === '' && to === '') {
			return Observable.throw({ status: 404 });

		} else {
			const data = [{ 'rate': 10 }];
			return Observable.of(data);
		}
	}
	getCollateralsList(collateralType: any, filter: string) {
		if (collateralType === '' && filter === '') {
			return Observable.throw({ status: 404 });

		} else {
			return Observable.of(GUARN_TYPE_COLLATERALS);
		}
	}
}
class MockPartyDetailsService {
	temp = new Observable(observer => {
		observer.next({ 'label': 'Personal Leadership Centre Pte.Ltd', 'value': 'GCIN0000000' });
	});

	subscribeToCPDetails(temp) {
		return Observable.of({ label: 'Personal Leadership Centre Pte.Ltd', value: 'GCIN0000000' });
	}

}

describe('CollateralSummaryComponent', () => {
	let component: CollateralSummaryComponent;
	let fixture: ComponentFixture<CollateralSummaryComponent>;
	const mockArray = [
		{ key: 'GUARN', amount: 40000 },
		{ key: 'Aircraft', amount: 100000 },
		{ key: 'Cash', amount: 120000 },
		{ key: 'Property', amount: 890000 }
	];
	const router = {
		navigate: jasmine.createSpy('navigate')
	};
	beforeEach(async(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
		TestBed.configureTestingModule({
			imports: [CommonModule,
				ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
				DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule, BrowserAnimationsModule,
				CustomPanelModule, CommonUIModule, RouterTestingModule, CounterpartyDetailsModule, ClsSharedCommonModule],
			declarations: [CollateralSummaryComponent]
		});
		TestBed.overrideComponent(CollateralSummaryComponent, {
			set: {
				providers: [
					{ provide: CollateralSummaryService, useClass: MockCollateralSummaryService },
					{ provide: Router, useValue: router },
					{ provide: CounterPartyDetailsService, useClass: MockPartyDetailsService }
				]
			}
		})
			.compileComponents();
		fixture = TestBed.createComponent(CollateralSummaryComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	}));

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('should currencyChangeFormatter work', () => {
		const resultArray = component.currencyChangeFormatter(mockArray, 1.0e+6);
		const expectedArray = [Object({ amount: 0.04 }), Object({ amount: 0.1 }), Object({ amount: 0.12 }), Object({ amount: 0.89 })];
		expect(resultArray).toEqual(expectedArray);
	});
	it('should initialize collateral summary values work', () => {
		component.mainAmountValues =[];
		component.totalDeposAmount = 0.00;
		component.totalGuarnAmount = 0.00;
		component.totalOtherIntagibleData =0.00;
		component.totalPropertyCollateralData =0.00;
		component.currencyDividerValue = 1;
		const mockData = [{ key: 'GUARN', amount: 0.00 },
			{ key: 'Cash', amount: 0.00},
			{ key: 'Aircraft', amount: 890000 },
			{ key: 'Property', amount: 12000 }]
		component.initializeCollateralSummaryDetails();
		expect(component.mainAmountValues).toEqual(mockData);

	});
	it(' Should amount values to be converted based on selection  of dropdownlist of currency Formatter (Millions Dropdownlist)', () => {
		component.mainAmountValues = mockArray;
		component.presentCurrencyFormatIn = 'Millions';
		component.selectionChangeFormat('Millions');
		const expectedArray = [Object({ amount: 0.04 }), Object({ amount: 0.1 }), Object({ amount: 0.12 }), Object({ amount: 0.89 })];
		expect(component.total).toEqual(expectedArray);
		component.selectionChangeFormat('Units');
	});
	it('Should redirect url onclick of Add /Update Collateral', () => {
		component.redirectToNewCollateral();
		expect(router.navigate).toHaveBeenCalledWith(['/newcollateral']);
	});
	it('Should redirect url onclick of Add /Update Collateral', () => {
		component.redirectToViewCollaterals();
		expect(router.navigate).toHaveBeenCalledWith(['/viewcollaterals']);
	});
	it('get currency list dropdown from API', () => {
		component.getCurrencyList();
		expect(component.currencyFormatValues).toEqual([{ code: 'INR' }, { code: 'SGD' }, { code: 'USD' }]);
	});
	it('should fetch collaterl data on from service', () => {
		component.currencyDividerValue = 1;
		component.fetchCollateralDetails(MockCollateralsMasterInqData);
		expect(component.totalDeposAmount).toBe(100000);
	});
	it('should return rate valus for items ', () => {
		component.currencyDividerValue = 1;
		this.totalGuarnAmount = 0.00;
		const item = {
			'ccyType': 'SGD',
			'amount': 10000
		}
		component.getCurrencyRatesForItemValues('GUARN', item);
		expect(component.totalGuarnAmount).toBe(100000);
	});
	it('should sum of collateral list item values Based on collateral type ', () => {
		component.currencyDividerValue = 1;
		const item = {
			'ccyType': 'SGD',
			'amount': 10000
		};
		this.totalGuarnAmount = 0.00;
		this.totalDeposAmount = 0.00;
		this.totalOtherIntagibleData = 0.00;
		this.totalPropertyCollateralData = 0.00;
		component.sumOfAmountValues('GUARN', item);
		component.sumOfAmountValues('Other', item);
		component.sumOfAmountValues('Property', item);
		expect(component.totalGuarnAmount).toBe(10000);
		expect(component.totalPropertyCollateralData).toBe(10000);
		expect(component.totalOtherIntagibleData).toBe(10000);
	});
	it('should calculate Initial values from list of collateral data ', () => {
		component.currencyDividerValue = 1;
		const item = [
			{ 'ccyType': 'SGD', 'amount': 10000 },
			{ 'ccyType': 'SGD', 'amount': 20000 }];
		this.totalGuarnAmount = 0.00;
		this.totalDeposAmount = 0.00;
		this.totalOtherIntagibleData = 0.00;
		this.totalPropertyCollateralData = 0.00;
		component.initialCurrencyConverter('GUARN', item);
		expect(component.totalGuarnAmount).toBe(30000);
		component.initialCurrencyConverter('Other', item);
		expect(component.totalOtherIntagibleData).toBe(30000);
		component.initialCurrencyConverter('Property', item);
		expect(component.totalPropertyCollateralData).toBe(30000);
	});
	it('should not call service if rates already captured in array', () => {
		component.currencyDividerValue = 1;
		component.presentCurrencyFormat = 'SGD';
		component.otherCollateralData = [
			{ 'amount': 890000, ccyType: 'SGD' }
		];
		component.selectionCurrencyChange('INR');
		expect(component.totalOtherIntagibleData).toBe(8900000);
	});
});
