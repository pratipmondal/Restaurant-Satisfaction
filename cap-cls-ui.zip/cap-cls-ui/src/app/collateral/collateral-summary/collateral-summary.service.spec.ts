import { fakeAsync, inject, TestBed } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod } from '@angular/http';
import { MockCollateralData, GUARN_TYPE_COLLATERALS, MockCollateralsMasterInqData, DEPOS_TYPE_COLLATERALS } from './collateral-summary-mock-data';
import { CollateralSummaryService } from './collateral-summary.service';
import { environment } from '../../../environments/environment';

describe('CollateralSummaryService', () => {
	let collateralSummaryService: CollateralSummaryService = null;
	const ratesUrl = environment.apiBaseUrl + environment.apiToGetRates;
	const currencyUrl = environment.apiBaseUrl + environment.apiToGetCurrencyList;
	let mockBackend: MockBackend = null;
	const data = MockCollateralData;
	const currencyDropdownList = [{ code: 'INR' }, { code: 'SGD' }, { code: 'USD' }];
	const mockRateValues = [{ rate: 10 }, { rate: 17 }, { rate: 18 }];
	const currencyRateValue = environment.apiBaseUrl + 'rate';
	// let service: CollateralSummaryService = null;
	// let backend: MockBackend = null;
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				CollateralSummaryService
			],
			imports: [HttpModule]
		});
	});
	beforeEach(
		inject([CollateralSummaryService, MockBackend], (service: CollateralSummaryService, backend: MockBackend) => {
			collateralSummaryService = service;
			mockBackend = backend;
		})
	);
	it('should Create Collateral Summary service ', inject([CollateralSummaryService], (service: CollateralSummaryService) => {
		expect(service).toBeTruthy();
	}));

	it('Should connect API for currency dropdownlist', fakeAsync(() => {
		spyOn(collateralSummaryService, 'getCurrency');
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(currencyUrl);
		});
	}));
	it('Should connect API for Rates dropdownlist Values', fakeAsync(() => {
		spyOn(collateralSummaryService, 'getRateValues');
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(ratesUrl);
		});
	}));
	it('should get responce from  currency API ', () => {
		spyOn(collateralSummaryService, 'getCurrency').and.callFake(function () {
			return currencyDropdownList;
		});
		expect(collateralSummaryService.getCurrency()).toEqual(currencyDropdownList);
	});
	it('should get responce from  Rates API ', () => {
		spyOn(collateralSummaryService, 'getRateValues').and.callFake(function () {
			return mockRateValues;
		});
		expect(collateralSummaryService.getRateValues('SGD', 'INR')).toEqual(mockRateValues);
	});
	it('should get responce from  Collateral Summary service', () => {
		spyOn(collateralSummaryService, 'getCollateralsList').and.callFake(function () {
			return GUARN_TYPE_COLLATERALS;
		});
		expect(collateralSummaryService.getCollateralsList('GUARN', ' ')).toEqual(GUARN_TYPE_COLLATERALS);
	});

});
