export const MockCollateralData = [
	{
		'collateralId': '',
		'collateralCode': 'G01',
		'collateralType': 'GUARN',
		'generalDetail': {
			'collateralDesc': 'TEST',
			'collateralClass': '',
			'collateralGrp': '',
			'collateralCreationDate': '2017-03-07T12:40:36.355Z',
			'collateralExpiryDate': '2017-03-07T12:40:36.355Z',
			'currencyCode': 'SGD',
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': '',
				'receivedDate': '2017-03-07T12:40:36.355Z',
				'reviewDate': '2017-03-07T12:40:36.355Z',
				'nextReviewDate': '2017-03-07T12:40:36.355Z',
				'signingDate': '2017-03-07T12:40:36.355Z',
				'executionDate': '2017-03-07T12:40:36.355Z',
				'comments': ''
			}
		},
		'GUARN': {
			'LodgeReceiptAndPayment': {
				'receiptAndPayment': [
					{
						'receiptType': '',
						'receiptAmt': {
							'value': 100000,
							'ccy': ''
						},
						'paymentType': '',
						'paymentAmt': {
							'value': 200000,
							'ccy': ''
						},
						'dueDate': '2017-03-07T12:40:36.355Z',
						'paidOrReceivedDate': '2017-03-07T12:40:36.355Z',
						'dateRange': '',
						'proofVerifiedDate': '2017-03-07T12:40:36.355Z',
						'paymentMode': '',
						'notes': '',
						'name': '',
						'freeCode1': '',
						'freeCode2': '',
						'freeText': '',
						'delete': false
					},
					{
						'receiptType': '',
						'receiptAmt': {
							'value': 100000,
							'ccy': ''
						},
						'paymentType': '',
						'paymentAmt': {
							'value': 200000,
							'ccy': ''
						},
						'dueDate': '2017-03-07T12:40:36.355Z',
						'paidOrReceivedDate': '2017-03-07T12:40:36.355Z',
						'dateRange': '',
						'proofVerifiedDate': '2017-03-07T12:40:36.355Z',
						'paymentMode': '',
						'notes': '',
						'name': '',
						'freeCode1': '',
						'freeCode2': '',
						'freeText': '',
						'delete': false
					}
				]
			},
			'LodgeDocumentationDetail': {
				'document': [
					{
						'documentCode': 'DOCCODE1',
						'documentDate': '2017-03-07T12:40:36.355Z',
						'documentId': '',
						'dueDate': '2017-03-07T12:40:36.355Z',
						'documentReceivedDate': '2017-03-07T12:40:36.355Z',
						'documentExpirationDate': '2017-03-07T12:40:36.355Z',
						'comments': '',
						'delete': false
					}
				]
			},
			'LodgeBeneficiaryDetail': {
				'beneficiaryList': [
					{
						'beneficiaryName': '',
						'cifId': 'CIF1',
						'beneficiaryIdType': '',
						'beneficiaryId': '',
						'addressLine1': '',
						'addressLine2': '',
						'addressLine3': '',
						'city': '',
						'state': '',
						'country': '',
						'postalCode': '',
						'phoneNo': '',
						'emailAddress': '',
						'telexNo': '',
						'faxNo': '',
						'delete': false
					}
				]
			},
			'CollateralValuationDetail': {
				'loanToValuePcnt': 0,
				'externalChargeAmt': {
					'value': 0,
					'ccy': ''
				},
				'collateralValue': {
					'value': 11000,
					'ccy': 'SGD'
				},
				'finalCollateralValue': {
					'value': 0,
					'ccy': 'SGD'
				},
				'apportioningMethod': 'P',
				'totalApportionedValue': {
					'value': 0,
					'ccy': 'SGD'
				},
				'balanceApportionableAmt': {
					'value': 0,
					'ccy': 'SGD'
				}
			},
			'LodgeOwnerShipDetail': {
				'collateralOwnerShipType': '',
				'ownerShipList': [
					{
						'cifId': 'CIF1',
						'idType': '',
						'idNo': 0,
						'name': '',
						'collateralOwnerShipPcnt': 0,
						'addressLine1': '',
						'addressLine2': '',
						'addressLine3': '',
						'city': '',
						'state': '',
						'country': '',
						'postalCode': '',
						'phoneNo': '',
						'emailAddress': '',
						'telexNo': '',
						'faxNo': '',
						'delete': false
					}
				]
			},
			'LodgeCollateralTypeSpecificDetail': {
				'guaranteeType': '',
				'guarantorName': '',
				'guarantorCifId': 'CIF1',
				'idType': '',
				'idNo': '',
				'guarantorType': '',
				'supportingCollateralsHeld': false,
				'guaranteePcnt': 10,
				'guaranteeAmt': {
					'value': 0,
					'ccy': ''
				},
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': ''
			},
			'FeeDetail': {
				'feeDetailList': [
					{
						'feeType': 'FEE2',
						'feeCode': 'FEECODE',
						'overrideFeeSetup': false,
						'feeDistributable': false,
						'multiple': false,
						'frequency': '',
						'nextAssessmentDate': '2017-03-07T12:40:36.356Z',
						'maxNumberOfAssessements': 0,
						'amortize': false,
						'amortizationTerm': 0,
						'method': '',
						'scriptName': '',
						'userEnteredAmt': {
							'value': 0,
							'ccy': ''
						},
						'userEnteredPcnt': 0,
						'remarks': '',
						'delete': false
					}
				],
				'feeCollectionAccount': '',
				'computedAmount': {
					'value': 0,
					'ccy': ''
				},
				'collectableAmountPcnt': 0,
				'collectableAmount': {
					'value': 0,
					'ccy': ''
				}
			},
			'CollateralValueDetail': {
				'unitValueMethod': false,
				'directValueMethod': false,
				'netValueMethod': false,
				'derivedValueMethod': false,
				'itemBasedMethod': false,
				'customerDerivationMethod': false,
				'defaultValueMethod': false,
				'childCollateralMethod': false
			}
		},
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': null
		}
	}
]

export const MockCollateralsMasterInqData = [
	{
		'collateralId': 'COLL2',
		'collateralCode': 'code02',
		'collateralType': 'DEPOS'
	},
	{
		'collateralId': 'COLL2312',
		'collateralCode': 'code02',
		'collateralType': 'DEPOS'
	},
	{
		'collateralId': 'COLL2442',
		'collateralCode': 'code03',
		'collateralType': 'DEPOS'
	},
	{
		'collateralId': 'aaaaaaa',
		'collateralCode': 'code03',
		'collateralType': 'GUARN'
	},
	{
		'collateralId': 'COLL10',
		'collateralCode': 'code03',
		'collateralType': 'GUARN'
	},
	{
		'collateralId': 'COLL100',
		'collateralCode': 'code03',
		'collateralType': 'GUARN'
	}
];


export const CASH_COLLATERAL_MOCK_LIST = [{
	'collateralId': 'COL00125200',
	'collateralCode': 'Fixed Deposits',
	'owner': 'Stevan Tan',
	'originalCurrency': 'GBP',
	'originalCollateralValue': 80000.00,
	'convertedCollateralValue': 143000.00,
	'beneficiaryID': [{
		'Personal Leadership Centre Pte. Ltd.': [],
		'Minera Thai Pte. Ltd.': ['LIM01020293', 'LIM01020211']
	}],
	'remarks': 'Charge over cash equivalent to 6 months of interest serving on the TL'
}, {
	'collateralId': 'COL00125197',
	'collateralCode': 'Fixed Deposits',
	'owner': 'Stevan Tan',
	'originalCurrency': 'USD',
	'originalCollateralValue': 80000.00,
	'convertedCollateralValue': 113000.00,
	'beneficiaryID': [{
		'Minera Thai Pte. Ltd.': []
	}],
	'remarks': '-'
}];

export const GUARANTEE_COLLATERAL_MOCK_LIST = [{
	'collateralId': 'COL00100502',
	'collateralCode': 'Guarantee - Standby L/C',
	'guarantor': 'United Overseas Bank Ltd.',
	'originalCurrency': 'SGD',
	'originalCollateralValue': 100000.00,
	'convertedCollateralValue': 140000.00,
	'beneficiaryID': [{
		'Personal Leadership Centre Pte. Ltd.': []
	}],
	'remarks': '-'
}];

export const OTHER_INTANGIBLE_COLLATERAL_MOCK_LIST = [{
	'collateralId': 'COL00128574',
	'collateralCode': 'Letter of Awareness / Comfort / Other Moral Undertaking',
	'owner': 'Personal Leadership Ltd.',
	'originalCurrency': 'USD',
	'originalCollateralValue': 100000.00,
	'convertedCollateralValue': 140000.00,
	'beneficiaryID': [{
		'Personal Leadership Centre Pte. Ltd.': []
	}],
	'remarks': '-'
}, {
	'collateralId': 'COL00128544',
	'collateralCode': 'Charge Over Receivable',
	'owner': 'Personal Leadership Ltd.',
	'originalCurrency': 'USD',
	'originalCollateralValue': 100000.00,
	'convertedCollateralValue': 140000.00,
	'beneficiaryID': [{
		'Personal Leadership Centre Pte. Ltd.': []
	}],
	'remarks': '-'
}];

export const GUARN_TYPE_COLLATERALS = [
	{
		'LodgeReceiptAndPayment': {
			'receiptAndPayment': []
		},
		'LodgeDocumentationDetail': {
			'document': []
		},
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'guaranteeType': '',
			'guarantorName': '',
			'guarantorCifId': '',
			'guarantorType': '',
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'ccy': '',
				'_isDeleted': false
			},
			'proposeAmt': {
				'ccy': '',
				'_isDeleted': false
			},
			'approvedAmt': {
				'ccy': '',
				'_isDeleted': false
			},
			'addressLine1': '',
			'addressLine2': '',
			'addressLine3': '',
			'city': '',
			'state': '',
			'country': '',
			'postalCode': ''
		},
		'FeeDetail': null,
		'CollateralValueDetail': {
			'unitValueMethod': false,
			'directValueMethod': false,
			'netValueMethod': false,
			'derivedValueMethod': false,
			'itemBasedMethod': false,
			'customerDerivationMethod': false,
			'defaultValueMethod': false,
			'childCollateralMethod': false
		},
		'collateralId': 'aaaaaaa',
		'collateralCode': 'code03',
		'generalDetail': {
			'collateralDesc': 'Modified Description for Guarn',
			'globalCollateral': false,
			'collateralClass': 'COLTRLCLS1',
			'collateralGroup': 'COLTRLGRP1',
			'collateralCreationDate': '2017-08-01T00:00:00.000Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': '',
				'receivedDate': null,
				'reviewDate': null,
				'nextReviewDate': null,
				'signingDate': null,
				'executionDate': null,
				'comments': ''
			},
			'solicitorDetails': {
				'solicitorName': '',
				'approvedSolicitor': false,
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': '',
				'phoneNo': '',
				'emailAddress': '',
				'telexNo': '',
				'faxNo': ''
			},
			'remarks': 'aaaaaaaa',
			'method': '',
			'collateralGrp': '',
			'solicitorName': '',
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': null
		},
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-19T05:03:18.535Z',
		'_modifiedOn': '2017-08-01T10:35:11.096Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': 'bb7b5a4d-ee7f-4a19-bf94-de95438388c5',
		'_version': 'bdca1617-8385-42df-be1b-bce34ce85777',
		'_requestId': '',
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': {
			'receiptAndPayment': [
				{
					'receiptOrPaymentInd': 'R',
					'receiptType': 'RECPT2',
					'receiptAmt': {
						'value': 100,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'paymentType': '',
					'paymentAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'dueDate': '2017-06-02T12:33:43.707Z',
					'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
					'dateFrom': '',
					'dateTo': '',
					'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
					'paymentMode': '',
					'notes': '',
					'name': '',
					'addressLine1': '',
					'addressLine2': '',
					'addressLine3': '',
					'city': '',
					'state': '',
					'country': '',
					'postalCode': '',
					'delete': false
				}
			]
		},
		'LodgeDocumentationDetail': {
			'document': [
				{
					'documentCode': 'DOCCODE1',
					'documentDate': '2017-06-02T12:33:43.707Z',
					'documentId': '',
					'dueDate': '2017-06-02T12:33:43.707Z',
					'documentReceivedDate': '2017-06-02T12:33:43.707Z',
					'documentExpirationDate': '2017-06-02T12:33:43.707Z',
					'documentStatus': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'CollateralValuationDetail': {
			'loanToValuePcnt': 40,
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 100000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 100000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 100000,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'guaranteeType': '',
			'guarantorName': 'Parvez',
			'guarantorCifId': 'CUST2',
			'guarantorType': '',
			'supportingCollateralsHeld': false,
			'guaranteePcnt': 10,
			'guaranteeAmt': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			},
			'proposedPcnt': 0,
			'proposeAmt': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			},
			'approvedPcnt': 0,
			'approvedAmt': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			},
			'addressLine1': 'DBS Bank LTD',
			'addressLine2': 'Marina Bay',
			'addressLine3': 'Marina Bay Financial Centre Tower 3',
			'city': 'SINGAPORE',
			'state': 'SN',
			'country': 'SINGAPORE',
			'postalCode': '018982'
		},
		'FeeDetail': {
			'debitA/cForFees': 'DebitAcct02',
			'feeDetailList': [
				{
					'feeType': 'FEE1',
					'feeCode': 'FEECODE1',
					'overrideFeeSetup': false,
					'feeDistributable': false,
					'multiple': false,
					'frequency': '',
					'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
					'maxNumberOfAssessements': 0,
					'amortize': false,
					'amortizationTerm': 0,
					'method': '',
					'scriptName': '',
					'userEnteredAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'userEnteredPcnt': 0,
					'comments': '',
					'delete': false
				}
			],
			'feeCollectionAccount': '',
			'computedAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			},
			'collectableAmountPcnt': 0,
			'collectableAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			}
		},
		'CollateralValueDetail': {
			'unitValueMethod': false,
			'directValueMethod': false,
			'netValueMethod': false,
			'derivedValueMethod': false,
			'itemBasedMethod': false,
			'customerDerivationMethod': false,
			'defaultValueMethod': false,
			'childCollateralMethod': false
		},
		'collateralId': 'COLL10',
		'collateralCode': 'code03',
		'generalDetail': {
			'collateralDesc': 'Lodgement for guarnt',
			'globalCollateral': false,
			'collateralClass': 'COLTRLCLS1',
			'collateralCreationDate': '2017-06-20T12:33:43.707Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': 'A2343223',
				'receivedDate': '2017-06-02T12:33:43.707Z',
				'reviewDate': '2017-06-02T12:33:43.707Z',
				'nextReviewDate': '2017-06-02T12:33:43.707Z',
				'signingDate': '2017-06-02T12:33:43.707Z',
				'executionDate': '2017-06-02T12:33:43.707Z',
				'comments': ''
			},
			'solicitorDetails': {
				'solicitorName': '',
				'approvedSolicitor': false,
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': '',
				'phoneNo': '',
				'emailAddress': '',
				'telexNo': '',
				'faxNo': ''
			},
			'collateralGrp': 'COLTRLGRP1',
			'businessLocation': 'INDIA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': '2017-06-02T12:33:43.707Z'
		},
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-06-20T12:22:43.480Z',
		'_modifiedOn': '2017-06-20T12:22:43.480Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '9d8ae773-d849-49ba-a268-8ca49f4fe289',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL100',
		'collateralCode': 'code03',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-06-27T10:13:10.249Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-06-27T10:13:10.415Z',
		'_modifiedOn': '2017-06-27T10:13:10.415Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '6032831a-26bb-4846-825d-8a0b1cf6139a',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL1000',
		'collateralCode': 'GAUCODE',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-07-05T08:39:27.349Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-05T08:39:27.483Z',
		'_modifiedOn': '2017-07-05T08:39:27.483Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '56d0b356-ce84-49ae-a88f-6c40780796f4',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL1001',
		'collateralCode': 'GAUCODE',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-07-05T08:46:54.442Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-05T08:46:54.609Z',
		'_modifiedOn': '2017-07-05T08:46:54.609Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '29be7c81-78bb-4e6e-80d3-cabe409021b2',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL1002',
		'collateralCode': 'GAUCODE',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-07-05T08:49:18.432Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-05T08:49:18.615Z',
		'_modifiedOn': '2017-07-05T08:49:18.615Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': 'e2e1bdc6-5773-4868-bb01-1c8fd740907d',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL1003',
		'collateralCode': 'GAUCODE',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-07-05T08:50:40.875Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-05T08:50:41.121Z',
		'_modifiedOn': '2017-07-05T08:50:41.121Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '0435d3e9-77ce-4c08-838a-866b0c17c3f8',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL1004',
		'collateralCode': 'GAUCODE',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-07-05T08:56:37.895Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-05T08:56:38.134Z',
		'_modifiedOn': '2017-07-05T08:56:38.134Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '8ce81aa4-64d1-4c73-bd04-f0b8cc4e1c40',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL1005',
		'collateralCode': 'GAUCODE',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-07-05T08:58:47.020Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-05T08:58:47.215Z',
		'_modifiedOn': '2017-07-05T08:58:47.215Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '27f907e5-9b6e-476c-bea5-ec8051c54e30',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': null,
		'LodgeDocumentationDetail': null,
		'CollateralValuationDetail': {
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'supportingCollateralsHeld': false,
			'guaranteeAmt': {
				'_isDeleted': false
			}
		},
		'FeeDetail': null,
		'CollateralValueDetail': null,
		'collateralId': 'COLL1006',
		'collateralCode': 'code03',
		'generalDetail': {
			'globalCollateral': false,
			'collateralCreationDate': '2017-07-05T09:01:38.622Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'businessLocation': 'USA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': null,
		'_type': 'GUARNCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-05T09:01:38.835Z',
		'_modifiedOn': '2017-07-05T09:01:38.835Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '6b8f5686-6162-4ed6-8060-fc267cb8e0e6',
		'_requestId': null,
		'_newVersion': null
	}
];

export const DEPOS_TYPE_COLLATERALS = [
	{
		'LodgeReceiptAndPayment': {
			'receiptAndPayment': [
				{
					'receiptOrPaymentInd': 'P',
					'receiptType': '',
					'receiptAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'paymentType': 'PYMT1',
					'paymentAmt': {
						'value': 100,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'dueDate': '2017-06-02T12:33:43.707Z',
					'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
					'dateFrom': '',
					'dateTo': '',
					'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
					'paymentMode': 'PAYMODE1',
					'notes': '',
					'name': '',
					'addressLine1': '',
					'addressLine2': '',
					'addressLine3': '',
					'city': '',
					'state': '',
					'country': '',
					'postalCode': '',
					'delete': false
				}
			]
		},
		'LodgeDocumentationDetail': {
			'document': [
				{
					'documentCode': 'DOCCODE1',
					'documentDate': '2017-06-02T12:33:43.707Z',
					'documentId': '',
					'dueDate': '2017-06-02T12:33:43.707Z',
					'documentReceivedDate': '2017-06-02T12:33:43.707Z',
					'documentExpirationDate': '2017-06-02T12:33:43.707Z',
					'documentStatus': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'CollateralValuationDetail': {
			'loanToValuePcnt': 40,
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 40000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 40000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 4000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 36000,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'fullBenefit': false,
			'depositDetails': [
				{
					'depositAcctNo': 'depAcct1',
					'maturityDate': '2017-06-02T12:33:43.707Z',
					'term': 0,
					'acctBalance': {
						'value': 30000,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'avlblBalance': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'proposedAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'approvedAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'bankId': '',
					'bankIdentifierCode': '',
					'branchId': '',
					'comments': '',
					'delete': false,
					'principle': {
						'ccy': 'SGD',
						'value': 40000,
						'_isDeleted': false
					}
				}
			]
		},
		'FeeDetail': {
			'debitA/cForFees': 'DebitAcct02',
			'feeDetailList': [
				{
					'feeType': 'FEE1',
					'feeCode': 'FEECODE1',
					'overrideFeeSetup': false,
					'feeDistributable': false,
					'multiple': false,
					'frequency': '',
					'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
					'maxNumberOfAssessements': 0,
					'amortize': false,
					'amortizationTerm': 0,
					'method': '',
					'scriptName': '',
					'userEnteredAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'userEnteredPcnt': 0,
					'comments': '',
					'delete': false
				}
			],
			'feeCollectionAccount': '',
			'computedAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			},
			'collectableAmountPcnt': 0,
			'collectableAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			}
		},
		'CollateralValueDetail': {
			'unitValueMethod': false,
			'directValueMethod': false,
			'netValueMethod': false,
			'derivedValueMethod': false,
			'itemBasedMethod': false,
			'customerDerivationMethod': false,
			'defaultValueMethod': false,
			'childCollateralMethod': false
		},
		'multiCcy': false,
		'collateralId': 'COLL1',
		'collateralCode': 'code02',
		'generalDetail': {
			'collateralDesc': 'Lodgement for deposit',
			'globalCollateral': false,
			'collateralClass': 'COLTRLCLS1',
			'collateralCreationDate': '2017-06-20T12:33:43.707Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': 'A2343223',
				'receivedDate': '2017-06-02T12:33:43.707Z',
				'reviewDate': '2017-06-02T12:33:43.707Z',
				'nextReviewDate': '2017-06-02T12:33:43.707Z',
				'signingDate': '2017-06-02T12:33:43.707Z',
				'executionDate': '2017-06-02T12:33:43.707Z',
				'comments': ''
			},
			'solicitorDetails': {
				'solicitorName': '',
				'approvedSolicitor': false,
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': '',
				'phoneNo': '',
				'emailAddress': '',
				'telexNo': '',
				'faxNo': ''
			},
			'collateralGrp': 'COLTRLGRP1',
			'businessLocation': 'INDIA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': '2017-06-02T12:33:43.707Z'
		},
		'_type': 'DEPOSCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-06-20T07:50:23.701Z',
		'_modifiedOn': '2017-06-20T07:54:55.974Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': '85e06895-93dd-4cb0-945f-36e5488f54c8',
		'_version': '5682253e-a28c-4a21-9444-032abf22dd4c',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': {
			'receiptAndPayment': [
				{
					'receiptOrPaymentInd': 'P',
					'receiptType': '',
					'receiptAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'paymentType': 'PYMT1',
					'paymentAmt': {
						'value': 100,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'dueDate': '2017-06-02T12:33:43.707Z',
					'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
					'dateFrom': '',
					'dateTo': '',
					'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
					'paymentMode': 'PAYMODE1',
					'notes': '',
					'name': '',
					'addressLine1': '',
					'addressLine2': '',
					'addressLine3': '',
					'city': '',
					'state': '',
					'country': '',
					'postalCode': '',
					'delete': false
				}
			]
		},
		'LodgeDocumentationDetail': {
			'document': [
				{
					'documentCode': 'DOCCODE1',
					'documentDate': '2017-06-02T12:33:43.707Z',
					'documentId': '',
					'dueDate': '2017-06-02T12:33:43.707Z',
					'documentReceivedDate': '2017-06-02T12:33:43.707Z',
					'documentExpirationDate': '2017-06-02T12:33:43.707Z',
					'documentStatus': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'CollateralValuationDetail': {
			'loanToValuePcnt': 40,
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 40000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 40000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 4000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 36000,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'fullBenefit': false,
			'depositDetails': [
				{
					'depositAcctNo': 'depAcct1',
					'maturityDate': '2017-06-02T12:33:43.707Z',
					'term': 0,
					'acctBalance': {
						'value': 30000,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'avlblBalance': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'proposedAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'approvedAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'bankId': '',
					'bankIdentifierCode': '',
					'branchId': '',
					'comments': '',
					'delete': false,
					'principle': {
						'ccy': 'SGD',
						'value': 40000,
						'_isDeleted': false
					}
				}
			]
		},
		'FeeDetail': {
			'debitA/cForFees': 'DebitAcct02',
			'feeDetailList': [
				{
					'feeType': 'FEE1',
					'feeCode': 'FEECODE1',
					'overrideFeeSetup': false,
					'feeDistributable': false,
					'multiple': false,
					'frequency': '',
					'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
					'maxNumberOfAssessements': 0,
					'amortize': false,
					'amortizationTerm': 0,
					'method': '',
					'scriptName': '',
					'userEnteredAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'userEnteredPcnt': 0,
					'comments': '',
					'delete': false
				}
			],
			'feeCollectionAccount': '',
			'computedAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			},
			'collectableAmountPcnt': 0,
			'collectableAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			}
		},
		'CollateralValueDetail': {
			'unitValueMethod': false,
			'directValueMethod': false,
			'netValueMethod': false,
			'derivedValueMethod': false,
			'itemBasedMethod': false,
			'customerDerivationMethod': false,
			'defaultValueMethod': false,
			'childCollateralMethod': false
		},
		'multiCcy': false,
		'collateralId': 'COLL2',
		'collateralCode': 'code02',
		'generalDetail': {
			'collateralDesc': 'Lodgement for deposit',
			'globalCollateral': false,
			'collateralClass': 'COLTRLCLS1',
			'collateralCreationDate': '2017-06-20T12:33:43.707Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': 'A2343223',
				'receivedDate': '2017-06-02T12:33:43.707Z',
				'reviewDate': '2017-06-02T12:33:43.707Z',
				'nextReviewDate': '2017-06-02T12:33:43.707Z',
				'signingDate': '2017-06-02T12:33:43.707Z',
				'executionDate': '2017-06-02T12:33:43.707Z',
				'comments': ''
			},
			'solicitorDetails': {
				'solicitorName': '',
				'approvedSolicitor': false,
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': '',
				'phoneNo': '',
				'emailAddress': '',
				'telexNo': '',
				'faxNo': ''
			},
			'collateralGrp': 'COLTRLGRP1',
			'businessLocation': 'INDIA'
		},
		'collateralOwnerShipType': null,
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': '2017-06-02T12:33:43.707Z'
		},
		'_type': 'DEPOSCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-06-20T07:50:39.275Z',
		'_modifiedOn': '2017-06-20T07:54:56.187Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': 'a4bdbe53-82fb-44a3-8f12-7346803c19db',
		'_version': 'a8c8eae6-4a8a-4e77-adac-0367ceb33a97',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': {
			'receiptAndPayment': [
				{
					'receiptOrPaymentInd': 'P',
					'receiptType': '',
					'receiptAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'paymentType': 'PYMT1',
					'paymentAmt': {
						'value': 100,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'dueDate': '2017-06-02T12:33:43.707Z',
					'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
					'dateFrom': '',
					'dateTo': '',
					'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
					'paymentMode': 'PAYMODE1',
					'notes': '',
					'name': '',
					'addressLine1': '',
					'addressLine2': '',
					'addressLine3': '',
					'city': '',
					'state': '',
					'country': '',
					'postalCode': '',
					'delete': false
				}
			]
		},
		'LodgeDocumentationDetail': {
			'document': [
				{
					'documentCode': '913',
					'documentDate': '2017-06-02T12:33:43.707Z',
					'documentId': '',
					'dueDate': '2017-06-02T12:33:43.707Z',
					'documentReceivedDate': '2017-06-02T12:33:43.707Z',
					'documentExpirationDate': '2017-06-02T12:33:43.707Z',
					'documentStatus': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'CollateralValuationDetail': {
			'loanToValuePcnt': 40,
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 40000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 40000,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 40000,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'fullBenefit': false,
			'depositDetails': [
				{
					'depositAcctNo': 'depAcct1',
					'sourceSystem': '',
					'maturityDate': '2017-06-02T12:33:43.707Z',
					'term': 0,
					'principal': {
						'value': 40000,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'acctBalance': {
						'value': 30000,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'avlblBalance': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'proposedAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'approvedAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'bankId': '',
					'bankIdentifierCode': '',
					'branchId': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'FeeDetail': {
			'debitA/cForFees': 'DebitAcct02',
			'feeDetailList': [
				{
					'feeType': 'FEE1',
					'feeCode': 'FEECODE1',
					'overrideFeeSetup': false,
					'feeDistributable': false,
					'multiple': false,
					'frequency': '',
					'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
					'maxNumberOfAssessements': 0,
					'amortize': false,
					'amortizationTerm': 0,
					'method': '',
					'scriptName': '',
					'userEnteredAmt': {
						'value': 0,
						'ccy': '',
						'_isDeleted': false
					},
					'userEnteredPcnt': 0,
					'comments': '',
					'delete': false
				}
			],
			'feeCollectionAccount': '',
			'computedAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			},
			'collectableAmountPcnt': 0,
			'collectableAmount': {
				'value': 0,
				'ccy': '',
				'_isDeleted': false
			}
		},
		'CollateralValueDetail': {
			'unitValueMethod': false,
			'directValueMethod': false,
			'netValueMethod': false,
			'derivedValueMethod': false,
			'itemBasedMethod': false,
			'customerDerivationMethod': false,
			'defaultValueMethod': false,
			'childCollateralMethod': false
		},
		'multiCcy': false,
		'collateralId': 'COLL2312',
		'collateralCode': 'code02',
		'generalDetail': {
			'collateralDesc': 'Lodgement for deposit',
			'globalCollateral': false,
			'country': 'INDIA',
			'collateralClass': 'COLTRLCLS1',
			'collateralGroup': 'COLTRLGRP1',
			'collateralCreationDate': '2017-07-24T06:13:39.248Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': 'A2343223',
				'receivedDate': '2017-06-02T12:33:43.707Z',
				'reviewDate': '2017-06-02T12:33:43.707Z',
				'nextReviewDate': '2017-06-02T12:33:43.707Z',
				'signingDate': '2017-06-02T12:33:43.707Z',
				'executionDate': '2017-06-02T12:33:43.707Z',
				'comments': ''
			},
			'solicitorDetails': {
				'solicitorName': '',
				'approvedSolicitor': false,
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': '',
				'phoneNo': '',
				'emailAddress': '',
				'telexNo': '',
				'faxNo': ''
			},
			'remarks': 'Deposit'
		},
		'collateralOwnerShipType': '',
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': '2017-06-02T12:33:43.707Z'
		},
		'_type': 'DEPOSCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-24T09:36:21.498Z',
		'_modifiedOn': '2017-07-24T09:36:21.498Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': '25c975e7-6ba8-478a-bcfa-773c3d0b9761',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': {
			'receiptAndPayment': [
				{
					'receiptOrPaymentInd': 'P',
					'receiptType': '',
					'receiptAmt': {
						'value': 0,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'paymentType': 'PYMT1',
					'paymentAmt': {
						'value': 10,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'dueDate': '2017-06-02T12:33:43.707Z',
					'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
					'dateFrom': '',
					'dateTo': '',
					'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
					'paymentMode': 'PAYMODE1',
					'notes': '',
					'name': '',
					'addressLine1': '',
					'addressLine2': '',
					'addressLine3': '',
					'city': '',
					'state': '',
					'country': '',
					'postalCode': '',
					'delete': false
				}
			]
		},
		'LodgeDocumentationDetail': {
			'document': [
				{
					'documentCode': '058',
					'documentDate': '2017-06-02T12:33:43.707Z',
					'documentId': '',
					'dueDate': '2017-06-02T12:33:43.707Z',
					'documentReceivedDate': '2017-06-02T12:33:43.707Z',
					'documentExpirationDate': '2017-06-02T12:33:43.707Z',
					'documentStatus': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'CollateralValuationDetail': {
			'loanToValuePcnt': 40,
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 100,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 100,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 100,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'fullBenefit': false,
			'depositDetails': [
				{
					'depositAcctNo': 'depAcct1',
					'sourceSystem': '',
					'maturityDate': '2017-07-11T00:00:00.000Z',
					'term': 0,
					'principal': {
						'value': 100,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'acctBalance': {
						'value': 50,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'avlblBalance': {
						'value': 50,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'proposedAmt': {
						'value': 40,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'approvedAmt': {
						'value': 30,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'bankId': '',
					'bankIdentifierCode': '',
					'branchId': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'FeeDetail': {
			'debitA/cForFees': 'DebitAcct02',
			'feeDetailList': [
				{
					'feeType': 'FEE1',
					'feeCode': 'FEECODE1',
					'overrideFeeSetup': false,
					'feeDistributable': false,
					'multiple': false,
					'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
					'maxNumberOfAssessements': 0,
					'amortize': false,
					'amortizationTerm': 0,
					'method': '',
					'scriptName': '',
					'userEnteredAmt': {
						'value': 0,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'userEnteredPcnt': 0,
					'comments': '',
					'delete': false
				}
			],
			'feeCollectionAccount': '',
			'computedAmount': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collectableAmountPcnt': 0,
			'collectableAmount': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'CollateralValueDetail': {
			'unitValueMethod': false,
			'directValueMethod': false,
			'netValueMethod': false,
			'derivedValueMethod': false,
			'itemBasedMethod': false,
			'customerDerivationMethod': false,
			'defaultValueMethod': false,
			'childCollateralMethod': false
		},
		'multiCcy': false,
		'collateralId': 'COLL2442',
		'collateralCode': 'code03',
		'generalDetail': {
			'collateralDesc': 'Lodgement for guarnt',
			'globalCollateral': false,
			'country': 'INDIA',
			'collateralClass': 'COLTRLCLS1',
			'collateralGroup': 'COLTRLGRP1',
			'collateralCreationDate': '2017-07-25T00:00:00.000Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': 'A2343223',
				'receivedDate': '2017-06-02T12:33:43.707Z',
				'reviewDate': '2017-06-02T12:33:43.707Z',
				'nextReviewDate': '2017-06-02T12:33:43.707Z',
				'signingDate': '2017-06-02T12:33:43.707Z',
				'executionDate': '2017-06-02T12:33:43.707Z'
			},
			'solicitorDetails': {
				'solicitorName': '',
				'approvedSolicitor': false,
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': '',
				'phoneNo': '',
				'emailAddress': '',
				'telexNo': '',
				'faxNo': ''
			},
			'remarks': 'Deposit'
		},
		'collateralOwnerShipType': '',
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': '2017-06-02T12:33:43.707Z'
		},
		'_type': 'DEPOSCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-25T04:37:55.672Z',
		'_modifiedOn': '2017-07-25T04:37:55.672Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': 'eafdb224-2320-4015-9017-f66cbbfd0b5a',
		'_requestId': null,
		'_newVersion': null
	},
	{
		'LodgeReceiptAndPayment': {
			'receiptAndPayment': [
				{
					'receiptOrPaymentInd': 'P',
					'receiptType': '',
					'receiptAmt': {
						'value': 0,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'paymentType': 'PYMT1',
					'paymentAmt': {
						'value': 10,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'dueDate': '2017-06-02T12:33:43.707Z',
					'paidOrReceivedDate': '2017-06-02T12:33:43.707Z',
					'dateFrom': '',
					'dateTo': '',
					'proofVerifiedDate': '2017-06-02T12:33:43.707Z',
					'paymentMode': 'PAYMODE1',
					'notes': '',
					'name': '',
					'addressLine1': '',
					'addressLine2': '',
					'addressLine3': '',
					'city': '',
					'state': '',
					'country': '',
					'postalCode': '',
					'delete': false
				}
			]
		},
		'LodgeDocumentationDetail': {
			'document': [
				{
					'documentCode': '058',
					'documentDate': '2017-06-02T12:33:43.707Z',
					'documentId': '',
					'dueDate': '2017-06-02T12:33:43.707Z',
					'documentReceivedDate': '2017-06-02T12:33:43.707Z',
					'documentExpirationDate': '2017-06-02T12:33:43.707Z',
					'documentStatus': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'CollateralValuationDetail': {
			'loanToValuePcnt': 40,
			'externalChargeAmt': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collateralValue': {
				'value': 100,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'finalCollateralValue': {
				'value': 100,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'apportioningMethod': 'P',
			'totalApportionedValue': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'balanceApportionableAmt': {
				'value': 100,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'LodgeCollateralTypeSpecificDetail': {
			'fullBenefit': false,
			'depositDetails': [
				{
					'depositAcctNo': 'depAcct1',
					'sourceSystem': '',
					'maturityDate': '2017-07-11T00:00:00.000Z',
					'term': 0,
					'principal': {
						'value': 100,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'acctBalance': {
						'value': 50,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'avlblBalance': {
						'value': 50,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'proposedAmt': {
						'value': 40,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'approvedAmt': {
						'value': 30,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'bankId': '',
					'bankIdentifierCode': '',
					'branchId': '',
					'comments': '',
					'delete': false
				}
			]
		},
		'FeeDetail': {
			'debitA/cForFees': 'DebitAcct02',
			'feeDetailList': [
				{
					'feeType': 'FEE1',
					'feeCode': 'FEECODE1',
					'overrideFeeSetup': false,
					'feeDistributable': false,
					'multiple': false,
					'nextAssessmentDate': '2017-06-02T12:33:43.722Z',
					'maxNumberOfAssessements': 0,
					'amortize': false,
					'amortizationTerm': 0,
					'method': '',
					'scriptName': '',
					'userEnteredAmt': {
						'value': 0,
						'ccy': 'SGD',
						'_isDeleted': false
					},
					'userEnteredPcnt': 0,
					'comments': '',
					'delete': false
				}
			],
			'feeCollectionAccount': '',
			'computedAmount': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			},
			'collectableAmountPcnt': 0,
			'collectableAmount': {
				'value': 0,
				'ccy': 'SGD',
				'_isDeleted': false
			}
		},
		'CollateralValueDetail': {
			'unitValueMethod': false,
			'directValueMethod': false,
			'netValueMethod': false,
			'derivedValueMethod': false,
			'itemBasedMethod': false,
			'customerDerivationMethod': false,
			'defaultValueMethod': false,
			'childCollateralMethod': false
		},
		'multiCcy': false,
		'collateralId': 'COLL2444',
		'collateralCode': 'code03',
		'generalDetail': {
			'collateralDesc': 'Lodgement for guarnt',
			'globalCollateral': false,
			'country': 'INDIA',
			'collateralClass': 'COLTRLCLS1',
			'collateralGroup': 'COLTRLGRP1',
			'collateralCreationDate': '2017-07-25T00:00:00.000Z',
			'collateralExpiryDate': '2018-06-08T12:33:43.707Z',
			'currencyCode': 'SGD',
			'BASELEligible': false,
			'collateralStatus': '',
			'applicationDetail': {
				'formNo': 'A2343223',
				'receivedDate': '2017-06-02T12:33:43.707Z',
				'reviewDate': '2017-06-02T12:33:43.707Z',
				'nextReviewDate': '2017-06-02T12:33:43.707Z',
				'signingDate': '2017-06-02T12:33:43.707Z',
				'executionDate': '2017-06-02T12:33:43.707Z'
			},
			'solicitorDetails': {
				'solicitorName': '',
				'approvedSolicitor': false,
				'addressLine1': '',
				'addressLine2': '',
				'addressLine3': '',
				'city': '',
				'state': '',
				'country': '',
				'postalCode': '',
				'phoneNo': '',
				'emailAddress': '',
				'telexNo': '',
				'faxNo': ''
			},
			'remarks': 'Deposit'
		},
		'collateralOwnerShipType': '',
		'withdrawalDetail': {
			'withdraw': false,
			'reasonCode': '',
			'withdrawalDate': '2017-06-02T12:33:43.707Z'
		},
		'_type': 'DEPOSCollateral',
		'_createdBy': 'cmsadmin',
		'_modifiedBy': 'cmsadmin',
		'_createdOn': '2017-07-25T04:38:12.284Z',
		'_modifiedOn': '2017-07-25T04:38:12.284Z',
		'scope': null,
		'_isDeleted': false,
		'_oldVersion': null,
		'_version': 'ed5d3761-3cc7-4e86-8963-b63686c83d18',
		'_requestId': null,
		'_newVersion': null
	}
];


export const MockCollateralPropertyData=[
	{
		'amount':12000,
		ccyType:'SGD'
}
]
export const MockOtherIntagibleData=[
	{
		'amount':890000,
		ccyType:'SGD'
}
]