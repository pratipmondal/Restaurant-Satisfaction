import { Component, OnInit } from '@angular/core';
import { CollateralSummaryService } from './collateral-summary.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import {
	MockCollateralPropertyData,
	MockCollateralsMasterInqData,
	MockOtherIntagibleData
} from './collateral-summary-mock-data';
import { CounterPartyDetailsService } from '../../common/counterparty-details/counterparty.service';
import { _ } from 'underscore';
import { CurrencyFormatPipe } from '../../shared/currency-pipe/currency-pipe';
@Component({
	selector: 'collateral-summary-component',
	templateUrl: './collateral-summary.component.html',
	styleUrls: ['./collateral-summary.component.scss']
})
export class CollateralSummaryComponent implements OnInit {
	public gridData: any[] = [];
	public listItems: any[] = ['Thousands', 'Millions', 'Units'];
	public currencyFormatValues: any[] = [];
	public total: any[] = [];
	public totalValue: number = 0;
	public mainAmountValues: any[] = [];
	public duplicateArrayForCurrency: any[];
	public collateralSummaryData: any[] = [];
	public currencyDividerValue: number = 1;
	// TODO get presentCurrencyFormat value from service Based on User login
	public presentCurrencyFormat: string = 'SGD';
	public presentCurrencyFormatIn: string = 'Units';
	public oldCurrencyFormatIn: string = 'Units';
	public tooltipTitle: string = 'Tooltip Title';
	public guaranteeTooltipTitle: string = 'Guarantee';
	public guaranteeTooltipDescription = 'Guarantee Description';
	cashTooltipTitle: string = 'Cash';
	cashTooltipContent: string = 'Cash Description';
	IntangibleTooltipTitle: string = 'Intangible';
	IntangibletooltipContent: string = 'Intangible Description';
	propertyTooltipTitle: string = 'Property';
	propertyTooltipContent: string = 'Property Description';
	public errorMsg: boolean = false;
	counterparty: any;
	collateralDataFromMastersInq: any;
	private guarnCollateralData: any;
	private deposCollateralData: any;
	public totalGuarnAmount: number = 0.00;
	public totalDeposAmount: number = 0.00;
	public sumOfGuarnDetails: any;
	public modifiedDeposCollateralData: any = [];
	public modifiedGuarnCollateralData: any = [];
	pipe: CurrencyFormatPipe = new CurrencyFormatPipe();
	public noCollateralFound: boolean = false;
	public totalPropertyCollateralData: number = 0.00;
	public totalOtherIntagibleData: number = 0.00;
	public otherCollateralData: any = [];
	public propertyCollateralData: any = [];
	public jsonDataForOtherCollateral: any = [];

	constructor(private collateralSummaryService: CollateralSummaryService, private router: Router, private counterPartyDetailsService: CounterPartyDetailsService) {
	}

	ngOnInit() {
		this.setUpCollateralSumamryComponent();
	}

	setUpCollateralSumamryComponent() {
		/*For Getting GCIN Value for searched Counterparty*/
		this.counterPartyDetailsService.subscribeToCPDetails({
			next: (value) => this.counterparty = value,
			error: (value) => this.returnError(value),
			complete: () => {
			}
		});

		/*GET collateral master data from GCIN Id*/
		/*TODO get Collateral master Data from API*/
		this.collateralDataFromMastersInq = MockCollateralsMasterInqData;
		this.initializeAmountValues();
		this.fetchCollateralDetails(this.collateralDataFromMastersInq);
		this.getCurrencyList();

	}

	initializeAmountValues() {
		this.initializeCollateralSummaryDetails();
	}

	initializeCollateralSummaryDetails() {
		this.mainAmountValues.push(
			{ key: 'GUARN', amount: this.totalGuarnAmount },
			{ key: 'Cash', amount: this.totalDeposAmount },
			{ key: 'Aircraft', amount: this.totalOtherIntagibleData },
			{ key: 'Property', amount: this.totalPropertyCollateralData }
		);
		this.duplicateArrayForCurrency = JSON.parse(JSON.stringify(this.mainAmountValues));
		this.total = this.currencyChangeFormatter(this.mainAmountValues, this.currencyDividerValue);
		this.otherCollateralData = MockOtherIntagibleData;
		this.jsonDataForOtherCollateral = MockOtherIntagibleData;
		this.propertyCollateralData = MockCollateralPropertyData;
		this.initialCurrencyConverter('Other', this.otherCollateralData);
		this.initialCurrencyConverter('Property', this.propertyCollateralData);
	}

	getCurrencyList() {
		this.collateralSummaryService.getCurrency().subscribe(data => {
			this.currencyFormatValues = data;
		}, error => {
			this.errorMsg = true;
			this.returnError(error);
		});
	}

	currencyChangeFormatter(currencyArray: any[], currencyDivider: any) {
		if (currencyArray !== undefined) {
			const currencyValueArray = currencyArray.map(function (obj) {
				const calculatedValue = { 'amount': (Math.abs(Number(obj.amount)) / (currencyDivider)) };
				return calculatedValue;
			});
			return currencyValueArray;
		}
	}

	selectionChangeFormat(amountFormat: any) {
		const duplicateArray = this.mainAmountValues;
		this.oldCurrencyFormatIn = this.presentCurrencyFormatIn;
		this.presentCurrencyFormatIn = amountFormat;
		if (this.presentCurrencyFormatIn === 'Millions') {
			this.currencyDividerValue = 1.0e+6;
			this.total = this.currencyChangeFormatter(duplicateArray, 1.0e+6);
		} else if (this.presentCurrencyFormatIn === 'Billions') {
			this.currencyDividerValue = 1.0e+9;
			this.total = this.currencyChangeFormatter(duplicateArray, 1.0e+9);
		} else if (this.presentCurrencyFormatIn === 'Units') {
			this.currencyDividerValue = 1;
			this.total = this.currencyChangeFormatter(duplicateArray, 1);
		} else if (this.presentCurrencyFormatIn === 'Thousands') {
			this.currencyDividerValue = 1.0e+3;
			this.total = this.currencyChangeFormatter(duplicateArray, 1.0e+3);
		}
	}

	selectionCurrencyChange(currencyForamt: any) {
		if (typeof currencyForamt !== 'object') {
			const selectedFormat = currencyForamt;
			const duplicateArray = this.mainAmountValues;
			const oldCurrencyFormat = this.presentCurrencyFormat;
			this.presentCurrencyFormat = selectedFormat;
			this.otherCollateralData = [];
			this.propertyCollateralData = [];
			this.propertyCollateralData = JSON.parse(JSON.stringify(MockCollateralPropertyData));
			this.otherCollateralData = JSON.parse(JSON.stringify(this.jsonDataForOtherCollateral));
			this.totalOtherIntagibleData = 0.00;
			this.totalPropertyCollateralData = 0.00;
			this.getCollateralArrayData('GUARN', this.collateralSummaryService.guarnCollateralDataFromService);
			this.getCollateralArrayData('DEPOS', this.collateralSummaryService.deposCollateralDataFromService);
			this.initialCurrencyConverter('Other', this.otherCollateralData);
			this.initialCurrencyConverter('Property', this.propertyCollateralData);
		}
	}

	redirectToNewCollateral() {
		this.collateralSummaryService.collateralOperation = 'ADD';
		this.router.navigate(['/newcollateral']);
	}

	redirectToViewCollaterals() {
		this.router.navigate(['/viewcollaterals']);
	}

	private returnError(error: any) {
		if (error.status === 500) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 400) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 409) {
			return Observable.throw(new Error(error.status));
		} else if (error.status === 404) {
			return Observable.throw(new Error(error.status));
		}
	}

	fetchCollateralDetails(collateralsMasterData) {
		collateralsMasterData = _.groupBy(collateralsMasterData, function (obj) {
			return obj.collateralType;
		});
		if (collateralsMasterData['GUARN']) {
			const collateralIds = _.map(collateralsMasterData['GUARN'], function (element, index, list) {
				return element.collateralId;
			});
			// const filter = { where: { collateralId: { inq: collateralIds } } };
			const filter = { limit: 10, order: '_createdOn desc' };

			this.collateralSummaryService.getCollateralsList('GUARN', filter).subscribe(data => {
				this.guarnCollateralData = data;
				this.collateralSummaryService.guarnCollateralDataFromService = this.guarnCollateralData;
				this.getCollateralArrayData('GUARN', this.guarnCollateralData);
			}, error => {
				this.returnError(error);
			}
			);
		}
		if (collateralsMasterData['DEPOS']) {
			const collateralIds = _.map(collateralsMasterData['DEPOS'], function (element, index, list) {
				return element.collateralId;
			});

			// const filter = { where: { collateralId: { inq: collateralIds } } };

			const filter = { limit: 10, order: '_createdOn desc' };

			this.collateralSummaryService.getCollateralsList('DEPOS', filter).subscribe(data => {
				this.deposCollateralData = data;
				this.collateralSummaryService.deposCollateralDataFromService = this.deposCollateralData;
				this.getCollateralArrayData('DEPOS', this.deposCollateralData);
				if (((this.deposCollateralData.length === 0) && (this.guarnCollateralData.length === 0)) || ((this.deposCollateralData.length === undefined) && (this.guarnCollateralData.length === undefined))) {
					this.noCollateralFound = true;
				}
			},
				error => {
					this.returnError(error);
				}
			);
		}
	}

	getCollateralArrayData(type: any, collateralArray: any) {
		this.totalGuarnAmount = 0.00;
		this.totalDeposAmount = 0.00;
		this.totalOtherIntagibleData = 0.00;
		this.totalPropertyCollateralData = 0.00;
		const collateralJson = collateralArray;
		this.modifiedGuarnCollateralData = [];
		this.modifiedDeposCollateralData = [];
		if (type === 'GUARN') {
			collateralJson.forEach(element => {
				const calculateAmountValues = element['CollateralValuationDetail']['collateralValue'];
				this.modifiedGuarnCollateralData.push({
					amount: calculateAmountValues['value'],
					ccyType: calculateAmountValues['ccy']
				});
			});
			this.initialCurrencyConverter(type, this.modifiedGuarnCollateralData);
		}
		if (type === 'DEPOS') {
			collateralJson.forEach(element => {
				const calculateAmountValuesForDepos = element['CollateralValuationDetail']['collateralValue'];
				this.modifiedDeposCollateralData.push({
					amount: calculateAmountValuesForDepos['value'],
					ccyType: calculateAmountValuesForDepos['ccy']
				});
			});
			this.initialCurrencyConverter(type, this.modifiedDeposCollateralData);
		}

	}

	initialCurrencyConverter(type: any, collateralJson: any) {
		this.sumOfGuarnDetails = collateralJson.map(item => {
			if (item['ccyType'] !== this.presentCurrencyFormat) {
				if (this.collateralSummaryService.rateConversionArray.length > 0) {
					const indexOfRate = this.collateralSummaryService.rateConversionArray.findIndex(data => data.from === item['ccyType'] && data.to === this.presentCurrencyFormat);
					if (indexOfRate !== undefined && (indexOfRate !== -1)) {
						item['amount'] = ((item['amount'] * (this.collateralSummaryService.rateConversionArray[indexOfRate]['rate'])));
						this.sumOfAmountValues(type, item);
					} else {
						this.getCurrencyRatesForItemValues(type, item);
					}
				} else {
					this.getCurrencyRatesForItemValues(type, item);
				}
			} else {
				this.sumOfAmountValues(type, item);
			}
			return item;
		}, this);
	}

	sumOfAmountValues(type: any, jsonData: any) {
		if (type === 'GUARN') {
			if (jsonData['amount'] !== undefined) {
				this.totalGuarnAmount += jsonData['amount'];
				if (this.totalGuarnAmount !== undefined) {
					this.total[0]['amount'] = ((this.totalGuarnAmount) / (this.currencyDividerValue));
					this.mainAmountValues[0]['amount'] = this.totalGuarnAmount;
					this.duplicateArrayForCurrency[0]['amount'] = this.totalGuarnAmount;
				}
			}
		}
		if (type === 'DEPOS') {
			if (jsonData['amount'] !== undefined) {
				this.totalDeposAmount += jsonData['amount'];
				if (this.totalDeposAmount !== undefined) {
					this.total[1]['amount'] = ((this.totalDeposAmount) / (this.currencyDividerValue));
					this.mainAmountValues[1]['amount'] = this.totalDeposAmount;
					this.duplicateArrayForCurrency[1]['amount'] = this.totalDeposAmount;
				}

			}
		}
		if (type === 'Other') {
			if (jsonData['amount'] !== undefined) {
				this.totalOtherIntagibleData += jsonData['amount'];
				if (this.totalOtherIntagibleData !== undefined) {
					this.total[2]['amount'] = ((this.totalOtherIntagibleData) / (this.currencyDividerValue));
					this.mainAmountValues[2]['amount'] = this.totalOtherIntagibleData;
					this.duplicateArrayForCurrency[2]['amount'] = this.totalOtherIntagibleData;
				}

			}
		}
		if (type === 'Property') {
			if (jsonData['amount'] !== undefined) {
				this.totalPropertyCollateralData += jsonData['amount'];
				if (this.totalPropertyCollateralData !== undefined) {
					this.total[3]['amount'] = ((this.totalPropertyCollateralData) / (this.currencyDividerValue));
					this.mainAmountValues[3]['amount'] = this.totalPropertyCollateralData;
					this.duplicateArrayForCurrency[3]['amount'] = this.totalPropertyCollateralData;
				}

			}
		}
	}

	getCurrencyRatesForItemValues(type: any, item: any) {
		this.collateralSummaryService.getRateValues(item['ccyType'], this.presentCurrencyFormat).subscribe(data => {
			if (data.length > 0) {
				const rate: any = data[0]['rate'];
				if (rate !== undefined) {
					item['amount'] = ((item['amount'] * (rate)));
					this.sumOfAmountValues(type, item);
					this.collateralSummaryService.rateConversionArray.push({
						from: item['ccyType'],
						to: this.presentCurrencyFormat,
						rate: rate
					});
				}
			}
		}, error => {
			this.errorMsg = true;
			this.returnError(error);
		});
	}
}
