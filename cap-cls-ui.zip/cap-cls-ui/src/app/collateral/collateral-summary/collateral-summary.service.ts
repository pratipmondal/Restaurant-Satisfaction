import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { _ } from 'underscore';

@Injectable()
export class CollateralSummaryService {
	public ratesUrl = environment.apiBaseUrl + environment.apiToGetRates;
	public currencyUrl = environment.apiBaseUrl + environment.apiToGetCurrencyList;
	/*TODO Change the service name*/
	public collateralmMsterDataUrl: string = environment.apiBaseUrl + 'mock-master';
	guarnCollateralDataFromService: any;
	deposCollateralDataFromService: any;
	selectedCollateral: any;
	selectedCollateralType: any;
	collateralTypes: any;
	collateralOperation: string = 'ADD';
	public rateConversionArray: any = [];

	constructor(private http: Http) {
		this.rateConversionArray = [];
	}

	public getCurrency(): Observable<any> {
		return this.http.get(this.currencyUrl)
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}

	getRateValues(fromCurreny: string, toCurrency: string): Observable<any> {
		const params: URLSearchParams = new URLSearchParams();
		const filter = '{"where":{"fromCurrency": "' + fromCurreny + '","toCurrency": "' + toCurrency + '"}}';
		params.set('filter', filter);
		return this.http.get(this.ratesUrl, { search: params })
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}

	public getCollateralDataFromMasters(gcinId: string): Observable<any> {
		/*TODO Append GCID to the URL*/
		return this.http.get(this.collateralmMsterDataUrl)
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}

	getCollateralsList(collateralType: string, filter?: any): Observable<any> {
		let collateralApi;
		switch (collateralType) {
			case 'GUARN':
				collateralApi = environment.apiGuarnCollaterals;
				break;
			case 'DEPOS':
				collateralApi = environment.apiDeposCollaterals;
				break;
			default:
				return Observable.throw('Invalid Collateral Type');
		}

		const params: URLSearchParams = new URLSearchParams();

		if (filter) {
			params.set('filter', JSON.stringify(filter));
		}
		return this.http.get(environment.apiBaseUrl + collateralApi, { search: params })
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.handleError(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}
	private extractData(res: Response) {
		const body = res.json();
		return body;
	}
	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}

}
