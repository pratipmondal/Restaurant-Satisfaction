import { TestBed, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { BeneficiaryService } from '../../../../src/app/collateral/beneficiary/beneficiary.component.service';
import { BeneficiaryIdList } from './beneficiary.data';
import { environment } from '../../../environments/environment';

class MockBeneficiaryService {

	getBeneficiaryIdDataService(data) {
		return Observable.of(BeneficiaryIdList);
	}

	addBeneficiary(data) {
		return Observable.of(BeneficiaryIdList);
	}
}

describe('BeneficiaryService', () => {
    let beneficiaryService: BeneficiaryService;
    let mockBackend: MockBackend;
    const urlToGetBeneficiaryID = environment.apiBaseUrl + environment.apiToGetCifId;
    const urlToAddBeneficiary = environment.apiBaseUrl + environment.apiCollateralCustomer;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                {provide: BeneficiaryService, useClass: MockBeneficiaryService}
            ],
            imports: [HttpModule]
        });
    });

	beforeEach(
		inject([BeneficiaryService, MockBackend], (service: BeneficiaryService, backend: MockBackend) => {
			beneficiaryService = service;
			mockBackend = backend;
		})
	);
	it('Beneficiary service should be defined', () => {
		expect(beneficiaryService).toBeDefined();
	});
	it('should call getBeneficiaryIdDataService API from service', () => {
		const filterData = 'GCIN';
		spyOn(beneficiaryService, 'getBeneficiaryIdDataService').and.callFake(function ({'searchKeyword': filterData}) {
			return BeneficiaryIdList;
		});
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Post);
			expect(connection.request.url).toBe(urlToGetBeneficiaryID);
		});
		expect(beneficiaryService.getBeneficiaryIdDataService({'searchKeyword': 'GCIN'})).toEqual(BeneficiaryIdList);
	});
	it('should add beneficiary Details from service', () => {
		const beneficiaryData = {
			'beneficiaryName': '16R2A GCIN4NF CN002 ',
			'beneficiaryIdType': 'COUNTERPARTY1',
			'beneficiaryId': 'GC0001045990',
			'beneficiaryDescription': '16R2A GCIN4NF CN002 (GC0001045990)'
		};
		spyOn(beneficiaryService, 'addBeneficiary').and.callFake(function (beneficiaryData) {
			return 'successful';
		});
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Post);
			expect(connection.request.url).toBe(urlToAddBeneficiary);
		});
		// work on progress f
		// expect(beneficiaryService.addBeneficiary(beneficiaryData)).toEqual('successful');
	});

});