import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { BeneficiaryList } from '../model/collateral';
import { BeneficiaryService } from './beneficiary.component.service';
import { CollateralService } from '../collateral.service';
import { ErrorResponse } from '../../shared';
import { ToastsComponent } from '../../shared/toasts/toasts.component';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { BeneficiaryIdList, beneficiaryLimitData, BeneficiaryRankJson } from './beneficiary.data';

@Component({
	selector: 'collateral-beneficiary',
	templateUrl: './beneficiary.component.html',
	styleUrls: ['./beneficiary.component.scss']
})
export class BeneficiaryComponent implements OnInit {
	public beneficiaryGridData: any[] = [];
	successMsg: boolean = false;
	errMsg: boolean = false;
	errorMessage: string;
	showLoader = false;
	errorResponse: ErrorResponse = null;
	public beneficiaryAddDialogBox: boolean = false;
	beneficiaryIdInvalid: boolean = false;
	beneficiaryRankInvalid: boolean = false;
	beneficiaryCapAmountInvalid: boolean = false;
	public events: any[] = [];
	public AddBeneficiaryForm: FormGroup;
	divForNormalGrid: boolean = true;
	public saveData: boolean = true;
	public showPopupDialog: boolean = false;
	public dialogTitleName: string = 'Add Beneficiary Details';
	noRecordsFlag: boolean = true;
	public counterPartyDetails: any;
	public rowIndex: number;
	public idList = [];
	argToastSelfTimeout: number;
	public duplicateValueErrDiv: boolean = false;
	argToastMessageObject: any;
	private divForServiceError: boolean;
	beneficiaryRankList: any;
	beneficiaryRankResponse: any = [];
	toastsComponent: ToastsComponent = new ToastsComponent();
	duplicateValueCheck: any;
	beneficiaryLinkageData: any = [];
	keyArrayFromLimit: string[] = [];
	@Input() iscollapsible: boolean;
	@Input() public beneficiaryForm: FormGroup;
	@Input() showAddBeneficiaryBtn: boolean = true;
	@Input() showSummaryGrid: boolean = false;

	constructor(private _fb: FormBuilder, private http: Http, private router: Router, private beneficiaryservice: BeneficiaryService, private collateralService: CollateralService) {
	}

	ngOnInit() {
		this.setUpBeneficiaryComponent();
	}

	setUpBeneficiaryComponent() {
		this.divForNormalGrid = !this.showSummaryGrid;
		this.getBeneficiaryListDetails();
		this.processFormItems();
		this.initialiseBeneficiaryForm();
		this.getBeneficiaryRank();
		this.getLimitDataForBeneficiary();
	}

	private getBeneficiaryListDetails() {
		if (this.collateralService.getCollateral().LodgeBeneficiaryDetail.beneficiaryList) {
			this.beneficiaryGridData = this.collateralService.getCollateral().LodgeBeneficiaryDetail.beneficiaryList;
		}
	}

	private initialiseBeneficiaryForm() {
		this.AddBeneficiaryForm = this._fb.group({
			beneficiaryId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryIdType: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryName: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryDescription: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryRankToShow: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryRankToSubmit: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryCapAmount: ['', [<any>Validators.required, <any>Validators.required]],
			beneficiaryCapAmountType: ['', [<any>Validators.required, <any>Validators.required]]
		});
	}

	getBeneficiaryRank() {
		this.beneficiaryservice.getBeneficiaryRankService().subscribe(
			response => {
				this.divForServiceError = false;
				this.beneficiaryRankList = BeneficiaryRankJson;
				this.beneficiaryRankResponse = this.formChargeRanksForGridDisplay(BeneficiaryRankJson);
			},
			error => {
				this.divForServiceError = true;
			},
			() => {
				this.divForServiceError = false;
			}
		);
	}

	getLimitDataForBeneficiary() {
		if (this.collateralService.getLimitData()) {
			this.beneficiaryLinkageData = this.collateralService.getLimitData();
		}
	}

	cancelForm() {
		this.duplicateValueErrDiv = false;
		this.showPopupDialog = false;
		this.saveData = true;
		this.AddBeneficiaryForm.reset();
		this.validationReset();
	}

	addBeneficiary() {
		this.dialogTitleName = 'Add Beneficiary Details';
		this.showPopupDialog = true;
		this.validationReset();
	}

	addBeneficiaryData(data: any) {
		this.validationReset();
		const flagValue = this.validaionCheck(data);
		if (flagValue === true && this.beneficiaryCapAmountInvalid === false && this.beneficiaryRankInvalid === false) {
			const dataObj = this.beneficiaryGridData.find(item => item.beneficiaryId === data.beneficiaryId);
			if (!(dataObj === undefined)) {
				this.duplicateValueErrDiv = true;
			} else {
				this.updateGridValueFunction(data, 'ADD');
			}
		}
	}

	beneficiaryEditFunc(item: BeneficiaryList, index: number): void {
		this.validationReset();
		this.dialogTitleName = 'Update Beneficiary';
		this.rowIndex = index;
		this.searchByGCINCIF(item.beneficiaryId);
		setTimeout(() => this.dataForEdit(item), 1000);
	}

	private dataForEdit(item: any) {
		this.saveData = false;
		this.showPopupDialog = true;
		if (this.idList !== undefined) {
			this.AddBeneficiaryForm = this._fb.group({
				beneficiaryId: [this.idList[0].gcin, [<any>Validators.required, <any>Validators.minLength(0)]],
				beneficiaryIdType: [this.idList[0].type, [<any>Validators.required, <any>Validators.minLength(0)]],
				beneficiaryName: [item.beneficiaryName, [<any>Validators.required, <any>Validators.minLength(0)]],
				beneficiaryDescription: [this.idList[0].description, [<any>Validators.required, <any>Validators.minLength(0)]],
				beneficiaryRankToShow: [this.beneficiaryRankResponse[item.rank], [<any>Validators.required, <any>Validators.minLength(0)]],
				beneficiaryRankToSubmit: [item.rank, [<any>Validators.required, <any>Validators.minLength(0)]],
				beneficiaryCapAmount: [item.capAmount, [<any>Validators.required, <any>Validators.required]],
				beneficiaryCapAmountType: [item.capAmountType, [<any>Validators.required, <any>Validators.required]]
			});
			this.duplicateValueCheck = this.AddBeneficiaryForm.value;
		}
	}

	updateBeneficiaryGridList(data: any) {
		this.validationReset();
		const flagValue = this.validaionCheck(data);
		if (flagValue === true) {
			if (JSON.stringify(this.duplicateValueCheck) === JSON.stringify(data)) {
				this.duplicateValueErrDiv = true;
			} else {
				if (this.duplicateValueCheck.beneficiaryId !== data.beneficiaryId) {
					const dataObj = this.beneficiaryGridData.find(item => item.beneficiaryId === data.beneficiaryId);
					if (!(dataObj === undefined)) {
						this.duplicateValueErrDiv = true;
					} else {
						this.saveData = true;
						this.updateGridValueFunction(data, 'UPDATE');
					}
				} else {
					this.saveData = true;
					this.updateGridValueFunction(data, 'UPDATE');
				}
			}
		}
	}

	private updateGridValueFunction(data: any, flag: string) {
		this.duplicateValueErrDiv = false;
		this.AddBeneficiaryForm.reset();
		this.showPopupDialog = false;
		const tempBeneficiaryItem = new BeneficiaryList();
		tempBeneficiaryItem.beneficiaryId = data.beneficiaryId;
		tempBeneficiaryItem.beneficiaryIdType = data.beneficiaryIdType;
		tempBeneficiaryItem.beneficiaryName = data.beneficiaryName;
		if (data.beneficiaryRankToSubmit === null) {
			tempBeneficiaryItem.rank = '';
		} else {
			tempBeneficiaryItem.rank = data.beneficiaryRankToSubmit;
		}
		if (isNaN(parseFloat(data.beneficiaryCapAmount))) {
			tempBeneficiaryItem.capAmount = 0.0;
		} else {
			tempBeneficiaryItem.capAmount = parseFloat(data.beneficiaryCapAmount);
		}
		tempBeneficiaryItem.capAmountType = data.beneficiaryCapAmountType;
		let toastMsg: string;
		if (flag === 'ADD') {
			this.beneficiaryGridData.push(tempBeneficiaryItem);
			this.beneficiaryservice.addBeneficiary(tempBeneficiaryItem).subscribe(data => {
			}, error => {
				this.errorResponse = <ErrorResponse>error;
			});
			toastMsg = 'A new record of beneficiary details has been successfully added.';
		} else if (flag === 'UPDATE') {
			this.beneficiaryGridData[this.rowIndex] = tempBeneficiaryItem;
			toastMsg = 'A record of beneficiary details has been successfully updated.';
		}
		this.beneficiaryForm.get('beneficiaryList').setValue(this.beneficiaryGridData);
		this.processFormItems();
		this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success', toastMsg, '', '');
	}

	beneficiaryRemoveItemFunc(itemIndex: number) {
		delete this.collateralService.limitDataBeneficiary[this.beneficiaryGridData[itemIndex].beneficiaryId];
		this.beneficiaryGridData.splice(itemIndex, 1);
		this.processFormItems();

		this.beneficiaryForm.controls['beneficiaryList'].setValue(this.beneficiaryGridData);

		this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
			'A record of beneficiary details has been successfully deleted.',
			'', '');
	}

	closeEventFromPopupDialog(showPopupDialog: boolean) {
		this.duplicateValueErrDiv = false;
		this.showPopupDialog = showPopupDialog;
		this.saveData = true;
		this.AddBeneficiaryForm.reset();
		this.validationReset();
	}

	searchByGCINCIF(searchValue: string) {
		const bodyData = {'searchKeyword': searchValue};
		if (searchValue.length > 2) {
			this.idList = [];
			this.showLoader = true;
			this.beneficiaryservice.getBeneficiaryIdDataService(bodyData).subscribe(
				response => {
					this.successMsg = true;
					this.errMsg = false;
					this.idList = response.map(function (item) {
						return ({
							'gcin': item.gcin,
							'description': item.gcin + '   ' + this.modifiedNameFunc(item.description, item.gcin),
							'type': item.type,
							'name': this.modifiedNameFunc(item.description, item.gcin)
						});

					}, this);
				},
				error => {
					this.showLoader = false;
					this.successMsg = false;
					this.errMsg = true;
					/*  FOR MOCKING DATA WHEN SERVICE IS NOT AVAILIBLE */
					// this.idList = BeneficiaryIdList.map(function (item) {
					// 	return ({
					// 		'gcin': item.gcin,
					// 		'description': item.gcin + '   ' + this.modifiedNameFunc(item.description, item.gcin),
					// 		'type': item.type,
					// 		'name': this.modifiedNameFunc(item.description, item.gcin)
					// 	});

					// }, this);
					this.errorMessage = 'Oops! something went wrong.    ' + error._body;
				},
				() => {
				}
			);
		}
	}

	onSearchGCIDCIFSelect(event) {
		const dataObj = this.idList.find(item => item.description === this.AddBeneficiaryForm.value.beneficiaryDescription);
		if (!(dataObj === undefined)) {
			this.beneficiaryIdInvalid = false;
			// const modifiedName = this.modifiedNameFunc(dataObj.description, dataObj.gcin);
			this.AddBeneficiaryForm.controls['beneficiaryId'].setValue(dataObj.gcin);
			this.AddBeneficiaryForm.controls['beneficiaryName'].setValue(dataObj.name);
			this.AddBeneficiaryForm.controls['beneficiaryIdType'].setValue(dataObj.type);
		} else {
			this.beneficiaryIdInvalid = true;
		}
	}

	addBeneficiaryClickedInNoData(e: Event) {
		this.addBeneficiary();
	}

	private processFormItems() {
		if (this.beneficiaryGridData.length > 0) {
			this.noRecordsFlag = false;
		} else {
			this.noRecordsFlag = true;
		}
	}

	private validationReset() {
		this.beneficiaryIdInvalid = false;
		this.beneficiaryRankInvalid = false;
		this.beneficiaryCapAmountInvalid = false;
	}

	private validaionCheck(data?: any) {
		let valid = false;
		const dataObj = this.idList.find(item => item.description === data.beneficiaryDescription);
		if (((data.beneficiaryDescription === '') || (data.beneficiaryDescription === null)) || (dataObj === undefined)) {
			this.beneficiaryIdInvalid = true;
			this.duplicateValueErrDiv = false;
			valid = false;
		} else {
			this.beneficiaryIdInvalid = false;
			valid = true;
		}
		if (data.beneficiaryRankToShow) {
			this.onRankSelect(data.beneficiaryRankToShow);
		}
		return valid;
	}

	private modifiedNameFunc(description: string, gcin: string): string {
		let tempName = description.replace(gcin, '');
		tempName = tempName.replace('()', '');
		return tempName;
	}

	formChargeRanksForGridDisplay(response: any) {
		const chargeRanksArray = [];
		if (response) {
			response.forEach(item => chargeRanksArray.push(item.rankDesc));
		}
		return chargeRanksArray;
	}

	onRankSelect(selectedRank: string) {
		const i = this.beneficiaryRankList.find(item => item.rankDesc === selectedRank);
		if (((i !== '') || (i !== null)) && (i !== undefined)) {
			this.beneficiaryRankInvalid = false;
			this.AddBeneficiaryForm.controls['beneficiaryRankToSubmit'].setValue(i.rank);
		} else {
			this.beneficiaryRankInvalid = true;
		}
	}

	rankValidation(rankInput: string) {
		if (rankInput === '') {
			this.beneficiaryRankInvalid = false;
		}
	}

	getLinkage(data: any) {
		const navigationExtras: NavigationExtras = {
			queryParams: {'gcinLabel': data.beneficiaryName, 'gcinValue': data.beneficiaryId}
		};
		this.router.navigate(['./facilityLinkage'], navigationExtras);
	}

}
