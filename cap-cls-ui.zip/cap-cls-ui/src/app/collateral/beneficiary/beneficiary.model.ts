export class BeneficiaryItemModel {
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    beneficiaryId: string;
    beneficiaryIdType: string;
    beneficiaryName: string;
    cifId: string;
    city: string;
    country: string;
    delete: boolean;
    emailAddress: string;
    faxNo: number;
    phoneNo: number;
    postalCode: number;
    state: string;
    telexNo: string;

    constructor() {
    this.addressLine1 = '';
    this.addressLine2 = '';
    this.addressLine3 = '';
    this.beneficiaryId = '';
    this.beneficiaryIdType = '';
    this.beneficiaryName = '';
    this.cifId = '';
    this.city = '';
    this.country = '';
    this.delete = false;
    this.emailAddress = '';
    this.faxNo = 0;
    this.phoneNo = 0;
    this.postalCode = 0;
    this.state = '';
    this.telexNo = '';
    }
}
