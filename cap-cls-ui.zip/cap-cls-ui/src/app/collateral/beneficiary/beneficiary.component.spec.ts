import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CollateralService } from '../collateral.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Collateral } from '../../collateral/model/collateral';
import { Observable } from 'rxjs/Rx';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { IntlModule } from '@progress/kendo-angular-intl';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { BeneficiaryComponent } from './beneficiary.component';
import { BeneficiaryService } from './beneficiary.component.service';
import {
	BeneficiaryListResponse,
	BeneficiaryIdList,
	BeneficiaryRankList,
	BeneficiaryRankJson,
	BeneficiaryIdModifiedList, beneficiaryLimitData
} from './beneficiary.data';
import { BeneficiaryList, LodgeBeneficiaryDetail } from '../model/collateral';
import { Router, NavigationExtras } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

class MockBeneficiaryService {
	getBeneficiaryIdDataService(data: any) {
		if (data.searchKeyword.length > 3) {
			return Observable.of(BeneficiaryIdModifiedList);
		} else {
			return Observable.throw({status: 404});
		}
	}

	getBeneficiaryEmptyList() {
		return [];
	}

	getBeneficiaryRankService() {
		return Observable.of(BeneficiaryRankJson);
	}

	getBeneficiaryList(data: any) {
		const mockBeneficiaryListItem = new BeneficiaryList();
		mockBeneficiaryListItem.beneficiaryId = data.beneficiaryId;
		mockBeneficiaryListItem.beneficiaryIdType = data.beneficiaryIdType;
		mockBeneficiaryListItem.beneficiaryName = data.beneficiaryName;
		return mockBeneficiaryListItem;
	}

	getMockBeneficiaryIdList(data: any) {
		return data;
	}

	addBeneficiary(data: BeneficiaryList) {
		const sampleObj = {};
		return Observable.of(sampleObj);
	}
}

class MockCollateralService {
	limitDataBeneficiary = beneficiaryLimitData;

	getLimitData() {
		return beneficiaryLimitData;
	}
	getCollateral() {
		const mockCollateral = new Collateral();
		const mockBeneficiaryListItem = new BeneficiaryList();
		mockBeneficiaryListItem.beneficiaryId = 'GC0001045990';
		mockBeneficiaryListItem.beneficiaryIdType = 'COUNTERPARTY1';
		mockBeneficiaryListItem.beneficiaryName = '16R2A GCIN4NF CN002 ';
		mockCollateral.LodgeBeneficiaryDetail.beneficiaryList.push(mockBeneficiaryListItem);
		return new Collateral();
	}

	getCounterParty(): Object {
		const item = new Object({beneficiaryName: 'hh', beneficiaryId: 'GCIN000'});

		return item;
	}
}
class MockFormBuilder extends FormBuilder {
	getBlankForm() {
		const formBuilder = new FormBuilder;
		const formGroup = formBuilder.group({
			beneficiaryId: ['', [Validators.required]],
			beneficiaryIdType: ['', [Validators.required]],
			beneficiaryName: ['', [Validators.required]],
			beneficiaryDescription: ['', [Validators.required]],
			beneficiaryRankToShow: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryRankToSubmit: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryCapAmount: ['', [<any>Validators.required, <any>Validators.required]],
			beneficiaryCapAmountType: ['', [<any>Validators.required, <any>Validators.required]]
		});
		return formGroup;
	}

	getAddForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			beneficiaryDescription: ['GC0001045992   16R2A GCIN4NF CN006 ', [Validators.required]],
			beneficiaryIdType: ['COUNTERPARTY', [Validators.required]],
			beneficiaryName: ['16R2A GCIN4NF CN006 ', [Validators.required]],
			beneficiaryId: ['GC0001045992', [Validators.required]],
			beneficiaryRankToShow: ['1DBS', [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryRankToSubmit: [0, [<any>Validators.required, <any>Validators.minLength(0)]],
			beneficiaryCapAmount: ['', [<any>Validators.required, <any>Validators.required]],
			beneficiaryCapAmountType: ['', [<any>Validators.required, <any>Validators.required]]
		});
		return formGroup;
	}

	getMainForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			beneficiaryList: ['', [Validators.required]]
		});
		return formGroup;
	}

	setMainForm(data: any) {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			beneficiaryList: [data, [Validators.required]]
		});
		return formGroup;
	}
}
describe('Beneficiary Component test cases', () => {
	let component: BeneficiaryComponent;
	let fixture: ComponentFixture<BeneficiaryComponent>;
	const beneficiaryData = {
		'beneficiaryName': '16R2A GCIN4NF CN002 ',
		'beneficiaryIdType': 'COUNTERPARTY1',
		'beneficiaryId': 'GC0001045990',
		'beneficiaryDescription': 'GC0001045990   16R2A GCIN4NF CN002 ',
		'beneficiaryRankToShow': '1DBS',
		'beneficiaryRankToSubmit': 0,
		'beneficiaryCapAmount': '',
		'beneficiaryCapAmountType': ''
	};
	const router = {
		navigate: jasmine.createSpy('navigate')
	};
	const mockbeneficiaryIdList = BeneficiaryIdModifiedList;
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				CommonModule,
				BrowserModule, FormsModule, ReactiveFormsModule,
				ButtonsModule, BrowserAnimationsModule,
				LoaderModule, GridModule, ClsSharedCommonModule, DateInputsModule, IntlModule, AutoCompleteModule
				, PopupDialogModule, CommonUIModule, RouterTestingModule
			],
			declarations: [BeneficiaryComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [{provide: CollateralService, useClass: MockCollateralService},
				{provide: BeneficiaryService, useClass: MockBeneficiaryService},
				{provide: Router, useValue: router},
				{provide: FormBuilder, useClass: MockFormBuilder}, BeneficiaryList
			]
		})
			.compileComponents();
	}));
	beforeEach(() => {
		fixture = TestBed.createComponent(BeneficiaryComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create Beneficiary Component',
		async(() => {
			fixture.detectChanges();
			expect(component).toBeTruthy();
		}));
	it('Should show normalgrid on init',
		async(() => {
			component.divForNormalGrid = true;
			component.showSummaryGrid = false;
			expect(component.divForNormalGrid).toBe(true);
			component.setUpBeneficiaryComponent();
			if (component.showSummaryGrid) {
				expect(component.divForNormalGrid).toBe(false);
			} else {
				expect(component.divForNormalGrid).toBe(true);
			}
		}));
	it('should show no-record-component-found when no data from service',
		async(() => {
			const mockBeneficiaryService: MockBeneficiaryService = new MockBeneficiaryService();
			component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryEmptyList());
			component.setUpBeneficiaryComponent();
			expect(component.noRecordsFlag).toBe(true);
		}));
	it('should not show no-record-component-found when data will come from service',
		async(() => {
			const mockFormBuilder = new MockFormBuilder();
			let collateralService: CollateralService;
			collateralService = TestBed.get(CollateralService);
			const collateral: Collateral = new Collateral;
			const lodgeBeneficiaryDetails: LodgeBeneficiaryDetail = new LodgeBeneficiaryDetail;
			const mockBeneficiaryService = new MockBeneficiaryService();
			lodgeBeneficiaryDetails.beneficiaryList = [mockBeneficiaryService.getBeneficiaryList(beneficiaryData)];
			collateral.LodgeBeneficiaryDetail = lodgeBeneficiaryDetails;
			spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
			component.setUpBeneficiaryComponent();
			expect(component.noRecordsFlag).toBe(false);
		}));
	it('PopDialog should be disabled',
		async(() => {
			expect(component.showPopupDialog).toBe(false);
		}));

	it('Conterparty details add to grid on load of component init',
		async(() => {
			fixture.detectChanges();
			const collateralMockservice = new MockCollateralService();
			component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
			expect(component.beneficiaryGridData.length).toBe(1);
		}));
	it('PopDialog box should open onclick of ADD Beneficiary button',
		async(() => {
			fixture.detectChanges();
			component.showPopupDialog = false;
			component.addBeneficiary();
			expect(component.showPopupDialog).toBe(true);
		}));
	it('Beneficiary form should be defined onclick of ADD Beneficiary button',
		async(() => {
			fixture.detectChanges();
			const mockForm = new MockFormBuilder();
			component.AddBeneficiaryForm = mockForm.getBlankForm();
			component.showPopupDialog = false;
			component.addBeneficiary();
			expect(component.AddBeneficiaryForm).toBeDefined();
		}));
	it('Data should add to grid on click of save button',
		async(() => {
			fixture.detectChanges();
			expect(component.beneficiaryGridData.length).toBe(0);
			component.showPopupDialog = false;
			component.AddBeneficiaryForm = null;
			component.addBeneficiary();
			const mockForm = new MockFormBuilder();
			component.AddBeneficiaryForm = mockForm.getAddForm();
			component.beneficiaryForm = mockForm.getMainForm();
			const mockBeneficiaryService: MockBeneficiaryService = new MockBeneficiaryService();
			component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
			component.beneficiaryRankList = BeneficiaryRankJson;
			component.beneficiaryRankResponse = BeneficiaryRankList;
			component.addBeneficiaryData(beneficiaryData);
			expect(component.beneficiaryGridData.length).toBeGreaterThan(0);
		}));
	it('PopDialog box should be close onclick of Cancel button',
		async(() => {
			fixture.detectChanges();
			component.showPopupDialog = true;
			component.cancelForm();
			expect(component.showPopupDialog).toBe(false);
		}));
	it('PopDialog box should be close  onclick of close  button',
		async(() => {
			fixture.detectChanges();
			component.showPopupDialog = true;
			component.closeEventFromPopupDialog(false);
			expect(component.showPopupDialog).toBe(false);
		}));
	it('Data should display in grid when beneficiary component loaded', async(() => {
		fixture.detectChanges();
		component.beneficiaryGridData = BeneficiaryListResponse;
		expect(component.beneficiaryGridData).toBe(BeneficiaryListResponse);
	}));
	it('Data should get from backend when something is entered in beneficiary id field',
		async(() => {
			fixture.detectChanges();
			component.idList = [];
			expect(component.idList.length).toBe(0);
			component.searchByGCINCIF('gcin');
			expect(component.idList.length).toBeGreaterThan(0);
		}));
	it('Error should get from backend when something wrong is entered in beneficiary id field',
		async(() => {
			fixture.detectChanges();
			component.idList = [];
			expect(component.idList.length).toBe(0);
			component.searchByGCINCIF('gfx');
			expect(component.errMsg).toBe(true);
		}));
	it('Data should get rank list from api when component will create',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryRankResponse = {};
			component.getBeneficiaryRank();
			expect(component.beneficiaryRankResponse[0]).toBe(BeneficiaryRankList[0]);
		}));
	it('value in beneficiary type will be set when beneficiary description value selected ',
		async(() => {
			fixture.detectChanges();
			component.idList = [];
			expect(component.idList.length).toBe(0);
			const mockForm = new MockFormBuilder();
			component.AddBeneficiaryForm = mockForm.getBlankForm();
			const mockBeneficiaryService = new MockBeneficiaryService();
			component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
			component.AddBeneficiaryForm.controls['beneficiaryDescription'].setValue('GC0001045995   16R2A GCIN4NF CN010 ');
			component.onSearchGCIDCIFSelect('GC0001045995   16R2A GCIN4NF CN010 ');
			expect(component.AddBeneficiaryForm.controls['beneficiaryId'].value).toBe('GC0001045995');
			expect(component.AddBeneficiaryForm.controls['beneficiaryName'].value).toBe('16R2A GCIN4NF CN010 ');
			expect(component.AddBeneficiaryForm.controls['beneficiaryIdType'].value).toBe('COUNTERPARTY5');
		}));
	it('Data should display in form onclick of edit icon',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryGridData = [];
			component.showPopupDialog = false;
			const mockForm = new MockFormBuilder();
			component.AddBeneficiaryForm = mockForm.getAddForm();
			const mockBeneficiaryService = new MockBeneficiaryService();
			component.beneficiaryEditFunc(mockBeneficiaryService.getBeneficiaryList(beneficiaryData), 1);
			fixture.detectChanges();
			expect(component.AddBeneficiaryForm.controls['beneficiaryDescription'].value).toBe('GC0001045992   16R2A GCIN4NF CN006 ');
		}));
	it('Data should update in Grid  onclick of update button with different beneficiary Id',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryGridData = [];
			component.showPopupDialog = false;
			const collateralMockservice = new MockCollateralService();
			component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
			expect(component.beneficiaryGridData.length).toBe(1);
			const mockBeneficiaryService = new MockBeneficiaryService();
			const mockForm = new MockFormBuilder();
			component.beneficiaryForm = mockForm.getMainForm();
			component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
			expect(component.beneficiaryGridData.length).toBe(2);
			const beneficiaryEditData = {
				'beneficiaryName': '16R2A GCIN4NF CN010 ',
				'beneficiaryIdType': 'COUNTERPARTY5',
				'beneficiaryId': 'GC0001045995',
				'beneficiaryDescription': 'GC0001045995   16R2A GCIN4NF CN010 '

			};
			component.rowIndex = 1;
			component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
			component.duplicateValueCheck = beneficiaryData;
			component.updateBeneficiaryGridList(beneficiaryEditData);
			expect(component.beneficiaryGridData[1].beneficiaryName).toBe(beneficiaryEditData.beneficiaryName);
		}));
	it('Data should update in Grid  onclick of update button with same beneficiary Id',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryGridData = [];
			component.showPopupDialog = false;
			const collateralMockservice = new MockCollateralService();
			component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
			expect(component.beneficiaryGridData.length).toBe(1);
			const mockBeneficiaryService = new MockBeneficiaryService();
			const mockForm = new MockFormBuilder();
			component.beneficiaryForm = mockForm.getMainForm();
			component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
			expect(component.beneficiaryGridData.length).toBe(2);
			const beneficiaryEditData = {
				'beneficiaryName': '16R2A GCIN4NF CN002 ',
				'beneficiaryIdType': 'COUNTERPARTY1',
				'beneficiaryId': 'GC0001045990',
				'beneficiaryDescription': 'GC0001045990   16R2A GCIN4NF CN002 ',
				'beneficiaryRankToShow': '2ND',
				'beneficiaryRankToSubmit': '2',
				'beneficiaryCapAmount': '',
				'beneficiaryCapAmountType': ''
			};
			component.rowIndex = 1;
			component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
			component.duplicateValueCheck = beneficiaryData;
			component.updateBeneficiaryGridList(beneficiaryEditData);
			expect(component.beneficiaryGridData[1].beneficiaryName).toBe(beneficiaryEditData.beneficiaryName);
		}));
	it('validation check for Beneficiary id field onclick of update button',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryGridData = [];
			component.showPopupDialog = false;
			const collateralMockservice = new MockCollateralService();
			component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
			expect(component.beneficiaryGridData.length).toBe(1);
			const mockBeneficiaryService = new MockBeneficiaryService();
			const mockForm = new MockFormBuilder();
			component.beneficiaryForm = mockForm.getMainForm();
			component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
			expect(component.beneficiaryGridData.length).toBe(2);
			const beneficiaryEditData = {
				'beneficiaryName': '16R2A GCIN4NF CN010 ',
				'beneficiaryIdType': 'COUNTERPARTY5',
				'beneficiaryId': 'GC0001045995',
				'beneficiaryDescription': '16R2A GCIN4NF CN010 (GC0001045995)'
			};
			component.rowIndex = 1;
			component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
			component.updateBeneficiaryGridList(mockBeneficiaryService.getBeneficiaryList(beneficiaryEditData));
			expect(component.beneficiaryIdInvalid).toBe(true);
		}));
	it('validation check for duplicate value onclick of update button',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryGridData = [];
			component.showPopupDialog = false;
			const collateralMockservice = new MockCollateralService();
			component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
			expect(component.beneficiaryGridData.length).toBe(1);
			const mockBeneficiaryService = new MockBeneficiaryService();
			const mockForm = new MockFormBuilder();
			component.beneficiaryForm = mockForm.getMainForm();
			component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
			expect(component.beneficiaryGridData.length).toBe(2);
			component.rowIndex = 1;
			component.idList = mockBeneficiaryService.getMockBeneficiaryIdList(mockbeneficiaryIdList);
			component.duplicateValueCheck = beneficiaryData;
			component.updateBeneficiaryGridList(beneficiaryData);
			expect(component.duplicateValueErrDiv).toBe(true);
		}));
	it('Data should Delete in Grid  onclick of Delete icon',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryGridData = [];
			component.showPopupDialog = false;
			const collateralMockservice = new MockCollateralService();
			component.beneficiaryGridData.push(collateralMockservice.getCounterParty);
			expect(component.beneficiaryGridData.length).toBe(1);
			const mockBeneficiaryService = new MockBeneficiaryService();
			const mockForm = new MockFormBuilder();
			component.beneficiaryForm = mockForm.getMainForm();
			component.beneficiaryGridData.push(mockBeneficiaryService.getBeneficiaryList(beneficiaryData));
			expect(component.beneficiaryGridData.length).toBe(2);
			component.beneficiaryRemoveItemFunc(1);
			expect(component.beneficiaryGridData.length).toBe(1);
		}));
	it('validation check for Beneficiary rank field onclick on valid value entered',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryRankResponse = {};
			component.getBeneficiaryRank();
			expect(component.beneficiaryRankResponse[2]).toBe(BeneficiaryRankList[2]);
			component.onRankSelect('1DBS');
			expect(component.beneficiaryRankInvalid).toBe(false);
		}));
	it('validation check for Beneficiary rank field onclick on invalid value entered',
		async(() => {
			fixture.detectChanges();
			component.beneficiaryRankResponse = {};
			component.getBeneficiaryRank();
			expect(component.beneficiaryRankResponse[1]).toBe(BeneficiaryRankList[1]);
			component.onRankSelect('xyz');
			expect(component.beneficiaryRankInvalid).toBe(true);
		}));
	it('on click of add or esit linkage link it should redirect to facility linkage page',
		async(() => {
		fixture.detectChanges();
		component.getLinkage(beneficiaryData);
		const navigationExtras: NavigationExtras = {
			queryParams: {'gcinLabel': beneficiaryData.beneficiaryName, 'gcinValue': beneficiaryData.beneficiaryId}
		};
		expect(router.navigate).toHaveBeenCalledWith([ './facilityLinkage' ], Object({ queryParams: Object({ gcinLabel: '16R2A GCIN4NF CN002 ', gcinValue: 'GC0001045990' }) }));
		}));

});
