import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Headers, Http, RequestOptions, URLSearchParams, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import { ErrorResponse } from '../../shared';

@Injectable()
export class BeneficiaryService {
	public params: any;

	constructor(private http: Http) {

	}

	errorResponseFunction(error: any) {
		const ErrorResponse = <ErrorResponse>error;
		return Observable.throw(<ErrorResponse>ErrorResponse);
	}

	public getBeneficiaryIdDataService(data: any): Observable<any> {
		const urlToGetBeneficiaryId = environment.apiBaseUrl + environment.apiToGetCifId;
		const headers = new Headers({'Content-Type': 'application/json'});
		const options = new RequestOptions({headers: headers});
		return this.http.post(urlToGetBeneficiaryId, data, options)
			.map(
				res => res.json()
			)
			.catch(
				error => this.handleError(error)
			);
	}

	addBeneficiary(item: any): Observable<any> {
		const urlToPostBeneficiary = environment.apiBaseUrl + environment.apiCollateralCustomer;
		const customer = {
			'entityId': item.beneficiaryId,
			'entityType': 'C',
			'entityName': item.beneficiaryIdType
		};
		return this.http.post(urlToPostBeneficiary, customer)
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.handleError(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	public getBeneficiaryRankService(): Observable<any> {
		const urlToGetBeneficiaryRank = environment.apiBaseUrl + environment.apiToGetChargeRank;
		return this.http.get(urlToGetBeneficiaryRank)
			.map(
				res => res.json()
			)
			.catch(error => this.handleError(error));
	}

	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}

}
