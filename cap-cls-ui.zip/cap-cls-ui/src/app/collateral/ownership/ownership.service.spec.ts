import { TestBed, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { OwnershipService } from './ownership.service';
import { OwnershipIdList } from './ownership.data-model';
import { environment } from '../../../environments/environment';


class TMockOwnershipService {


    getGCIDCIFData(data) {
        return Observable.of(OwnershipIdList);
    }
}

describe('OwnershipService', () => {
    let ownershipService: OwnershipService;
    let mockBackend: MockBackend;
    const urlToGetOwnershipID = environment.apiBaseUrl + environment.apiToGetCifId;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: Http,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        return new Http(backend, options);
                    },
                    deps: [MockBackend, BaseRequestOptions]
                },
                { provide: OwnershipService, useClass: TMockOwnershipService }
            ],
            imports: [HttpModule]
        });
    });

    beforeEach(
        inject([OwnershipService, MockBackend], (service: OwnershipService, backend: MockBackend) => {
            ownershipService = service;
            mockBackend = backend;
        })
    );

    it('Ownership service should be defined', () => {
        expect(ownershipService).toBeDefined();
    });

    it('should call getGCIDCIFData API from service', () => {
        const filterData = 'GCIN';
        spyOn(ownershipService, 'getGCIDCIFData').and.callFake(function ({ 'searchKeyword': filterData }) { return OwnershipIdList; });         // returnValue(OwnershipIdList);

        mockBackend.connections.subscribe((connection: MockConnection) => {
            expect(connection.request.method).toBe(RequestMethod.Post);
        });

        expect(ownershipService.getGCIDCIFData({ 'searchKeyword': 'GCIN' })).toEqual(OwnershipIdList);
    });



});

