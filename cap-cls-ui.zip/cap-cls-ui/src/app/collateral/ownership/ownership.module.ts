

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { OwnershipComponent } from './ownership.component';
import { OwnershipService } from './ownership.service';
// Import the Kendo UI Component
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { GridModule } from '@progress/kendo-angular-grid';

import { IntlModule } from '@progress/kendo-angular-intl';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { CommonUIModule } from '../../common/commonUI.module'
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { FormGroup, FormControl, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';

import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';


@NgModule({
    declarations: [OwnershipComponent],
    imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpModule,
        ButtonsModule, DateInputsModule, IntlModule, ClsSharedCommonModule,
        DropDownsModule, GridModule, CommonUIModule, PopupDialogModule],
    providers: [OwnershipService],
    exports: [OwnershipComponent]
})
export class OwnershipModule {
    public static forRoot(): ModuleWithProviders {
        return { ngModule: OwnershipModule, providers: [] };
    }

}