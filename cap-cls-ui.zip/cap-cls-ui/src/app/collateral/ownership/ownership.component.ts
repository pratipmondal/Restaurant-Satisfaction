
import { Component, OnInit } from '@angular/core';
import { Input } from '@angular/core';
import { OwnershipService } from './ownership.service';
import { OwnershipItemModel } from './ownership.model';
import { ChangeDetectorRef } from '@angular/core';
import { CollateralService } from '../collateral.service';
import { ErrorResponse } from '../../shared';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastsComponent } from '../../shared/toasts/toasts.component';

@Component({
	selector: 'collateral-ownership',
	templateUrl: './ownership.component.html',
	styleUrls: ['./ownership.component.scss'],
})
export class OwnershipComponent implements OnInit {

	showPopupDialog: boolean = false;
	rowIndex: number;

	divForNormalGrid: boolean = false;
	sumOfOwnershipPercentage: number = 0.0;
	noRecordsFlg: boolean = false;

	argToastMessageObject: any;

	counterPartyInvalid: boolean = false;
	percentageInvalid: boolean = false;
	duplicateOwnershipGCINErrDivFlg: boolean = false;
	exceed100LmitDivFlg: boolean = false;

	ownershipItemsList: OwnershipItemModel[] = [];
	toastsComponent: ToastsComponent = new ToastsComponent();

	public searchGCIDCIFData = [];
	tmpSelectedGCIN: string = '';
	gridData: any[];
	summarygrid: any = []
	errMsg: boolean = false;
	errorMessage: string;
	showLoader = false;
	modalAction: string = '';
	disableGCINCIF: boolean = false;
	errorResponse: ErrorResponse = null;
	public selectedGCINItem: any;

	public dialogTitle: string;

	@Input() yesNoPromptForDelete: any;
	@Input() showAddOwnershipBtn: boolean = true;
	@Input() showSummaryGrid: boolean;
	@Input() ownershipForm: FormGroup;

	ownershipItemForm: FormGroup;
	previousPercentage: number = 0.0;

	constructor(private _fb: FormBuilder, public ownershipService: OwnershipService, private cdRef: ChangeDetectorRef, private collateralService: CollateralService) {
		// TODO :
	}

	getRecentDetections(): void {
		this.ownershipForm.valueChanges.subscribe(recent => {
			this.cdRef.detectChanges(); // <== added
		});
	}

	ngOnInit(): void {
		this.setupComponent();
	}

	setupComponent() {
		this.customizeOwnershipGridForSummaryComp();
		if (this.collateralService.getCollateral().LodgeOwnerShipDetail.ownerShipList) {
			this.gridData = this.collateralService.getCollateral().LodgeOwnerShipDetail.ownerShipList;
		} else {
			this.gridData = [];
		}
		this.summarygrid = this.gridData;
		this.ownershipItemsList = this.gridData;
		this.processFormItems();
	}


	// Delete Button click event emit
	public ownershipRemoveItem(index: number) {


		if (!(this.gridData.length > 0)) {
			return;
		}

		if (!((index >= 0) && (index < this.gridData.length))) {
			return;
		}

		this.gridData.splice(index, 1);
		this.ownershipItemsList = this.gridData;

		this.argToastMessageObject = this.toastsComponent
			.buildToastMessageObject('success',
			'A record of ownership details has been successfully removed.',
			'', '');
		this.ownershipForm.controls['ownershipid'].setValue(this.gridData);
		this.processFormItems();
	}

	cleanseItemDescription(description: string, gcin: string): string {

		if ((!description) && (!gcin)) {
			return;
		}

		if (description.search(gcin) < 0) {     // the gcin doesnot exist in description hence return.
			return description;
		}

		let cleanItem = description.replace(gcin, '');
		cleanItem = cleanItem.replace('()', '').trim();

		return cleanItem;
	}



	public searchByGCINCIF(searchValue: string) {

		this.searchGCIDCIFData = [];

		if (searchValue.length > 2) {
			this.ownershipService.getGCIDCIFData(searchValue).subscribe(data => {
				if (data) {
					this.searchGCIDCIFData = [];
					this.searchGCIDCIFData = data.map(function (item) {
						return ({
							'ownershipCode': item.gcin,
							'ownershipName': item.gcin + ' ' + this.cleanseItemDescription(item.description, item.gcin),  //item.description,  // 
							'ownershipType': item.type
						});
					}, this);
				}
			},
				error => {
					this.errMsg = true;
					this.errorMessage = 'Oops! something went wrong.    ' + error._body;
				}
			);
		}
	}



	public showAddOwnershipDialog() {
		this.modalAction = 'ADD_ITEM';
		this.dialogTitle = 'Add Ownership Details';

		this.ownershipItemForm = this._fb.group({
			cifId: ['', [Validators.required]],
			idType: ['', [Validators.required]],
			collateralOwnerShipPcnt: ['', [Validators.required]],
			name: ['', [Validators.required]],
			actualCFID: ['', [Validators.required]],
		});

		this.ownershipItemForm.controls['collateralOwnerShipPcnt'].valueChanges.subscribe(data => {
			this.percentageInvalid = false;
			this.exceed100LmitDivFlg = false;

		});
		this.showPopupDialog = true;
		this.disableGCINCIF = false;
		this.validationReset();
	}

	public showUpdateOwnershipDialog(argData: OwnershipItemModel, index: number) {

		this.searchByGCINCIF(argData.cifId);   // Make call to get the latest description for the GCIN


		this.showLoader = false;
		if (!(this.searchGCIDCIFData === undefined)) {
			const tmpDisplayCFID = this.searchGCIDCIFData[0]['ownershipName'];
			this.validationReset();
			this.rowIndex = index;
			this.modalAction = 'UPDATE_ITEM';
			this.dialogTitle = 'Update Ownership Details';
			this.ownershipItemForm = this._fb.group({
				cifId: [tmpDisplayCFID, [Validators.required]],
				idType: [argData.idType, [Validators.required]],
				collateralOwnerShipPcnt: [argData.collateralOwnerShipPcnt, [Validators.required]],
				name: [argData.name, [Validators.required]],
				actualCFID: [argData.cifId, [Validators.required]],
			});
			this.previousPercentage = argData.collateralOwnerShipPcnt;   // Will be used for validation
			this.showPopupDialog = true;
			this.disableGCINCIF = true;
		}

		this.ownershipItemForm.controls['collateralOwnerShipPcnt'].valueChanges
			.subscribe(data => {
				this.percentageInvalid = false;
				this.exceed100LmitDivFlg = false;
			});


	}


	private closeEventFromPopupDialog(e: boolean): void {
		this.showPopupDialog = e;
		this.ownershipItemForm.reset();
	}



	getGridPercentageSum(): number {
		let gridSumOfOwnershipPercentage: number = 0.0;
		for (let i = 0; i < this.gridData.length; i++) {
			gridSumOfOwnershipPercentage += parseFloat(this.gridData[i]['collateralOwnerShipPcnt']);
		}
		gridSumOfOwnershipPercentage = this.roundNumber(gridSumOfOwnershipPercentage, 12);
		return gridSumOfOwnershipPercentage;
	}


	checkFormValidity(ownershipFormValue: OwnershipItemModel): boolean {

		let finalResult: boolean = true;
		// Check if there is Duplicate ownership ID in teh List  in case of an add_item
		if ((this.modalAction === 'ADD_ITEM') && (this.selectedGCINItem !== undefined)) {

			// check that cif value  has been correctly   populated from the  resposne Search results
			if (ownershipFormValue.cifId.toString() !== this.selectedGCINItem[0].ownershipName.toString()) {
				this.counterPartyInvalid = true;
				finalResult = (finalResult && false);
			}
			else {
				// check for Duplicity of GCINS
				const dataObj = this.gridData.find(item => item.cifId.toString() === ownershipFormValue['actualCFID'].toString());
				if (dataObj === undefined) {
					this.duplicateOwnershipGCINErrDivFlg = false;
					this.counterPartyInvalid = false;
					finalResult = (finalResult && true);
				}
				else {
					this.counterPartyInvalid = true;
					this.duplicateOwnershipGCINErrDivFlg = true;
					finalResult = (finalResult && false);
				}
			}
		}
		else {
			if ((this.modalAction === 'UPDATE_ITEM') && (this.selectedGCINItem !== undefined)) {
				this.duplicateOwnershipGCINErrDivFlg = false;
				this.counterPartyInvalid = false;
				finalResult = (finalResult && true);
			}
			else {
				finalResult = (finalResult && false);
				this.counterPartyInvalid = true;
			}
		}



		// Check for the validity of the  Percentages entered.
		if ((ownershipFormValue['collateralOwnerShipPcnt'].toString().length === 0)) {
			this.percentageInvalid = true;
			finalResult = (finalResult && false);
		}
		else {
			const gridSumOfOwnershipPercentage: number = this.getGridPercentageSum();

			// Sum of Percentages  should be  within grange 0 -100 with 3 decimal places.
			let tmpSumPercentage = (Number.parseFloat(ownershipFormValue['collateralOwnerShipPcnt'].toString()) + gridSumOfOwnershipPercentage) - this.previousPercentage;
			tmpSumPercentage = this.roundNumber(tmpSumPercentage, 12);

			if (!((tmpSumPercentage <= 100) && (tmpSumPercentage >= 0))) {
				this.percentageInvalid = true;
				this.exceed100LmitDivFlg = true;
				finalResult = (finalResult && false);
			}
			else {
				this.percentageInvalid = false;
				finalResult = (finalResult && true);
			}
		} return finalResult;
	}



	SubmitOwnershipForm(ownershipFormValue: OwnershipItemModel): boolean {

		this.ownershipService.addOwnership(ownershipFormValue)
			.subscribe(data => { }, error => {
				this.errorResponse = <ErrorResponse>error;
			});

		if (!this.checkFormValidity(ownershipFormValue)) {
			return false;
		}

		this.showPopupDialog = false;
		this.gridData = [];

		if (this.modalAction === 'UPDATE_ITEM') {
			this.ownershipItemsList.forEach(function (item) {

				if (item.cifId === ownershipFormValue.actualCFID) {
					item.collateralOwnerShipPcnt = ownershipFormValue.collateralOwnerShipPcnt;
				}
			});

			this.ownershipForm.controls['ownershipid'].setValue(this.ownershipItemsList);
			this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
				'A record of ownership details has been successfully updated.',
				'', '');

		}

		if (this.modalAction === 'ADD_ITEM') {

			const ownershipItemModel = new OwnershipItemModel();
			ownershipItemModel.cifId = this.tmpSelectedGCIN;
			ownershipItemModel.name = ownershipFormValue.name;
			ownershipItemModel.idType = ownershipFormValue.idType;
			ownershipItemModel.collateralOwnerShipPcnt = ownershipFormValue.collateralOwnerShipPcnt;

			this.ownershipItemsList.push(ownershipItemModel);
			this.tmpSelectedGCIN = '';

			this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
				'A new record of ownership details has been successfully added.',
				'', '');
			this.ownershipForm.controls['ownershipid'].setValue(this.ownershipItemsList);
		}

		this.ownershipItemForm.reset();
		this.showPopupDialog = false;
		this.modalAction = '';

		this.gridData = this.ownershipItemsList;
		this.processFormItems();
	}


	onSearchGCIDCIFSelect(e: any): void {

		this.duplicateOwnershipGCINErrDivFlg = false;    // reset valdiation flags
		this.counterPartyInvalid = true;

		// tslint:disable-next-line:curly
		if (e === undefined)
			return;    // if underfined

		let selectItem = this.searchGCIDCIFData.filter(
			function (data) { return data.ownershipName === e; }
		);

		if (selectItem.length === 0) {
			this.counterPartyInvalid = true;
			return;     // if no data found
		}
		else {
			this.counterPartyInvalid = false;
		}

		this.selectedGCINItem = selectItem;    //  selected item retained for later validation  in form save

		const cleansedName = this.cleanseItemDescription(selectItem[0]['ownershipName'], selectItem[0]['ownershipCode']);

		this.ownershipItemForm.controls['name'].setValue(cleansedName);
		this.ownershipItemForm.controls['idType'].setValue(selectItem[0]['ownershipType']);
		this.ownershipItemForm.controls['actualCFID'].setValue(selectItem[0]['ownershipCode']);

		this.tmpSelectedGCIN = selectItem[0]['ownershipCode'];
	}


	stopPropagation(e: Event) {
		e.preventDefault();
	}

	processFormItems() {

		// Check for no records Flag
		// tslint:disable-next-line:curly
		if (this.ownershipItemsList.length > 0)
			this.noRecordsFlg = false;
		// tslint:disable-next-line:curly
		else
			this.noRecordsFlg = true;

		// Reset Values
		this.sumOfOwnershipPercentage = 0.000;
		for (let i = 0; i < this.gridData.length; i++) {
			this.sumOfOwnershipPercentage = this.sumOfOwnershipPercentage + parseFloat(this.gridData[i]['collateralOwnerShipPcnt']);
		}
		this.sumOfOwnershipPercentage = this.roundNumber(this.sumOfOwnershipPercentage, 12);

	}

	roundNumber(number, decimals): number {
		const newnumber = new Number(number + '').toFixed(parseInt(decimals));
		return parseFloat(newnumber);
	}


	customizeOwnershipGridForSummaryComp() {
		if (this.showSummaryGrid) {
			this.divForNormalGrid = false;
		} else {
			this.divForNormalGrid = true;
		}
	}

	onLabelClicked(e: Event) {
		this.showAddOwnershipDialog();
	}

	validationReset() {
		this.counterPartyInvalid = false;
		this.percentageInvalid = false;
		this.duplicateOwnershipGCINErrDivFlg = false;
		this.exceed100LmitDivFlg = false;
	}

}
