import { Injectable } from "@angular/core";
import "rxjs/add/operator/map";
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import { Observable } from "rxjs";
import { environment } from '../../../environments/environment';
import { ErrorResponse } from '../../shared';
import { OwnershipItemModel } from "./ownership.model";

@Injectable()
export class OwnershipService {
    public params: any;

    constructor(private http: Http) {

    }

    errorResponseFunction(error: any) {
        const ErrorResponse = <ErrorResponse>error;
        return Observable.throw(<ErrorResponse>ErrorResponse);
    }

    public getGCIDCIFData(searchValue: any): Observable<any> {
        const urlToGetCifId = environment.apiBaseUrl + environment.apiToGetCifId;
        const headers = new Headers({'Content-Type': 'application/json'});
        const options = new RequestOptions({headers: headers});
        const bodyData = { 'searchKeyword': searchValue };

        return this.http.post(urlToGetCifId, bodyData, options)
			.map(
                res => res.json()
            );
    }

    addOwnership(item: OwnershipItemModel): Observable<any> {
        const urlToPostOwnership = environment.apiBaseUrl + environment.apiCollateralCustomer;
        const customer = {
            'entityId': item.actualCFID,
            'entityType': 'C',
            'entityName': item.idType
        };
        return this.http.post(urlToPostOwnership, customer)
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
        function onSuccessSuccess(resp: Response) {
            return (resp.json());
        }
    }

}