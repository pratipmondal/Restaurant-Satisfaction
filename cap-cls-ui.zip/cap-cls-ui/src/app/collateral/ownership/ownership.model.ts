export class OwnershipItemModel {

    // ownershipId: string;
    // ownershipIdType: string;
    // ownershipPercentage: Date;


    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    cifId: string;
    city: string;
    collateralOwnerShipPcnt: number;
    country: string;
    delete: boolean;
    emailAddress: string;
    faxNo: string;
    idNo: number;
    idType: string;
    name: string;
    phoneNo: string;
    postalCode: string;
    state: string;
    telexNo: string;
    actualCFID: string;

    constructor() {
        this.cifId = '',
        this.idType = '',
        this.idNo = 0,
        this.name = '',
        this.collateralOwnerShipPcnt = 0,
        this.addressLine1 = '',
        this.addressLine2 = '',
        this.addressLine3 = '',
        this.city = '',
        this.state = '',
        this.country = '',
        this.postalCode = '',
        this.phoneNo = '',
        this.emailAddress = '',
        this.telexNo = '',
        this.faxNo = '',
        this.delete = false
        this.actualCFID = ''
    }

}


