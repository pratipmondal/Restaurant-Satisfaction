import {Component, Input, OnInit, ViewEncapsulation, AfterViewInit, ChangeDetectorRef} from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import {CollateralService} from '../../collateral.service';
import {CustomFormControl} from '../../../common/custom-form-controls/custom-form-control';
import {TextboxValidator} from '../../../common/custom-validators/custom-textbox-validator';
import {ErrorResponse} from '../../../shared';
import {Location} from '../../model/';
@Component({
    selector: 'general-details',
    templateUrl: './general-details.html',
    encapsulation: ViewEncapsulation.Emulated,
    styleUrls: ['./general-details.scss']
})
export class GeneralDetailsComponent implements OnInit, AfterViewInit {
    heading: string;
    percentageCollateralHeading: string;
    toggle: boolean;
    toggleDBSPercentage: boolean;
    valid: boolean;
    recDateValidate: boolean;
    errorResponse: ErrorResponse = null;
    ccyAmountValidate: boolean;
    formNoValidate: boolean;
    validateSolicitor: boolean;
    nextReviewDateValidate: boolean;
    expiryDateValidate: boolean;
    maxAmountValidate: boolean;
    collatarelPercentValidate: boolean;
    executionDateValidate: boolean;
    inputLoanValidate: boolean;
    valueFromSelectedButton: string = 'No';
    private selectedBtn: string = 'value2';
    selectedCollateralType: string = '';
    selectedValueMethod: string = 'Fixed Method';
    private selectedMethod: string = 'value1';
    locations: Array<Location> = [];
    loanToValuePercentage: number = 0;

    @Input()
    collateralDetailsForm: FormGroup;

    formErrors = {
        'currencyType': '',
        'amount': '',
        'expiryDate': null,
        'generalDetailsRemarks': '',
        'loanValuePcnt': '',
        'locationControl': '',
        'collateralValuePcnt': '',
        'sharingBasis': '',
        'maxCondition': '',
        'maxAmountCurrencyType': '',
        'maxAmount': '',
        'fixedAmountCurrencyType': '',
        'fixedAmount': '',
        'proportionateValuePcnt': '',
        'formNo': '',
        'recievedDate': null,
        'reviewDate': null,
        'nextReviewDate': null,
        'signingDate': null,
        'executionDate': null,
        'applicationDetailsRemarks': '',
        'method': '',
        'solicitorName': ''
    };

    formTouched = {
        'currencyType': false,
        'amount': false,
        'expiryDate': false,
        'generalDetailsRemarks': false,
        'loanValuePcnt': false,
        'locationControl': false,
        'collateralValuePcnt': false,
        'sharingBasis': false,
        'maxCondition': false,
        'maxAmountCurrencyType': false,
        'maxAmount': false,
        'fixedAmountCurrencyType': false,
        'fixedAmount': false,
        'proportionateValuePcnt': false,
        'formNo': false,
        'recievedDate': false,
        'reviewDate': false,
        'nextReviewDate': false,
        'signingDate': false,
        'executionDate': false,
        'applicationDetailsRemarks': false,
        'baselEligible': false,
        'method': false,
        'solicitorName': false
    };

    validationMessages = {};

    constructor(private collateralService: CollateralService, private _changeDetectionRef: ChangeDetectorRef) {
        this.heading = 'Add Application Details';
        this.percentageCollateralHeading = 'Add DBS % of Collateral Value Details';
        this.toggle = false;
        this.toggleDBSPercentage = false;
        this.valid = false;
        this.ccyAmountValidate = false;
        this.maxAmountValidate = false;
        this.inputLoanValidate = false;
        this.collatarelPercentValidate = false;
        this.nextReviewDateValidate = false;
        this.recDateValidate = false;
        this.formNoValidate = false;
        this.expiryDateValidate = false;
        this.executionDateValidate = false;
        this.executionDateValidate = false;
        this.validateSolicitor = false;

    }

    ngOnInit() {
        this.selectedCollateralType = this.collateralService.selectedCollateralType;
        this.addFormControls();
        this.setGeneralDetails();
        if (this.collateralService.getCollateral().generalDetail.applicationDetail) {
            if (this.isApplicationDetailsAvailable()) {
                this.toggle = true;
            }
            this.setApplicationDetails();
        }
        this.initLocations();

    }

    ngAfterViewInit(): void {
        this.collateralDetailsForm.valueChanges.subscribe(data => this.onValueChanged(data));
        this._changeDetectionRef.detectChanges();
    }

    private setGeneralDetails() {
        if (this.collateralService.selectedCollateralType === 'GUARN') {
            this.collateralDetailsForm.get('amount').setValue(this.collateralService.getCollateral().CollateralValuationDetail.finalCollateralValue.value.toString());
        }
        if (this.collateralService.getCollateral().CollateralValuationDetail.loanToValuePcnt) {
            this.loanToValuePercentage = this.collateralService.getCollateral().CollateralValuationDetail.loanToValuePcnt;
        }
        this.collateralDetailsForm.get('loanValuePcnt').setValue(this.loanToValuePercentage);
        this.collateralDetailsForm.get('expiryDate').setValue(this.collateralService.getCollateral().generalDetail.collateralExpiryDate);
        this.collateralDetailsForm.get('generalDetailsRemarks').setValue(this.collateralService.getCollateral().generalDetail.remarks);
        this.collateralDetailsForm.get('currencyType').setValue(this.collateralService.getCollateral().generalDetail.currencyCode);
        this.collateralDetailsForm.get('locationControl').setValue({code: this.collateralService.getCollateral().generalDetail.country});
        if (this.collateralService.getCollateral().generalDetail.SolicitorDetails)
            this.collateralDetailsForm.get('solicitorName').setValue(this.collateralService.getCollateral().generalDetail.SolicitorDetails.solicitorName);
        this.collateralService.getCollateral().generalDetail.BASELEligible ? this.selectedBtn = 'value1' : this.selectedBtn = 'value2';
        if (this.collateralService.getCollateral().generalDetail.method === 'All Monies') {
            this.selectedMethod = 'value2';
        } else {
            this.selectedMethod = 'value1';
        }
    }

    private initLocations() {
        this.collateralService.getLocations().subscribe(data => {
                this.locations = data;
            }, error => {
            }
        );
    }

    private setApplicationDetails() {
        this.collateralDetailsForm.get('formNo').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.formNo);
        this.collateralDetailsForm.get('recievedDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.receivedDate);
        this.collateralDetailsForm.get('signingDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.signingDate);
        this.collateralDetailsForm.get('executionDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.executionDate);
        this.collateralDetailsForm.get('applicationDetailsRemarks').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.comments);
        this.collateralDetailsForm.get('reviewDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.reviewDate);
        this.collateralDetailsForm.get('nextReviewDate').setValue(this.collateralService.getCollateral().generalDetail.applicationDetail.nextReviewDate);
    }

    private isApplicationDetailsAvailable() {
        return this.collateralService.getCollateral().generalDetail.applicationDetail.formNo ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.receivedDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.signingDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.executionDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.comments ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.reviewDate ||
            this.collateralService.getCollateral().generalDetail.applicationDetail.nextReviewDate;
    }

    addFormControls() {

        const emptyControls = ['currencyType', 'amount', 'applicationDetailsRemarks', 'loanValuePcnt', 'locationControl', 'baselEligible',
            'collateralValuePcnt', 'sharingBasis', 'maxCondition', 'maxAmountCurrencyType', 'maxAmount',
            'fixedAmountCurrencyType', 'fixedAmount', 'formNo', 'method', 'solicitorName'
        ];
        for (const emptyControl of emptyControls) {
            this.addEmptyControls(emptyControl);
        }
        const nullControls = ['recievedDate', 'reviewDate', 'nextReviewDate', 'signingDate', 'executionDate',
            'expiryDate', 'generalDetailsRemarks', 'proportionateValuePcnt'];
        for (const nullControl of nullControls) {
            this.addNullControls(nullControl);
        }
    }

    private addEmptyControls(control: string) {
        if (control === 'amount') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'CCY Amount';
        }
        if (control === 'loanValuePcnt') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Loan to Value';
        }

        if (control === 'solicitorName') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Solicitor Name';
        }

        if (control === 'locationControl') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl({
                code: '',
                value: ''
            }, [TextboxValidator.requiredDropDown]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Location';
        }
        this.collateralDetailsForm.addControl(control, new FormControl(''));
    }

    private addNullControls(control: string) {
        if (control === 'amount') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'CCY Amount';
        }
        if (control === 'loanValuePcnt') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Loan to Value';
        }

        if (control === 'solicitorName') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl(null, [TextboxValidator.required]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'text';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Solicitor Name';
        }

        if (control === 'locationControl') {
            this.collateralDetailsForm.addControl(control, new CustomFormControl({
                code: '',
                value: ''
            }, [TextboxValidator.requiredDropDown]));
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).type = 'dropdown';
            (<CustomFormControl>this.collateralDetailsForm.controls[control]).label = 'Location';
        }
        // error panel code
        this.collateralDetailsForm.addControl(control, new FormControl(null));
    }

    onValueChanged(data?: any) {
        if (!this.collateralDetailsForm) {
            return;
        }
        const form = this.collateralDetailsForm;
        for (const field in this.formErrors) {
            this.formErrors[field] = '';
            const control = form.get(field);
            if (control) {
                this.formTouched[field] = control.touched;
                if (control && control.dirty && !control.valid) {
                    const messages = this.validationMessages[field];
                    if (messages) {
                        for (const key in control.errors) {
                            this.formErrors[field] += messages[key] + ' ';
                        }
                    }
                }
            }
        }
        this.pushToApportion(data);
    }

    pushToApportion(data?: any) {
        if (this.collateralService.selectedCollateralType !== 'GUARN') {
            return;
        }
        let amt = 0;
        if (data && data.amount) {
            amt = data.amount;
        }
        const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
        // calculations
        collateralObj.collateralValue.value = amt;
        collateralObj.finalCollateralValue.value =
            collateralObj.collateralValue.value - 0;
        collateralObj.balanceApportionableAmt.value = collateralObj.finalCollateralValue.value - collateralObj.totalApportionedValue.value;

        collateralObj.collateralValue.ccy = this.collateralDetailsForm.get('currencyType').value;
        collateralObj.finalCollateralValue.ccy = this.collateralDetailsForm.get('currencyType').value;
        collateralObj.balanceApportionableAmt.ccy = this.collateralDetailsForm.get('currencyType').value;
    }

    eventFromToggleButton(valueFromSelectedButton: any) {
        this.valueFromSelectedButton = valueFromSelectedButton;
        this.collateralDetailsForm.get('baselEligible').setValue(valueFromSelectedButton === 'Yes');
    }

    methodEvent(selectedValueMethod: any) {
        this.selectedValueMethod = selectedValueMethod;
        this.collateralDetailsForm.get('method').setValue(selectedValueMethod);
    }

    validateLoan(pst) {
        this.inputLoanValidate = !(pst._textvalue);
    }

    validateCollateralPercentage(cvp) {
        this.collatarelPercentValidate = !(cvp._textvalue);
    }

    showDBSPercentageOfCollateralValues() {
        if (!this.toggleDBSPercentage) {
            this.toggleDBSPercentage = true;
            this.percentageCollateralHeading = 'Remove DBS % of Collateral Value Details';
            const controls = ['collateralValuePcnt', 'sharingBasis', 'proportionateValuePcnt', 'maxAmount', 'fixedAmount'];
            for (const control of controls) {
                this.updateControl(control);
            }
        } else {
            this.toggleDBSPercentage = false;
            this.percentageCollateralHeading = 'Add DBS % of Collateral Value Details';
            this.maxAmountValidate = false;
            this.collatarelPercentValidate = false;
        }

    }

    showApplicationDetails() {
        if (!this.toggle) {
            this.toggle = true;
            this.heading = 'Remove Application Details';
            const controls = ['recievedDate', 'reviewDate', 'nextReviewDate', 'signingDate', 'executionDate',
                'applicationDetailsRemarks'];
            for (const control of controls) {
                this.updateControl(control);
            }
            const textControls = ['applicationDetailsRemarks', 'formNo'];
            for (const textControl of textControls) {
                this.updateControlEmpty(textControl);
            }
        } else {
            this.toggle = false;
            this.heading = 'Add Application Details';
            this.nextReviewDateValidate = false;
            this.executionDateValidate = false;
            this.recDateValidate = false;
            this.formNoValidate = false;
        }
    }

    private updateControlEmpty(textControl: string) {
        if (this.collateralDetailsForm.get(textControl)) {
            this.collateralDetailsForm.get(textControl).setValue('');
        }
    }

    updateControl(formControl: string) {
        const control = this.collateralDetailsForm.get(formControl);
        if (control) {
            control.setValue(null);
        }
    }

    onTouched(element) {
        if (!this.collateralDetailsForm) {
            return;
        }
        this.formTouched[element] = true;
    }


    onFocusHasError(element: string) {
        if (this.collateralService.formSubmitClicked && this.collateralDetailsForm.controls[element] && this.collateralDetailsForm.controls[element]['invalid']) {
            return true;
        }
        return false;
    }

    reviewValidator() {
        const nextReviewDate = this.collateralDetailsForm.get('nextReviewDate').value;
        const reviewDate = this.collateralDetailsForm.controls['reviewDate'].value;
        if (reviewDate > nextReviewDate) {
            this.nextReviewDateValidate = true;
        } else {
            this.nextReviewDateValidate = false;
        }
    }

    reviewExeDateValidator() {
        const executionDate = this.collateralDetailsForm.get('executionDate').value;
        const signingDate = this.collateralDetailsForm.get('signingDate').value;
        if (signingDate > executionDate) {
            this.executionDateValidate = true;
        } else {
            this.executionDateValidate = false;
        }
    }

    validateCCYAmount(ccy) {
        this.ccyAmountValidate = !(ccy.amount);
    }

    validateMaxAmount(mc) {
        this.maxAmountValidate = !(mc.amount);
    }

    validateRecDate(event) {
        if (event !== null) {
            const val = event.value;
            if (val === null)
                this.recDateValidate = true;
            else
                this.recDateValidate = false;
        }
    }

    validateFormNo(formNo) {
        this.formNoValidate = !(formNo.value);
    }

    validateSolicitorName(solicitorName) {
        console.log(solicitorName);
        this.validateSolicitor = !(solicitorName.value);
    }

    validateExpDate(expd) {
        const collateralCreatedDate = new Date();
        const expiryDate = this.collateralDetailsForm.get('expiryDate').value;

        if (collateralCreatedDate > expiryDate) {
            this.expiryDateValidate = true;
        } else {
            this.expiryDateValidate = false;
        }
    }

    isMethodAllowed() {
        return (this.selectedCollateralType !== 'DEPOS');
    }
}
