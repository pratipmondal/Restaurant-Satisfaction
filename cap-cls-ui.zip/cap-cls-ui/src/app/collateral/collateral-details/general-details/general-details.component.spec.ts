import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {ChangeDetectorRef} from '@angular/core';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { GeneralDetailsComponent } from './general-details.component';
import { CollateralService } from '../../collateral.service';
import { isUndefined } from 'util';
import { Collateral } from '../../../collateral/model/collateral';
import createSpy = jasmine.createSpy;
import createSpyObj = jasmine.createSpyObj;
import { Observable } from 'rxjs/Observable';
import { FormGroup, FormControl } from '@angular/forms';

class MockCollateralService {
    selectedCollateralType: string = 'GUARN';
    getCollateral() {
        return new Collateral();
    }

    getLocations(){
        return Observable.of({});
    }
}
class MockChangeDetectorRef{

}

describe('GeneralDetailsComponent', () => {
    let component: GeneralDetailsComponent;
    let fixture: ComponentFixture<GeneralDetailsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [GeneralDetailsComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
            providers: [{ provide: CollateralService, useClass: MockCollateralService },
                {provide: ChangeDetectorRef, useClass: MockChangeDetectorRef}
            ]
        })
            .compileComponents();

    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(GeneralDetailsComponent);
        component = fixture.componentInstance;
        component.collateralDetailsForm = new FormGroup({}, );
       // spyOn(component, 'addFormControls');

    });

    it('should create GeneralDetailsComponent', () => {
        expect(component).toBeTruthy();
    });

    it('should call ngOnInit GeneralDetailsComponent', () => {
        spyOn(component, 'setGeneralDetails');
        spyOn(component, 'setApplicationDetails');
        component.ngOnInit();
    });

    it('should call addFormControls GeneralDetailsComponent', () => {
        component.addFormControls();
    });


    it('should call validateLoan GeneralDetailsComponent', () => {
        component.validateLoan({ _textvalue: undefined });
        expect(component.inputLoanValidate).toBe(true);
        component.validateLoan({ _textvalue: 2 });
        expect(component.inputLoanValidate).toBe(false);
    });

    it('should call validateCollateralPercentage GeneralDetailsComponent', () => {
        component.validateCollateralPercentage({ _textvalue: undefined });
        expect(component.collatarelPercentValidate).toBe(true);
        component.validateCollateralPercentage({ _textvalue: 2 });
        expect(component.collatarelPercentValidate).toBe(false);
    });

    it('should call validateCCYAmount GeneralDetailsComponent', () => {
        component.validateCCYAmount({ amount: undefined });
        expect(component.ccyAmountValidate).toBe(true);
        component.validateCCYAmount({ amount: 2 });
        expect(component.ccyAmountValidate).toBe(false);
    });

    it('should call validateMaxAmount GeneralDetailsComponent', () => {
        component.validateMaxAmount({ amount: undefined });
        expect(component.maxAmountValidate).toBe(true);
        component.validateMaxAmount({ amount: 2 });
        expect(component.maxAmountValidate).toBe(false);
    });
    it('should call validateRecDate GeneralDetailsComponent', () => {
        component.validateRecDate({ value: null });
        expect(component.recDateValidate).toBe(true);
        component.validateRecDate({ value: 2 });
        expect(component.recDateValidate).toBe(false);
    });

    it('should call validateFormNo GeneralDetailsComponent', () => {
        component.validateFormNo({ value: undefined });
        expect(component.formNoValidate).toBe(true);
        component.validateFormNo({ value: 2 });
        expect(component.formNoValidate).toBe(false);
    });

    it('showDBSPercentageOfCollateralValues will update the toggle for disable DBS% fields', () => {
        component.toggleDBSPercentage = false;
        component.showDBSPercentageOfCollateralValues();
        expect(component.percentageCollateralHeading).toBe('Remove DBS % of Collateral Value Details');
    });

    it('showDBSPercentageOfCollateralValues will update the toggle for enabling DBS% fields', () => {
        component.toggleDBSPercentage = true;
        component.showDBSPercentageOfCollateralValues();
        expect(component.percentageCollateralHeading).toBe('Add DBS % of Collateral Value Details');
    });

    it('showApplicationDetails will update the toggle for disable application fields', () => {
        component.toggle = false;
        component.showApplicationDetails();
        expect(component.heading).toBe('Remove Application Details');
    });

    it('showApplicationDetails will update the toggle for enabling DBS% fields', () => {
        component.toggle = true;
        component.showApplicationDetails();
        expect(component.heading).toBe('Add Application Details');
    });
    it('reviewExeDateValidator should return true if signing date is greater than execute date', () => {
        component.collateralDetailsForm = new FormGroup({ executionDate: new FormControl(new Date('2017-07-04')), signingDate: new FormControl(new Date('2017-07-05')) });
        component.reviewExeDateValidator();
        expect(component.executionDateValidate).toBe(true);
    });
    it('reviewExeDateValidator should return false if signing date is less than execute date', () => {
        component.collateralDetailsForm = new FormGroup({ executionDate: new FormControl(new Date('2017-07-06')), signingDate: new FormControl(new Date('2017-07-05')) });
        component.reviewExeDateValidator();
        expect(component.executionDateValidate).toBe(false);
    });
    it('reviewValidator should return true if signing date is greater than execute date', () => {
        component.collateralDetailsForm = new FormGroup({ nextReviewDate: new FormControl(new Date('2017-07-04')), reviewDate: new FormControl(new Date('2017-07-05')) });
        component.reviewValidator();
        expect(component.nextReviewDateValidate).toBe(true);
    });
    it('reviewValidator should return false if signing date is less than execute date', () => {
        component.collateralDetailsForm = new FormGroup({ nextReviewDate: new FormControl(new Date('2017-07-06')), reviewDate: new FormControl(new Date('2017-07-05')) });
        component.reviewValidator();
        expect(component.nextReviewDateValidate).toBe(false);
    });
    it('validateExpDate should return true if Collateral create date is greater than Expiry Date', () => {
        const expDate = new Date();
        expDate.setDate(expDate.getDate() - 1);
        component.collateralDetailsForm = new FormGroup({ expiryDate: new FormControl(expDate)});
        component.validateExpDate({});
        expect(component.expiryDateValidate).toBe(true);
    });
    it('validateExpDate should return false if Collateral create date is less than Expiry Date', () => {
        const expDate = new Date();
        expDate.setDate(expDate.getDate() + 1);
        component.collateralDetailsForm = new FormGroup({ expiryDate: new FormControl(expDate)});
        component.validateExpDate({});
        expect(component.expiryDateValidate).toBe(false);
    });

    it('addFormControls should add controls to formgroup', () => {
        component.collateralDetailsForm = new FormGroup({});
        component.addFormControls();
        expect(component.collateralDetailsForm.get('currencyType')).not.toBe(undefined);
        expect(component.collateralDetailsForm.get('recievedDate')).not.toBe(undefined);
    });
    it('eventFromToggleButton should assign values on change on toggle componemt', () => {
        component.collateralDetailsForm = new FormGroup({ baselEligible: new FormControl()});
        component.eventFromToggleButton('Yes');
        expect(component.collateralDetailsForm.get('baselEligible').value).toBe(true);
        component.eventFromToggleButton('No');
        expect(component.collateralDetailsForm.get('baselEligible').value).toBe(false);
    });
    it('methodEvent should assign values on change on toggle componemt', () => {
        component.collateralDetailsForm = new FormGroup({ method: new FormControl()});
        component.methodEvent('Fixed Amount');
        expect(component.collateralDetailsForm.get('method').value).toBe('Fixed Amount');
        component.methodEvent('All Monies');
        expect(component.collateralDetailsForm.get('method').value).toBe('All Monies');
    });
    it('should call validateSolicitor GeneralDetailsComponent', () => {
        component.validateSolicitorName({ value: undefined });
        expect(component.validateSolicitor).toBe(true);
        component.validateSolicitorName({ value: 2 });
        expect(component.validateSolicitor).toBe(false);
    });
    it('pushToApportion should populate apportion values', () => {
        component.collateralDetailsForm = new FormGroup({ currencyType: new FormControl('INR')});
        component.pushToApportion({amount: 123});
        component.pushToApportion(undefined);
    });
    it('pushToApportion should populate apportion values', () => {
        component.collateralDetailsForm = new FormGroup({ formNo: new FormControl(), recievedDate: new FormControl(),
            signingDate: new FormControl(), applicationDetailsRemarks: new FormControl(),
            executionDate: new FormControl(), reviewDate: new FormControl(), nextReviewDate: new FormControl()});
        component.showApplicationDetails();
        expect(component.collateralDetailsForm.get('nextReviewDate')).not.toBe(undefined);
    });

    it('should check if all monies are allowed based on collateral type' , () =>{
        component.selectedCollateralType = 'GUARN';
        expect(component.isMethodAllowed()).toBe(true);
        component.selectedCollateralType = 'DEPOS';
        expect(component.isMethodAllowed()).toBe(false);
    });
});
