import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SpecificDetailsItemModel } from './specific-details-model';
import { SpecificDetailsService } from './specific-details.service';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { CollateralService } from '../collateral.service';
import { ToastsComponent } from '../../shared/toasts/toasts.component';

@Component({
	selector: 'collateral-specific-details',
	templateUrl: './specific-details.component.html',
	styleUrls: ['./specific-details.component.scss'],
	providers: [SpecificDetailsService, SpecificDetailsItemModel]
})
export class SpecificDetailsComponent implements OnInit {
	public opened: boolean = false;
	public gridData: SpecificDetailsItemModel[] = [];
	public events: any[] = [];
	public bankId: string;
	refDepositObj: any = [];
	refBankIdObj: any = [];
	refDataOnDepositSelect: any;
	sumOfPrincipalAmount: number = 0;
	sumOfAvailableBalance: number = 0;
	sumOfAccountBalance: number = 0;
	public addSpecificDetailsForm: FormGroup;
	showPopupDialog: boolean = false;
	showSpecificDetailsField: boolean = false;
	bankIdValue: string = '';
	bankName: string = '';
	depositAccName: string = '';
	accountBalance: number;
	saveSpecificDetails: boolean = true;
	updateSpecificDetails: boolean = false;
	public rowIndex: number;
	specificDetailsDialogTitle: string;
	divForNormalGrid: boolean = true;
	argToastMessageObject: any;
	divForData: boolean = true;
	accountBalanceCcy: string = '';
	principalAmntCcy: string = '';
	ccyAmountValidate: boolean;
	submitted: boolean;
	bankIdInvalid: boolean;
	depositIdInvalid: boolean;
	collateralCurrency: string;
	collateralValue: number = 0.0;
	showWarningMsg: boolean = false;
	accountBalanceForWarning: number = 0.0;
	toastsComponent: ToastsComponent = new ToastsComponent();
	@Input() showSummaryGrid: boolean = false;
	@Input() showAddSpecificDetailsBtn: boolean = true;
	@Input() public particularsForm: FormGroup;
	public gridDataObj: any;
	public specifiDetailsMain: any;
	public tempUpdateObj: any;
	updateDetailsFlag: boolean;

	constructor(private _fb: FormBuilder, private specificDetailsService: SpecificDetailsService, private collateralService: CollateralService, private tempSpecificDetailsModel: SpecificDetailsItemModel) {
		this.ccyAmountValidate = false;
	}

	ngOnInit() {
		this.customizeSpecificDetailsGridForSummaryComp();
		this.setDataInGrid();
		this.initializeFormGroup();
		this.getBankId();
		this.getGeneralDetails();
		this.convertTotalValueCurrencyInGrid();
	}
	setDataInGrid() {
		if (!this.particularsForm) {
			this.particularsForm = this._fb.group({
				particularsList: [[]]
			});
		}
		if (this.particularsForm.get('particularsList').value && (this.particularsForm.get('particularsList').value !== undefined || this.particularsForm.get('particularsList').value !== null)) {
			this.gridData = this.particularsForm.get('particularsList').value;
		} else {
			this.gridData = [];
		}
		this.divForData = !(this.gridData.length === 0);

	}

	initializeFormGroup() {
		this.addSpecificDetailsForm = this._fb.group({
			bankId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			particularsDepositId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			principalAmount: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			availableBalance: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			accountBalance: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			maturityDate: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			term: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			depositNum: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			branchAccount: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			facilityRef: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			plegorName: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			earmarkReason: [],
			particularsComment: [],
			principalAmntCcy: [],
			availableBalanceCcy: [],
			accountBalanceCcy: ['', [<any>Validators.required, <any>Validators.minLength(0)]]
		});
		this.subscribeToFormChanges();
	}

	subscribeToFormChanges() {
		this.particularsForm.valueChanges.subscribe(data => this.onSpecificDetailsFormChanged(data));
	}

	public openPopDialog() {
		this.bankIdInvalid = false;
		this.depositIdInvalid = false;
		if (this.addSpecificDetailsForm.untouched) {
			this.submitted = false;
		}
		this.showPopupDialog = true;
		this.showSpecificDetailsField = false;
		this.saveSpecificDetails = true;
		this.updateSpecificDetails = false;
		this.specificDetailsDialogTitle = 'Add Specific Details';
	}

	closeEventFromPopupDialog(showPopupDialog: boolean) {
		this.showPopupDialog = showPopupDialog;
		this.addSpecificDetailsForm.reset();
	}

	getGeneralDetails() {
		const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
		const generalDetailObj = this.collateralService.getCollateral().generalDetail;
		this.collateralCurrency = generalDetailObj.currencyCode;
		this.collateralValue = collateralObj.collateralValue.value;
	}

	getBankId() {
		this.specificDetailsService.getBankId().subscribe(
			response => {
				this.refBankIdObj = response;
			},
			error => {
			},
			() => {
			}
		);
	}

	onBankIdSelect(selectedBankId) {
		const dataObj = this.refBankIdObj.find(item => item.bankId === selectedBankId);
		if (((selectedBankId !== 'undefined') || (selectedBankId !== '')) && (dataObj !== undefined)) {
			this.bankIdInvalid = false;
			this.showSpecificDetailsField = false;
			this.bankIdValue = selectedBankId;
			this.specificDetailsService.getDepositId(this.bankIdValue).subscribe(
				response => {
					const responseObj = [];
					responseObj.push(response);
					this.refDepositObj = responseObj;
					this.showSpecificDetailsField = false;
					this.refDataOnDepositSelect = '';
				},
				error => {
				},
				() => {
				}
			);
		} else {
			this.bankIdInvalid = true;
		}
		if (selectedBankId === '') {
			this.showSpecificDetailsField = false;
			this.addSpecificDetailsForm.controls['particularsDepositId'].setValue('');
		}
	}

	onDepositIdSelect(selectedDepositId) {
		this.subscribeToFormChanges();
		const depositDataObj = this.refDepositObj.find(item => item.accountNum === selectedDepositId);
		if (((selectedDepositId !== 'undefined') || (selectedDepositId !== '')) && (depositDataObj !== undefined)) {
			(<FormControl>this.addSpecificDetailsForm.controls['bankId'])
				.setValue(this.bankIdValue);
			this.depositIdInvalid = false;
			this.specificDetailsService.getSpecificDetails(this.bankIdValue, selectedDepositId).subscribe(
				response => {
					this.refDataOnDepositSelect = response;
					this.settingValuesForSpecificDetailsForm();
					this.settingFormControlFromSelectedDepositId();
					this.showSpecificDetailsField = true;
				},
				error => {
					this.showSpecificDetailsField = false;
				},
				() => {
				}
			);
		} else {
			this.depositIdInvalid = true;
		}
		if (selectedDepositId === '') {
			this.showSpecificDetailsField = false;
		}
	}

	private settingValuesForSpecificDetailsForm() {
		this.bankName = this.refDataOnDepositSelect['bankName'];
		this.depositAccName = this.refDataOnDepositSelect['depositAccName'];
	}

	private settingFormControlFromSelectedDepositId() {
		(<FormControl>this.addSpecificDetailsForm.controls['particularsDepositId'])
			.setValue(this.refDataOnDepositSelect['accountNum']);
		(<FormControl>this.addSpecificDetailsForm.controls['maturityDate'])
			.setValue(new Date(this.refDataOnDepositSelect['maturityDate']));
		(<FormControl>this.addSpecificDetailsForm.controls['term'])
			.setValue(this.refDataOnDepositSelect['term']);
		(<FormControl>this.addSpecificDetailsForm.controls['branchAccount'])
			.setValue('xyz');
		(<FormControl>this.addSpecificDetailsForm.controls['facilityRef'])
			.setValue('Yes');
		(<FormControl>this.addSpecificDetailsForm.controls['plegorName'])
			.setValue('Jhon Doe');
		(<FormControl>this.addSpecificDetailsForm.controls['principalAmount'])
			.setValue(this.refDataOnDepositSelect['principalAmount']);
		(<FormControl>this.addSpecificDetailsForm.controls['availableBalance'])
			.setValue(this.refDataOnDepositSelect['availableBalance']);
		(<FormControl>this.addSpecificDetailsForm.controls['accountBalance'])
			.setValue(this.accountBalance, { onlySelf: true });
		(<FormControl>this.addSpecificDetailsForm.controls['principalAmntCcy'])
			.setValue('SGD', { onlySelf: true });
		(<FormControl>this.addSpecificDetailsForm.controls['availableBalanceCcy'])
			.setValue('SGD', { onlySelf: true });
	}

	cancelForm() {
		this.showPopupDialog = false;
		this.showSpecificDetailsField = false;
		this.addSpecificDetailsForm.reset();
	}

	addSpecificDetailsData(data: SpecificDetailsItemModel) {
		this.submitted = true;
		if ((data['accountBalance']) === null || (data['accountBalance']) === undefined || (data['accountBalance'].toString()) === '') {
			this.ccyAmountValidate = true;
		}
		const isDepositIdValid = this.validationCheckForDepositId(data);
		const isBankIdValid = this.validationCheckForBankId(data);
		if (isDepositIdValid && isBankIdValid) {
			if (this.addSpecificDetailsForm.valid) {
				this.specifiDetailsMain = {};
				this.divForData = true;
				this.showPopupDialog = false;
				this.tempSpecificDetailsModel.bankName = this.bankName;
				this.tempSpecificDetailsModel.depositAccName = this.depositAccName;
				this.tempSpecificDetailsModel.bankId = data.bankId;
				this.tempSpecificDetailsModel.particularsDepositId = data.particularsDepositId;
				this.tempSpecificDetailsModel.maturityDate = data.maturityDate;
				this.tempSpecificDetailsModel.earmarkReason = this.checkForRemarksValue(data['earmarkReason']);
				this.tempSpecificDetailsModel.particularsComment = this.checkForRemarksValue(data['particularsComment']);
				this.tempSpecificDetailsModel.term = data.term;
				this.tempSpecificDetailsModel.depositNum = data.depositNum;
				this.tempSpecificDetailsModel.branchAccount = data.branchAccount;
				this.tempSpecificDetailsModel.facilityRef = data.facilityRef;
				this.tempSpecificDetailsModel.plegorName = data.plegorName;
				this.tempSpecificDetailsModel.principalAmount = parseFloat(data['principalAmount'].toString());
				this.tempSpecificDetailsModel.availableBalance = parseFloat(data['availableBalance'].toString());
				this.tempSpecificDetailsModel.accountBalance = parseFloat(data['accountBalance'].toString());
				this.tempSpecificDetailsModel.accountBalanceCcy = data.accountBalanceCcy;
				this.tempSpecificDetailsModel.principalAmntCcy = this.addSpecificDetailsForm.controls['principalAmntCcy'].value;
				this.tempSpecificDetailsModel.availableBalanceCcy = this.addSpecificDetailsForm.controls['availableBalanceCcy'].value;
				this.accountBalanceForWarning = this.tempSpecificDetailsModel.accountBalance;
				this.setMainSpecificData();
				if (this.gridData.length > 0) {
					this.gridData.pop();
				}
				this.gridData.push(this.tempSpecificDetailsModel);
				this.processSumValuesForGrid(this.gridData);
				this.addSummaryRow();
				this.particularsForm.controls['particularsList'].setValue(this.gridData);
				this.addSpecificDetailsForm.reset();
				this.showPopupDialog = false;
				this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
					'A record of Specific details has been successfully Added.',
					'', '');

			}
		}
	}

	updateSpecificDetailsData(data: SpecificDetailsItemModel) {
		const isDepositIdValid = this.validationCheckForDepositId(data);
		const isBankIdValid = this.validationCheckForBankId(data);
		if (isDepositIdValid && isBankIdValid) {
			if (this.addSpecificDetailsForm.valid) {
				data['principalAmount'] = parseFloat(data['principalAmount'].toString());
				data['availableBalance'] = parseFloat(data['availableBalance'].toString());
				data['accountBalance'] = parseFloat(data['accountBalance'].toString());
				data['bankName'] = this.bankName;
				data['depositAccName'] = this.depositAccName;
				data['earmarkReason'] = this.checkForRemarksValue(data['earmarkReason']);
				data['particularsComment'] = this.checkForRemarksValue(data['particularsComment']);
				// Update data in Specific Details Model
				const bankIdInRecordIndex = this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.depositDetails.findIndex(item => item.bankId === this.bankIdValue);
				this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.depositDetails[bankIdInRecordIndex].depositAcctNo = data['depositNum'];
				this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.depositDetails[bankIdInRecordIndex].acctBalance.value = data['accountBalance'];
				this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.depositDetails[bankIdInRecordIndex].acctBalance.ccy = data['accountBalanceCcy'];

				if (this.gridData.length > 1) {
					this.gridData.pop();
				}

				this.gridData[this.rowIndex] = data;
				this.processSumValuesForGrid(this.gridData);
				this.addSummaryRow();
				this.addSpecificDetailsForm.reset();
				this.showPopupDialog = false;
				this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
					'A record of Specific details has been successfully updated.',
					'', '');

				this.particularsForm.controls['particularsList'].setValue(this.gridData);
			}
		}
	}

	validationCheckForDepositId(data?: any) {
		let valid: boolean = false;
		const dataObj = this.refDepositObj.find(item => item.accountNum === data.particularsDepositId);
		if (((dataObj !== 'undefined') || (dataObj !== '')) && (dataObj !== undefined)) {
			this.depositIdInvalid = false;
			valid = true;
		} else {
			this.depositIdInvalid = true;
			valid = false;
		}
		return valid;
	}

	validationCheckForBankId(data?: any) {
		let valid: boolean = false;
		const dataObj = this.refBankIdObj.find(item => item.bankId === data.bankId);
		if (((dataObj !== 'undefined') || (dataObj !== '')) && (dataObj !== undefined)) {
			this.bankIdInvalid = false;
			valid = true;
		} else {
			this.bankIdInvalid = true;
			valid = false;
		}
		return valid;
	}

	setMainSpecificData() {
		this.specifiDetailsMain['depositAcctNo'] = this.tempSpecificDetailsModel.depositNum;
		this.specifiDetailsMain['maturityDate'] = this.tempSpecificDetailsModel.maturityDate;
		this.specifiDetailsMain['term'] = this.tempSpecificDetailsModel.term;
		this.specifiDetailsMain['bankId'] = this.tempSpecificDetailsModel.bankId;
		this.specifiDetailsMain['branchId'] = this.tempSpecificDetailsModel.branchAccount;
		this.specifiDetailsMain['acctBalance'] = {};
		this.specifiDetailsMain['acctBalance']['value'] = this.tempSpecificDetailsModel.accountBalance;
		this.specifiDetailsMain['acctBalance']['ccy'] = this.tempSpecificDetailsModel.accountBalanceCcy;
		this.specifiDetailsMain['principle'] = {};
		this.specifiDetailsMain['principle']['value'] = this.tempSpecificDetailsModel.principalAmount;
		this.specifiDetailsMain['principle']['ccy'] = this.tempSpecificDetailsModel.principalAmntCcy;
		this.specifiDetailsMain['avlblBalance'] = {};
		this.specifiDetailsMain['avlblBalance']['value'] = this.tempSpecificDetailsModel.availableBalance;
		this.specifiDetailsMain['avlblBalance']['ccy'] = this.tempSpecificDetailsModel.availableBalanceCcy;
		this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.depositDetails.push(this.specifiDetailsMain);
	}

	populateTotalAmount(updatedGridData?: any) {
		let accountBalanceCounter = 0;
		let principalAmountCounter = 0;
		let availableBalanceCounter = 0;
		const updatedGridElement = updatedGridData;
		for (let i = 0; i < updatedGridElement.length; i++) {
			if (updatedGridElement[i]['accountBalance'] > 0) {
				accountBalanceCounter = accountBalanceCounter + parseFloat(updatedGridElement[i]['accountBalance'].toString());
			} else {
				accountBalanceCounter = 0;
			}
			if (updatedGridElement[i]['principalAmount'] > 0) {
				principalAmountCounter = principalAmountCounter + parseFloat(updatedGridElement[i]['principalAmount'].toString());
			} else {
				principalAmountCounter = 0;
			}
			if (updatedGridElement[i]['availableBalance'] > 0) {
				availableBalanceCounter = availableBalanceCounter + parseFloat(updatedGridElement[i]['availableBalance'].toString());
			} else {
				availableBalanceCounter = 0;
			}
		}
		this.sumOfPrincipalAmount = principalAmountCounter;
		this.sumOfAvailableBalance = availableBalanceCounter;
		this.sumOfAccountBalance = accountBalanceCounter;
		this.tempSpecificDetailsModel.accountBalance = this.sumOfAccountBalance;
		this.tempSpecificDetailsModel.principalAmount = this.sumOfPrincipalAmount;
		this.tempSpecificDetailsModel.availableBalance = this.sumOfAvailableBalance;
	}

	addSummaryRow() {
		this.tempSpecificDetailsModel = new SpecificDetailsItemModel;
		this.tempSpecificDetailsModel.bankId = 'Total';
		this.tempSpecificDetailsModel.accountBalanceCcy = this.collateralCurrency;
		this.tempSpecificDetailsModel.principalAmntCcy = this.collateralCurrency;
		this.tempSpecificDetailsModel.availableBalanceCcy = this.collateralCurrency;
		this.gridData[this.gridData.length] = this.tempSpecificDetailsModel;
		this.showCollateralValueAmountInWarning();
	}

	public editSpecificDetails(tempSpecificDetailsModel, index: number): void {
		this.bankIdInvalid = false;
		this.depositIdInvalid = false;
		this.showPopupDialog = true;
		this.saveSpecificDetails = false;
		this.updateSpecificDetails = true;
		this.showSpecificDetailsField = true;
		this.specificDetailsDialogTitle = 'Update Specific Details';
		this.rowIndex = index;
		this.bankName = tempSpecificDetailsModel.bankName;
		this.depositAccName = tempSpecificDetailsModel.depositAccName;
		if (tempSpecificDetailsModel !== undefined) {
			this.addSpecificDetailsForm = this._fb.group({
				bankId: [tempSpecificDetailsModel.bankId, [<any>Validators.required, <any>Validators.minLength(0)]],
				particularsDepositId: [tempSpecificDetailsModel.particularsDepositId, [<any>Validators.required, <any>Validators.minLength(0)]],
				principalAmount: [tempSpecificDetailsModel.principalAmount, [<any>Validators.required, <any>Validators.minLength(0)]],
				availableBalance: [tempSpecificDetailsModel.availableBalance, [<any>Validators.required, <any>Validators.minLength(0)]],
				accountBalance: [tempSpecificDetailsModel.accountBalance, [<any>Validators.required, <any>Validators.minLength(0)]],
				maturityDate: [tempSpecificDetailsModel.maturityDate, [<any>Validators.required, <any>Validators.minLength(0)]],
				term: [tempSpecificDetailsModel.term, [<any>Validators.required, <any>Validators.minLength(0)]],
				depositNum: [tempSpecificDetailsModel.depositNum, [<any>Validators.required, <any>Validators.minLength(0)]],
				branchAccount: [tempSpecificDetailsModel.branchAccount, [<any>Validators.required, <any>Validators.minLength(0)]],
				facilityRef: [tempSpecificDetailsModel.facilityRef, [<any>Validators.required, <any>Validators.minLength(0)]],
				plegorName: [tempSpecificDetailsModel.plegorName, [<any>Validators.required, <any>Validators.minLength(0)]],
				earmarkReason: [tempSpecificDetailsModel.earmarkReason],
				particularsComment: [tempSpecificDetailsModel.particularsComment],
				principalAmntCcy: ['SGD'],
				availableBalanceCcy: ['SGD'],
				accountBalanceCcy: [tempSpecificDetailsModel.accountBalanceCcy, [<any>Validators.required, <any>Validators.minLength(0)]]
			});
			this.subscribeToFormChanges();
		}
	}

	public removeClickedSpecificDetailsItem(itemIndex: number) {
		this.rowIndex = itemIndex;
		this.collateralService.getCollateral().LodgeCollateralTypeSpecificDetail.depositDetails.splice(this.rowIndex, 1);
		if (this.gridData.length === 2) {
			this.gridData.splice(this.rowIndex, 2);
		} else {
			this.gridData.splice(this.rowIndex, 1);
		}
		if (this.gridData.length === 0) {
			this.divForData = false;
		} else {
			this.divForData = true;
			if (this.gridData.length > 1) {
				this.gridData.pop();
			}
			this.processSumValuesForGrid(this.gridData);
			this.addSummaryRow();
		}
		this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
			'A record of Specific details has been successfully removed.',
			'', '');
		this.particularsForm.controls['particularsList'].setValue(this.gridData);
	}

	customizeSpecificDetailsGridForSummaryComp() {
		if (this.showSummaryGrid) {
			this.divForNormalGrid = false;
			this.processSumValuesForGrid(this.gridData);
			this.addSummaryRow();
		} else {
			this.divForNormalGrid = true;
		}
	}

	onLabelClicked($event) {
		this.openPopDialog();
	}

	validateCCYAmount(ccy) {
		if (ccy.amount) {
			this.ccyAmountValidate = false;
		} else {
			this.ccyAmountValidate = true;
		}
	}

	private checkForRemarksValue(data: string) {
		if (data === '' || data === null || data === 'undefined') {
			return '-';
		} else {
			return data;
		}
	}

	onSpecificDetailsFormChanged(data?: any) {
		if (this.collateralService.selectedCollateralType === 'GUARN') {
			return;
		}
		let amt = 0;
		let dataList: any[] = [];
		if (data && data.particularsList) {
			dataList = data.particularsList;
			dataList.forEach(p => {
				if (p.accountBalance) {
					amt += p.accountBalance;
				}
			});
		}

		const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
		collateralObj.collateralValue.value = amt;
		collateralObj.finalCollateralValue.value =
			collateralObj.collateralValue.value - collateralObj.externalChargeAmt.value;
		collateralObj.balanceApportionableAmt.value = collateralObj.finalCollateralValue.value - collateralObj.totalApportionedValue.value;
	}

	showCollateralValueAmountInWarning() {
		const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
		this.collateralValue = collateralObj.collateralValue.value;
		if (this.accountBalanceForWarning > this.collateralValue) {
			this.showWarningMsg = true;
			setTimeout(() => {
				this.showWarningMsg = false;
			}, 8000);
		}
	}

	convertTotalValueCurrencyInGrid() {
		if (this.gridData.length > 0) {
			this.gridData.pop();
		}
		this.processSumValuesForGrid(this.gridData);
		this.addSummaryRow();
	}

	processSumValuesForGrid(gridElement?: any, from?: any, to?: any) {
		this.gridDataObj = JSON.parse(JSON.stringify(this.gridData));
		for (let i = 0; i < gridElement.length; i++) {
			this.specificDetailsService.getRateValues(gridElement[i].principalAmntCcy, this.collateralCurrency).subscribe(data => {
				if (data.length > 0) {
					const rate: any = data[0]['rate'];
					if (rate !== undefined) {
						this.gridDataObj[i].principalAmount = this.gridDataObj[i].principalAmount * rate;
						this.populateTotalAmount(this.gridDataObj);
					}
				} else {
					this.gridDataObj[i].principalAmount = 0;
					this.populateTotalAmount(this.gridDataObj);
				}
			});

			this.specificDetailsService.getRateValues(gridElement[i].accountBalanceCcy, this.collateralCurrency).subscribe(data => {
				if (data.length > 0) {
					const rate: any = data[0]['rate'];
					if (rate !== undefined) {
						this.gridDataObj[i].accountBalance = this.gridDataObj[i].accountBalance * rate;
						this.populateTotalAmount(this.gridDataObj);
					}
				} else {
					this.gridDataObj[i].accountBalance = 0;
					this.populateTotalAmount(this.gridDataObj);
				}
			});

			this.specificDetailsService.getRateValues(gridElement[i].availableBalanceCcy, this.collateralCurrency).subscribe(data => {
				if (data.length > 0) {
					const rate: any = data[0]['rate'];
					if (rate !== undefined) {
						this.gridDataObj[i].availableBalance = this.gridDataObj[i].availableBalance * rate;
						this.populateTotalAmount(this.gridDataObj);
					}
				} else {
					this.gridDataObj[i].availableBalance = 0;
					this.populateTotalAmount(this.gridDataObj);
				}
			});
		}

	}

}

