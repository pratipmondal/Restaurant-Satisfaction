import { TestBed, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { fakeAsync } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { environment } from '../../../environments/environment';
import { SpecificDetailsService } from './specific-details.service';

describe('SpecificDetailsService', () => {
  let specificDetailsService: SpecificDetailsService;
  let mockBackend: MockBackend;
  const bankIdValue = 'bank1';
  const selectedDepositId = '123';
  const urlToGetBankID = environment.apiBaseUrl + environment.apitToGetBankId;
  const urlToGetDepositId = environment.apiBaseUrl + environment.apiToGetDepositId + '=' + bankIdValue;
  const urlToGetSpecificDetails = environment.apiBaseUrl + environment.apiToGetDepositId + '='
    + bankIdValue + environment.apiToGetSpecificDetails + '=' + selectedDepositId;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        { provide: XHRBackend, useClass: MockBackend },
        SpecificDetailsService
      ],
      imports: [HttpModule]
    });
  });

  beforeEach(
    inject([SpecificDetailsService, MockBackend], (service: SpecificDetailsService, backend: MockBackend) => {
      specificDetailsService = service;
      mockBackend = backend;
    })
  );

  it('should ...', inject([SpecificDetailsService], (service: SpecificDetailsService) => {
    expect(service).toBeTruthy();
  }));

  it('Specific Details - should connect mock service api for Bank Id', fakeAsync(() => {
    specificDetailsService.getBankId();
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe(urlToGetBankID);
    });
  }));

  it('Specific Details - should give response for Bank Id',
    inject([SpecificDetailsService, XHRBackend], (SpecificDetailsService, backend) => {

      const mockResponse = {
        data: [
          { bankId: 'bank1' },
          { bankId: 'bank2' }
        ]
      };

      backend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      SpecificDetailsService.getBankId().subscribe((bankId) => {
        expect(bankId.length).toBe(2);
        expect(bankId[0].bankId).toEqual('bank1');
        expect(bankId[1].bankId).toEqual('bank2');
      });
    }));

  it('Specific Details - should connect mock service api for Deposit Id', fakeAsync(() => {
    specificDetailsService.getDepositId(bankIdValue);
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe(urlToGetDepositId);
    });
  }));

  it('Specific Details - should give response for Deposit Id on selected Bank Id',
    inject([SpecificDetailsService, XHRBackend], (SpecificDetailsService, backend) => {

      const mockResponse = {
        data: [
          { depsoitId: 123 },
          { depsoitId: 456 }
        ]
      };

      backend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });

      SpecificDetailsService.getBankId().subscribe((depsoitId) => {
        expect(depsoitId.length).toBe(2);
        expect(depsoitId[0].depsoitId).toEqual(123);
        expect(depsoitId[1].depsoitId).toEqual(456);
      });
    }));

  it('Specific Details - should connect mock service api for getting Specific Details on Deposit Id', fakeAsync(() => {
    specificDetailsService.getSpecificDetails(bankIdValue, selectedDepositId);
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.url).toBe(urlToGetSpecificDetails);
    });
  }));

});
