import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable()
export class SpecificDetailsService {
	public ratesUrl = environment.apiBaseUrl + 'rate';

	constructor(private http: Http) {
	}

	public getBankId(): Observable<any> {
		const urlToGetBankID = environment.apiBaseUrl + environment.apitToGetBankId;
		return this.http.get(urlToGetBankID)
			.map(this.extractData)
			.catch(error => this.handleError(error));
		function onSuccess(resp: Response) {
			return (resp.json());
		}
	}

	public getDepositId(bankIdValue: string): Observable<any> {
		const urlToGetDepositID = environment.apiBaseUrl + environment.apiToGetDepositId + '=' + bankIdValue;
		return this.http.get(urlToGetDepositID)
			.map(this.extractData)
			.catch(error => this.handleError(error));
		function onSuccess(resp: Response) {
			return (resp.json());
		}
	}

	public getSpecificDetails(bankIdValue: string, selectedDepositId: string): Observable<any> {
		const urlToGetSpecificDetails = environment.apiBaseUrl + environment.apiToGetDepositId + '='
			+ bankIdValue + environment.apiToGetSpecificDetails + '=' + selectedDepositId;
		return this.http.get(urlToGetSpecificDetails)
			.map(this.extractData)
			.catch(error => this.handleError(error));
		function onSuccess(resp: Response) {
			return (resp.json());
		}
	}

	getRateValues(fromCurreny: string, toCurrency: string): Observable<any> {
		const params: URLSearchParams = new URLSearchParams();
		const filter = '{"where":{"fromCurrency": "' + fromCurreny + '","toCurrency": "' + toCurrency + '"}}';
		params.set('filter', filter);
		return this.http.get(this.ratesUrl, {search: params})
			.map(this.extractData)
			.catch(error => this.handleError(error));
	}

	private extractData(res: Response) {
		const body = res.json();
		return body;
	}

	private handleError(error: any): Promise<any> {
		return Promise.reject(error.message || error);
	}

}
