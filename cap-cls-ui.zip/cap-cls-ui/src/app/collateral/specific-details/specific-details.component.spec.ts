import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule, By } from '@angular/platform-browser';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { SpecificDetailsComponent } from './specific-details.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Observable } from 'rxjs/Rx';
import { AutoCompleteModule, DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { IntlModule } from '@progress/kendo-angular-intl';
import { CommonUIModule } from '../../common/commonUI.module';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { Collateral, CollateralValuationDetail } from '../../collateral/model/collateral';
import { CollateralService } from '../collateral.service';
import { SpecificDetailsService } from './specific-details.service';
import { SpecificDetailsItemModel } from './specific-details-model';
import { DeposLodgeCollateralTypeSpecificDetail } from '../model/collateral';
import { depositDetails } from './specific-details-data';

class MockSpecificDetailsService {
	getRateValues(from: string, to: string) {
		if (from === '' && to === '') {
			return Observable.throw({ status: 404 });

		} else {
			const data = [{ 'rate': 1 }];
			return Observable.of(data);
		}
	}

	getMockSpecificDetails(data: any) {
		return Observable.of(data);
	}

	getBlankSpecificDetailsData() {
		return Observable.of([]);
	}

	getSpecificDetailsData(data: any) {
		return data;
	}
}

class MockCollateralService {
	getCollateral() {
		return new Collateral();
	}
}

class MockFormBuilder extends FormBuilder {
	setMainFormWithSpecificDetailsVal(data: any) {
		const mockSpecificDetailsService: MockSpecificDetailsService = new MockSpecificDetailsService();
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			particularsList: [data, [Validators.required]]
		});
		return formGroup;
	}

	getBlankForm() {
		const FB = new FormBuilder;
		const FG = FB.group({
			bankId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			particularsDepositId: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			principalAmount: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			availableBalance: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			accountBalance: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			maturityDate: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			term: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			depositNum: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			branchAccount: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			facilityRef: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			plegorName: ['', [<any>Validators.required, <any>Validators.minLength(0)]],
			earmarkReason: [],
			particularsComment: [],
			principalAmntCcy: ['SGD'],
			availableBalanceCcy: ['SGD'],
			accountBalanceCcy: ['SGD', [<any>Validators.required, <any>Validators.minLength(0)]]
		});
		return FG;
	}

	getAddForm() {
		const FB: FormBuilder = new FormBuilder;
		const FG: FormGroup = FB.group({
			bankId: ['bank1', [<any>Validators.required, <any>Validators.minLength(0)]],
			particularsDepositId: ['123', [<any>Validators.required, <any>Validators.minLength(0)]],
			principalAmount: ['5000', [<any>Validators.required, <any>Validators.minLength(0)]],
			availableBalance: ['6000', [<any>Validators.required, <any>Validators.minLength(0)]],
			accountBalance: ['8000', [<any>Validators.required, <any>Validators.minLength(0)]],
			maturityDate: ['19Jun2018', [<any>Validators.required, <any>Validators.minLength(0)]],
			term: ['Term 1', [<any>Validators.required, <any>Validators.minLength(0)]],
			depositNum: ['DP1', [<any>Validators.required, <any>Validators.minLength(0)]],
			branchAccount: ['DBS Singapore', [<any>Validators.required, <any>Validators.minLength(0)]],
			facilityRef: ['Yes', [<any>Validators.required, <any>Validators.minLength(0)]],
			plegorName: ['Marissa', [<any>Validators.required, <any>Validators.minLength(0)]],
			earmarkReason: [],
			particularsComment: ['SGD'],
			principalAmntCcy: ['SGD'],
			availableBalanceCcy: ['SGD'],
			accountBalanceCcy: ['SGD', [<any>Validators.required, <any>Validators.minLength(0)]]
		});
		return FG;
	}
}

describe('SpecificDetailsComponent', () => {
	let component: SpecificDetailsComponent;
	let fixture: ComponentFixture<SpecificDetailsComponent>;

	const SpecificDetailsData = {
		'bankId': 'bank1',
		'bankName': 'DBS',
		'depositAccName': 'Marissa',
		'particularsDepositId': '123',
		'principalAmount': 1000.10,
		'availableBalance': 12989,
		'accountBalance': 320000,
		'maturityDate': '21 Apr 2017',
		'term': 'term 1',
		'depositNum': 'DN123',
		'branchAccount': 'DBS Singapore',
		'facilityRef': 'Yes',
		'plegorName': 'Marissa',
		'earmarkReason': ' ',
		'particularsComment': ' ',
		'principalAmntCcy': 'SGD',
		'availableBalanceCcy': 'SGD',
		'accountBalanceCcy': 'SGD'
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				CommonModule, PopupDialogModule, BrowserModule, BrowserAnimationsModule, HttpModule, GridModule,
				ButtonsModule, FormsModule, ReactiveFormsModule, AutoCompleteModule, DropDownListModule, DateInputsModule,
				IntlModule, CommonUIModule, LoaderModule, ClsSharedCommonModule
			],
			declarations: [SpecificDetailsComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA],
			providers: [{ provide: CollateralService, useClass: MockCollateralService },
			{ provide: SpecificDetailsService },
			{ provide: FormBuilder, useClass: MockFormBuilder }
			]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(SpecificDetailsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('Should show normalgrid on init',
		async(() => {
			component.divForNormalGrid = true;
			component.showSummaryGrid = false;
			expect(component.divForNormalGrid).toBe(true);
			component.customizeSpecificDetailsGridForSummaryComp();
			if (component.showSummaryGrid) {
				expect(component.divForNormalGrid).toBe(false);
			} else {
				expect(component.divForNormalGrid).toBe(true);
			}
		}));

	it('PopDialog should be disabled',
		async(() => {
			expect(component.showPopupDialog).toBe(false);
		}));

	it('should display Add Specific Details', async(() => {
		let de: DebugElement;
		let el: HTMLElement;
		de = fixture.debugElement.query(By.css('button.add-specific-details-btn'));
		el = de.nativeElement;
		fixture.detectChanges();
		expect(el.textContent).toContain('Add Specific Details');
	}));

	it('open pop dialog ', async(() => {
		let de: DebugElement;
		let el: HTMLElement;
		de = fixture.debugElement.query(By.css('button.add-specific-details-btn'));
		el = de.nativeElement;
		fixture.detectChanges();
		expect(el.textContent).toContain('Add Specific Details');
	}));

	it('Should open popup on click event of Add Specific Details button ', async(() => {
		fixture.detectChanges();
		component.showPopupDialog = false;
		component.openPopDialog();
		expect(component.showPopupDialog).toBe(true);
		expect(component.bankIdInvalid).toBe(false);
		expect(component.depositIdInvalid).toBe(false);
		expect(component.showSpecificDetailsField).toBe(false);
		expect(component.saveSpecificDetails).toBe(true);
		expect(component.updateSpecificDetails).toBe(false);
		if (component.addSpecificDetailsForm.untouched) {
			expect(component.submitted).toBe(false);
		}
	}));

	it('PopDialog box should be close on closeEventFromPopupDialog',
		async(() => {
			fixture.detectChanges();
			component.showPopupDialog = true;
			component.closeEventFromPopupDialog(false);
			expect(component.showPopupDialog).toBe(false);
		}));

	it('Cancel button should close the popup', async(() => {
		fixture.detectChanges();
		component.cancelForm();
		expect(component.showPopupDialog).toBe(false);
		expect(component.showSpecificDetailsField).toBe(false);
	}));

	it('Should show normalgrid on init', (async () => {
		component.divForNormalGrid = true;
		component.showSummaryGrid = false;
		expect(component.divForNormalGrid).toBe(true);
	}));

	it('should show no-record-component-found when no data from service',
		async(() => {
			component.gridData = [];
			component.setDataInGrid();
			expect(component.divForData).toBe(false);
		}));

	it('should not show no-record-component-found when data will come from service',
		async(() => {
			const mockFormBuilder = new MockFormBuilder();
			component.particularsForm = mockFormBuilder.setMainFormWithSpecificDetailsVal(SpecificDetailsData);
			const mockSpecificDetailsService: MockSpecificDetailsService = new MockSpecificDetailsService();
			component.gridData = mockSpecificDetailsService.getSpecificDetailsData(SpecificDetailsData);
			component.setDataInGrid();
			expect(component.divForData).toBe(true);
		}));

	it('Specific Details form should be defined onclick of Add Specific Details button',
		async(() => {
			fixture.detectChanges();
			const mockFormBuilder = new MockFormBuilder();
			component.addSpecificDetailsForm = mockFormBuilder.getBlankForm();
			component.showPopupDialog = false;
			expect(component.addSpecificDetailsForm).toBeDefined();
		}));

	it('Data should not add to grid if form Invalid', async(() => {
		fixture.detectChanges();
		component.showPopupDialog = false;
		const mockFormBuilder = new MockFormBuilder();
		component.addSpecificDetailsForm = mockFormBuilder.getAddForm();
		component.addSpecificDetailsData(component.addSpecificDetailsForm.value);
		component.refDepositObj = [{ accountNum: '123' }];
		component.refBankIdObj = [{ bankId: 'bank1' }];
		expect(component.addSpecificDetailsForm.invalid).toBeFalsy();
	}));

	it('Data should update to grid on click of update button',
		async(() => {
			fixture.detectChanges();
			component.refDepositObj = [{ accountNum: '123' }];
			component.refBankIdObj = [{ bankId: 'bank1' }];
			const mockFormBuilder = new MockFormBuilder();
			component.addSpecificDetailsForm = mockFormBuilder.getBlankForm();
			component.updateSpecificDetailsData(component.addSpecificDetailsForm.value);
			const item: SpecificDetailsItemModel = new SpecificDetailsItemModel;
			item.bankName = SpecificDetailsData.bankName;
			item.depositAccName = SpecificDetailsData.depositAccName;
			item.bankId = SpecificDetailsData.bankId;
			item.particularsDepositId = SpecificDetailsData.particularsDepositId;
			item.maturityDate = SpecificDetailsData.maturityDate;
			item.earmarkReason = SpecificDetailsData.earmarkReason;
			item.particularsComment = SpecificDetailsData.particularsComment;
			item.term = SpecificDetailsData.term;
			item.depositNum = SpecificDetailsData.depositNum;
			item.branchAccount = SpecificDetailsData.branchAccount;
			item.facilityRef = SpecificDetailsData.facilityRef;
			item.plegorName = SpecificDetailsData.plegorName;
			item.principalAmount = parseFloat(SpecificDetailsData.principalAmount.toString());
			item.availableBalance = parseFloat(SpecificDetailsData.availableBalance.toString());
			item.accountBalance = parseFloat(SpecificDetailsData.accountBalance.toString());
			component.gridData.push(item);
			expect(component.gridData.length).toBeGreaterThan(0);
			expect(component.showPopupDialog).toBeFalsy();
		}));

	it('PopUp dialog should open with populated fields on click of Edit button',
		async(() => {
			fixture.detectChanges();
			const mockFormBuilder = new MockFormBuilder();
			component.addSpecificDetailsForm = mockFormBuilder.getAddForm();
			const mockUpdatedSpecificDetailsData = new SpecificDetailsItemModel();
			mockUpdatedSpecificDetailsData['bankName'] = 'DBS Singapore';
			mockUpdatedSpecificDetailsData['bankId'] = 'bank1';
			mockUpdatedSpecificDetailsData['depositNum'] = '123';
			mockUpdatedSpecificDetailsData['particularsDepositId'] = '123';
			mockUpdatedSpecificDetailsData['principalAmount'] = 1000;
			mockUpdatedSpecificDetailsData['availableBalance'] = 1000;
			mockUpdatedSpecificDetailsData['accountBalance'] = 1000;
			mockUpdatedSpecificDetailsData['maturityDate'] = '18 June 2017';
			mockUpdatedSpecificDetailsData['term'] = 'term1';
			mockUpdatedSpecificDetailsData['facilityRef'] = 'Yes';
			mockUpdatedSpecificDetailsData['plegorName'] = 'Marissa';
			mockUpdatedSpecificDetailsData['earmarkReason'] = 'Earmark Comment';
			mockUpdatedSpecificDetailsData['particularsComment'] = 'Other Comments';
			const rowIndex = 1;
			component.editSpecificDetails(mockUpdatedSpecificDetailsData, rowIndex);
			expect(component.addSpecificDetailsForm.controls['bankId'].value).toBe('bank1');
			expect(component.bankIdInvalid).toBeFalsy();
			expect(component.depositIdInvalid).toBeFalsy();
			expect(component.saveSpecificDetails).toBeFalsy();
			expect(component.showPopupDialog).toBeTruthy();
			expect(component.updateSpecificDetails).toBeTruthy();
			expect(component.showSpecificDetailsField).toBeTruthy();
			expect(component.specificDetailsDialogTitle).toBe('Update Specific Details');
		}));

	it('On onBankIdSelect function check for selecting bank id',
		async(() => {
			const BankId = [
				{ bankId: 'bank1' },
				{ bankid: 'bank2' }
			];
			fixture.detectChanges();
			component.refBankIdObj = BankId;
			component.onBankIdSelect('bank1');
			expect(component.bankIdValue).toEqual('bank1');
			expect(component.bankIdInvalid).toBeFalsy();
			expect(component.showSpecificDetailsField).toBeFalsy();
		}));

	it('should not give deposit id if selected bank id is invalid onBankIdSelect function',
		async(() => {
			fixture.detectChanges();
			component.onBankIdSelect('');
			expect(component.bankIdInvalid).toBeTruthy();
			expect(component.showSpecificDetailsField).toBeFalsy();
			expect(component.addSpecificDetailsForm.controls['particularsDepositId'].value).toBe('');
		}));

	it('On onDepositIdSelect function check for selecting deposit id',
		async(() => {
			fixture.detectChanges();
			component.refDepositObj = [{ accountNum: '123' }];
			component.onDepositIdSelect('123');
			expect(component.depositIdInvalid).toBeFalsy();
		}));

	it('should not show specific details if selected deposit id is invalid onDepositIdSelect function',
		async(() => {
			fixture.detectChanges();
			component.onDepositIdSelect('');
			expect(component.depositIdInvalid).toBeTruthy();
			expect(component.showSpecificDetailsField).toBeFalsy();
		}));

	it('show collateral value amount on save and update of specific details', async(() => {
		fixture.detectChanges();
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		const collateral: Collateral = new Collateral;
		const collateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail;
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		collateralValuationDetail.collateralValue.value = 0.00;
		component.accountBalanceForWarning = 200.00;
		component.showCollateralValueAmountInWarning();
		expect(component.showWarningMsg).toBe(true);
	}));

	it('should show selected collateral currency if grid data visible - on ng oninit',
		async(() => {
			const mockFormBuilder = new MockFormBuilder();
			component.particularsForm = mockFormBuilder.setMainFormWithSpecificDetailsVal(SpecificDetailsData);
			const mockSpecificDetailsService: MockSpecificDetailsService = new MockSpecificDetailsService();
			component.gridData = mockSpecificDetailsService.getSpecificDetailsData(SpecificDetailsData);
			component.convertTotalValueCurrencyInGrid();
			expect(component.processSumValuesForGrid).toHaveBeenCalled;
			expect(component.addSummaryRow).toHaveBeenCalled;
		}));

});
