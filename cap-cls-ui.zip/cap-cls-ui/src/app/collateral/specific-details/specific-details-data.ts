export const depositDetails = [{
	'depositAcctNo': 'depAcct1',
	'maturityDate': '2017-06-02T12:33:43.707Z',
	'term': 0,
	'acctBalance': {
		'value': 30000,
		'ccy': 'SGD',
		'_isDeleted': false
	},
	'avlblBalance': {
		'value': 0,
		'ccy': '',
		'_isDeleted': false
	},
	'proposedAmt': {
		'value': 0,
		'ccy': '',
		'_isDeleted': false
	},
	'approvedAmt': {
		'value': 0,
		'ccy': '',
		'_isDeleted': false
	},
	'bankId': '',
	'bankIdentifierCode': '',
	'branchId': '',
	'comments': '',
	'delete': false,
	'principle': {
		'ccy': 'SGD',
		'value': 40000,
		'_isDeleted': false
	}
}
];
