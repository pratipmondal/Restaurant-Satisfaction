export class SpecificDetailsItemModel {
	bankName: string;
	bankId: string;
	depositAccName: string;
	depositNum: string;
	particularsDepositId: string;
	principalAmount: number;
	availableBalance: number;
	accountBalance: number;
	maturityDate: string;
	term: string;
	branchAccount: string;
	facilityRef: string;
	plegorName: string;
	earmarkReason: string;
	particularsComment: string;
	accountBalanceCcy: string;
	principalAmntCcy: string;
	availableBalanceCcy: string;

	constructor() {
		this.bankName = '';
		this.bankId = '';
		this.depositAccName = '';
		this.depositNum = '';
		this.particularsDepositId = '';
		this.principalAmount = 0;
		this.availableBalance = 0;
		this.accountBalance = 0;
		this.maturityDate = '';
		this.term = '';
		this.branchAccount = '';
		this.facilityRef = '';
		this.plegorName = '';
		this.earmarkReason = '';
		this.particularsComment = '';
		this.accountBalanceCcy = '';
		this.principalAmntCcy = '';
		this.availableBalanceCcy = '';
	}
}
