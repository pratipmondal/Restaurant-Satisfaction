import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpecificDetailsComponent } from './specific-details.component';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { IntlModule } from '@progress/kendo-angular-intl';
import { CommonUIModule } from '../../common/commonUI.module';
import { SpecificDetailsItemModel } from './specific-details-model';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';

@NgModule({
  imports: [
    CommonModule, PopupDialogModule, BrowserModule, BrowserAnimationsModule, HttpModule, GridModule,
    ButtonsModule, FormsModule, ReactiveFormsModule, AutoCompleteModule, DropDownListModule, DateInputsModule,
    IntlModule, CommonUIModule, LoaderModule, ClsSharedCommonModule
  ],
  declarations: [SpecificDetailsComponent],
  exports: [SpecificDetailsComponent],
  providers: []
})

export class SpecificDetailsModule {
  public static forRoot(): ModuleWithProviders {
    return { ngModule: SpecificDetailsModule, providers: [] };
  }
}
