import { MockBackend, MockConnection } from '@angular/http/testing';
import { environment } from '../../../environments/environment';
import { inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, RequestMethod } from '@angular/http';
import { ChargeService } from './charge.component.service';
import { Observable } from 'rxjs/Observable';
import { ChargeRankJSON, NatureOfCharges } from './charge.data';

class MockChargeService {
	getNatureOfCharges() {
		return Observable.of(NatureOfCharges);
	}

	getChargeRank() {
		return Observable.of(ChargeRankJSON);
	}
}

describe('ChargeService', () => {
	let mockBackend: MockBackend;
	let chargeService: ChargeService;

	const urlToGetNatureOfCharges = environment.apiBaseUrl + environment.apiToGetNatureOfCharges;
	const urlToGetChargeRank = environment.apiBaseUrl + environment.apiToGetChargeRank;

	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				MockBackend,
				BaseRequestOptions,
				{
					provide: Http,
					useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
						return new Http(backend, options);
					},
					deps: [MockBackend, BaseRequestOptions]
				},
				{provide: ChargeService, useClass: MockChargeService}
			],
			imports: [HttpModule]
		});
	});

	beforeEach(
		inject([ChargeService, MockBackend], (service: ChargeService, backend: MockBackend) => {
			chargeService = service;
			mockBackend = backend;
		})
	);
	it(' service should be defined', () => {
		expect(chargeService).toBeDefined();
	});

	it('should call getNatureOfCharges API from service', () => {
		spyOn(chargeService, 'getNatureOfCharges').and.returnValue(NatureOfCharges);
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(urlToGetNatureOfCharges);
		});
		expect(chargeService.getNatureOfCharges()).toEqual(NatureOfCharges);
	});

	it('should call getChargeRank API from service', () => {
		spyOn(chargeService, 'getChargeRank').and.returnValue(ChargeRankJSON);
		mockBackend.connections.subscribe((connection: MockConnection) => {
			expect(connection.request.method).toBe(RequestMethod.Get);
			expect(connection.request.url).toBe(urlToGetChargeRank);
		});
		expect(chargeService.getChargeRank()).toEqual(ChargeRankJSON);
	});
});
