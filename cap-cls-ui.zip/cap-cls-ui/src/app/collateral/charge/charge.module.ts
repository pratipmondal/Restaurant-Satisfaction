import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, ModuleWithProviders, NgModule } from '@angular/core';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { ChargeComponent } from './charge.component';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { CommonUIModule } from '../../common/commonUI.module';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { ToggleButtonModule } from '../../common/toggle-button/toggle-button.module';
import { IntlModule } from '@progress/kendo-angular-intl';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { ChargeService } from './charge.component.service';

@NgModule({
	imports: [CommonModule, BrowserModule, LoaderModule, GridModule, DialogModule,
		ButtonsModule, InputsModule, ReactiveFormsModule, AutoCompleteModule,
		DateInputsModule, CommonUIModule, PopupDialogModule, ToggleButtonModule,
		IntlModule, ClsSharedCommonModule],
	declarations: [ChargeComponent],
	providers: [ChargeService],
	exports: [ChargeComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class ChargeModule {
	public static forRoot(): ModuleWithProviders {
		return {ngModule: ChargeModule, providers: []};
	}
}
