import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';

@Injectable()
export class ChargeService {

	public urlToGetNatureOfCharges = environment.apiBaseUrl + environment.apiToGetNatureOfCharges;
	public urlToGetChargeRank = environment.apiBaseUrl + environment.apiToGetChargeRank;

	constructor(private http: Http) {

	}

	public getNatureOfCharges(): Observable<any> {
		return this.http.get(this.urlToGetNatureOfCharges)
			.map(
				res => res.json()
			);
	}

	public getChargeRank(): Observable<any> {
		return this.http.get(this.urlToGetChargeRank)
			.map(
				res => res.json()
			);
	}

}
