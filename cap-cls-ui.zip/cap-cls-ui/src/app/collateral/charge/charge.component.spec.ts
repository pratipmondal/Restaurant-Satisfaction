import { ChargeComponent } from './charge.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { AutoCompleteModule } from '@progress/kendo-angular-dropdowns';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { LoaderModule } from '../../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { ClsSharedCommonModule } from '../../shared/shared-common.module';
import { IntlModule } from '@progress/kendo-angular-intl';
import { ToggleButtonModule } from '../../common/toggle-button/toggle-button.module';
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { Collateral, CollateralValuationDetail } from '../model/collateral';
import { CollateralService } from '../collateral.service';
import { Observable } from 'rxjs/Observable';
import { ChargeService } from './charge.component.service';
import { ChargeRankJSON, ChargeRankList, NatureOfCharges } from './charge.data';
import { ChargeDataModel } from './charge.model';
import { CurrencyDropdownService } from '../../common/currency-dropdown/currency-dropdown.service';

class MockChargeService {
	getNatureOfCharges() {
		return Observable.of(NatureOfCharges);
	}

	getBlankChargeData() {
		return Observable.of([]);
	}

	getOneChargeData(data: any) {
		return data;
	}

	getChargeRank() {
		return Observable.of(ChargeRankJSON);
	}
}
class MockCollateralService {
	getCollateral() {
		return new Collateral();
	}
}
class MockFormBuilder extends FormBuilder {

	getBlankForm() {
		const formBuilder = new FormBuilder;
		const formGroup = formBuilder.group({
			natureOfCharge: ['', [Validators.required]],
			chargeRankToSubmit: ['', [Validators.required]],
			chargeRankToShow: ['', [Validators.required]],
			chargeAmount: ['', [Validators.required]],
			filingDate: ['', [Validators.required]],
			receiptDate: ['', [Validators.required]],
			registrationAuthInfo: [],
			currencyType: ['', [Validators.required]]
		});
		return formGroup;
	}

	getAddChargeForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			natureOfCharge: ['CHARGENAT1', [Validators.required]],
			chargeRankToSubmit: [1, [Validators.required]],
			chargeRankToShow: ['1ST', [Validators.required]],
			chargeAmount: [100000.00, [Validators.required]],
			filingDate: ['2017-05-12T07:06:17.255Z', [Validators.required]],
			receiptDate: ['2017-05-12T07:06:17.255Z', [Validators.required]],
			registrationAuthInfo: ['ABCD'],
			currencyType: ['SGD', [Validators.required]]
		});
		return formGroup;
	}

	setMainForm() {
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			chargeList: ['', [Validators.required]]
		});
		return formGroup;
	}

	setMainFormWithChargeListVal(data: any) {
		const mockChargeService: MockChargeService = new MockChargeService();
		const formBuilder: FormBuilder = new FormBuilder;
		const formGroup: FormGroup = formBuilder.group({
			chargeList: [data, [Validators.required]]
		});
		return formGroup;
	}

}

class MockCurrencyService {
	getCurrencies(filter?: any) {
		return {
			body: [
				{
					'code': 'SGD',
					'description': 'SGD Currency',
					'id': '5f30e506-a276-4865-95aa-210667ded1a8'
				},
				{
					'code': 'EUR',
					'description': 'EUR Currency',
					'id': '6acc19da-6c8a-441d-ba8b-7d41efbe9ab9'
				}],
			subscribe: function (data?: any) {
			}
		};
	}
}

describe('Component : ChargeComponent', () => {

	let chargeComponent: ChargeComponent;
	let fixture: ComponentFixture<ChargeComponent>;
	const chargeData = {
		'natureOfCharge': 'Dummy',
		'chargeRank': 0,
		'externalCharge': 'No',
		'chargeAmount': 200000.08,
		'filingDate': '21 Apr 2017',
		'receiptDate': '20 Apr 2017',
		'registrationAuthInfo': '-',
		'currencyType': 'SGD'
	};

	const chargeDataForForm = {
		'natureOfCharge': 'Dummy',
		'chargeRankToShow': '1DBS',
		'chargeRankToSubmit': 0,
		'externalCharge': 'No',
		'chargeAmount': 200000.08,
		'filingDate': '21 Apr 2017',
		'receiptDate': '20 Apr 2017',
		'registrationAuthInfo': '-',
		'currencyType': 'SGD'
	};

	beforeEach(async(() => {
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
		TestBed.configureTestingModule({
			imports: [CommonModule, BrowserModule, LoaderModule, GridModule, DialogModule,
				ButtonsModule, InputsModule, ReactiveFormsModule, AutoCompleteModule,
				DateInputsModule, CommonUIModule, PopupDialogModule, ToggleButtonModule,
				IntlModule, ClsSharedCommonModule],
			declarations: [ChargeComponent],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [
				{provide: CollateralService, useClass: MockCollateralService},
				{provide: FormBuilder, useClass: MockFormBuilder},
				{provide: ChargeService, useClass: MockChargeService},
				{provide: CurrencyDropdownService, useClass: MockCurrencyService}
			]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ChargeComponent);
		chargeComponent = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(chargeComponent).toBeTruthy();
	});

	it('should show no-record-component-found when no data from service', () => {
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.chargeGridData = mockChargeService.getBlankChargeData();
		chargeComponent.setUpChargeComponent();
		expect(chargeComponent.divForNoData).toBe(true);
	});

	it('should not show no-record-component-found', () => {
		const mockFormBuilder = new MockFormBuilder();
		chargeComponent.chargeForm = mockFormBuilder.setMainFormWithChargeListVal(chargeData);
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.chargeGridData = mockChargeService.getOneChargeData(chargeData);
		chargeComponent.setUpChargeComponent();
		expect(chargeComponent.divForNoData).toBe(false);
	});

	it('Charge data should get added to grid on click of save button', async(() => {
		fixture.detectChanges();
		const mockFormBuilder = new MockFormBuilder();
		chargeComponent.chargeRankList = ChargeRankJSON;
		chargeComponent.chargeRankResponse = ChargeRankList;
		chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.natureOfCharges = mockChargeService.getNatureOfCharges();
		chargeComponent.addChargeData(mockChargeService.getOneChargeData(chargeDataForForm));
		expect(chargeComponent.chargeGridData.length).toBeGreaterThan(0);
	}));

	it('should show summary grid', async(() => {
		const mockFormBuilder = new MockFormBuilder();
		chargeComponent.chargeForm = mockFormBuilder.setMainFormWithChargeListVal(chargeData);
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.chargeGridData = mockChargeService.getOneChargeData(chargeData);
		chargeComponent.showSummaryGrid = true;
		chargeComponent.setUpChargeComponent();
		expect(chargeComponent.showSummaryGrid).toBe(true);
	}));

	it('should show normal grid', async(() => {
		const mockFormBuilder = new MockFormBuilder();
		chargeComponent.chargeForm = mockFormBuilder.setMainFormWithChargeListVal(chargeData);
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.chargeGridData = mockChargeService.getOneChargeData(chargeData);
		chargeComponent.showSummaryGrid = false;
		chargeComponent.setUpChargeComponent();
		expect(chargeComponent.showSummaryGrid).toBe(false);
	}));

	it('Charge dialog box should get opened on click of Add Charge button', async(() => {
		fixture.detectChanges();
		chargeComponent.showAddChargeDialog();
		expect(chargeComponent.addChargeDetailsDialogBox).toBe(true);
		expect(chargeComponent.chargeDialogTitleName).toEqual('Add Charge Details');
	}));

	it('Charge dialog box should get closed on click of Cancel button', async(() => {
		fixture.detectChanges();
		chargeComponent.closeAddChargeDetailsDialogBox();
		expect(chargeComponent.addChargeDetailsDialogBox).toBe(false);
	}));

	it('toggle button event should be emitted', async(() => {
		fixture.detectChanges();
		const valueFromSelectedButton = 'Yes';
		chargeComponent.eventFromToggleButton(valueFromSelectedButton);
		expect(chargeComponent.valueFromSelectedButton).toBe('Yes');
	}));

	it('should close charge dialog box when cancel button is clicked', async(() => {
		fixture.detectChanges();
		chargeComponent.cancelForm();
		expect(chargeComponent.addChargeDetailsDialogBox).toBe(false);
	}));

	it('should validate charge amount', async(() => {
		fixture.detectChanges();
		const $event = {amount: 100000.00};
		chargeComponent.validateChargeAmount($event);
		expect(chargeComponent.chargeAmountValidate).toBe(false);
	}));

	it('should throw error on charge amount ', async(() => {
		fixture.detectChanges();
		const $event = {};
		chargeComponent.validateChargeAmount($event);
		expect(chargeComponent.chargeAmountValidate).toBe(true);
	}));

	it('should return "-" when checkForRegAuthValue is null', async(() => {
		fixture.detectChanges();
		const $value = '';
		expect(chargeComponent.checkForRegAuthValue($value)).toBe('-');
	}));

	it('should return "abc" when checkForRegAuthValue is "abc"', async(() => {
		fixture.detectChanges();
		const $value = 'abc';
		expect(chargeComponent.checkForRegAuthValue($value)).toBe('abc');
	}));

	it('should return error when nature of charge value is not in service response', async(() => {
		fixture.detectChanges();
		const mockNatureOfChargesData = NatureOfCharges;
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.natureOfCharges = mockNatureOfChargesData;
		const $value = 'abc';
		chargeComponent.validationCheckForNatureOfCharge($value);
		expect(chargeComponent.natureOfChargeDivError).toBe(true);
		expect(chargeComponent.validationCheckForNatureOfCharge($value)).toBe(false);
	}));

	it('should not return error when nature of charge value is not in service response', async(() => {
		fixture.detectChanges();
		const mockNatureOfChargesData = NatureOfCharges;
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.natureOfCharges = mockNatureOfChargesData;
		const $value = 'CHARGENAT2';
		chargeComponent.validationCheckForNatureOfCharge($value);
		expect(chargeComponent.natureOfChargeDivError).toBe(false);
		expect(chargeComponent.validationCheckForNatureOfCharge($value)).toBe(true);
	}));

	it('should return error when charge rank value is not in service response', async(() => {
		fixture.detectChanges();
		chargeComponent.chargeRankList = ChargeRankJSON;
		chargeComponent.chargeRankResponse = ChargeRankList;
		const $value = 'xyz';
		chargeComponent.validationCheckForChargeRank($value);
		expect(chargeComponent.chargeRankDivError).toBe(true);
		expect(chargeComponent.validationCheckForChargeRank($value)).toBe(false);
	}));

	it('should not return error when charge rank value is not in service response', async(() => {
		fixture.detectChanges();
		chargeComponent.chargeRankList = ChargeRankJSON;
		chargeComponent.chargeRankResponse = ChargeRankList;
		const $value = '1DBS';
		chargeComponent.validationCheckForChargeRank($value);
		expect(chargeComponent.chargeRankDivError).toBe(false);
		expect(chargeComponent.validationCheckForChargeRank($value)).toBe(true);
	}));

	it('Data should get displayed in Update Charge Dialog Box fields onclick of edit icon', async(() => {
		fixture.detectChanges();
		const mockUpdatedChargeData = {};
		mockUpdatedChargeData['natureOfCharge'] = 'CHARGENAT1';
		mockUpdatedChargeData['chargeRank'] = '1ST';
		mockUpdatedChargeData['chargeAmount'] = 200000.08;
		mockUpdatedChargeData['filingDate'] = new Date('2017-05-12T07:06:17.255Z');
		mockUpdatedChargeData['receiptDate'] = new Date('2017-05-12T07:06:17.255Z');
		mockUpdatedChargeData['registrationAuthority'] = '-';
		const mockFormBuilder = new MockFormBuilder();
		chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.natureOfCharges = mockChargeService.getNatureOfCharges();
		chargeComponent.chargeGridData.push(mockUpdatedChargeData);
		const rowIndex = 1;
		chargeComponent.chargeEditFunc(mockUpdatedChargeData, rowIndex);
		expect(chargeComponent.addChargeForm.controls['natureOfCharge'].value).toBe('CHARGENAT1');
		expect(chargeComponent.chargeDialogTitleName).toBe('Update Charge Details');
	}));

	it('Data should get updated in Grid  onclick of update button', async(() => {
		fixture.detectChanges();
		chargeComponent.chargeRankList = ChargeRankJSON;
		chargeComponent.chargeRankResponse = ChargeRankList;
		const mockFormBuilder = new MockFormBuilder();
		chargeComponent.addChargeForm = mockFormBuilder.getAddChargeForm();
		const mockNatureOfChargesData = NatureOfCharges;
		const mockChargeService: MockChargeService = new MockChargeService();
		chargeComponent.chargeRankList = ChargeRankJSON;
		chargeComponent.chargeRankResponse = ChargeRankList;
		chargeComponent.natureOfCharges = mockChargeService.getNatureOfCharges();
		chargeComponent.chargeGridData.push(chargeData);
		const mockUpdatedChargeData = new ChargeDataModel();
		mockUpdatedChargeData.natureOfCharge = mockFormBuilder.getAddChargeForm().controls['natureOfCharge'].value;
		mockUpdatedChargeData['chargeRankToShow'] = mockFormBuilder.getAddChargeForm().controls['chargeRankToShow'].value;
		mockUpdatedChargeData.chargeAmount = mockFormBuilder.getAddChargeForm().controls['chargeAmount'].value;
		mockUpdatedChargeData.filingDate = mockFormBuilder.getAddChargeForm().controls['filingDate'].value;
		mockUpdatedChargeData.receiptDate = mockFormBuilder.getAddChargeForm().controls['receiptDate'].value;
		mockUpdatedChargeData.registrationAuthInfo = mockFormBuilder.getAddChargeForm().controls['registrationAuthInfo'].value;
		chargeComponent.rowIndex = 1;
		chargeComponent.updateChargeData(mockUpdatedChargeData);
		expect(chargeComponent.chargeGridData[1].registrationAuthority).toBe(mockUpdatedChargeData.registrationAuthInfo);
	}));

	it('Data should get deleted from Grid onclick of delete icon', async(() => {
		fixture.detectChanges();
		chargeComponent.chargeGridData.push(chargeData);
		const rowIndex = 0;
		chargeComponent.removeClickedChargeData(rowIndex);
		expect(chargeComponent.chargeGridData.length).toBe(0);
	}));

	it('validation check for total charge amount when amount is greater than to Collateral value', async(() => {
		fixture.detectChanges();
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		const collateral: Collateral = new Collateral;
		const collateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail;
		collateralValuationDetail.collateralValue.value = 0.00;
		collateralValuationDetail.externalChargeAmt.value = 0.00;
		collateral.CollateralValuationDetail = collateralValuationDetail;
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		chargeComponent.validateChargeAmountWithValuationDetail(6000.00);
		expect(chargeComponent.maxChargeAmountErrMsg).toBe('No Collateral Value provided to calculate Charge Amount.');
		expect(chargeComponent.maxChargeAmountReachedDivError).toBe(true);
	}));

	it('validation check for total charge amount when amount is smaller than or equal to Collateral value', async(() => {
		fixture.detectChanges();
		let collateralService: CollateralService;
		collateralService = TestBed.get(CollateralService);
		const collateral: Collateral = new Collateral;
		const collateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail;
		collateralValuationDetail.collateralValue.value = 5000.00;
		collateralValuationDetail.externalChargeAmt.value = 0.00;
		collateral.CollateralValuationDetail = collateralValuationDetail;
		spyOn(collateralService, 'getCollateral').and.returnValue(collateral);
		chargeComponent.validateChargeAmountWithValuationDetail(5000.00);
		expect(chargeComponent.maxChargeAmountReachedDivError).toBe(false);
	}));
});
