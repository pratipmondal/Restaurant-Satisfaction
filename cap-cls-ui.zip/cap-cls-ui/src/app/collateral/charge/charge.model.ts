export class ChargeDataModel {
	natureOfCharge: string;
	chargeRank: string;
	chargeAmount: number;
	filingDate: Date;
	receiptDate: Date;
	registrationAuthInfo: string;
	currencyType: string;
}
