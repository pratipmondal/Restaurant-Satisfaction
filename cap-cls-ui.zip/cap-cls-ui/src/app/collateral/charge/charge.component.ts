import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ChargeService } from './charge.component.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ChargeDataModel } from './charge.model';
import { Observable } from 'rxjs/Rx';
import { CollateralService } from '../collateral.service';
import { CurrencyFormatPipe } from '../../shared/currency-pipe/currency-pipe';
import { ToastsComponent } from '../../shared/toasts/toasts.component';
@Component({
	selector: 'collateral-charge',
	templateUrl: './charge.component.html',
	styleUrls: ['./charge.component.scss']
})
export class ChargeComponent implements OnInit, AfterViewInit {

	addChargeDetailsDialogBox: boolean = false;
	public addChargeForm: FormGroup;
	divForNoData: boolean;
	sumOfChargeAmount: number = 0;
	submitted: boolean = false;

	@Input() showAddChargeBtn: boolean = true;

	@Input() showSummaryGrid: boolean = false;

	@Input() chargeForm: FormGroup;

	@Output() dataFromChargeComponent: EventEmitter<any> = new EventEmitter<string>();

	@Input() show: boolean = true;

	public chargeGridData: any;
	valueFromSelectedButton: string = 'No';
	private selectedBtn: string = 'value2';

	public events: any[] = [];
	public saveData: boolean = true;
	public rowIndex: number;
	public chargeDialogTitleName: string = 'Add Charge Details';
	natureOfCharges: any;
	argToastMessageObject: any;
	private divForServiceError: boolean;
	chargeAmountValidate: boolean = false;
	natureOfChargeDivError: boolean = false;
	chargeRankDivError: boolean = false;
	maxChargeAmountReachedDivError: boolean = false;
	maxChargeAmount: number = 0.0;
	maxChargeAmountErrMsg = '';
	pipe: CurrencyFormatPipe = new CurrencyFormatPipe();
	toastsComponent: ToastsComponent = new ToastsComponent();
	chargeRankList: any;
	chargeRankResponse: any = [];

	constructor(private _fb: FormBuilder, private chargeService: ChargeService, private collateralService: CollateralService, private cdr: ChangeDetectorRef) {
	}

	ngOnInit() {
		this.setUpChargeComponent();
	}

	/*Function to set up charge component*/
	setUpChargeComponent() {
		if (!this.chargeForm) {
			this.chargeForm = this._fb.group({
				chargeList: [[]]
			});
		}
		if (this.chargeForm.get('chargeList').value && (this.chargeForm.get('chargeList').value !== undefined || this.chargeForm.get('chargeList').value !== null)) {
			this.chargeGridData = this.chargeForm.get('chargeList').value;
		} else {
			this.chargeGridData = [];
		}
		this.divForNoData = (this.chargeGridData.length === 0);
		this.populateTotalChargeAmountValue();
		this.addChargeForm = this._fb.group({
			natureOfCharge: ['', [<any>Validators.required, <any>Validators.required]],
			chargeRankToShow: ['', [<any>Validators.required, <any>Validators.required]],
			chargeRankToSubmit: ['', [<any>Validators.required, <any>Validators.required]],
			chargeAmount: ['', [<any>Validators.required, <any>Validators.required]],
			filingDate: ['', [<any>Validators.required, <any>Validators.required]],
			receiptDate: ['', [<any>Validators.required, <any>Validators.required]],
			registrationAuthInfo: [],
			currencyType: ['', [<any>Validators.required, <any>Validators.required]]
		});
		this.subscribeToFormChanges();
		this.getChargeRankData();
	}

	/*Function to manually call view Init for updating charge*/
	ngAfterViewInit() {
		this.cdr.detectChanges();
	}

	/*Function to check for form changes that will be reflected in apportion*/
	private subscribeToFormChanges() {
		this.chargeForm.valueChanges.subscribe(data => this.onChargeFormChanged(data));
	}

	/*Function to show Add Charge Dialog Box*/
	showAddChargeDialog() {
		this.saveData = true;
		this.submitted = false;
		this.chargeAmountValidate = false;
		this.chargeDialogTitleName = 'Add Charge Details';
		this.addChargeDetailsDialogBox = true;
		this.getNatureOfChargesData();
		this.getChargeRankData();
		this.validationReset();
	}

	/*Function to close Add Charge Dialog Box from dialog cross button and emit close event for cls-popup-component*/
	closeAddChargeDetailsDialogBox(addChargeDetailsDialogBox?: boolean) {
		this.addChargeDetailsDialogBox = false;
		this.addChargeForm.reset();
		this.validationReset();
	}

	/*Function to add Charge data*/
	addChargeData(data: any) {
		this.submitted = true;
		if (data['chargeAmount'] === null || data['chargeAmount'] === undefined || data['chargeAmount'] === '') {
			this.chargeAmountValidate = true;
			this.maxChargeAmountReachedDivError = false;
		} else {
			if (this.valueFromSelectedButton === 'Yes') {
				this.validateChargeAmountWithValuationDetail(data['chargeAmount']);
			} else {
				this.maxChargeAmountReachedDivError = false;
			}
		}

		const isNatureOfChargeValid = this.validationCheckForNatureOfCharge(data['natureOfCharge']);
		const isChargeRankValid = this.validationCheckForChargeRank(data['chargeRankToShow']);
		if (!this.maxChargeAmountReachedDivError) {
			if (isNatureOfChargeValid && isChargeRankValid) {
				if (this.addChargeForm.valid) {
					this.addChargeDetailsDialogBox = false;
					data['registrationAuthInfo'] = this.checkForRegAuthValue(data['registrationAuthInfo']);
					const dataForAddCharge = {
						'chargeAmount': parseFloat(data['chargeAmount']),
						'chargeRank': data['chargeRankToSubmit'],
						'externalCharge': this.valueFromSelectedButton,
						'filingDate': data['filingDate'],
						'natureOfCharge': data['natureOfCharge'],
						'receiptDate': data['receiptDate'],
						'registrationAuthority': data['registrationAuthInfo'],
						'currencyType': data['currencyType']
					};
					this.chargeGridData.push(dataForAddCharge);
					if (this.chargeGridData.length === 0) {
						this.divForNoData = true;
					} else {
						this.divForNoData = false;
						this.chargeForm.controls['chargeList'].setValue(this.chargeGridData);
						this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
							'A new record of charge details has been successfully added.',
							'', '');
						this.populateTotalChargeAmountValue();
					}
					this.submitted = false;
					this.chargeAmountValidate = false;
					this.addChargeForm.reset();
					this.validationReset();
				}
			}
		}
	}

	/*Function to emit event for toggle button and setting up the value to be saved*/
	eventFromToggleButton(valueFromSelectedButton: any) {
		this.valueFromSelectedButton = valueFromSelectedButton;
	}

	/*Function to close the Add Charge Dialog Box when clicked on Cancel button*/
	cancelForm() {
		this.addChargeDetailsDialogBox = false;
		this.addChargeForm.reset();
		this.validationReset();
	}

	/*Function to call when edit icon is clicked from charge grid*/
	chargeEditFunc(item: any, index: number): void {
		this.addChargeForm.reset();
		this.chargeDialogTitleName = 'Update Charge Details';
		this.rowIndex = index;
		this.saveData = false;
		this.addChargeDetailsDialogBox = true;
		this.valueFromSelectedButton = (item['externalCharge']);
		if (this.valueFromSelectedButton === 'Yes') {
			this.selectedBtn = 'value1';
		} else {
			this.selectedBtn = 'value2';
		}
		this.getNatureOfChargesData();
		this.getChargeRankData();
		const dataForEditCharge = {
			'chargeAmount': item['chargeAmount'],
			'chargeRank': item['chargeRankToShow'],
			'externalCharge': item['externalCharge'],
			'filingDate': item['filingDate'],
			'natureOfCharge': item['natureOfCharge'],
			'receiptDate': item['receiptDate'],
			'registrationAuthInfo': item['registrationAuthority'],
			'currencyType': item['currencyType']
		};
		if (dataForEditCharge !== undefined) {
			this.addChargeForm = this._fb.group({
				natureOfCharge: [item['natureOfCharge'], [<any>Validators.required, <any>Validators.required]],
				chargeRankToShow: [this.chargeRankResponse[item['chargeRank']], [<any>Validators.required, <any>Validators.required]],
				chargeRankToSubmit: [item['chargeRank'], [<any>Validators.required, <any>Validators.required]],
				chargeAmount: [item['chargeAmount'], [<any>Validators.required, <any>Validators.required]],
				filingDate: [item['filingDate'], [<any>Validators.required, <any>Validators.required]],
				receiptDate: [item['receiptDate'], [<any>Validators.required, <any>Validators.required]],
				registrationAuthInfo: item['registrationAuthority'],
				currencyType: [item['currencyType'], [<any>Validators.required, <any>Validators.required]]
			});
			this.chargeAmountValidate = false;
			this.subscribeToFormChanges();
			this.ngAfterViewInit();
		}
	}

	/*Function when update button is clicked*/
	updateChargeData(data: ChargeDataModel) {
		this.ngAfterViewInit();
		if (data['chargeAmount'] === null || data['chargeAmount'] === undefined || data['chargeAmount'].toString() === '') {
			this.chargeAmountValidate = true;
			this.maxChargeAmountReachedDivError = false;
		} else {
			if (this.valueFromSelectedButton === 'Yes') {
				this.validateChargeAmountWithValuationDetail(data['chargeAmount']);
			} else {
				this.maxChargeAmountReachedDivError = false;
			}
		}
		const isNatureOfChargeValid = this.validationCheckForNatureOfCharge(data['natureOfCharge']);
		const isChargeRankValid = this.validationCheckForChargeRank(data['chargeRankToShow']);

		if (!this.maxChargeAmountReachedDivError) {
			if (isNatureOfChargeValid && isChargeRankValid) {
				if (this.addChargeForm.valid) {
					this.addChargeDetailsDialogBox = false;
					data['registrationAuthInfo'] = this.checkForRegAuthValue(data['registrationAuthInfo']);
					const dataForUpdateCharge = {
						'chargeAmount': parseFloat(data['chargeAmount'].toString()),
						'chargeRank': data['chargeRankToSubmit'],
						'externalCharge': this.valueFromSelectedButton,
						'filingDate': data['filingDate'],
						'natureOfCharge': data['natureOfCharge'],
						'receiptDate': data['receiptDate'],
						'registrationAuthority': data['registrationAuthInfo'],
						'currencyType': data['currencyType']
					};
					this.chargeGridData[this.rowIndex] = dataForUpdateCharge;
					this.populateTotalChargeAmountValue();
					this.emitChargeDataValueFromChargeComp();
					this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
						'A record of charge details has been successfully updated.',
						'', '');
					this.chargeForm.controls['chargeList'].setValue(this.chargeGridData);
					this.addChargeForm.reset();
					this.validationReset();
				}
			}
		}
	}

	/*Function to call when remove icon is clicked from charge grid*/
	removeClickedChargeData(itemIndex: number) {
		this.chargeGridData.splice(itemIndex, 1);
		if (this.chargeGridData.length === 0) {
			this.divForNoData = true;
		} else {
			this.divForNoData = false;
			this.populateTotalChargeAmountValue();
		}
		this.argToastMessageObject = this.toastsComponent.buildToastMessageObject('success',
			'A record of charge details has been successfully deleted.',
			'', '');
		this.chargeForm.controls['chargeList'].setValue(this.chargeGridData);
	}

	/*Function to calculate Total Charge Amount for charge grid*/
	private populateTotalChargeAmountValue() {
		let localChargeAmountCounter = 0;
		for (let i = 0; i < this.chargeGridData.length; i++) {
			localChargeAmountCounter = localChargeAmountCounter
				+ parseFloat(this.chargeGridData[i]['chargeAmount']);
		}
		this.sumOfChargeAmount = localChargeAmountCounter;
	}

	/*Function to emit Total Charge Amount (if required)*/
	emitChargeDataValueFromChargeComp() {
		this.dataFromChargeComponent
			.emit({'chargedGridData': this.chargeGridData, 'sumValue': this.sumOfChargeAmount});
	}

	/*Function to get Nature of Charges Data from Service*/
	private getNatureOfChargesData() {
		this.chargeService.getNatureOfCharges().subscribe(
			response => {
				this.divForServiceError = false;
				this.natureOfCharges = response;
			},
			error => {
				this.divForServiceError = true;
				/*Do whatever with the error on the basis of error code*/
				if (error.status === 500) {
					return Observable.throw(new Error(error.status));
				} else if (error.status === 400) {
					return Observable.throw(new Error(error.status));
				} else if (error.status === 409) {
					return Observable.throw(new Error(error.status));
				} else if (error.status === 404) {
					return Observable.throw(new Error(error.status));
				}
			},
			() => {
				this.divForServiceError = false;
			}
		);
	}

	/*Function to get Charge Rank Data*/
	private getChargeRankData() {
		this.chargeService.getChargeRank().subscribe(
			response => {
				this.divForServiceError = false;
				this.chargeRankList = response;
				this.chargeRankResponse = this.formChargeRanksForGridDisplay(response);
			},
			error => {
				this.divForServiceError = true;
				/*Do whatever with the error on the basis of error code*/
				if (error.status === 500) {
					return Observable.throw(new Error(error.status));
				} else if (error.status === 400) {
					return Observable.throw(new Error(error.status));
				} else if (error.status === 409) {
					return Observable.throw(new Error(error.status));
				} else if (error.status === 404) {
					return Observable.throw(new Error(error.status));
				}
			},
			() => {
				this.divForServiceError = false;
			}
		);
	}

	formChargeRanksForGridDisplay(response: any) {
		const chargeRanksArray = [];
		if (response) {
			response.forEach(item => chargeRanksArray.push(item.rankDesc) );
		}
		return chargeRanksArray;
	}

	/*Function to validate charge amount (because using Currency Component)*/
	validateChargeAmount($event) {
		if ($event.amount) {
			this.chargeAmountValidate = false;
		} else {
			this.chargeAmountValidate = true;
			this.maxChargeAmountReachedDivError = false;
		}
	}

	/*Function to be called when Registration Authority Value is not set*/
	checkForRegAuthValue(data: string) {
		if (data === '' || data === null || data === 'undefined') {
			return '-';
		} else {
			return data;
		}
	}

	/*Function to be called when there is a change in the Charge Form to be reflected in Apportion Tab*/
	onChargeFormChanged(data?: any) {
		let amt = 0;
		let arr: any[] = [];
		if (data && data.chargeList) {
			arr = data.chargeList;
		}
		arr.forEach(ch => {
			if (ch.externalCharge && ch.externalCharge.toString().toUpperCase() === 'YES') {
				amt += ch.chargeAmount;
			}
		});
		const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
		collateralObj.externalChargeAmt.value = amt;
		collateralObj.finalCollateralValue.value =
			collateralObj.collateralValue.value - collateralObj.externalChargeAmt.value;
		collateralObj.balanceApportionableAmt.value = collateralObj.finalCollateralValue.value - collateralObj.totalApportionedValue.value;
	}

	/*Function on Nature of Charge value change and to validate for Nature of Charge Selected Value*/
	validationCheckForNatureOfCharge(data?: any) {
		let valid: boolean = false;
		const dataObj = this.natureOfCharges.find(item => item.code === data);

		if (((dataObj !== 'undefined') || (dataObj !== '')) && (dataObj !== undefined)) {
			this.natureOfChargeDivError = false;
			valid = true;
		} else {
			this.natureOfChargeDivError = true;
			valid = false;
		}
		return valid;
	}

	/*Function on Charge Rank value change and to validate for Charge Rank Selected Value*/
	validationCheckForChargeRank(data?: any) {
		let valid: boolean = false;
		const dataObj = this.chargeRankList.find(item => item.rankDesc === data);
		if (((dataObj !== null) || (dataObj !== '')) && (dataObj !== undefined)) {
			this.chargeRankDivError = false;
			valid = true;
			const valueToSubmit = dataObj.rank;
			this.addChargeForm.controls['chargeRankToSubmit'].setValue(valueToSubmit);
		} else {
			this.chargeRankDivError = true;
			valid = false;
		}
		return valid;
	}

	/*Function to Reset validations*/
	private validationReset() {
		this.natureOfChargeDivError = false;
		this.chargeRankDivError = false;
		this.maxChargeAmountReachedDivError = false;
	}

	/*Function to validate charge amount with Valuation Details*/
	validateChargeAmountWithValuationDetail(data?: any) {
		const collateralObj = this.collateralService.getCollateral().CollateralValuationDetail;
		this.maxChargeAmount = collateralObj.collateralValue.value - collateralObj.externalChargeAmt.value;
		if (this.maxChargeAmount > 0.0) {
			this.maxChargeAmountErrMsg = 'Charge amount should be less than or equal to Collateral Value amount (' + this.pipe.transform(this.maxChargeAmount, 2, 'SGD') + ') as External Charge is applied.';
		} else {
			this.maxChargeAmountErrMsg = 'No Collateral Value provided to calculate Charge Amount.';
		}
		this.maxChargeAmountReachedDivError = !(this.maxChargeAmount >= data);
	}
}
