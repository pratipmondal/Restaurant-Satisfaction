export const ChargeListResponse = [{
	'natureOfCharge': 'Dummy',
	'chargeRank': '1ST',
	'externalCharge': 'No',
	'chargeAmount': '200,000.08',
	'filingDate': '21 Apr 2017',
	'receiptDate': '20 Apr 2017',
	'registrationAuthority': '-'
}, {
	'natureOfCharge': 'Dummy',
	'chargeRank': '1DBS',
	'externalCharge': 'No',
	'chargeAmount': '40,000.01',
	'filingDate': '21 Apr 2017',
	'receiptDate': '20 Apr 2017',
	'registrationAuthority': '-'
}];

export const ChargeRankList = ['1DBS', '1ST', '2ND', '3RD', '4TH', '5TH', '6TH', '7TH', '8TH', '9TH'];

export const NatureOfCharges = [
	{
		'code': 'CHARGENAT1',
		'description': 'Nature of charge code1',
		'id': '59155ee950c8b30600c7949c',
		'_type': 'NatureOfCharge',
		'_createdBy': 'upload',
		'_modifiedBy': 'upload',
		'_createdOn': '2017-05-12T07:06:17.255Z',
		'_modifiedOn': '2017-05-12T07:06:17.255Z',
		'_version': '003f258d-e68b-4882-b747-940a6a7bf893',
		'_isDeleted': false
	},
	{
		'code': 'CHARGENAT2',
		'description': 'Nature of charge code1',
		'id': '59155ee950c8b30600c7949d',
		'_type': 'NatureOfCharge',
		'_createdBy': 'upload',
		'_modifiedBy': 'upload',
		'_createdOn': '2017-05-12T07:06:17.302Z',
		'_modifiedOn': '2017-05-12T07:06:17.302Z',
		'_version': '302fa2b8-e5fa-4a69-bd68-dafe47fa549c',
		'_isDeleted': false
	}
];

export const ChargeRankJSON =
[{'rank': 0, 'rankDesc': '1DBS'},
	{'rank': 1, 'rankDesc': '1ST'},
	{'rank': 2, 'rankDesc': '2ND'},
	{'rank': 3, 'rankDesc': '3RD'},
	{'rank': 4, 'rankDesc': '4TH'},
	{'rank': 5, 'rankDesc': '5TH'},
	{'rank': 6, 'rankDesc': '6TH'},
	{'rank': 7, 'rankDesc': '7TH'},
	{'rank': 8, 'rankDesc': '8TH'},
	{'rank': 9, 'rankDesc': '9TH'}];
