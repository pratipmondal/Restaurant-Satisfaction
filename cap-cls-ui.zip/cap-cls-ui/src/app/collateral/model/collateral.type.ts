    export interface Section {
        CollateralCodeLinkageDetail: boolean;
        subSections: any[];
        CollateralCodeAlertEventDetail?: boolean;
        CollateralCodeSecurityDetail?: boolean;
        CollateralCodeAdditionalDetail?: boolean;
        CollateralCodeUnitValueDetail?: boolean;
        CollateralCodeDetailsInAltLang?: boolean;
        CollateralCodeCompanyDetail?: boolean;
    }

    export interface Code {
        sections: Section[];
    }

    export interface SubSection {
        OwnerShipDetail: boolean;
        subSections: any[];
        LodgeTenancyDetail?: boolean;
        LodgeGuaranteeDetail?: boolean;
        LodgeOtherDetail?: boolean;
        LodgeDepositDetail?: boolean;
        ForeClosureDetail?: boolean;
        RepossessionDetail?: boolean;
    }

    export interface Section2 {
        LodgeChargeDetail: boolean;
        subSections: SubSection[];
        LodgeReceiptAndPayment?: boolean;
        LodgeInspectionAndAppraisal?: boolean;
        LodgeDocumentationDetail?: boolean;
        LodgeBeneficiaryDetail?: boolean;
        LodgeInsuranceDetail?: boolean;
        CollateralValuationDetail?: boolean;
        LodgeDynamicSection?: boolean;
        LodgeSalesNotesDetail?: boolean;
        LodgeOwnerShipDetail?: boolean;
        LodgeCollateralTypeSpecificDetail?: boolean;
        LodgeNonPerformanceDetail?: boolean;
    }

    export interface Lodge {
        sections: Section2[];
    }

    export interface SubSection2 {
        CalculationMethod: boolean;
        subSections: any[];
    }

    export interface Section3 {
        FeeDetail: boolean;
        subSections: SubSection2[];
        CollateralValueDetail?: boolean;
    }

    export interface Common {
        sections: Section3[];
    }

    export interface Sections {
        code: Code;
        lodge: Lodge;
        common: Common;
    }

    export interface CollateralType {
        collateralType: string;
        collateralTypeDesc: string;
        sections: Sections;
        id: string;
        _version: string;
        _createdBy: string;
        _modifiedBy: string;
    }
