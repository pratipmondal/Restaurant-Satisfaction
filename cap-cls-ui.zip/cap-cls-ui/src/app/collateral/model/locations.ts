export interface Location {
    code: string;
    description: string;
    id: string;
    parentRefCode: string;
    parentRefType: string;
    scope: string;
    _createdBy: string;
    _createdOn: string;
    _isDeleted: boolean;
    _modifiedBy: string;
    _modifiedOn: Date;
    _newVersion: string;
    _oldVersion: string;
    _requestId: string;
    _type: string;
}