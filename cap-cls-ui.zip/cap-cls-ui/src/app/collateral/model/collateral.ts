import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject
export class Collateral {
    LodgeReceiptAndPayment: LodgeReceiptAndPayment = new LodgeReceiptAndPayment();
    LodgeDocumentationDetail: LodgeDocumentationDetail = new LodgeDocumentationDetail();
    CollateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail();
    LodgeCollateralTypeSpecificDetail: GuarnLodgeCollateralTypeSpecificDetail | DeposLodgeCollateralTypeSpecificDetail = new GuarnLodgeCollateralTypeSpecificDetail();
    // FeeDetail: FeeDetail = new FeeDetail();
    CollateralValueDetail: CollateralValueDetail = new CollateralValueDetail();
    collateralId: string = '';
    collateralCode: string = '';
    generalDetail: GeneralDetail = new GeneralDetail();
    collateralOwnerShipType: string = '';
    withdrawalDetail: WithdrawalDetail = new WithdrawalDetail();
    LodgeBeneficiaryDetail: LodgeBeneficiaryDetail = new LodgeBeneficiaryDetail();
    LodgeOwnerShipDetail: LodgeOwnerShipDetail = new LodgeOwnerShipDetail();
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}


@JsonObject
export class ReceiptAmt {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class PaymentAmt {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class ReceiptAndPayment {
    receiptOrPaymentInd: string = '';
    receiptType: string = '';
    receiptAmt: ReceiptAmt = new ReceiptAmt();
    paymentType: string = '';
    paymentAmt: PaymentAmt = new PaymentAmt();
    dueDate: Date = null;
    paidOrReceivedDate: Date = null;
    dateFrom: string = '';
    dateTo: string = '';
    proofVerifiedDate: Date = null;
    paymentMode: string = '';
    notes: string = '';
    name: string = '';
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
    delete: boolean = false;
    id: string = '';
}

@JsonObject
export class LodgeReceiptAndPayment {
    receiptAndPayment: ReceiptAndPayment[] = [];
    id: string = '';
}

@JsonObject
export class Document {
    documentCode: string = '';
    documentDate: Date = null;
    documentId: string = '';
    dueDate: Date = null;
    documentReceivedDate: Date = null;
    documentExpirationDate: Date = null;
    documentStatus: string = '';
    comments: string = '';
    delete: boolean = false;
}

@JsonObject
export class LodgeDocumentationDetail {
    document: Document[] = [];
    id: string = '';
}

@JsonObject
export class ExternalChargeAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class CollateralValue {
    value: number;
    ccy: string = '';
}

@JsonObject
export class FinalCollateralValue {
    value: number;
    ccy: string = '';
}

@JsonObject
export class TotalApportionedValue {
    value: number;
    ccy: string = '';
}

@JsonObject
export class BalanceApportionableAmt {
    value: number;
    ccy: string = '';

}

@JsonObject
export class CollateralValuationDetail {
    loanToValuePcnt: number;
    externalChargeAmt: ExternalChargeAmt = new ExternalChargeAmt();
    collateralValue: CollateralValue = new CollateralValue();
    finalCollateralValue: FinalCollateralValue = new FinalCollateralValue();
    apportioningMethod: string = '';
    totalApportionedValue: TotalApportionedValue = new TotalApportionedValue();
    balanceApportionableAmt: BalanceApportionableAmt = new BalanceApportionableAmt();
}

@JsonObject
export class GuaranteeAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class ProposeAmt {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class ApprovedAmt {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class GuarnLodgeCollateralTypeSpecificDetail {
    guaranteeType: string = '';
    guarantorName: string = '';
    guarantorCifId: string = '';
    guarantorType: string = '';
    supportingCollateralsHeld: boolean = false;
    guaranteePcnt: number;
    guaranteeAmt: GuaranteeAmt = new GuaranteeAmt();
    proposedPcnt: number;
    proposeAmt: ProposeAmt = new ProposeAmt();
    approvedPcnt: number;
    approvedAmt: ApprovedAmt = new ApprovedAmt();
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
    id: string = '';
}

@JsonObject
export class UserEnteredAmt {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class FeeDetailList {
    feeType: string = '';
    feeCode: string = '';
    overrideFeeSetup: boolean = false;
    feeDistributable: boolean = false;
    multiple: boolean = false;
    frequency: string = '';
    nextAssessmentDate: Date = null;
    maxNumberOfAssessements: number;
    amortize: boolean = false;
    amortizationTerm: number;
    method: string = '';
    scriptName: string = '';
    userEnteredAmt: UserEnteredAmt = new UserEnteredAmt();
    userEnteredPcnt: number;
    comments: string = '';
    delete: boolean = false;
    id: string = '';
}

@JsonObject
export class ComputedAmount {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class CollectableAmount {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class FeeDetail {
    debitAcForFees: string = '';
    feeDetailList: FeeDetailList[] = [];
    feeCollectionAccount: string = '';
    computedAmount: ComputedAmount = new ComputedAmount();
    collectableAmountPcnt: number;
    collectableAmount: CollectableAmount = new CollectableAmount;
    id: string = '';
}

@JsonObject
export class CollateralValueDetail {
    unitValueMethod: boolean = false;
    directValueMethod: boolean = false;
    netValueMethod: boolean = false;
    derivedValueMethod: boolean = false;
    itemBasedMethod: boolean = false;
    customerDerivationMethod: boolean = false;
    defaultValueMethod: boolean = false;
    childCollateralMethod: boolean = false;
    id: string = '';
}

@JsonObject
export class ApplicationDetail {
    formNo: string = '';
    receivedDate: Date = null;
    reviewDate: Date = null;
    nextReviewDate: Date = null;
    signingDate: Date = null;
    executionDate: Date = null;
    comments: string = '';
    id: string = '';
}

@JsonObject
export class SolicitorDetails {
    solicitorName: string = '';
    approvedSolicitor: boolean = false;
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
    phoneNo: string = '';
    emailAddress: string = '';
    telexNo: string = '';
    faxNo: string = '';
    id: string = '';
}

@JsonObject
export class GeneralDetail {
    collateralDesc: string = '';
    globalCollateral: boolean = false;
    country: string = '';
    collateralClass: string = '';
    collateralGroup: string = '';
    collateralCreationDate: string = null;
    collateralExpiryDate: string = null;
    currencyCode: string = '';
    BASELEligible: boolean = false;
    collateralStatus: string = '';
    applicationDetail: ApplicationDetail = new ApplicationDetail();
    solicitorDetails: SolicitorDetails = new SolicitorDetails();
    remarks: string = '';
    id: string = '';
}

@JsonObject
export class WithdrawalDetail {
    withdraw: boolean = false;
    reasonCode: string = '';
    withdrawalDate: Date = null;
    id: string = '';
}

@JsonObject
export class Principal {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class AcctBalance {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class AvlblBalance {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class ProposedAmt {
    value: number;
    ccy: string = '';
    id: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _isDeleted: boolean = false;
    _oldVersion: string = '';
    _version: string = '';
    _requestId: string = '';
    _newVersion: string = '';
}

@JsonObject
export class LodgeOwnerShipDetail {
collateralOwnerShipType: string = '';
ownerShipList: OwnerShipList[] = [];
}

@JsonObject
export class OwnerShipList {
cifId: string = '';
idType: string = '';
idNo: string = '';
name: string = '';
collateralOwnerShipPcnt: number;
addressLine1: string = '';
addressLine2: string = '';
addressLine3: string = '';
city: string = '';
state: string = '';
country: string = '';
postalCode: string = '';
phoneNo: string = '';
emailAddress: string = '';
telexNo: string = '';
faxNo: string = '';
delete: boolean = false;
}

@JsonObject
export class BeneficiaryList {
beneficiaryName: string = '';
cifId: string = '';
beneficiaryIdType: string = '';
beneficiaryId: string = '';
addressLine1: string = '';
addressLine2: string = '';
addressLine3: string = '';
city: string = '';
state: string = '';
country: string = '';
postalCode: string = '';
phoneNo: string = '';
emailAddress: string = '';
telexNo: string = '';
faxNo: string = '';
delete: boolean = false;
rank: string = '';
capAmount: number = 0;
capAmountType: string = '';
}

@JsonObject
export class LodgeBeneficiaryDetail {
beneficiaryList: BeneficiaryList[] = [];
}

@JsonObject
export class DepositDetail {
    depositAcctNo: string = '';
    sourceSystem: string = '';
    maturityDate: Date = null;
    term: number;
    principal: Principal = new Principal();
    acctBalance: AcctBalance = new AcctBalance();
    avlblBalance: AvlblBalance = new AvlblBalance();
    proposedAmt: ProposedAmt = new ProposedAmt();
    approvedAmt: ApprovedAmt = new ApprovedAmt();
    bankId: string = '';
    bankIdentifierCode: string = '';
    branchId: string = '';
    comments: string = '';
    delete: boolean = false;
    id: string = '';
}

@JsonObject
export class DeposLodgeCollateralTypeSpecificDetail {
    fullBenefit: boolean = false;
    depositDetails: DepositDetail[] = [];
    id: string = '';
}