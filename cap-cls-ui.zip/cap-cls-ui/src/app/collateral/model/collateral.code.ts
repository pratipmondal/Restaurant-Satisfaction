    export interface GeneralDetail {
        collateralCodeDescription: string;
        collateralClass: string;
        collateralGroup: string;
        loanToValuePercent: number;
    }

    export interface CollateralCodeLinkageDetail {
        primaryCollateral: boolean;
        secondaryCollateral: boolean;
    }

    export interface MaxAmtAllowed {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface MaxPrimaryAmtAllowed {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface MaxSecondaryAmtAllowed {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface TotalAmtUnderPrimaryAC {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface TotalAmtUnderSecondaryAC {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface TotalAmtUnderPrimaryNodes {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface TotalAmtUnderSecondaryNodes {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface CollateralCodeAlertEventDetail {
        maxAmtAllowed: MaxAmtAllowed;
        maxPrimaryAmtAllowed: MaxPrimaryAmtAllowed;
        maxSecondaryAmtAllowed: MaxSecondaryAmtAllowed;
        drawingPowerContributionPercent: number;
        maxAmtExceededEvent: boolean;
        primaryAmtExceededEvent: boolean;
        secondaryAmtExceededEvent: boolean;
        drawingPowerExceededEvent: boolean;
    }

    export interface CollateralCodeAdditionalDetail {
        updateCollateralDrawingPower: boolean;
        valuationFrequencyInMonths: number;
        remarks: string;
    }

    export interface CollateralCodeDetailsInAltLang {
        description: string;
    }

    export interface UserEnteredAmt {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface FeeDetailList {
        feeType: string;
        feeCode: string;
        overrideFeeSetup: boolean;
        feeDistributable: boolean;
        multiple: boolean;
        frequency: string;
        nextAssessmentDate: Date;
        maxNumberOfAssessements: number;
        amortize: boolean;
        amortizationTerm: number;
        method: string;
        scriptName: string;
        userEnteredAmt: UserEnteredAmt;
        delete: boolean;
    }

    export interface ComputedAmount {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface CollectableAmount {
        value: number;
        ccy: string;
        _isDeleted: boolean;
    }

    export interface FeeDetail {
        feeDetailList: FeeDetailList[];
        feeCollectionAccount: string;
        computedAmount: ComputedAmount;
        collectableAmountPcnt: number;
        collectableAmount: CollectableAmount;
    }

    export interface CollateralValueDetail {
        unitValueMethod: boolean;
        directValueMethod: boolean;
        netValueMethod: boolean;
        derivedValueMethod: boolean;
        itemBasedMethod: boolean;
        customerDerivationMethod: boolean;
        defaultValueMethod: boolean;
        childCollateralMethod: boolean;
    }

    export interface DEPOS {
        CollateralCodeLinkageDetail: CollateralCodeLinkageDetail;
        CollateralCodeAlertEventDetail: CollateralCodeAlertEventDetail;
        CollateralCodeAdditionalDetail: CollateralCodeAdditionalDetail;
        CollateralCodeDetailsInAltLang: CollateralCodeDetailsInAltLang;
        FeeDetail: FeeDetail;
        CollateralValueDetail: CollateralValueDetail;
        _isDeleted: boolean;
    }

    export interface FreezeDetail {
        freezeStatus: boolean;
    }

    export interface CollateralCode {
        collateralCode: string;
        collateralType: string;
        generalDetail: GeneralDetail;
        id: string;
        _type: string;
        _createdBy: string;
        _modifiedBy: string;
        _createdOn: Date;
        _modifiedOn: Date;
        _version: string;
        DEPOS: DEPOS;
        freezeDetail: FreezeDetail;
    }