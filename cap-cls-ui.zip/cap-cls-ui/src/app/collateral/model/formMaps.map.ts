export class FormMaps{
    public static map = {
        'Collateral Details': 'details',
        'Particulars': 'particulars',
        'Beneficiary': 'beneficiary',
        'Ownership': 'ownership',
        'Charge': 'charge',
        'Document': 'document',
        'Valuation': 'valuation',
        'Summary': 'summary'
    };
}