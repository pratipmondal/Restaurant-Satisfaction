import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject
export class ApplicationDetail {
    formNo: string = '';
    receivedDate: Date = null;
    reviewDate: Date = null;
    nextReviewDate: Date = null;
    signingDate: Date = null;
    executionDate: Date = null;
    comments: string = '';
}

@JsonObject
export class SolicitorDetails {
    solicitorName: string = '';
    approvedSolicitor: boolean = false;
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
    phoneNo: string = '';
    emailAddress: string = '';
    telexNo: string = '';
    faxNo: string = '';
}

@JsonObject
export class GeneralDetail {
    collateralDesc: string = '';
    globalCollateral: boolean = false;
    businessLocation: string = '';
    collateralClass: string = '';
    collateralGrp: string = '';
    collateralCreationDate: String = null;
    collateralExpiryDate: String = null;
    currencyCode: string = '';
    BASELEligible: boolean = false;
    method: string = '';
    solicitorName: string = '';
    collateralStatus: string = '';
    remarks: string = '';
    applicationDetail: ApplicationDetail = new ApplicationDetail();
    solicitorDetails: SolicitorDetails =  new SolicitorDetails();
}

@JsonObject
export class WithdrawalDetail {
    withdraw: boolean = false;
    reasonCode: string = '';
    withdrawalDate: Date = null;
}

@JsonObject
export class ReceiptAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class PaymentAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class ReceiptAndPayment {
    receiptOrPaymentInd: string = '';
    receiptType: string = '';
    receiptAmt: ReceiptAmt =  new ReceiptAmt();
    paymentType: string = '';
    paymentAmt: PaymentAmt = new PaymentAmt();
    dueDate: Date = null;
    paidOrReceivedDate: Date = null;
    dateFrom: string = '';
    dateTo: string = '';
    proofVerifiedDate: Date = null;
    paymentMode: string = '';
    notes: string = '';
    name: string = '';
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
    delete: boolean = false;
}

@JsonObject
export class LodgeReceiptAndPayment {
    receiptAndPayment: ReceiptAndPayment[] = [];
}

@JsonObject
export class Document {
    documentCode: string = '';
    documentDate: Date = null;
    documentId: string = '';
    dueDate: Date = null;
    documentReceivedDate: Date = null;
    documentExpirationDate: Date = null;
    documentStatus: string = '';
    comments: string = '';
    delete: boolean = false;
}

@JsonObject
export class LodgeDocumentationDetail {
    document: Document[] = [];
}

@JsonObject
export class BeneficiaryList {
    beneficiaryName: string = '';
    cifId: string = '';
    beneficiaryIdType: string = '';
    beneficiaryId: string = '';
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
    phoneNo: string = '';
    emailAddress: string = '';
    telexNo: string = '';
    faxNo: string = '';
    delete: boolean = false;
    rank: string = '';
    capAmount: number = 0;
    capAmountType: string = '';
}

@JsonObject
export class LodgeBeneficiaryDetail {
    beneficiaryList: BeneficiaryList[] = [];
}

@JsonObject
export class ExternalChargeAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class CollateralValue {
    value: number;
    ccy: string = '';
}

@JsonObject
export class FinalCollateralValue {
    value: number;
    ccy: string = '';
}

@JsonObject
export class TotalApportionedValue {
    value: number;
    ccy: string = '';
}

@JsonObject
export class BalanceApportionableAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class CollateralValuationDetail {
    loanToValuePcnt: number;
    externalChargeAmt: ExternalChargeAmt = new ExternalChargeAmt();
    collateralValue: CollateralValue = new CollateralValue();
    finalCollateralValue: FinalCollateralValue = new FinalCollateralValue();
    apportioningMethod: string = '';
    totalApportionedValue: TotalApportionedValue = new TotalApportionedValue();
    balanceApportionableAmt: BalanceApportionableAmt = new BalanceApportionableAmt();
}

@JsonObject
export class OwnerShipList {
    cifId: string = '';
    idType: string = '';
    idNo: string = '';
    name: string = '';
    collateralOwnerShipPcnt: number;
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
    phoneNo: string = '';
    emailAddress: string = '';
    telexNo: string = '';
    faxNo: string = '';
    delete: boolean = false;
}

@JsonObject
export class LodgeOwnerShipDetail {
    collateralOwnerShipType: string = '';
    ownerShipList: OwnerShipList[] = [];
}

@JsonObject
export class GuaranteeAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class ProposeAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class ApprovedAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class LodgeCollateralTypeSpecificDetail {
    guaranteeType: string = '';
    guarantorName: string = '';
    guarantorCifId: string = '';
    guarantorType: string = '';
    supportingCollateralsHeld: boolean = false;
    guaranteePcnt: number;
    guaranteeAmt: GuaranteeAmt = new GuaranteeAmt();
    proposedPcnt: number;
    proposeAmt: ProposeAmt = new ProposeAmt();
    approvedPcnt: number;
    approvedAmt: ApprovedAmt = new ApprovedAmt();
    addressLine1: string = '';
    addressLine2: string = '';
    addressLine3: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    postalCode: string = '';
}

@JsonObject
export class UserEnteredAmt {
    value: number;
    ccy: string = '';
}

@JsonObject
export class FeeDetailList {
    feeType: string = '';
    feeCode: string = '';
    overrideFeeSetup: boolean = false;
    feeDistributable: boolean = false;
    multiple: boolean = false;
    frequency: string = '';
    nextAssessmentDate: Date = null;
    maxNumberOfAssessements: number;
    amortize: boolean = false;
    amortizationTerm: number;
    method: string = '';
    scriptName: string = '';
    userEnteredAmt: UserEnteredAmt = new UserEnteredAmt();
    userEnteredPcnt: number;
    comments: string = '';
    delete: boolean = false;
}

@JsonObject
export class ComputedAmount {
    value: number;
    ccy: string = '';
}

@JsonObject
export class CollectableAmount {
    value: number;
    ccy: string = '';
}

@JsonObject
export class FeeDetail {
    debitAcForFees: string = '';
    feeDetailList: FeeDetailList[] = [];
    feeCollectionAccount: string = '';
    computedAmount: ComputedAmount = new ComputedAmount();
    collectableAmountPcnt: number;
    collectableAmount: CollectableAmount = new CollectableAmount();
}

@JsonObject
export class CollateralValueDetail {
    unitValueMethod: boolean = false;
    directValueMethod: boolean = false;
    netValueMethod: boolean = false;
    derivedValueMethod: boolean = false;
    itemBasedMethod: boolean = false;
    customerDerivationMethod: boolean = false;
    defaultValueMethod: boolean = false;
    childCollateralMethod: boolean = false;
}

@JsonObject
export class Collateral {
    collateralId: string = '';
    collateralCode: string = '';
    collateralType: string = '' ;
    draft: boolean = false;
    _version: string = '';
    _type: string = '';
    _createdBy: string = '';
    _modifiedBy: string = '';
    _createdOn: Date = null;
    _modifiedOn: Date = null;
    _oldVersion: string = '';
    _requestId: string = '';
    _isDeleted: boolean = false;
    generalDetail: GeneralDetail = new GeneralDetail();
    withdrawalDetail: WithdrawalDetail = new WithdrawalDetail();
    LodgeReceiptAndPayment: LodgeReceiptAndPayment = new LodgeReceiptAndPayment();
    LodgeDocumentationDetail: LodgeDocumentationDetail = new LodgeDocumentationDetail();
    LodgeBeneficiaryDetail: LodgeBeneficiaryDetail = new LodgeBeneficiaryDetail();
    CollateralValuationDetail: CollateralValuationDetail = new CollateralValuationDetail();
    LodgeOwnerShipDetail: LodgeOwnerShipDetail = new LodgeOwnerShipDetail();
    LodgeCollateralTypeSpecificDetail: LodgeCollateralTypeSpecificDetail = new LodgeCollateralTypeSpecificDetail();
    // FeeDetail: FeeDetail = new FeeDetail();
    CollateralValueDetail: CollateralValueDetail = new CollateralValueDetail();
}
