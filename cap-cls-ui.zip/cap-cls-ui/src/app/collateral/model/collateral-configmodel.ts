export interface CollateralConfigModel {
    
}
