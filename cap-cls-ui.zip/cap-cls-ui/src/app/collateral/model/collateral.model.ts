export interface CollateralId {

}

export interface Details {

}

export interface Beneficiary {

}

export interface Valution {

}

export interface Apportion {

}

export interface Ownership {

}

export interface Charge {

}

export interface Particulars {

}

export interface Collateral {
    collateralId: CollateralId;
    details: Details;
    particulars: Particulars;
    document: Document;
    beneficiary: Beneficiary;
    apportion: Apportion;
    ownership: Ownership;
    charge: Charge;
}
