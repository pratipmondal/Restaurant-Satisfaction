import { environment } from '../../environments/environment';
import { Injectable, Inject } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CollateralReponse } from './collateralData';
import { Observable, Observer } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AutoSaveService } from '../common/autosave/auto-save.service';
import { SaveInProgress } from '../common/models/types';
import { ErrorResponse } from 'app/shared';
import { Collateral } from './model/collateral';
import { JsonConvert } from 'json2typescript';
import { Subject } from 'rxjs/Subject';
import { collateralResData } from './new-collateral/new-collateral.data';
import { limitData } from './facility-linkage-data/limits.data';
import { beneficiaryLimitData } from './beneficiary/beneficiary.data';
import * as _ from 'underscore';

@Injectable()
export class CollateralService {

	saveStateObservable: BehaviorSubject<SaveInProgress>;
	collateral: any;
	selectedCollateralType: string = null;
	tabSections: Array<String> = [];
	selectedTab: string;
	public limitDataBeneficiary: any = {};
	// error panel code
	private errorsModel: Subject<any> = new Subject<any>(); // the Object that would be used to control the error panel components
	formSubmitClicked: boolean = false; // check whether the Form was submitted or not
	errorTabs: any[] = []; // for controlling the tabs with errors, error icons for each tab
	// error panel code
	modifiedForm: string;

	private routeToHomePanel = new Subject<any>();

	sendMessage(message: string) {
		this.routeToHomePanel.next(message);
	}

	getMessage(): Observable<any> {
		return this.routeToHomePanel.asObservable();
	}

	constructor(private http: Http, private autoSaveService: AutoSaveService
		, private _fb: FormBuilder) {
		this.saveStateObservable = new BehaviorSubject(false);

		// error panel code
		this.errorsModel.next({
			errorForm: {},
			entireForm: {},
			currentFormName: ''
		});
		// error panel code
	}

	// error panel code
	setErrorsModel(err?: any) {
		this.errorsModel.next(err);
	}

	// error panel code

	// error panel code
	getErrorsModel() {
		return this.errorsModel.asObservable();
	}

	// error panel code

	subscribeToSaveState(listner: Observer<SaveInProgress>) {
		this.saveStateObservable.subscribe(listner);
	}

	unSubscribeToSaveState() {
		this.saveStateObservable.unsubscribe();
		this.saveStateObservable = new BehaviorSubject(false);
	}

	setupAutoSave(form: FormGroup, listner: Observer<SaveInProgress>) {

		this.unSubscribeToSaveState();
		this.autoSaveService.unsubscribeToFormChanges();

		this.subscribeToSaveState(listner);
		this.autoSaveService.setup(form, this.saveStateObservable);
	}

	getCollateralFullForm(type: string, id: string): Observable<any> {
		return this.http.get('' + type + '/' + id)
			.map(
				res => res.json()
			);
	}

	public getCollateralForm() {
		return this._fb.group({
			details: this.getDetailsForm(),
			beneficiary: this.getBeneficiaryForm(),
			charge: this.getChargeForm(),
			valuation: this.getApportionForm(),
			document: this.getDocumentForm(),
			ownership: this.getOwnershipForm(),
			particulars: this.getParticularsForm()
		});

	}

	/*createCollateral(collateral: any) {
	 this.postCollateral(collateral).subscribe(data => {
	 console.log(JSON.stringify(data));
	 this.collateral=JsonConvert.deserializeString(JSON.stringify(data), Collateral);

	 console.log(this.collateral);
	 },
	 error => { }
	 );
	 }*/

	postCollateral(collateral: any): Observable<any> {
		// return Observable.of(collateralResData);
		let collateralApi;
		if (this.selectedCollateralType === 'GUARN') {
			collateralApi = environment.apiGuarnCollaterals;
		} else if (this.selectedCollateralType === 'DEPOS') {
			collateralApi = environment.apiDeposCollaterals;
		} else {
			return Observable.throw('Invalid Collateral Type');
		}

		const url = environment.apiBaseUrl + collateralApi;
		return this.http.post(url, collateral)
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	/*    submitCollateral() {
	 // this.putCollateral().subscribe(data => {
	 //     this.collateral = JsonConvert.deserializeString(JSON.stringify(data), Collateral);
	 // },
	 //     error => { }
	 // );
	 return this.putCollateral();
	 }
	 */
	submitCollateral(): Observable<any> {

		let collateralApi;
		if (this.selectedCollateralType === 'GUARN') {
			collateralApi = environment.apiGuarnCollaterals;
		} else if (this.selectedCollateralType === 'DEPOS') {
			collateralApi = environment.apiDeposCollaterals;
		} else {
			return Observable.throw('Invalid Collateral Type');
		}
		const url = environment.apiBaseUrl + collateralApi;
		return this.http.put(url + '/' + this.collateral.collateralId, this.collateral)
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	getDetailsForm() {
		const tabForm = this._fb.group({
			collateralid: ['']
		});
		tabForm.valueChanges.subscribe(data => {
			this.modifiedForm = 'details';
		});
		return tabForm;
	}

	getParticularsForm() {
		const tabForm = this._fb.group({
			particularsList: ['']
		});
		tabForm.valueChanges.subscribe(data => {
			this.modifiedForm = 'Particular';
		});
		return tabForm;

	}

	getBeneficiaryForm() {
		const tabForm = this._fb.group({
			beneficiaryList: []
		});
		tabForm.valueChanges.subscribe(data => {
			this.modifiedForm = 'Beneficiary';
		});
		return tabForm;
	}

	getCollateral() {
		return this.collateral;
	}

	getDocumentForm(document?: Document) {
		const tabForm = this._fb.group({
			documentidList: []
		});
		tabForm.valueChanges.subscribe(data => {
			this.modifiedForm = 'document';
		});
		return tabForm;
	}

	getChargeForm() {
		const tabForm = this._fb.group({
			chargeList: ['']
		});
		tabForm.valueChanges.subscribe(data => {
			this.modifiedForm = 'charge';
		});
		return tabForm;
	}

	getApportionForm() {
		return this._fb.group({});
	}

	getOwnershipForm() {
		const tabForm = this._fb.group({
			ownershipid: []
		});
		tabForm.valueChanges.subscribe(data => {
			this.modifiedForm = 'ownership';
		});
		return tabForm;
	}

	getCollateralTypes(filter?: any): Observable<any> {
		// TODO: we need to use search filter
		const url = environment.apiBaseUrl + environment.apiGetcollateralTypes;
		const params: URLSearchParams = new URLSearchParams();
		if (filter) {
			params.set('filter', JSON.stringify(filter));
		}
		return this.http.get(url)
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	getCollateralCodes(filter?: any): Observable<any> {
		// TODO: we need to use search filter
		const url = environment.apiBaseUrl + environment.apiGetcollateralCodes;
		const params: URLSearchParams = new URLSearchParams();
		if (filter) {
			filter = '{"where":{"collateralType": "' + filter + '"}}';
			params.set('filter', filter);
		}
		return this.http.get(url, {search: params})
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	getLocations(): Observable<any> {
		const url = environment.apiBaseUrl + environment.apiToGetCountries;
		return this.http.get(url)
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	errorResponseFunction(error: any) {
		const ErrorResponse = <ErrorResponse>error;
		return Observable.throw(<ErrorResponse>ErrorResponse);
	}

	getLimitsByLimitTypeId(filter?: any): Observable<any> {
		// return Observable.of(limitData);
		const url = environment.apiBaseUrl + environment.apiLimit;
		const params: URLSearchParams = new URLSearchParams();
		if (filter) {
			// filter = '{"where":{"limitTypeId": "' + filter + '"}}';
			params.set('filter', JSON.stringify(filter));
		}
		return this.http.get(url, {search: params})
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
		function onSuccessSuccess(resp: Response) {
			return (resp.json());
		}
	}

	getLinkagesByCollateral(collateralId?: any): Observable<any> {
		// return Observable.of(linkageData);
		let url;
		if (this.selectedCollateralType === 'GUARN') {
			url = environment.apiBaseUrl + environment.apiGuarnCollaterals;
		} else if (this.selectedCollateralType === 'DEPOS') {
			url = environment.apiBaseUrl + environment.apiDeposCollaterals;
		} else {
			return Observable.throw('Invalid Collateral Type');
		}
		url += '/' + collateralId + '/linkage-detail';
		const params: URLSearchParams = new URLSearchParams();
		if (collateralId) {
			collateralId = '{"where":{"collateralId": "' + collateralId + '"}}';
			params.set('filter', collateralId);
		}
		return this.http.get(url, {search: params})
			.map(onSuccessSuccess.bind(this))
			.catch(error => this.errorResponseFunction(error));
		function onSuccessSuccess(resp: Response) {

			return (resp.json());
		}
	}

	getLinkages(collateralId?: any) {
		this.getLinkagesByCollateral(collateralId).subscribe(data => {
				this.limitDataBeneficiary = data;

				const limits = _.map(data, function (element, index, list) {
					return element.entityId;
				});

				const filter = {where: {limitId: {inq: limits}}, fields: ['limitId', 'limitTypeId']};

				this.getLimitsByLimitTypeId(filter).subscribe(limits => {
						this.limitDataBeneficiary = _.groupBy(_.map(this.limitDataBeneficiary, function (element, index, list) {
							const linkage = _.where(limits, {limitId: element.entityId});
							return {
								limitId: element.entityId,
								collateralId: element.collateralId,
								gcin: linkage[0].limitTypeId
							};
						}), function (obj) {
							return obj.gcin;
						});
					},
					error => {
					}
				);
			},
			error => {
			}
		);
	}
	getLimitData(){
		return this.limitDataBeneficiary;
	}

}
