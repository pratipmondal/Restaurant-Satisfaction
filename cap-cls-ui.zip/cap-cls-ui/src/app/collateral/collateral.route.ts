import {Route} from '@angular/router';

import {UserRouteAccessService} from '../shared';
import {CollateralComponent} from './';
import {NewCollateralComponent} from './new-collateral/new-collateral.component';

export const COLLATERAL_ROUTE: Route = {
    path: 'collateral',
    component: CollateralComponent,
    data: {
        pageTitle: 'CLS - Collateral'
    },
    children: [{
        path: 'newcollateral',
        component: NewCollateralComponent,
        data: {
            pageTitle: 'CLS - New Collateral'
        }
    }],
    canActivate: [UserRouteAccessService]
};