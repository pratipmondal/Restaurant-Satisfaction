export * from './register.route';
export * from './register.component';
export * from './register.module';
