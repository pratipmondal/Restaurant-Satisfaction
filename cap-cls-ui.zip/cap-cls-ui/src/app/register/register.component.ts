import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../login/authentication.service';
//import { AlertService } from 'alert.service';
import { UserService } from './user.service';

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: [ './register.component.scss' ],
    providers: [ AuthenticationService,
                 //AlertService, 
                 UserService ]
})

export class RegisterComponent implements OnInit {
    loading: boolean = false;
    model: any = {};
    message: string;
    messageError: string;
    referenceNameInParent: string;
    itemValueFromGrid: any;
    eventChangeValFromUploader: string;
    eventChangeValFromSingleUpload: string;
    showLoader: boolean = false;
    showYesNoPrompt: boolean = false;
    showGlobalMessage: boolean = false;
    referenceTypebjs: any;

    loginInfo: JSON;
    public sessionToken;

    messageFromParentToGlobalMessageComp: any;

    payload: any;
    eventChangeValFromSingleUploadForUpdate: any;
    globalMessageEventChangeValFromUploader: any;

    constructor( private authenticationservice: AuthenticationService,
                 private userService: UserService,
                 //private alertService: AlertService,
                 private router: Router ) {
    }

    ngOnInit() {

    }
  
  register() {
        this.loading = true;
        this.userService.create(this.model)
            .subscribe(
                data => {
                  //this.alertService.success('Registration successful', true);
                  //this.router.navigate(['/ref-data']);
                  //console.log("data="+data.message);
                  this.message = data.message;
                },
                error => {
                    //this.alertService.error(error);
                    this.loading = false;
                  this.messageError = 'Error during the service call';
                });
    }

    

}