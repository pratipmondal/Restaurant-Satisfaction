import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges  } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../login/authentication.service';
import { UserService } from '../register/user.service';
import { DataStateChangeEvent, GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { process, State } from '@progress/kendo-data-query';

@Component({
    selector: 'app-search-user',
    templateUrl: './search-user.component.html',
    styleUrls: [ './search-user.component.scss' ],
    providers: [ AuthenticationService,
                 UserService ]
})

export class SearchUserComponent implements OnInit {
    model: any = {};
    public users: any = [];
    private gridView: GridDataResult;
    private state: State = {
        skip: 0,
        take: 4
    };
    @Output()
    onSelectRowValue: EventEmitter<any> = new EventEmitter<any>();
    constructor( private authenticationservice: AuthenticationService,
                 private userService: UserService,
                 private router: Router) {
    }

    ngOnInit() {
      this.searchUser();
    }
  
  searchUser() {
        this.userService.getAll()
            .subscribe(
                data => {
                  this.users = data;
                  this.gridView = process(this.users, this.state);
                  console.log("SUCCESS3 !!!!!"+this.users[0].userid);
                },
                error => {
                    console.log('Error during getting users from Service3');
                });
    }

    protected dataStateChange( state: DataStateChangeEvent ): void {
        this.state = state;
        this.gridView = process(this.users, this.state);
    }
    
    /**Edit Button click event emit */
    public editFunc( item ): void {
    	console.log('Edit is clicked');
        let tempArr = [];
        tempArr.push({OP_CODE: 'UPDATE'});
        tempArr.push(item);
        this.onSelectRowValue.emit(tempArr);
    }

}