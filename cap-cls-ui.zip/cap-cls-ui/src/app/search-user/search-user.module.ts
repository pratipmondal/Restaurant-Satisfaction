import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AuthenticationService } from '../login/authentication.service';
import { ClsSharedCommonModule } from '../shared/';
import { LoaderModule } from '../shared/progression/loader/loader.module';
import { GridModule } from '@progress/kendo-angular-grid';
import { CounterpartyDetailsModule } from '../shared/counterparty-details/counterparty-details.module';
import { REGISTER_ROUTE, SearchUserComponent } from './index';


@NgModule({
    imports: [
        RouterModule.forChild([ REGISTER_ROUTE ]), CommonModule,
        BrowserModule, FormsModule, ReactiveFormsModule,
        ButtonsModule, BrowserAnimationsModule,
        LoaderModule, GridModule, ClsSharedCommonModule, CounterpartyDetailsModule
    ],
    declarations: [
        SearchUserComponent
    ],
    providers: [ AuthenticationService],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class SearchUserModule {
}
