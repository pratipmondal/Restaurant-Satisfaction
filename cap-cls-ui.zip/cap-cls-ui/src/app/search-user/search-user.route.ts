import { Route } from '@angular/router';

import { UserRouteAccessService } from '../shared';
import { SearchUserComponent } from './search-user.component';

export const REGISTER_ROUTE: Route = {
    path: 'search-user',
    component: SearchUserComponent,
    data: {
        authorities: [],
        pageTitle: 'CLS - Register User'
    },
    canActivate: [ UserRouteAccessService ]

};
