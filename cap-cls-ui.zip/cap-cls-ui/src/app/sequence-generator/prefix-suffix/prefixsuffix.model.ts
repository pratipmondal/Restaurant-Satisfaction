export class PrefixSuffixGrid {
    prefixSuffix: string;
    prefixSuffixType: string;
    userDefinedValue: string;
    from: number;
    to: number;
    newSeries: string;
    id: string;
    _type: string;
    _createdBy: string;
    _modifiedBy: string;
    _createdOn: Date;
    _modifiedOn: Date;
    _version: string;
    _isDeleted: boolean;
}
