import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PrefixSuffixCode, PrefixSuffixGrid, PrefixSuffixTypes } from '../model';

@Component({
    selector: 'kendo-grid-edit-form',
    templateUrl: 'prefixsuffix.form.html',
    styleUrls: [ '../seq-gen-form/seq-gen-form.component.scss', './prefixsuffix.scss' ]
})
export class PrefixSuffixFormComponent implements OnInit, OnDestroy {

    private newSeries: any[] = [];
    private isUserDefinedType: boolean = true;
    active: boolean = false;
    private userDefinedValue = new FormControl(null);
    editForm: FormGroup;

    formErrors = {
        'prefixSuffix': '',
        'prefixSuffixType': '',
        'userDefinedValue': '',
        'from': '',
        'to': '',
        'newSeries': ''
    };

    validationMessages = {
        'prefixSuffix': {
            'required': 'Prefix Suffix is required.'
        },
        'prefixSuffixType': {
            'required': 'Prefix Suffix Type is required.'
        },
        'userDefinedValue': {
            'required': 'User Defined Value is required.',
            'maxlength': 'User Defined Value cannot be more than 6 characters long.'
        },
        'from': {
            'required': 'From is required.',
            'maxlength': 'User Defined Value cannot be more than 2 characters long.'
        },
        'to': {
            'required': 'To is required.',
            'maxlength': 'User Defined Value cannot be more than 2 characters long.'
        },
        'newSeries': {
            'required': 'New Series is required.'
        }
    };

    @Input()
    psCodes: PrefixSuffixTypes[];

    @Input()
    psTypes: PrefixSuffixCode[];

    @Input()
    isNew: boolean = false;

    @Output()
    cancel: EventEmitter<any> = new EventEmitter();
    @Output()
    save: EventEmitter<PrefixSuffixGrid> = new EventEmitter();

    @Input()
    public set model( record: PrefixSuffixGrid ) {
        if (!this.isNew) {
            this.editForm.get('prefixSuffix').setValue({'code': record.prefixSuffix});
            this.editForm.get('prefixSuffixType').setValue({'code': record.prefixSuffixType});
            this.editForm.get('from').setValue(record.from);
            this.editForm.get('to').setValue(record.to);
            this.editForm.get('userDefinedValue').setValue(record.userDefinedValue);
            this.editForm.get('newSeries').setValue({'value': record.newSeries});
        }
        this.active = record !== undefined;
    }

    constructor() {
        this.editForm = new FormGroup({
            'prefixSuffix': new FormControl(null, [ Validators.required ]),
            'prefixSuffixType': new FormControl(null, [ Validators.required ]),
            'userDefinedValue': new FormControl({
                value: null,
                disabled: true
            }, [ Validators.required, Validators.maxLength(6) ]),
            'from': new FormControl(null, [ Validators.required, Validators.maxLength(2) ]),
            'to': new FormControl(null, [ Validators.required, Validators.maxLength(2) ]),
            'newSeries': new FormControl(null, Validators.required),
        }, this.validator);

        this.editForm.get('userDefinedValue').disable(true);

        this.newSeries = [ {'value': 'Y', 'label': 'Yes'}, {'value': 'N', 'label': 'No'} ];
    }

    ngOnInit() {
        this.editForm.valueChanges.subscribe(data => this.onValueChanged(data));

    }

    validator( g: FormGroup ) {
        return g.get('from').value <= g.get('to').value
            ? null : {'mismatch': true};
    }

    onValueChanged( data?: any ) {
        if (!this.editForm) {
            return;
        }
        const form = this.editForm;
        for (const field in this.formErrors) {
            this.formErrors[ field ] = '';
            const control = form.get(field);
            if (control && control.dirty && !control.valid) {
                const messages = this.validationMessages[ field ];
                for (const key in control.errors) {
                    this.formErrors[ field ] += messages[ key ] + ' ';
                }
            }
        }
    }

    public onSave( e ): void {
        e.preventDefault();
        this.save.emit(this.copyData());
        this.active = false;
    }

    populateFromandTo() {
        this.editForm.get('from').setValue('1');
        this.editForm.get('to').setValue(this.editForm.get('userDefinedValue').value.length);
        this.editForm.get('newSeries').setValue({'value': 'N'});
    }

    reset() {
        this.editForm.get('userDefinedValue').setValue(null);
        this.editForm.get('from').setValue(null);
        this.editForm.get('to').setValue(null);
        this.editForm.get('newSeries').setValue(null);
    }

    public onCancel( e ): void {
        e.preventDefault();
        this.closeForm();
    }

    private closeForm(): void {
        this.active = false;
        this.cancel.emit();
    }

    handleUserDefinedValue( value ): void {
        if (value && value.code === 'UD') {
            this.isUserDefinedType = false;
            this.editForm.get('from').disable(true);
            this.editForm.get('to').disable(true);
            this.editForm.get('newSeries').disable(true);
            this.editForm.get('userDefinedValue').enable(true);
            this.reset();
        } else {
            this.isUserDefinedType = true;
            this.editForm.get('from').enable(true);
            this.editForm.get('to').enable(true);
            this.editForm.get('newSeries').enable(true);
            this.editForm.get('userDefinedValue').disable(true);
        }
    }

    copyData(): PrefixSuffixGrid {
        const record: PrefixSuffixGrid = new PrefixSuffixGrid();
        record.prefixSuffix = this.editForm.get('prefixSuffix').value.code;
        record.prefixSuffixType = this.editForm.get('prefixSuffixType').value.code;
        record.userDefinedValue = this.editForm.get('userDefinedValue').value;
        record.from = this.editForm.get('from').value;
        record.to = this.editForm.get('to').value;
        record.newSeries = this.editForm.get('newSeries').value.value;
        return record;
    }

    ngOnDestroy() {
    }
}
