import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { PrefixSuffixComponent } from './prefixsuffixgrid.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Rx';
import { PrefixSuffixCode, PrefixSuffixGrid, PrefixSuffixTypes } from '../model';
import { SeqGenService } from '../../shared';

function getPfRecord1(): PrefixSuffixGrid {
    const pfgrid = new PrefixSuffixGrid();
    pfgrid[ 'prefixSuffix' ] = 'PS';
    pfgrid[ 'prefixSuffixType' ] = 'Limit';
    pfgrid[ 'userDefinedValue' ] = '';
    pfgrid[ 'from' ] = 1;
    pfgrid[ 'to' ] = 2;
    pfgrid[ 'newSeries' ] = 'Y';
    pfgrid[ 'id' ] = 'some_id';
    return pfgrid;
}
function getPfRecord2(): PrefixSuffixGrid {
    const pfgrid = new PrefixSuffixGrid();
    pfgrid[ 'prefixSuffix' ] = 'AB';
    pfgrid[ 'prefixSuffixType' ] = 'Test';
    pfgrid[ 'userDefinedValue' ] = '';
    pfgrid[ 'from' ] = 1;
    pfgrid[ 'to' ] = 2;
    pfgrid[ 'newSeries' ] = 'Y';
    pfgrid[ 'id' ] = 'some_id';
    return pfgrid;
}


class MockSeqGenService {
    getPrefixSuffixCodes() {
        const pscodes: PrefixSuffixCode = [ {'code': 'P', 'description': 'Prefix'}, {
            'code': 'S',
            'description': 'Suffix'
        } ];

        return Observable.of(pscodes);
    }

    getPrefixSuffixTypes() {
        const pscodes: PrefixSuffixTypes = [ {'code': 'L', 'description': 'Limit'}, {
            'code': 'UD',
            'description': 'User Defined'
        } ];

        return Observable.of(pscodes);
    }
}


describe('PrefixSuffixComponent (inline template)', () => {
    let component: PrefixSuffixComponent;
    let fixture: ComponentFixture<PrefixSuffixComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ FormsModule, ReactiveFormsModule ],
            declarations: [ PrefixSuffixComponent ],
            providers: [ {provide: SeqGenService, useClass: MockSeqGenService} ],
            schemas: [ NO_ERRORS_SCHEMA ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PrefixSuffixComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        de = fixture.debugElement;
        el = de.nativeElement;
    });
    it('should populate Prefix Suffix Details', () => {
        component.populatePrefixSuffix();
        expect(component.prefixSuffixCode[ 1 ].code).toBe('S');
        expect(component.PrefixSuffixTypes[ 0 ].code).toBe('L');

    });
    it('should set properties while adding record on Prefix Suffix table', () => {
        component.addHandler();
        expect(component.isNew).toBe(true);
        expect(component.createComp).toBe(true);
        expect(component.editDataItem).not.toBeNull();

    });
    it('should set properties while Editing record on Prefix Suffix table', () => {
        const dataItem: any = getPfRecord1();
        component.editHandler({dataItem});
        expect(component.isNew).toBe(false);
        expect(component.createComp).toBe(true);
        expect(component.editDataItem).not.toBeNull();
        expect(component.editDataItem.prefixSuffix).toBe('PS');
    });
    it('should set properties while Cancel record on Prefix Suffix table', () => {
        component.cancelHandler();
        expect(component.createComp).toBe(false);
        expect(component.editDataItem).toBeUndefined;
    });

    it('should save record on Prefix Suffix table while adding', () => {
        component.psDetails.push(getPfRecord1());
        component.isNew = true;
        component.saveHandler(getPfRecord2());
        expect(component.createComp).toBe(false);
        expect(component.psDetails.length).toBe(2);
        expect(component.editDataItem).toBeUndefined;
    });
    it('should update record on Prefix Suffix table while editing', () => {
        component.psDetails.push(getPfRecord1());
        component.psDetails.push(getPfRecord2());

        const dataItem: PrefixSuffixGrid = getPfRecord1();
        const newDataItem: PrefixSuffixGrid = getPfRecord1();

        component.editHandler({dataItem});

        newDataItem.prefixSuffix = 'XY';
        spyOn(component, 'findSelectedPSIndex').and.returnValue(1);
        component.saveHandler(newDataItem);

        expect(component.createComp).toBe(false);
        expect(component.psDetails.length).toBe(2);
        expect(component.psDetails[ 1 ].prefixSuffix).toBe('XY');
        expect(component.editDataItem).toBeUndefined;
    });
    it('should be able to find index of selected value', () => {
        component.psDetails.push(getPfRecord1());
        component.psDetails.push(getPfRecord2());
        expect(component.psDetails.length).toBe(2);
        spyOn(component.psDetails, 'indexOf').and.returnValue(1);
        expect(component.findSelectedPSIndex(getPfRecord2())).toBe(1);
    });
    it('should be able to remove the records', () => {
        component.psDetails.push(getPfRecord1());
        component.psDetails.push(getPfRecord2());
        const dataItem: PrefixSuffixGrid = getPfRecord1();

        spyOn(component.psDetails, 'indexOf').and.returnValue(0);
        component.removeHandler({dataItem});
        expect(component.psDetails.length).toBe(1);
    });
});
