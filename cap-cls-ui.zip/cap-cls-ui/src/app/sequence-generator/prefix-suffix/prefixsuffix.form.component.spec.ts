import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { PrefixSuffixFormComponent } from './prefixsuffix.form.component';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

import { PrefixSuffixGrid } from '../model';

function getPfGrid(): PrefixSuffixGrid {
    const pfgrid = new PrefixSuffixGrid();
    pfgrid[ 'prefixSuffix' ] = 'PS';
    pfgrid[ 'prefixSuffixType' ] = 'Limit';
    pfgrid[ 'userDefinedValue' ] = '';
    pfgrid[ 'from' ] = 1;
    pfgrid[ 'to' ] = 2;
    pfgrid[ 'newSeries' ] = 'Y';
    pfgrid[ 'id' ] = 'some_id';
    return pfgrid;
}
describe('PrefixSuffixFormComponent (inline template)', () => {
    let component: PrefixSuffixFormComponent;
    let fixture: ComponentFixture<PrefixSuffixFormComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ FormsModule, ReactiveFormsModule ],
            declarations: [ PrefixSuffixFormComponent ],
            providers: [],
            schemas: [ NO_ERRORS_SCHEMA ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PrefixSuffixFormComponent);
        component = fixture.componentInstance;
        component.editForm = new FormGroup({
            'prefixSuffix': new FormControl(null, Validators.required),
            'prefixSuffixType': new FormControl(null, Validators.required),
            'userDefinedValue': new FormControl({value: null, disabled: true}, Validators.required),
            'from': new FormControl({disabled: false}, Validators.required),
            'to': new FormControl({disabled: false}, Validators.required),
            'newSeries': new FormControl({disabled: false}, Validators.required)
        });
        fixture.detectChanges();
        de = fixture.debugElement;
        el = de.nativeElement;
    });

    it('should set model', () => {
        component.model = getPfGrid();
        expect(component.editForm.get('prefixSuffix').value.code).toEqual('PS');
        expect(component.editForm.get('prefixSuffixType').value.code).toEqual('Limit');
        expect(component.editForm.get('newSeries').value.value).toEqual('Y');
        expect(component.editForm.get('from').value).toEqual(1);
        expect(component.editForm.get('to').value).toEqual(2);
        expect(component.editForm.get('userDefinedValue').value).toEqual('');
        expect(component.editForm.get('newSeries').value.value).toEqual('Y');
    });

    it('should disable userdefined values', () => {
        component.handleUserDefinedValue({});
        expect(component.editForm.get('from').enabled).toEqual(true);
        expect(component.editForm.get('to').enabled).toEqual(true);
        expect(component.editForm.get('newSeries').enabled).toEqual(true);
        expect(component.editForm.get('userDefinedValue').enabled).toEqual(false);
    });

    it('should save', () => {
        component.model = getPfGrid();
        component.onSave(new Event('click'));
        expect(component.save).toBeTruthy();
        expect(component.active).toEqual(false);
    });

    it('should copy data and return ', () => {
        component.model = getPfGrid();
        expect(component.editForm.get('prefixSuffix').value.code).toEqual('PS');
        expect(component.editForm.get('prefixSuffixType').value.code).toEqual('Limit');
        expect(component.editForm.get('newSeries').value.value).toEqual('Y');
        expect(component.editForm.get('from').value).toEqual(1);
        expect(component.editForm.get('to').value).toEqual(2);
        expect(component.editForm.get('userDefinedValue').value).toEqual('');
        expect(component.editForm.get('newSeries').value.value).toEqual('Y');
    });

    it('should enable userdefined values', () => {
        component.handleUserDefinedValue({'code': 'UD'});
        expect(component.editForm.get('from').enabled).toEqual(false);
        expect(component.editForm.get('to').enabled).toEqual(false);
        expect(component.editForm.get('newSeries').enabled).toEqual(false);
        expect(component.editForm.get('userDefinedValue').enabled).toEqual(true);
    });


    it('should populate from and to', () => {
        const pfgrid = new PrefixSuffixGrid();
        pfgrid[ 'userDefinedValue' ] = 'ABCD';
        component.model = pfgrid;
        component.populateFromandTo();
        expect(component.editForm.get('from')).toBeTruthy();
        expect(component.editForm.get('from').value).toBeDefined();
        expect(component.editForm.get('to')).toBeTruthy();
        expect(component.editForm.get('to').value).toBeDefined();
    });

    it('should reset values', () => {
        component.reset();
        expect(component.editForm.get('userDefinedValue').value).toEqual(null);
        expect(component.editForm.get('from').value).toEqual(null);
        expect(component.editForm.get('to').value).toEqual(null);
        expect(component.editForm.get('newSeries').value).toEqual(null);
    });

    it('should contains instance of formGroup', () => {
        fixture.detectChanges();
        expect(component.editForm instanceof FormGroup).toBe(true);
    });

    it('should contains prefixsuffix', () => {
        fixture.detectChanges();
        expect(component.editForm.get('prefixSuffix')).toBeTruthy();
    });

    it('should contains prefixSuffixType', () => {
        fixture.detectChanges();
        expect(component.editForm.get('prefixSuffixType')).toBeTruthy();
    });

    it('should contains from', () => {
        fixture.detectChanges();
        expect(component.editForm.get('from')).toBeTruthy();
    });

    it('should contains to', () => {
        fixture.detectChanges();
        expect(component.editForm.get('to')).toBeTruthy();
    });

    it('should contains newSeries', () => {
        fixture.detectChanges();
        expect(component.editForm.get('newSeries')).toBeTruthy();
    });

    it('should onCancel', () => {
        component.model = getPfGrid();
        component.onCancel(new Event('click'));
        expect(component.onCancel).toBeTruthy();
        expect(component.active).toEqual(false);
    });
});


