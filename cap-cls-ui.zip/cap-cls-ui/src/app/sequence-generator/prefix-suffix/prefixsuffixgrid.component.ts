import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

import { DataStateChangeEvent, GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { orderBy, process, SortDescriptor, State } from '@progress/kendo-data-query';
import { ErrorResponse, SeqGenService } from '../../shared';
import { PrefixSuffixCode, PrefixSuffixGrid, PrefixSuffixTypes } from '../model';

@Component({
    selector: 'prefix-suffix',
    templateUrl: './prefixsuffixgrid.html',
    styleUrls: [ './prefixsuffix.scss' ]
})
export class PrefixSuffixComponent implements OnInit, OnChanges {

    private gridView: GridDataResult;
    private sort: SortDescriptor[] = [];
    public prefixSuffixCode: PrefixSuffixCode[];
    public PrefixSuffixTypes: PrefixSuffixTypes[];
    private errorResponse: ErrorResponse = null;
    public editDataItem: PrefixSuffixGrid;
    public isNew: boolean;
    public createComp: boolean;
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10,
        filter: null
    };

    @Output()
    psDetailsEmit = new EventEmitter<PrefixSuffixGrid[]>();

    @Input('gridData')
    psDetails: PrefixSuffixGrid[];

    @Input('operation')
    operation: string;

    constructor( private seqGenService: SeqGenService ) {
        if (!this.psDetails) {
            this.psDetails = [];
        }
        this.populatePrefixSuffix();
    }

    public ngOnInit(): void {
        this.gridView = process(this.psDetails, this.gridState);
    }

    ngOnChanges( changes: SimpleChanges ) {
        if (changes[ 'psDetails' ]) {
            if (!this.psDetails) {
                this.psDetails = [];
            }
            this.loadData();
        }
    }

    public onStateChange( state: DataStateChangeEvent ) {
        this.gridState = state;
        this.loadData();
    }

    protected sortChange( sort: SortDescriptor[] ): void {
        this.sort = sort;
    }

    protected pageChange( event: PageChangeEvent ): void {
        this.gridState.skip = event.skip;
    }

    private loadItems(): void {
        this.gridView = {
            data: this.psDetails.slice(this.gridState.skip, this.gridState.skip + this.gridState.take),
            total: this.psDetails.length
        };
    }

    public loadData() {
        const gridView = process(this.psDetails, this.gridState);
        this.gridView = {
            data: orderBy(gridView.data, this.sort),
            total: gridView.total
        };

    }

    public addHandler() {
        this.editDataItem = new PrefixSuffixGrid();
        this.isNew = true;
        this.createComp = true;
    }

    public editHandler( {dataItem} ) {
        this.createComp = true;
        this.editDataItem = dataItem;
        this.isNew = false;
    }

    public cancelHandler() {
        this.editDataItem = undefined;
        this.createComp = false;
    }

    public saveHandler( data: PrefixSuffixGrid ) {
        this.createComp = false;

        if (this.isNew) {
            this.psDetails.unshift(data);
        } else {
            this.psDetails[ this.findSelectedPSIndex(this.editDataItem) ] = data;
        }

        this.psDetailsEmit.emit(this.psDetails);
        this.loadData();
        this.editDataItem = undefined;
    }


    public removeHandler( {dataItem} ) {
        this.psDetails.splice(this.findSelectedPSIndex(dataItem), 1);
        this.psDetailsEmit.emit(this.psDetails);
        this.loadData();
    }

    findSelectedPSIndex( product: PrefixSuffixGrid ): number {
        return this.psDetails.indexOf(product);
    }

    populatePrefixSuffix() {
        this.seqGenService.getPrefixSuffixCodes().subscribe(data => {
            this.prefixSuffixCode = <PrefixSuffixCode[]>data;
        }, error => {
            this.errorResponse = <ErrorResponse>error;
        });

        this.seqGenService.getPrefixSuffixTypes().subscribe(data => {
            this.PrefixSuffixTypes = <PrefixSuffixTypes[]>data;
        }, error => {
            this.errorResponse = <ErrorResponse>error;
        });
    }
}


