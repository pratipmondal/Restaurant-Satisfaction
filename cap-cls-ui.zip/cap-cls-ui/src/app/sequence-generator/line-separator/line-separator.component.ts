import { Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'seq-gen-line-separator',
    template: `
            <div class="line-container">
            <span [class]="lineSeparatorClass">{{title}}</span>
            <hr>            
            <hr  width="30px" align="left" class="line-bold"></div>
            
            `,
    styleUrls: [ './line-separator.component.scss' ]
})
export class LineSeparatorComponent implements OnInit {

    @Input()
    title: string;

    @Input()
    lineSeparatorClass: string;

    constructor() {
    }

    ngOnInit() {
    }

}
