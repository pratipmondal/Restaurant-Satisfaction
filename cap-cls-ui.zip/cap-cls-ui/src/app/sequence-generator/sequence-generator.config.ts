import { OpaqueToken } from '@angular/core';

import { SQConfig } from './model/sequence-configmodel';
import { environment } from '../../environments/environment';

export let SEQ_GEN_CONFIG = new OpaqueToken('sequence-generator.config');

export const SeqGenConfig: SQConfig = {
	uiMeta: environment.apiBaseUrl + 'UIComponent/modelmeta/sequence-generator',
	sequence: environment.apiBaseUrl + 'sequence',
	prefixSuffixCodes: environment.apiBaseUrl + 'prefix-suffix-code',
	prefixSuffixTypes: environment.apiBaseUrl + 'prefix-suffix-type',
	login: environment.apiBaseUrl + 'login',
	sequenceTypes: environment.apiBaseUrl + 'sequence-type'
};
