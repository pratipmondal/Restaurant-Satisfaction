import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';

import { SequenceGeneratorComponent } from './sequence-generator.component';
import { SeqGenService } from '../shared/httpapi/seq-gen.service';
import { LoginService, OauthService } from '../shared';
import { Observable } from 'rxjs/Rx';
import { SequenceGeneratorUiMetaModel } from './model/sequence-generator-uimetamodel';
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';


class MockSeqGenService {
    getToken() {
        return 'token';
    }

    getUiMetaModel() {
        return Observable.of(new SequenceGeneratorUiMetaModel());
    }
}

class MockLoginService {
}

class MockOathService {
}
describe('Sequence Generator UI', () => {
    let component: SequenceGeneratorComponent;
    let fixture: ComponentFixture<SequenceGeneratorComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ HttpModule, FormsModule, RouterTestingModule ],
            declarations: [ SequenceGeneratorComponent ],
            providers: [ {provide: SeqGenService, useClass: MockSeqGenService},
                {provide: LoginService, useClass: MockLoginService},
                {provide: OauthService, useClass: MockOathService} ],
            schemas: [ NO_ERRORS_SCHEMA ]
        });

        fixture = TestBed.createComponent(SequenceGeneratorComponent);
        component = fixture.debugElement.componentInstance;
        TestBed.compileComponents();
    }));


    it('should create the Sequence Generator Component', async(() => {
        expect(component).toBeTruthy();
    }));

    it('should Sequence Generator Component be rendered', async(() => {
        expect(component.showActions).toEqual(true);
    }));

    it('should Sequence Generator Component render title', async(() => {
        fixture.detectChanges();
        const compiled = fixture.debugElement.nativeElement;
        expect(compiled.querySelector('div').textContent).toContain('Select the action for Sequence Generator');
    }));

    it('getToken returns null when SequenceGeneratorUiMetaModel is null', async(() => {
        let seqGenService: SeqGenService;
        seqGenService = TestBed.get(SeqGenService);
        spyOn(seqGenService, 'getUiMetaModel').and.returnValue(Observable.of(null));
        expect(component.getmeta()).toBeUndefined;
        expect(seqGenService.getUiMetaModel).toHaveBeenCalled();
    }));


    it('should actionSelect method be called on click event on add radio-button ', fakeAsync(() => {
        fixture.detectChanges();
        spyOn(component, 'actionSelect');
        const btn = fixture.debugElement.query(By.css('#options'));
        btn.triggerEventHandler('click', 'Add');
        tick();
        fixture.detectChanges();
        expect(component.actionSelect).toHaveBeenCalled();
    }));


    it('should actionSelect method be called and update the instance', async(() => {
        component.actionSelect('Modify');
        expect(component.performAction).toEqual('Modify');
        expect(component.showActions).toBe(false);
    }));

    it('should cancelEvent method be called on cancel button ', async(() => {
        component.cancelEvent(event);
        expect(component.showActions).toBe(true);
    }));
});
