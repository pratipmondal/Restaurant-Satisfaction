import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { ComboBoxModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { ClsSharedCommonModule } from '../shared/';

import { SeqGenFormComponent } from './seq-gen-form/seq-gen-form.component';
import { SEQ_GEN_ROUTE, SequenceGeneratorComponent } from './';
import { SEQ_GEN_CONFIG, SeqGenConfig } from './sequence-generator.config';
import { PrefixSuffixComponent } from './prefix-suffix/prefixsuffixgrid.component';
import { PrefixSuffixFormComponent } from './prefix-suffix/prefixsuffix.form.component';
import { LineSeparatorComponent } from './line-separator/line-separator.component';
import { CounterpartyDetailsModule } from '../shared/counterparty-details/counterparty-details.module';


@NgModule({
    imports: [
        RouterModule.forChild([ SEQ_GEN_ROUTE ]), CommonModule,
        ButtonsModule, DialogModule, GridModule, FormsModule, BrowserModule,
        DropDownsModule, ReactiveFormsModule, InputsModule, ComboBoxModule,
        ClsSharedCommonModule, CounterpartyDetailsModule
    ],
    declarations: [
        SequenceGeneratorComponent,
        SeqGenFormComponent,
        PrefixSuffixComponent,
        PrefixSuffixFormComponent,
        LineSeparatorComponent
    ],
    entryComponents: [],
    providers: [
        {provide: SEQ_GEN_CONFIG, useValue: SeqGenConfig}
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class SequenceGeneratorModule {
}
