import { Route } from '@angular/router';

import { UserRouteAccessService } from '../shared';
import { SequenceGeneratorComponent } from './';

export const SEQ_GEN_ROUTE: Route = {
    path: 'seq-gen',
    component: SequenceGeneratorComponent,
    data: {
        pageTitle: 'CLS - Sequence Generator'
    },
    canActivate: [ UserRouteAccessService ]
};
