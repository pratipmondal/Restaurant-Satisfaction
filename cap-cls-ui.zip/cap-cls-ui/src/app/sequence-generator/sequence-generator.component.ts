import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import { SequenceGeneratorUiMetaModel } from './';
import { LoginService, OauthService, SeqGenService } from '../shared';

@Component({
    selector: 'seq-gen',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './sequence-generator.html',
    styleUrls: [ './sequence-generator.component.scss' ]

})
export class SequenceGeneratorComponent implements OnInit {
    seqGenActions: any[];
    performAction: string;
    showActions: boolean;
    uimeta: SequenceGeneratorUiMetaModel;

    constructor( private loginService: LoginService, private seqGenService: SeqGenService, private oauthService: OauthService ) {
        this.seqGenActions = [ {'value': 'add', 'text': 'Add'}, {
            'value': 'modify',
            'text': 'Modify'
        }, {'value': 'enquire', 'text': 'Enquire'} ];
        this.showActions = true;
    }

    ngOnInit(): void {
    }

    actionSelect( selectedValue ) {
        this.performAction = selectedValue;
        this.showActions = false;
    }

    getmeta() {
        this.seqGenService.getUiMetaModel().subscribe(data => {
            this.uimeta = <SequenceGeneratorUiMetaModel>data;
        });
    }

    cancelEvent( isCancel ) {
        this.showActions = true;
    }

}
