export interface PrefixSuffixCode {
    code?: string;
    description?: string;
    id?: string;
    parentRefType?: string;
    parentRefCode?: string;
    type?: string;
    createdBy?: string;
    modifiedBy?: string;
    createdOn?: Date;
    modifiedOn?: Date;
    version?: string;
    isDeleted?: boolean;
}
