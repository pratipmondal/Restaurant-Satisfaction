export interface SQConfig {
    uiMeta: string;
    sequence: string;
    prefixSuffixCodes: string;
    prefixSuffixTypes: string;
    login: string;
    sequenceTypes: string;
}
