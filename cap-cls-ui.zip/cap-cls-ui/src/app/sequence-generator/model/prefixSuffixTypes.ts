export interface PrefixSuffixTypes {
    code?: string;
    description?: string;
    parentRefType?: string;
    parentRefCode?: string;
    id?: string;
    type?: string;
    createdBy?: string;
    modifiedBy?: string;
    createdOn?: Date;
    modifiedOn?: Date;
    version?: string;
    isDeleted?: boolean;
}
