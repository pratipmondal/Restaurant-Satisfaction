export interface sequenceCode {
    regexp: string;
}

export interface Where {
    sequenceCode: sequenceCode;
}

export interface SequenceCodeFilter {
    where: Where;
    limit: string;
}
