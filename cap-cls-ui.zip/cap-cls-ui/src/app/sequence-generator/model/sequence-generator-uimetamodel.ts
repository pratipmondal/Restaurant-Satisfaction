export interface Elements {
}

export interface SequenceType {
    type: string;
    required: boolean;
}

export interface SequenceCode {
    type: string;
    unique: boolean;
    required: boolean;
    caseInsensitive: boolean;
    max: number;
    pattern: string;
}

export interface StartNum {
    type: string;
    required: boolean;
    numericality: string;
    min: number;
}

export interface EndNum {
    type: string;
    required: boolean;
    numericality: string;
    min: number;
}

export interface Listdata {
    code: string;
    description: string;
    id: string;
    _type: string;
    _createdBy: string;
    _modifiedBy: string;
    _createdOn: Date;
    _modifiedOn: Date;
    _version: string;
    _isDeleted: boolean;
}

export interface ZeroFill {
    type: string;
    length: number;
    required: boolean;
    caseInsensitive: boolean;
    refcodetype: string;
    default: string;
    displayproperty: string;
    valueproperty: string;
    listdata: Listdata[];
}

export interface FieldLength {
    type: string;
    required: boolean;
    numericality: string;
    default: number;
}

export interface PrefixSuffix {
    type: string;
    refcodetype: string;
    caseInsensitive: boolean;
    required: boolean;
}

export interface PrefixSuffixType {
    type: string;
    refcodetype: string;
    required: boolean;
}

export interface UserDefinedValue {
    type: string;
    length: number;
    pattern: string;
}

export interface From {
    type: string;
    required: boolean;
    min: number;
    max: number;
    numericality: string;
    default: number;
}

export interface To {
    type: string;
    min: number;
    max: number;
    numericality: string;
}

export interface NewSeries {
    type: string;
    refcodetype: string;
    caseInsensitive: boolean;
    default: string;
}

export interface SubModelMeta {
    prefixSuffix: PrefixSuffix;
    prefixSuffixType: PrefixSuffixType;
    userDefinedValue: UserDefinedValue;
    from: From;
    to: To;
    newSeries: NewSeries;
}

export interface PrefixSuffixGrid0 {
    type: string;
    itemtype: string;
    modeltype: string;
    subModelMeta: SubModelMeta;
}

export interface Properties {
    sequenceType: SequenceType;
    sequenceCode: SequenceCode;
    startNum: StartNum;
    endNum: EndNum;
    zeroFill: ZeroFill;
    fieldLength: FieldLength;
    prefixSuffixGrid: PrefixSuffixGrid0;
}

export interface Nntm {
    resturl: string;
    properties: Properties;
}

export interface PrefixSuffix3 {
    type: string;
    refcodetype: string;
    caseInsensitive: boolean;
    required: boolean;
}

export interface PrefixSuffixType2 {
    type: string;
    refcodetype: string;
    required: boolean;
}

export interface UserDefinedValue2 {
    type: string;
    length: number;
    pattern: string;
}

export interface From2 {
    type: string;
    required: boolean;
    min: number;
    max: number;
    numericality: string;
    default: number;
}

export interface To2 {
    type: string;
    min: number;
    max: number;
    numericality: string;
}

export interface NewSeries2 {
    type: string;
    refcodetype: string;
    caseInsensitive: boolean;
    default: string;
}

export interface Properties2 {
    prefixSuffix: PrefixSuffix3;
    prefixSuffixType: PrefixSuffixType2;
    userDefinedValue: UserDefinedValue2;
    from: From2;
    to: To2;
    newSeries: NewSeries2;
}

export interface PrefixSuffix2 {
    resturl: string;
    properties: Properties2;
}

export interface Models {
    Nntm: Nntm;
    PrefixSuffix: PrefixSuffix2;
}

export interface SequenceType2 {
    type: string;
    required: boolean;
}

export interface SequenceCode2 {
    type: string;
    unique: boolean;
    required: boolean;
    caseInsensitive: boolean;
    max: number;
    pattern: string;
}

export interface StartNum2 {
    type: string;
    required: boolean;
    numericality: string;
    min: number;
}

export interface EndNum2 {
    type: string;
    required: boolean;
    numericality: string;
    min: number;
}

export interface Listdata2 {
    code: string;
    description: string;
    id: string;
    _type: string;
    _createdBy: string;
    _modifiedBy: string;
    _createdOn: Date;
    _modifiedOn: Date;
    _version: string;
    _isDeleted: boolean;
}

export interface ZeroFill2 {
    type: string;
    length: number;
    required: boolean;
    caseInsensitive: boolean;
    refcodetype: string;
    default: string;
    displayproperty: string;
    valueproperty: string;
    listdata: Listdata2[];
}

export interface FieldLength2 {
    type: string;
    required: boolean;
    numericality: string;
    default: number;
}

export interface PrefixSuffix4 {
    type: string;
    refcodetype: string;
    caseInsensitive: boolean;
    required: boolean;
}

export interface PrefixSuffixType3 {
    type: string;
    refcodetype: string;
    required: boolean;
}

export interface UserDefinedValue3 {
    type: string;
    length: number;
    pattern: string;
}

export interface From3 {
    type: string;
    required: boolean;
    min: number;
    max: number;
    numericality: string;
    default: number;
}

export interface To3 {
    type: string;
    min: number;
    max: number;
    numericality: string;
}

export interface NewSeries3 {
    type: string;
    refcodetype: string;
    caseInsensitive: boolean;
    default: string;
}

export interface SubModelMeta2 {
    prefixSuffix: PrefixSuffix4;
    prefixSuffixType: PrefixSuffixType3;
    userDefinedValue: UserDefinedValue3;
    from: From3;
    to: To3;
    newSeries: NewSeries3;
}

export interface PrefixSuffixGrid2 {
    type: string;
    itemtype: string;
    modeltype: string;
    subModelMeta: SubModelMeta2;
}

export interface Properties3 {
    sequenceType: SequenceType2;
    sequenceCode: SequenceCode2;
    startNum: StartNum2;
    endNum: EndNum2;
    zeroFill: ZeroFill2;
    fieldLength: FieldLength2;
    prefixSuffixGrid: PrefixSuffixGrid2;
}

export interface Metadata {
    models: Models;
    resturl: string;
    properties: Properties3;
}

export class SequenceGeneratorUiMetaModel {
    componentName: string;
    elements: Elements;
    modelName: string;
    modelAlias: string;
    metadata: Metadata;
    autoInjectFields: boolean;
}

