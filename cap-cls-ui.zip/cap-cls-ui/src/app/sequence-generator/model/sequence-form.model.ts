export interface Scope {
}

export class PrefixSuffixGrid {
    prefixSuffix: string;
    prefixSuffixType: string;
    userDefinedValue: string;
    from: number;
    to: number;
    newSeries: string;
    id: string;
    _type: string;
    _createdBy: string;
    _modifiedBy: string;
    _createdOn: Date;
    _modifiedOn: Date;
    scope: Scope;
    _version: string;
    _isDeleted: boolean;
}

export interface Scope2 {
}

export interface SequenceFormModel {
    sequenceType: string;
    sequenceCode: string;
    startNum: number;
    endNum: number;
    zeroFill: string;
    fieldLength: number;
    prefixSuffixGrid: PrefixSuffixGrid[];
    id: string;
    _type: string;
    _createdBy: string;
    _modifiedBy: string;
    _createdOn: Date;
    _modifiedOn: Date;
    scope: Scope2;
    _version: string;
    _isDeleted: boolean;
}
