import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

import { SeqGenService } from '../../shared/httpapi/seq-gen.service';
import { Observable } from 'rxjs/Rx';
import { SequenceGeneratorUiMetaModel } from '../model/sequence-generator-uimetamodel';
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { SeqGenFormComponent } from './seq-gen-form.component';


class MockSeqGenService {
    getToken() {
        return 'token';
    }

    getUiMetaModel() {
        return Observable.of(new SequenceGeneratorUiMetaModel());
    }

    getSequenceTypes() {
        return Observable.of();
    }
}


describe('Sequence Generator Form UI', () => {
    let component: SeqGenFormComponent;
    let fixture: ComponentFixture<SeqGenFormComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ HttpModule, FormsModule, RouterTestingModule, ReactiveFormsModule ],
            declarations: [ SeqGenFormComponent ],
            providers: [ {provide: SeqGenService, useClass: MockSeqGenService} ],
            schemas: [ NO_ERRORS_SCHEMA ]
        });
        fixture = TestBed.createComponent(SeqGenFormComponent);
        TestBed.compileComponents();

        component = fixture.debugElement.componentInstance;
        component.seqForm = new FormGroup({
            'seqType': new FormControl(null, Validators.required),
            'seqCode': new FormControl(null, [ Validators.required, Validators.maxLength(5) ]),
            'startNum': new FormControl(null, Validators.required),
            'endNum': new FormControl(null, Validators.required),
            'fieldLength': new FormControl(null, Validators.required)
        });
    });

    it('should ngOnInit() be called on component', () => {
        component.ngOnInit();
    });


    it('should create the Sequence Generator form', async(() => {
        expect(component).toBeTruthy();
    }));

    it('should Sequence Generator Form for to be rendered', async(() => {
        expect(component.isvalid).toEqual(false);
    }));

    it('should Sequence Generator Form for to be rendered', async(() => {
        expect(component.isvalid).toEqual(false);
    }));

    it('should check if startnum greater than endNum ', async(() => {
        component.startNumControl = new FormControl({value: 20});
        component.startNumControl.setValidators([ Validators.required ]);
        component.endNumControl = new FormControl({value: 5});
        component.endNumControl.setValidators([ Validators.required ]);
        component.seqForm = new FormGroup({
            'startNum': component.startNumControl,
            'endNum': component.endNumControl
        });
        expect(component.startSeqEndSeqValidator(component.seqForm)).toEqual({'mismatch': true});
    }));


    it('should check if endNum greater than startNum ', async(() => {
        component.seqForm = new FormGroup({
            'startNum': new FormControl(5, Validators.required),
            'endNum': new FormControl(20, Validators.required)
        });
        expect(component.startSeqEndSeqValidator(component.seqForm)).toEqual(null);
    }));


    it('should onTouched change the values of forTouched Object ', async(() => {
        component.seqForm = new FormGroup({});
        component.onTouched('seqType');
        expect(component.formTouched.seqType).toBe(true);
    }));

    it('should onTouched change the values of forTouched Object ', async(() => {

        component.seqForm = new FormGroup({
            'seqType': new FormControl(null, Validators.required),
            'seqCode': new FormControl(null, [ Validators.required, Validators.maxLength(5) ]),
            'startNum': new FormControl(null, Validators.required),
            'endNum': new FormControl(null, Validators.required),
            'fieldLength': new FormControl(null, Validators.required)
        });
        component.formErrors = {
            'seqType': 'dummySeqType',
            'seqCode': 'dummySeqCode',
            'startNum': 1,
            'endNum': 2,
            'fieldLength': '10'
        };
        component.onValueChanged();

    }));
});
