import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ErrorResponse, SeqGenService } from '../../shared';
import { PrefixSuffixCode, PrefixSuffixGrid, PrefixSuffixTypes, SequenceCodeFilter, SequenceFormModel } from '../model';

@Component({
    selector: 'app-seq-gen-form',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './seq-gen-form.component.html',
    styleUrls: [ './seq-gen-form.component.scss', '../sequence-generator.component.scss' ]
})
export class SeqGenFormComponent implements OnInit {
    sequenceCodeFilter: SequenceCodeFilter;
    message: string;
    globalMsg: boolean;
    failMsg: any[];
    seqTypes: any[];
    zeroFill: any[];
    disableSubmit: boolean;
    seqFormModel: SequenceFormModel;
    isvalid: boolean;
    searchData: Array<SequenceFormModel> = [];
    seqCodeDict: Map<String, SequenceFormModel>;
    prefixSuffixCode: PrefixSuffixCode[];
    PrefixSuffixTypes: PrefixSuffixTypes[];
    errorResponse: ErrorResponse = null;
    selectedItem: any;

    @Input()
    action: string;
    @Input()
    showSearch: boolean;
    @Input()
    disableModify: boolean;
    @Input()
    disableEnquiry: boolean;

    @Output()
    isCancel = new EventEmitter<boolean>();

    seqForm: FormGroup;

    seqTypeControl: FormControl;
    seqCodeControl: FormControl;
    startNumControl: FormControl;
    endNumControl: FormControl;
    fieldLengthControl: FormControl;
    testboolean: Boolean = false;

    jsonMsgType: string;
    jsonMsgBody: string[];

    statusObject: {} = {
        'msg_type': this.jsonMsgType,
        'msg_body': this.jsonMsgBody
    };

    formErrors = {
        'seqType': null,
        'seqCode': '',
        'startNum': null,
        'endNum': null,
        'fieldLength': ''
    };

    formTouched = {
        'seqType': false,
        'seqCode': false,
        'startNum': false,
        'endNum': false,
        'fieldLength': false
    };

    validationMessages = {
        'seqCode': {
            'required': 'Sequence code is required.'
        },
        'seqType': {
            'required': 'Sequence Type is required.'
        },
        'startNum': {
            'required': 'Start Sequence is required.'
        },
        'endNum': {
            'required': 'End Sequence is required.'
        },
        'fieldLength': {
            'required': 'Field Length is required.'
        }
    };

    constructor( private seqGenService: SeqGenService, private router: Router,
                 private route: ActivatedRoute, private location: Location ) {
        this.globalMsg = false;
        this.seqCodeDict = new Map();
        this.isvalid = false;
        // this.seqTypes = [{"value": "collateral", "label": "Collateral"}, {"value": "limits", "label": "Limits"}];
        this.zeroFill = [ {'value': 'Y', 'text': 'Yes'}, {'value': 'N', 'text': 'No'} ];
        this.seqFormModel = <SequenceFormModel>{};
        this.seqFormModel.zeroFill = 'Y';
        this.sequenceCodeFilter = {where: {sequenceCode: {regexp: ''}}, limit: '10'};
        this.sequenceCodeFilter.where.sequenceCode.regexp = '';
        this.sequenceCodeFilter.limit = '10';
        this.populateSequenceTypes();
    }

    ngOnInit(): void {
        this.seqTypeControl = new FormControl(null);
        this.seqTypeControl.setValidators([ Validators.required ]);

        this.seqCodeControl = new FormControl(null);
        this.seqCodeControl.setValidators([ Validators.required, Validators.maxLength(5) ]);

        this.startNumControl = new FormControl(null);
        this.startNumControl.setValidators([ Validators.required ]);

        this.endNumControl = new FormControl(null);
        this.endNumControl.setValidators([ Validators.required ]);

        this.fieldLengthControl = new FormControl(null);
        this.fieldLengthControl.setValidators([ Validators.required ]);

        this.seqForm = new FormGroup({
            'seqType': this.seqTypeControl,
            'seqCode': this.seqCodeControl,
            'startNum': this.startNumControl,
            'endNum': this.endNumControl,
            'fieldLength': this.fieldLengthControl
        }, this.startSeqEndSeqValidator);

        this.seqForm.valueChanges.subscribe(data => this.onValueChanged(data));
    }

    populateSequenceTypes() {
        this.seqGenService.getSequenceTypes().subscribe(data => {
            this.seqTypes = data;
        }, error => {
            this.errorResponse = <ErrorResponse>error;
        });
    }

    startSeqEndSeqValidator( g: FormGroup ) {
        return g.get('endNum').value > g.get('startNum').value
            ? null : {'mismatch': true};
    }

    onTouched( element ) {
        if (!this.seqForm) {
            return;
        }
        this.formTouched[ element ] = true;
    }

    onValueChanged( data?: any ) {
        if (!this.seqForm) {
            return;
        }
        const form = this.seqForm;
        for (const field in this.formErrors) {
            this.formErrors[ field ] = '';
            const control = form.get(field);
            this.formTouched[ field ] = control.touched;
            if (control && control.dirty && !control.valid) {
                const messages = this.validationMessages[ field ];
                for (const key in control.errors) {
                    this.formErrors[ field ] += messages[ key ] + ' ';
                }
            }
        }
    }

    typeChange( seqType ) {
        if (seqType) {
            this.seqFormModel.sequenceType = seqType.code;
        }
    }

    getPrefixsuffixData( psdata: PrefixSuffixGrid[] ) {
        this.seqFormModel.prefixSuffixGrid = psdata;
    }

    submitSeqForm( seqFormModel ) {
        if (this.action === 'Create New') {
            this.seqGenService.addSequence(seqFormModel).subscribe(data => {
                this.globalMsg = true;
                this.statusObject[ 'msg_type' ] = 'SUCCESS';
                this.statusObject[ 'msg_body' ] = [ 'Record Saved!!' ];
                // this.redirect();
            }, error => {
                this.errorResponse = <ErrorResponse>error;
                this.globalMsg = true;
                this.failMsg = this.getErrorsList(this.errorResponse, this.failMsg);
                this.statusObject[ 'msg_type' ] = 'FAILURE';
                this.statusObject[ 'msg_body' ] = this.failMsg;

            });
        }
        if (this.action === 'Modify') {
            this.seqGenService.updateSequence(seqFormModel).subscribe(data => {
                this.globalMsg = true;
                this.statusObject[ 'msg_type' ] = 'SUCCESS';
                this.statusObject[ 'msg_body' ] = [ 'Record Updated!!' ];
                // this.redirect();
            }, error => {
                this.errorResponse = <ErrorResponse>error;
                this.globalMsg = true;
                this.failMsg = this.getErrorsList(this.errorResponse, this.failMsg);
                this.statusObject[ 'msg_type' ] = 'FAILURE';
                this.statusObject[ 'msg_body' ] = this.failMsg;
            });
        }
    }

    wait( ms ) {
        let start = Date.now(),
            now = start;
        while (now - start < ms) {
            now = Date.now();
        }
    }

    redirect() {
        this.wait(3100);
        window.location.reload();
    }

    getErrorsList( errorResponse, failMsg ): any[] {
        failMsg = [];
        const errorBody = JSON.parse(errorResponse._body);
        for (let i = 0; i < errorBody[ 'errors' ].length; i++) {
            const error = errorBody[ 'errors' ][ i ];
            failMsg.push((error.path) ? error.path.slice(6) + ' : ' + error.message : error.code + ' : ' + error.message);
        }
        return failMsg;
    }

    renderSeqGenForm( seqCode ) {
        if (seqCode) {
            this.seqFormModel = this.seqCodeDict.get(seqCode);
            if (this.seqFormModel === undefined) {
                this.seqFormModel = <SequenceFormModel>{};
            }
            this.seqForm.get('seqType').setValue({'code': this.seqFormModel.sequenceType});
        }
        this.seqForm.get('seqType').disable(true);
    }

    handleRecord( searchValue ) {
        this.searchData = [];
        if (searchValue) {
            this.sequenceCodeFilter.where.sequenceCode.regexp = '/' + searchValue + '/i';
            this.seqGenService.getSequence(this.sequenceCodeFilter).subscribe(data => {
                    this.searchData = data;
                    if (this.searchData) {
                        for (let i = 0; i < this.searchData.length; i++) {
                            this.seqCodeDict.set(data[ i ].sequenceCode, data[ i ]);
                        }
                    }
                },
                error =>
                    this.errorResponse = <ErrorResponse>error
            );
        }
    }

    cancel() {
        this.isCancel.emit();
    }

    closeStatusObject() {
        this.globalMsg = false;
    }

    toggleError() {
        this.globalMsg = false;
        this.failMsg = [];
    }
}
