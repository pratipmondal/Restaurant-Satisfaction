// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `angular-cli.json`.

export const environment = {
	production: false,
	envName: 'sit',
	// edgeverveApiBaseUrl: 'http://cap-cls-service.dev.apps.cs.sgp.dbs.com/cls/api/v1/referenceData/ReferenceTypes?token=',
	token: '?token=',
	apiBaseUrl: 'https://cap-cls-service.sit.apps.cs.sgp.dbs.com/cls/api/v1/',
	oauthUrl: 'http://oauth-uaa.sit.apps.cs.sgp.dbs.com/oauth/authorize',
	oauthIssuer: 'http://oauth-uaa.sit.apps.cs.sgp.dbs.com/identity',
	clientid: 'cls-service',
	apiToGetAllReferenceTypes: 'reference-type',
	apiToPostReferenceTypeBulk: 'reference-data/bulk/',
	apiToGetPostReferenceData: 'reference-data/',
	apiToGetNatureOfCharges: 'nature-of-charge',
	apiToGetCifId: 'customer/search/',
	// apiBaseUrl: 'http://localhost:8080/cls/api/v1/',
	apiToGetCollateralOwnershipData: 'collateral-ownership/',
	apiGetGCINCIFCodeInfo: 'GCINCIFCodeInfo/',
	apiGetcollateralCodes: 'collateral-code',
	apiGetcollateralTypes: 'collateral-type',
	documentCodes: 'document-code',
	apientitysearch: 'entity/search/',
	apitToGetBankId: 'bank-id',
	apiToGetDepositId: 'bank-detail?bankId',
	apiToGetSpecificDetails: '&accountNum',
	apiToGetChargeRank: 'charge-rank',
	apiCollateralCustomer: 'collateralCustomers',
	apiToGetCountries: 'country',
	apiGuarnCollaterals: 'guarantee-collateral',
	apiDeposCollaterals: 'deposit-collateral',
	apiToWithdrawGuarnCollateral: 'guarantee-collateral/{id}/withdraw',
	apiToWithdrawDeposCollateral: 'deposit-collateral/{id}/withdraw',
	apiLimit: 'limit',
	apiDocumentStatus: 'document-status',
	apiToGetRates: 'rate',
	apiToGetCurrencyList: 'currency'
};
