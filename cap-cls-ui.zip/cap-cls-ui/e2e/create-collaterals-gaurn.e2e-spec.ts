describe('should complete add,edit,delete journey for collateral of Guarantee Type', () => {

	const createCollateralGaurnTestSuite = require('./utils/CollateralsCreateGaurnHelper');
	const editCollateralGaurnTestSuite = require('./utils/CollateralsEditGaurnHelper');
	const withdrawCollateralGaurnTestSuite = require('./utils/CollateralsWithdrawGaurnHelper');
	const processCreateCollateralGaurn = () => {
		createCollateralGaurnTestSuite.CreateCollateralGaurnTestSuite();
	};

	const processEditCollateralGaurn = () => {
		editCollateralGaurnTestSuite.EditCollateralGaurnTestSuite();
	};

	const processWithdrawCollateralGaurn = () => {
		withdrawCollateralGaurnTestSuite.WithdrawCollateralGaurnTestSuite();
	};

	describe('should create a collateral of guarantee type', () => {
		processCreateCollateralGaurn();
	});

	describe('should edit already created collateral of guarantee type', () => {
		processEditCollateralGaurn();
	});

	describe('should withdraw existing collateral of guarantee type ', () => {
		processWithdrawCollateralGaurn();
	});

});
