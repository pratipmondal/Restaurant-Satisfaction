import { E2eSpecHelper } from './E2eSpecHelper';
import { $ } from 'protractor';
import { document } from 'ng2-bootstrap/utils/facade/browser';
exports.DocumentTestSuite = function () {
	describe('Document Page', function () {
		const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
		const document: any = {
			saveFormBtn: $('#save-form-btn'),
			addDetailsBtn: $('#add-details-btn'),
			closeDialogIcon: $('.k-dialog-close'),
			noRecordLink: $('#no-records-label a'),
			deleteIcon: $('#deleteIcon'),
			documentIdOnTab: $('#document_tab'),
			documentBtnForPopDialog: $('.clsBtnSecondary'),
			documentLabel: $('#documentLable'),
			documentCodeId: $('#doccumentCodeId'),
			documentSearchId: $('#documentSearchId'),
			documentCodeErrorMessage: $('#documentCodeErrorMessage'),
			documentEditIcon: $('#editIcon'),
			documentCodeSearch: (searchTerm: string): any => e2eSpecHelper.dropDownSearchKeys(searchTerm, '#doccumentCodeId .k-searchbar .k-input'),
			documentCustodianSearch: (searchTerm: string): any => e2eSpecHelper.dropDownSearchKeys(searchTerm, '#documentSearchId .k-searchbar .k-input'),
			documentRemark: $('.commentTextArea__input'),
			documentRemarkInput: (documentRemarkInput: string): any => $('.commentTextArea__input').sendKeys(documentRemarkInput),
			documentDateIcon: $('#documentDate .k-select'),
			documentDueDate: $('#documentDueDate .k-select'),
			documentReceivedDate: $('#documentReceivedDate .k-select'),
			documentExpirationDate: $('#documentExpirationDate .k-select'),
			dateToday: $('.k-today '),
			dateWeekend: $('.k-weekend')
		};

		it('should display Document Tab on click', function () {
			e2eSpecHelper.sleepBrowser(1000);
			document.documentIdOnTab.click();
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('#document_tab', 'Document');
			e2eSpecHelper.sleepBrowser(1000);
		});

		it('should check for no records found for document', function () {
			e2eSpecHelper.verifyTextContains('#no-records-header', 'No Document Details Found');
			e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding document details');
			document.noRecordLink.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.closeDialogIcon.click();

		});

		it('should not validate Document Details if fields are empty', function () {
			e2eSpecHelper.sleepBrowser(2000);
			document.documentBtnForPopDialog.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.saveFormBtn.click();
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('.has-error');
		});

		it('should validate and save details for document', function () {
			e2eSpecHelper.sleepBrowser(1000);
			document.documentCodeId.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.documentDateIcon.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.dateToday.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.documentDueDate.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.dateToday.click();
			document.documentExpirationDate.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.dateWeekend.click();
			e2eSpecHelper.sleepBrowser(1000);
			document.documentCodeSearch('913-- Construction Budget');
			document.documentCustodianSearch('07--Doc Release (Pend Redemption)');
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully Added.');
		});

		it('should show error if invalid entries are given', function () {
			document.documentBtnForPopDialog.click();
			e2eSpecHelper.sleepBrowser(1000);
			document.documentCodeSearch('aaaaa');
			document.documentCustodianSearch('aaaaa');
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('.has-error');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyPresence('.k-dialog-close');
			document.closeDialogIcon.click();
			e2eSpecHelper.sleepBrowser(2000);
		});

		it('should update document details', function () {
			document.documentEditIcon.click();
			e2eSpecHelper.sleepBrowser(2000);
			document.documentRemark.clear();
			document.documentRemarkInput('Test Remarks');
			document.saveFormBtn.click();
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully Updated.');
			e2eSpecHelper.verifyPresence('.k-grid');

		});

		it('should remove document details on click of delte button', function () {
			e2eSpecHelper.verifyPresence('#deleteIcon');
			document.deleteIcon.click();
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyPresence('#no-records-div');
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Document details has been successfully deleted.');
			e2eSpecHelper.sleepBrowser(2000);
		});

	});
};

exports.DocumentTestSuiteForEditFlow = function () {
	describe('Document Page for Edit Flow', function () {
		/*TODO */
	});
};
