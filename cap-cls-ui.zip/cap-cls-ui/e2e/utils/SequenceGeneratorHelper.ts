import { browser, by, element, protractor, $, $$ } from 'protractor';
import * as fs from 'fs';
import * as path from 'path';

function getRandomString(length) {
    var string = '';
    var letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    for (var i = 0; i < length; i++) {
        string += letters.charAt(Math.floor(Math.random() * letters.length));
    }
    return string;
}


exports.SequenceGeneratorTestSuite = function() {

    describe('Sequence Generator page', function () {
        browser.ignoreSynchronization = true;

    it('should navigate to add Sequence Generator page after selecting Add', () => {
        element.all(by.id('options')).get(0).click();
        expect(browser.driver.findElement(by.className('cst-padding sub-panel-label')).getText()).toEqual('Create New Sequence');
    });

    it('should navigate to Sequence Generator main page on click of Cancel button', () => {
        element(by.buttonText('Cancel')).click();
        expect(browser.driver.findElement(by.className('cst-padding panel-label')).getText()).toEqual('Sequence Generator');
    });

    it('should populate values ', () => {
        element.all(by.id('options')).get(0).click();
        browser.sleep(3000);
        var comboBox = element(by.id("seqType")).element(by.className('k-dropdown-wrap k-state-default')).element(by.className('k-searchbar')).element(by.className('k-input'));
        comboBox.sendKeys(protractor.Key.ARROW_DOWN);

        element(by.id('seqCode')).sendKeys(getRandomString(5));
        element(by.id('startNum')).element(by.className('k-numeric-wrap')).element(by.className('k-input k-formatted-value')).sendKeys('12');
        element(by.id('endNum')).element(by.className('k-numeric-wrap')).element(by.className('k-input k-formatted-value')).sendKeys('123');
        element(by.id('fieldLength')).element(by.className('k-numeric-wrap')).element(by.className('k-input k-formatted-value')).sendKeys('123');
        element(by.className('submit-button-seq clsBtn')).click();

        expect(browser.driver.findElement(by.className('cst-padding panel-label')).getText()).toEqual('Sequence Generator');
    });

    it('should navigate to seq gen home page after Add', () => {
        browser.get('/seq-gen');
    });

    it('should navigate to Modify Sequence Generator page after selecting Modify', () => {
        element.all(by.id('options')).get(1).click();
        expect(browser.driver.findElement(by.className('cst-padding sub-panel-label')).getText()).toEqual('Modify Sequence');
    });

    it('should set values on modify sequence', () => {
       var el = element(by.tagName('kendo-autocomplete')).element(by.tagName('kendo-searchbar')).element(by.tagName('input'));
        el.sendKeys('DINE');
        browser.sleep(3000);
        el.sendKeys(protractor.Key.ARROW_DOWN);
        el.sendKeys(protractor.Key.ENTER);
        element(by.className('cancel-button-seq clsBtnCancel k-button')).click();
        element(by.id('endNum')).element(by.className('k-numeric-wrap')).element(by.className('k-input k-formatted-value')).sendKeys('123');
        element(by.className('submit-button-seq clsBtn')).click();
        expect(browser.driver.findElement(by.className('cst-padding panel-label')).getText()).toEqual('Sequence Generator');
    });

     it('should navigate to seq gen home page after Modify', () => {
        browser.get('/seq-gen');
    });

    it('should navigate to Enquire Sequence Generator page after selecting Enquire', () => {
        element.all(by.id('options')).get(2).click();
        expect(browser.driver.findElement(by.className('cst-padding sub-panel-label')).getText()).toEqual('Enquire Sequence');
    });

    it('should set values on Enquire sequence', () => {
        var el = element(by.tagName('kendo-autocomplete')).element(by.tagName('kendo-searchbar')).element(by.tagName('input'));
        el.sendKeys('DINE');
        browser.sleep(3000);
        el.sendKeys(protractor.Key.ARROW_DOWN);
        el.sendKeys(protractor.Key.ENTER);
        element(by.id('done')).click();
        expect(browser.driver.findElement(by.className('cst-padding panel-label')).getText()).toEqual('Sequence Generator');
    });

    });
};