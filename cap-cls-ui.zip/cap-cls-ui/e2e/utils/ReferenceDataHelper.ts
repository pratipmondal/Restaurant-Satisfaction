import { browser, by, element, protractor } from 'protractor';
import { E2eSpecHelper } from './E2eSpecHelper';

exports.ReferenceDataTestSuite = function () {

	const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

	describe('Reference Data Page', function () {

		browser.ignoreSynchronization = true;

		it('should load reference data page', function () {
			const kl = e2eSpecHelper.sideNav.getCssValue('width');
			expect(e2eSpecHelper.sideNav.getCssValue('width')).toEqual('0px');
			e2eSpecHelper.hamburgerIcon.click();
			browser.sleep(2000);
			e2eSpecHelper.refDataLink.click();
		});

		it('should display heading as Reference Types', () => {
			browser.sleep(2000);
			expect(element(by.xpath('//span[@class=\'ref-type panel-label\']')).getText()).toEqual('Reference Types');
		});

		it('bulk upload button should be disabled', () => {
			expect(element(by.css('.upload_file_custom')).getAttribute('disabled')).toBe('true');
		});

		it('add single upload button should be disabled', () => {
			expect(element(by.css('.single_button_class ')).getAttribute('disabled')).toBe('true');
		});

		it('should display "No records available" when page loads', () => {
			expect(element(by.xpath('//tr[@class=\'k-grid-norecords\']')).getText()).toEqual('No records available.');
		});

		it('should type "Country" in auto complete and display data in the grid', () => {
			browser.sleep(1000);
			element(by.className('k-widget k-autocomplete k-header ')).click();
			element(by.css('kendo-searchbar > .k-input')).sendKeys('Country', protractor.Key.ENTER);
			expect(element(by.css('.single_button_class')).isEnabled()).toEqual(true);
			expect(element(by.css('.upload_file_custom')).isEnabled()).toEqual(true);
			expect(element(by.css('.file_upload')).isEnabled()).toEqual(true);
		});

		it('click on Add ref button', () => {
			browser.sleep(2000)
			element(by.css('.single_button_class ')).click();
			const addDialogBox = element(by.css('.k-dialog-title'));
			browser.wait(function () {
				return browser.isElementPresent(addDialogBox);
			}, 1000);
			expect(addDialogBox.getText()).toEqual('Reference Data');
			const codeInput = element(by.css('[formControlName="code"]'));
			const descriptionInput = element(by.css('[formControlName="description"]'));
			const selectRefType = element(by.css('.parentRefSelect > kendo-searchbar > .k-input')).sendKeys('Country', protractor.Key.ENTER);
			codeInput.sendKeys('Singapore');
			descriptionInput.sendKeys('Singapore');
			expect(element(by.css('.save-btn')).isEnabled()).toBeTruthy();
		});

		it('click on Cancel button when adding ref', () => {
			browser.sleep(1000);
			const cancelBtn = element(by.css('.cancel-btn'));
			expect(cancelBtn.isPresent()).toBeTruthy();
			cancelBtn.click();
			expect(element(by.css('.main-container')).isPresent()).toBeFalsy();
		});

		it('should open file upload popup and close', () => {
			browser.sleep(1000);
			browser.actions().mouseMove(element(by.css('.upload_file_custom'))).perform();
			const absolutePath = e2eSpecHelper.path.resolve(__dirname, './sample_refcode_success.xlsx');
			element(by.className('file_upload')).sendKeys(absolutePath);
			expect(element(by.css('.k-dialog-title')).getText()).toEqual('File to Upload');
			browser.sleep(1000);
			element(by.className('k-window-actions k-dialog-actions ')).click();
			expect(element(by.css('.k-dialog-title')).isPresent()).toBeFalsy();
		});

		it('should click the edit icon and open the update page', () => {

			const editIconLink = element.all(by.id('editIcon')).get(2);
			expect(editIconLink.isPresent()).toBeTruthy();
			editIconLink.click();

		});

		it('click on edit ref button', () => {
			browser.sleep(1000);
			const updateDialogBox = element(by.css('.k-dialog-title'));
			browser.wait(function () {
				return browser.isElementPresent(updateDialogBox);
			}, 1000);
			expect(updateDialogBox.getText()).toEqual('Reference Data');
		});

		it('click on Cancel button when updating ref', () => {
			const cancelBtn = element(by.css('.cancel-btn'));
			expect(cancelBtn.isPresent()).toBeTruthy();
			cancelBtn.click();
		});

	});

};
