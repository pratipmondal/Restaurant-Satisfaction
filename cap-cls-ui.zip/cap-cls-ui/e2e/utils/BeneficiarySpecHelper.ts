import { E2eSpecHelper } from './E2eSpecHelper';
import { $, protractor } from 'protractor';

exports.BeneficiaryTestSuite = function () {
	describe('Beneficiary_Page', function () {
		const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
		const beneficiary: any = {
			beneficiaryIdOnTab: $('#beneficiary_tab'),
			beneficiaryIdDropdown: $('.beneficiary_id'),
			beneficiaryIdDropdownResult: $('.k-list-container .k-list .k-item:first-child'),
			beneficiaryIdDropdownValue: (searchTerm: string): any => $('.beneficiary_id .k-searchbar > .k-input').sendKeys(searchTerm),
			beneficiaryRankDropdown: $('.beneficiary_rank'),
			beneficiaryRankDropdownResult: $('.k-list-container .k-list .k-item:first-child'),
			beneficiaryRankDropdownValue: (searchTerm: string): any => $('.beneficiary_rank .k-searchbar > .k-input').sendKeys(searchTerm),
			beneficiaryRankDropdownValueEnter: (searchTerm: string): any => $('.beneficiary_rank .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
			beneficiaryCapAmount: $('#BeneficiaryCapAmountInput'),
			beneficiaryCapAmountValue: (beneficiaryCapAmountVal: string): any => $('#BeneficiaryCapAmountInput input.cls-text').sendKeys(beneficiaryCapAmountVal),
			disableEditIcon: $('.k-grid table tr:first-child #beneficiaryEditIcon'),
			disableDeleteIcon: $('.k-grid table tr:first-child #beneficiaryDeleteIcon'),
			beneficiaryEditIcon: $('.k-grid table tr:nth-child(2) #beneficiaryEditIcon'),
			beneficiaryDeleteIcon: $('.k-grid table tr:nth-child(2) #beneficiaryDeleteIcon'),
			closeButton: $('.k-i-x')
		};
		it('should have the title of tab as Beneficiary', function () {
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdOnTab.click();
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('#beneficiary_tab', 'Beneficiary');
		});
		it('should have a counterparty record in grid', function () {
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('.k-grid table tr:first-child #beneficiaryName', 'Personal Leadership Centre Pte.Ltd');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyPresence('.not-editable');
			// browser.actions().mouseMove(element(by.css(beneficiary.disableEditIcon))).perform();
		});
		it('should display validation errors in beneficiary dialog box when entering invalid value for Beneficiary Data', function () {
			e2eSpecHelper.waitForAndClickButton('.clsBtnSecondary', 'Add Beneficiary Details');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.waitForAndClickButton('#beneficiary_save', 'Save');
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('.has-error');
			e2eSpecHelper.sleepBrowser(2000);
			beneficiary.closeButton.click();
		});
		it('should add valid beneficiary data, display toast and reflect on grid on click of add beneficiary button', function () {
			e2eSpecHelper.waitForAndClickButton('.clsBtnSecondary', 'Add Beneficiary Details');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdDropdown.click();
			beneficiary.beneficiaryIdDropdownValue('gcin');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdDropdownResult.click();
			e2eSpecHelper.waitForAndClickButton('#beneficiary_save', 'Save');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A new record of beneficiary details has been successfully added.');
		});
		it('should update beneficiary data, display toast and reflect on grid on click of edit icon', function () {
			e2eSpecHelper.verifyPresence('#beneficiaryEditIcon');
			beneficiary.beneficiaryEditIcon.click();
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryRankDropdown.click();
			beneficiary.beneficiaryRankDropdownValue('1DBS');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdDropdownResult.click();
			e2eSpecHelper.waitForAndClickButton('#beneficiary_update', 'Update');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of beneficiary details has been successfully updated.');
		});
		it('should delete beneficiary data, display toast and reflect on grid on click of delete icon', function () {
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('#beneficiaryDeleteIcon');
			e2eSpecHelper.sleepBrowser(2000);
			beneficiary.beneficiaryDeleteIcon.click();
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of beneficiary details has been successfully deleted.');
		});
		it('should validate rank optional field with invalid data entry in beneficiary form', function () {
			e2eSpecHelper.waitForAndClickButton('.clsBtnSecondary', 'Add Beneficiary Details');
			e2eSpecHelper.sleepBrowser(2000);
			beneficiary.beneficiaryIdDropdown.click();
			beneficiary.beneficiaryIdDropdownValue('GCIN');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdDropdownResult.click();
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryRankDropdown.click();
			beneficiary.beneficiaryRankDropdownValueEnter('ABC');
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('.has-error');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.closeButton.click();
		});
		it('should validate cap amount optional field with valid data entry in beneficiary form', function () {
			e2eSpecHelper.waitForAndClickButton('.clsBtnSecondary', 'Add Beneficiary Details');
			e2eSpecHelper.sleepBrowser(2000);
			beneficiary.beneficiaryIdDropdown.click();
			beneficiary.beneficiaryIdDropdownValue('gcin');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdDropdownResult.click();
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryCapAmount.click();
			beneficiary.beneficiaryCapAmountValue('10k');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.waitForAndClickButton('#beneficiary_save', 'Save');
		});
		it('should validate cap amount optional field with invalid data entry in beneficiary form', function () {
			e2eSpecHelper.waitForAndClickButton('.clsBtnSecondary', 'Add Beneficiary Details');
			e2eSpecHelper.sleepBrowser(2000);
			beneficiary.beneficiaryCapAmount.click();
			beneficiary.beneficiaryCapAmountValue('abc');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.waitForAndClickButton('#beneficiary_save', 'Save');
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('.has-error-ccy');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.closeButton.click();
		});
		it('should validate duplicate value entry in beneficiary details page', function () {
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.waitForAndClickButton('.clsBtnSecondary', 'Add Beneficiary Details');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdDropdown.click();
			beneficiary.beneficiaryIdDropdownValue('gcin');
			e2eSpecHelper.sleepBrowser(1000);
			beneficiary.beneficiaryIdDropdownResult.click();
			e2eSpecHelper.waitForAndClickButton('#beneficiary_save', 'Save');
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyPresence('.duplicateValueDiv');
		});
	});
};

exports.BeneficiaryTestSuiteForEditFlow = function () {
	describe('Beneficiary_Page for Edit Flow', function () {
		/*TODO*/
	});
};
