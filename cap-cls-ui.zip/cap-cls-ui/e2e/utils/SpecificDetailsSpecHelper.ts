import { E2eSpecHelper } from './E2eSpecHelper';
import { $, browser, protractor } from 'protractor';
exports.SpecificDetailsTestSuite = function () {
	describe('Specific_Details_Page', function () {
		const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
		const specificDetails: any = {
			specificDetailsIdOnTab: $('#specific_details_tab'),
			addSpecificDetailsBtn: $('.add-specific-details-btn'),
			saveFormBtn: $('#save-form-btn'),
			updateFormBtn: $('#update-form-btn'),
			editIcon: $('#editIcon'),
			deleteIcon: $('#deleteIcon'),
			addDetailsBtn: $('#add-details-btn'),
			closeDialogIcon: $('.k-dialog-close'),
			fcfdDropdown: $('#fcfd-dropdwon'),
			fcfdSearch: (searchTerm: string): any => $('#fcfd-dropdwon .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
			depositAcDropdown: $('#depositAc-Dropdown'),
			depositAcSearch: (searchTerm: string): any => $('#depositAc-Dropdown .k-searchbar > .k-input').sendKeys(searchTerm, protractor.Key.ENTER),
			depositAcInputBox: $('#depositAc-Dropdown .k-searchbar > .k-input'),
			depositNoInputBox: $('#depositNo'),
			depositNoInputValue: (inputTerm: string): any => $('#depositNo').sendKeys(inputTerm),
			earmarkAmount: $('#earmark-amount input.cls-text'),

			earmarkAmountInput: (earmarkAmountInput: string): any => $('#earmark-amount input.cls-text').sendKeys(earmarkAmountInput),

			earmarkReasonTextarea: $('#earmark-reason textarea.commentTextArea__input'),

			earmarkReasonInput: (earmarkReasonInput: string): any =>
				specificDetails.earmarkReasonTextarea.sendKeys(earmarkReasonInput),

			earmarkReasonUpdateInput: (earmarkReasonInput: string) => specificDetails.earmarkReasonTextarea.clear()
				.then(() => specificDetails.earmarkReasonTextarea.sendKeys(earmarkReasonInput)),

			remarksTextarea: $('#remarks textarea.commentTextArea__input'),
			remarksTextareaInput: (remarksTextareaInput: string): any => specificDetails.remarksTextarea.sendKeys(remarksTextareaInput),
			noRecordLink: $('#no-records-label-link')
		};

		it('should display Specific Details Tab on click', function () {
			browser.sleep(2000);
			specificDetails.specificDetailsIdOnTab.click();
			browser.waitForAngular();
			e2eSpecHelper.verifyTextContains('#specific_details_tab', 'Specific Details');
			e2eSpecHelper.verifyPresence('.tab-element-underline');
		});

		it('should check for No Record Found', function () {
			specificDetails.noRecordLink.click();
			specificDetails.closeDialogIcon.click();
			e2eSpecHelper.verifyTextContains('#no-records-header', 'No Specific Details Found');
			e2eSpecHelper.verifyTextContains('#no-records-label a', 'adding specific details');
			e2eSpecHelper.sleepBrowser(2000);
		});

		it('should open popup dialog when clicked on Add Specific Details Button', function () {
			specificDetails.addSpecificDetailsBtn.click();
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Add Specific Details');
			e2eSpecHelper.verifyTextContains('.add-specific-details-btn', 'Add Specific Details');
		});

		it('should show validation errors when Specific Details fields are empty and clicked on save button', function () {
			specificDetails.saveFormBtn.click();
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('.has-error');
		});

		it('validate Specific Details and save data to grid', function () {
			e2eSpecHelper.sleepBrowser(1000);
			specificDetails.fcfdDropdown.click();
			specificDetails.fcfdSearch('bank1');
			e2eSpecHelper.sleepBrowser(1000);
			specificDetails.depositAcDropdown.click();
			specificDetails.depositAcSearch('123');
			e2eSpecHelper.sleepBrowser(1000);
			specificDetails.depositNoInputBox.click();
			specificDetails.depositNoInputValue('DN1');
			e2eSpecHelper.verifyPresence('#show-specific-details-fields');
			e2eSpecHelper.verifyPresence('.disabled-container');
			specificDetails.earmarkAmount.click();
			specificDetails.earmarkAmountInput('10k');
			e2eSpecHelper.sleepBrowser(1000);
			specificDetails.earmarkReasonTextarea.click();
			specificDetails.earmarkReasonInput('Earmark Test');
			specificDetails.remarksTextarea.click();
			specificDetails.remarksTextareaInput('Test Remarks');
			e2eSpecHelper.sleepBrowser(2000);
			specificDetails.saveFormBtn.click();
			browser.waitForAngular('wait for toast message');
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully Added.');
			e2eSpecHelper.verifyPresence('.k-grid');
			e2eSpecHelper.verifyPresence('.warning-box');
			e2eSpecHelper.sleepBrowser(3000);
		});

		it('should not show other fields for Specific Details When Deposit A/c is Cleared', function () {
			e2eSpecHelper.verifyPresence('#editIcon');
			specificDetails.editIcon.click();
			e2eSpecHelper.sleepBrowser(1000);
			specificDetails.depositAcInputBox.clear();
			specificDetails.depositNoInputBox.click();
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyPresence('#show-specific-details-fields', false);
			e2eSpecHelper.verifyPresence('.disabled-container', false);
			specificDetails.closeDialogIcon.click();
			e2eSpecHelper.verifyPresence('.k-grid');
		});

		it('should update Specific Details', function () {
			e2eSpecHelper.verifyPresence('#editIcon');
			specificDetails.editIcon.click();
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('.k-dialog-title', 'Update Specific Details');
			e2eSpecHelper.verifyTextContains('#update-form-btn', 'Update');
			specificDetails.earmarkReasonUpdateInput('Earmark Update');
			e2eSpecHelper.sleepBrowser(2000);
			specificDetails.updateFormBtn.click();
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully updated.');
			e2eSpecHelper.verifyPresence('.warning-box');
			e2eSpecHelper.sleepBrowser(3000);
		});

		it('should delete specific details item from grid when clicked on delete icon', function () {
			specificDetails.deleteIcon.click();
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyTextContains('.toast__msg', 'A record of Specific details has been successfully removed.');
		});

	});
};

exports.SpecificDetailsTestSuiteForEditFlow = function () {
	describe('Specific_Details_Page for edit flow', function () {
		/*TODO*/
	});
};
