import { $, browser, by, element } from 'protractor';
import { E2eSpecHelper } from './E2eSpecHelper';

export class HomeSpecHelper {
	e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

	loadLandingPage = () => {
		browser.get('/');
		this.e2eSpecHelper.verifyPresence('#mySidenav', true);
	}
}
