import { E2eSpecHelper } from './E2eSpecHelper';
import { $, browser } from 'protractor';

exports.SummaryTestSuite = function () {
	describe('Summary_Details_Page', function () {
		const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();

		const summary: any = {
			summaryTabId: $('#summary_tab'),
			generalDetailsPanelId: '#general-details-section',
			beneficiaryDetailsPanelId: '#beneficiary-details-section',
			valuationDetailsPanelId: '#valuation-details-section',
			spanLabel: 'span.panel-label',
			spanKArrowIcon: 'span.k-icon-arrow'
		};

		it('should have the title of tab as Summary', function () {
			e2eSpecHelper.sleepBrowser(2000);
			summary.summaryTabId.click();
			e2eSpecHelper.sleepBrowser(1000);
			e2eSpecHelper.verifyTextContains('#summary_tab', 'Summary');
		});

		it('should show default panels on Summary Tab', function () {
			e2eSpecHelper.verifyTextContains(summary.generalDetailsPanelId + ' ' + summary.spanLabel, 'General Details');
			e2eSpecHelper.verifyTextContains(summary.valuationDetailsPanelId + ' ' + summary.spanLabel, 'Valuation');
		});

		it('should open-close default panels on Summary Tab', function () {
			e2eSpecHelper.scrollToElement(summary.valuationDetailsPanelId);
			browser.sleep(3000);
			/*Close the default panels one at a time*/
			e2eSpecHelper.buttonClick(summary.generalDetailsPanelId + ' ' + summary.spanKArrowIcon);
			e2eSpecHelper.buttonClick(summary.valuationDetailsPanelId + ' ' + summary.spanKArrowIcon);
			browser.sleep(3000);
			/*Open the default panels one at a time*/
			e2eSpecHelper.buttonClick(summary.generalDetailsPanelId + ' ' + summary.spanKArrowIcon);
			e2eSpecHelper.buttonClick(summary.valuationDetailsPanelId + ' ' + summary.spanKArrowIcon);
			e2eSpecHelper.scrollToTheTop();
		});

	});
};
