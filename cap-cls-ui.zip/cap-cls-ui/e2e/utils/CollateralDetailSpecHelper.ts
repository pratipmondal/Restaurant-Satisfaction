import { $, by, element, protractor } from 'protractor';
import { E2eSpecHelper } from './E2eSpecHelper';

exports.CollateralDetailsTestSuite = function () {
	const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
	describe('Collateral_Details_Page', function () {
		it('should  navigate to Collateral Details Page', () => {
			// expect(browser.driver.findElement(by.className('panel-label')).getText()).toContain('Collateral ID.');
			e2eSpecHelper.sleepBrowser(2000);
			e2eSpecHelper.verifyTextContains('#general-details-panel-id', 'General Details');
			// expect(browser.driver.findElement(by.className('cst-padding sub-panel-label')).getText()).toEqual('General Details');
		});

		it('should validate the Amount fields', () => {
			e2eSpecHelper.sleepBrowser(2000);
			element(by.css('[placeholder="Enter CCY amount"]')).sendKeys('');
			element(by.id('ccyAmount')).click();
			expect(element.all(by.id('currencyAmounterror')).getText()).toContain('Please enter amount.');
		});

		it('should toggle the add/remove Collateral Value Details ', () => {
			e2eSpecHelper.sleepBrowser(2000);
			const link = element.all(by.id('toggleDBSPercentagelink'));
			link.click();
			expect(link.getText()).toContain('Remove DBS % of Collateral Value Details');
			link.click();
			expect(link.getText()).toContain('Add DBS % of Collateral Value Details');

		});

		it('should toggle the add/remove Application Details and check validation error are removed on toggle', () => {
			e2eSpecHelper.sleepBrowser(2000);
			const link = element.all(by.id('toggleApplicationLink'));
			link.click();
			expect(link.getText()).toContain('Remove Application Details');
			element(by.css('[placeholder="Enter form no."]')).sendKeys('');
			element.all(by.id('formNoLabel')).click();
			expect(element.all(by.id('formNoError')).getText()).toContain('Please enter value.');
			link.click();
			expect(link.getText()).toContain('Add Application Details');
			expect(element.all(by.id('formNoError')).getText()).not.toContain('Please enter value.');
			e2eSpecHelper.sleepBrowser(2000);
			link.click();
			element(by.css('[placeholder="Enter form no."]')).sendKeys('abc123');
		});

		it('should fill the appropriate data and move to next tab.', () => {
			e2eSpecHelper.sleepBrowser(2000);
			element(by.css('[placeholder="Enter CCY amount"]')).sendKeys('12');
			element(by.css('[placeholder="Enter solicitor name"]')).sendKeys('solicitor name');
			$('#locationControl').click();
			$('#locationControl .k-searchbar > .k-input').sendKeys('INDIA', protractor.Key.ENTER);
			element(by.css('[name=generalDetailsRemarks]')).element(by.className('commentTextArea')).element(by.tagName('textarea')).sendKeys('this is e2e testing');
			element(by.css('[formcontrolname="loanValuePcnt"]')).element(by.className('prefixSuffix-box')).element(by.tagName('input')).sendKeys('50');
			const link = element.all(by.id('toggleDBSPercentagelink'));
			link.click();
			e2eSpecHelper.sleepBrowser(2000);
			element(by.css('[placeholder="Enter max fixed amount"]')).sendKeys('21');
			element(by.css('[formcontrolname="collateralValuePcnt"]')).element(by.className('prefixSuffix-box')).element(by.tagName('input')).sendKeys('50');
			element(by.css('[name=applicationDetailsRemarks]')).element(by.className('commentTextArea')).element(by.tagName('textarea')).sendKeys('this is e2e testing');
			e2eSpecHelper.scrollToTheTop();
		});
	});
};

exports.CollateralDetailsTestSuiteForEditFlow = function () {
	const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
	describe('Collateral_Details_Page', function () {
		/*TODO*/
	});
};
