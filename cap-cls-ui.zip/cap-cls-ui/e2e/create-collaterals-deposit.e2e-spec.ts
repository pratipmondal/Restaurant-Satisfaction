describe('should complete add,edit,delete journey for collateral of Deposit Type', () => {

	const createCollateralDeposTestSuite = require('./utils/CollateralsCreateDeposHelper');
	const editCollateralDeposTestSuite = require('./utils/CollateralsEditDeposHelper');
	const withdrawCollateralDeposTestSuite = require('./utils/CollateralsWithdrawDeposHelper');

	const processCreateCollateralDepos = () => {
		createCollateralDeposTestSuite.CreateCollateralDeposTestSuite();
	};

	const processEditCollateralDepos = () => {
		editCollateralDeposTestSuite.EditCollateralDeposTestSuite();
	};

	const processWithdrawCollateralDepos = () => {
		withdrawCollateralDeposTestSuite.WithdrawCollateralDeposTestSuite();
	};

	describe('should create a collateral of deposit type', () => {
		processCreateCollateralDepos();
	});

	describe('should edit already created collateral of deposit type', () => {
		processEditCollateralDepos();
	});

	describe('should withdraw existing collateral of deposit type ', () => {
		processWithdrawCollateralDepos();
	});

});
