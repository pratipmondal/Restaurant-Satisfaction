import { browser } from 'protractor';
import { E2eSpecHelper } from './utils/E2eSpecHelper';
import { HomeSpecHelper } from './utils/HomeSpecHelper';

describe('landing page', function () {
	const e2eSpecHelper: E2eSpecHelper = new E2eSpecHelper();
	const homeSpecHelper: HomeSpecHelper = new HomeSpecHelper();
	const sequenceGeneratorTestSuite = require('./utils/SequenceGeneratorHelper');
	const referenceDataTestSuite = require('./utils/ReferenceDataHelper');

	const ssoLogin = () => {
		browser.get('https://oauth-uaa.sit.apps.cs.sgp.dbs.com/login');
		e2eSpecHelper.enterValueByName('username', 'marissa_rm');
		e2eSpecHelper.enterValueByName('password', 'koala');
		e2eSpecHelper.buttonClick('.island-button');
	};

	it('should able to do SSO login and show home page', () => {
		ssoLogin();
		homeSpecHelper.loadLandingPage();
	});

	/*E2E for Sequence Generator Page*/
	const processSequenceGeneratorTestSuite = () => {
		sequenceGeneratorTestSuite.SequenceGeneratorTestSuite();
	};

	/*E2E for ReferenceDatePage*/
	const processReferenceDataTestSuite = () => {
		referenceDataTestSuite.ReferenceDataTestSuite();
	};

	describe('should verify Sequence Generator', () => {
		processSequenceGeneratorTestSuite();
	});

	describe('should verify ReferenceData', () => {
		processReferenceDataTestSuite();
	});

});
