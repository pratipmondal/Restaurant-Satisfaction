## Special Note & Assumptions

1. Once the canvas is created, to draw Line/Rectangle/BucketFill if you give any coordinate, which is outside of the Canvas area, 
   it will throw an exception and in command line it will ask to enter the command once again.
   
2. For Line & Rectangle drawing : x1 has to be less than or equals to x2
								  y1 has to be less than or equals to y2
								  
3. For Line & Rectangle drawing : If x1 = x2 && y1 = y2 then it will draw a point.								  

4. Junit & JBehave API is being used to run the test cases.

# The Canvas Drawing

The Below is a sample run of the program.

enter command: L 1 2 6 2
First Create a Canvas!!!!
enter command: R 14 1 18 3
First Create a Canvas!!!!
enter command: C 20 4
----------------------
|                    |
|                    |
|                    |
|                    |
----------------------
enter command: L 1 2 6 200
Only Horizontal or Vertical line is supported!!!!
enter command: L 1 2 60 2
Provided corrdinates are out of Canvas!!!!
enter command: L 6 2 1 2
Either x1 is greater than x2 or y1 is greater than y2!!!!
enter command: L 1 2 6 2
----------------------
|                    |
|xxxxxx              |
|                    |
|                    |
----------------------
enter command: L 6 3 6 4
----------------------
|                    |
|xxxxxx              |
|     x              |
|     x              |
----------------------
enter command: R 18 3 14 1
Either x1 is greater than x2 or y1 is greater than y2!!!!
enter command: R 14 1 180 3
Provided corrdinates are out of Canvas!!!!
enter command: R 14 1 18 3
----------------------
|             xxxxx  |
|xxxxxx       x   x  |
|     x       xxxxx  |
|     x              |
----------------------
enter command: B 10 3 o
----------------------
|oooooooooooooxxxxxoo|
|xxxxxxooooooox   xoo|
|     xoooooooxxxxxoo|
|     xoooooooooooooo|
----------------------
enter command: Q
Quiting...

## Commands to Run the program

1. Please install maven & JDK 1.8 in your machine first & set the classpath accordingly.
2. Open a command prompt & move to the location of your project/pom.xml file.
3. RUN : mvn clean install ----> It will run all test cases & create a canvas-drawing-1.0.jar file in target folder
4. RUN : mvn clean install -DskipTests ----> If you want to skip the test cases & create canvas-drawing-1.0.jar file in target folder
5. In command prompt move to target folder.
6. RUN : java -jar canvas-drawing-1.0.jar
7. Give input accordingly.


