package com.cs;

import com.cs.exception.MaxCountExceedException;
import com.cs.service.CalculatorService;
import com.cs.service.CalculatorServiceImpl;
import com.cs.validation.ValidatorUtil;
import com.sun.deploy.util.StringUtils;

import java.util.Arrays;

public class Calculator {

    public int add(String input) throws MaxCountExceedException{
        if(null != input && input.length() == 0){
            return 0;
        }

        CalculatorService service = new CalculatorServiceImpl();
        return service.process(input);
    }
}
