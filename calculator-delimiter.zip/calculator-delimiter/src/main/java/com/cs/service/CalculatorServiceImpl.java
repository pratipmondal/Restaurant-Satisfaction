package com.cs.service;

import com.cs.exception.MaxCountExceedException;
import com.cs.exception.NegativeNumberException;
import com.cs.factory.CalculatorDelimiterFactory;
import com.cs.factory.Delimiter;
import com.cs.validation.ValidatorUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class CalculatorServiceImpl implements CalculatorService{

    public int process(String input){
        CalculatorDelimiterFactory delimiterFactory = new CalculatorDelimiterFactory();
        Delimiter delimiter = delimiterFactory.getDelimiter(input);
        return this.calculateSum(delimiter.getInput(),delimiter.getDelimiter());
    }

    private int calculateSum(String input, String delimiter) {
        String[] split = input.split(delimiter);
        return Arrays.stream(split).mapToInt(x -> {
            if(x.equals("")) return 0;
            if (Integer.parseInt(x) < 0) throw new NegativeNumberException("Negative number not allowed : " + x);
            return Integer.parseInt(x) > 1000 ? 0 : Integer.parseInt(x);
        }).sum();
    }
}
