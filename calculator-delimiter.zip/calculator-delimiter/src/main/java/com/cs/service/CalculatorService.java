package com.cs.service;

public interface CalculatorService {
    public int process(String input);
}
