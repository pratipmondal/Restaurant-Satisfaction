package com.cs.exception;

public class MaxCountExceedException extends RuntimeException {
    public MaxCountExceedException(String message) {
        super(message);
    }
}
