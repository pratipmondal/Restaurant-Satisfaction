package com.cs.validation;

public class ValidatorUtil {

    public static boolean validateInputCount(String[] input){
        return input.length > 3 ? false : true;
    }
}
