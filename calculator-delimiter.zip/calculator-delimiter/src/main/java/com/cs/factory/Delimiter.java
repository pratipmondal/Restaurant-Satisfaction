package com.cs.factory;

public interface Delimiter {

    public String getInput();

    public String getDelimiter();
}
