package com.cs.factory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class MultipleCustomDelimiter implements Delimiter{

    private final String DELIMITER = ",|\n";

    private final String CUSTOM_PATTERN = "\\[(.*?)\\]";

    private String input;

    private String delimiter;

    public MultipleCustomDelimiter(String input) {
        input = input.substring(2);
        List<String> customDelimiterList = new ArrayList<>();
        Matcher m = Pattern.compile(CUSTOM_PATTERN).matcher(input);
        while(m.find()) {
            String str = m.group(1);
            if(str.contains("*")) customDelimiterList.add(Arrays.stream(str.split("")).map(x -> "\\"+x).collect(Collectors.joining()));
            else customDelimiterList.add(str);
        }
        String delimiter = String.join("|", customDelimiterList);
        this.input = input.substring(input.lastIndexOf("]")+1);
        this.delimiter = DELIMITER.concat("|").concat(delimiter);
    }

    @Override
    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    @Override
    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }
}
