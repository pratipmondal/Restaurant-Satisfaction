package com.cs.factory;

public class SingleCustomDelimiter implements Delimiter{

   private String input;

    private String delimiter;

    public SingleCustomDelimiter(String input) {
        String delimiter = input.substring(2, input.indexOf("\n"));
        input = input.substring(input.lastIndexOf("\n")+1);
        this.input = input;
        this.delimiter = delimiter;
    }

    @Override
    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    @Override
    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }
}
