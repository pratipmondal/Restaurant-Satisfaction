package com.cs.factory;

public class CalculatorDelimiterFactory {

    private final String DELIMITER = ",|\n";

    private final String CUSTOM_SEPERATOR_INDICATOR = "//";

    public Delimiter getDelimiter(String input){
            if(!input.startsWith(CUSTOM_SEPERATOR_INDICATOR)) {
                //No Custom delimiter
                return new BasicDelimiter(input);
            }else{
                if(!input.contains("[") && !input.contains("]")){
                    //Custom delimiter but it doesn't contain any[]
                    return new SingleCustomDelimiter(input);
                }
                //Multiple Custom delimiter with []
                return new MultipleCustomDelimiter(input);
            }
    }
}
