package com.cs.factory;

public class BasicDelimiter implements Delimiter{

    private final String DELIMITER = ",|\n";

    private String input;

    private String delimiter;

    public BasicDelimiter(String input) {
        this.input = input;
        this.delimiter = DELIMITER;
    }

    @Override
    public String getInput() {
        return input;
    }

    @Override
    public String getDelimiter() {
        return this.delimiter = delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }

    public void setInput(String input) {
        this.input = input;
    }
}
