package com.cs;

import com.cs.exception.MaxCountExceedException;
import com.cs.exception.NegativeNumberException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {

    private Calculator calculator;

    @Before
    public void setUp(){
        calculator = new Calculator();
    }

    @Test
    public void testEmptyInput() throws Exception {
        int sum = calculator.add("");
        Assert.assertEquals(sum, 0);
    }

    @Test
    public void testValidInput() throws Exception {
        int sum = calculator.add("1,2,3");
        Assert.assertEquals(sum, 6);
    }

    @Test(expected = NegativeNumberException.class)
    public void testNegativeNumberInput() throws Exception {
        int sum = calculator.add("1,-2,3");
    }

    @Test
    public void testInputWithOneNextLine() throws Exception {
        int sum = calculator.add("1\n2,3");
        Assert.assertEquals(sum, 6);
    }

    @Test(expected = NumberFormatException.class)
    public void testInputWithStringValue() throws Exception {
        int sum = calculator.add("1\n2,s");
    }

    @Test
    public void testIgnoreValueMoreThan1000() throws Exception {
        int sum = calculator.add("1,2,1005");
        Assert.assertEquals(sum, 3);
    }

    @Test
    public void testWithCustomSeperator1() throws Exception {
        int sum = calculator.add("//[***]\n1***2***3");
        Assert.assertEquals(sum, 6);
    }

    @Test
    public void testWithCustomSeperator2() throws Exception {
        int sum = calculator.add("//[*][%]\n1*2%3");
        Assert.assertEquals(sum, 6);
    }

    @Test
    public void testWithCustomSeperator3() throws Exception {
        int sum = calculator.add("//[*][%%]\n1*2%%1003");
        Assert.assertEquals(sum, 3);
    }

    @Test
    public void testWithCustomSeperator4() throws Exception {
        int sum = calculator.add("//;\n1;2");
        Assert.assertEquals(sum, 3);
    }
}
