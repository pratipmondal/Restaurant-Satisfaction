package com.n26.exception;

public class FutureTimeException extends RuntimeException {
    public FutureTimeException(String message) {
        super(message);
    }
}
