package com.n26.exception;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import java.time.format.DateTimeParseException;

@RestController
@ControllerAdvice
@Slf4j
public class GenericExceptionHandler {
	@ExceptionHandler(OldTimeException.class)
	public ResponseEntity<?> olderTimeinputException(OldTimeException e) {
		log.error(e.getMessage(), e);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@ExceptionHandler(FutureTimeException.class)
	public ResponseEntity<?> futureTimeException(FutureTimeException e) {
		log.error(e.getMessage(), e);
		return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(JsonParseException.class)
	public ResponseEntity<?> jsonParseException(JsonParseException e) {
		log.error(e.getMessage(), e);
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(InvalidFormatException.class)
	public ResponseEntity<?> invalidFormatException(InvalidFormatException e) {
		log.error(e.getMessage(), e);
		return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<?> illegalArgumentException(IllegalArgumentException e) {
		log.error(e.getMessage(), e);
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(JsonMappingException.class)
	public ResponseEntity<?> jsonMappingException(JsonMappingException e) {
		log.error(e.getMessage(), e);
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DateTimeParseException.class)
	public ResponseEntity<?> dateTimeParseException(DateTimeParseException e) {
		log.error(e.getMessage(), e);
		return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
	}
}

