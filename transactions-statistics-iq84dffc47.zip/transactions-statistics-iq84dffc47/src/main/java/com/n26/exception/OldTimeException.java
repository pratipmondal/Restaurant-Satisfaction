package com.n26.exception;

public class OldTimeException extends RuntimeException {
    public OldTimeException(String message) {
        super(message);
    }
}
