package com.n26.service;

import com.n26.exception.NoRecordFoundException;
import com.n26.model.StatisticsResponse;
import com.n26.repository.TransactionRepository;
import com.n26.model.TransactionRequest;
import com.n26.util.TransactionUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.DoubleSummaryStatistics;

@Service
@Slf4j
public class TransactionService {
    private static DecimalFormat f = new DecimalFormat("0.00");

    static{
        f.setMinimumFractionDigits(2);
        f.setMinimumIntegerDigits(1);
    }
    private TransactionRepository transactionRepository;

    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public void deleteAllTransactions() {
        transactionRepository.deleteAllTransactions();
    }

    public void saveTransaction(TransactionRequest request) {
        if(TransactionUtility.validate(request))
            transactionRepository.saveTransaction(request);
    }

    public ResponseEntity<?> getTransaction() throws NoRecordFoundException{
        DoubleSummaryStatistics statistics = transactionRepository.getStatistics();
        if(statistics.getCount() > 0) {
            return ResponseEntity.status(HttpStatus.OK).body(
                    StatisticsResponse.builder().sum(getBigDecimalValue(statistics.getSum()))
                    .avg(getBigDecimalValue(statistics.getAverage()))
                    .max(getBigDecimalValue(statistics.getMax()))
                    .min(getBigDecimalValue(statistics.getMin()))
                    .count(statistics.getCount())
                    .build());
        }
        return ResponseEntity.status(HttpStatus.OK).body(
                StatisticsResponse.builder().sum("0.00")
                        .avg("0.00")
                        .max("0.00")
                        .min("0.00")
                        .count(0)
                        .build());
    }

    private String getBigDecimalValue(Double value){
        return f.format(new BigDecimal(value).setScale(2, BigDecimal.ROUND_HALF_UP));
    }
}
