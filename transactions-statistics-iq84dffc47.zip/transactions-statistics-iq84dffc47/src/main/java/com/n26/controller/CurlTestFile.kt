package com.n26.controller

import java.util.concurrent.TimeUnit

fun main(args: Array<String>) {
    println("Hello, World!")
    val process = ProcessBuilder("curl", "http://localhost:8080/getByte").start()
    process.inputStream.reader(Charsets.UTF_8).use {
        println(it.readText())
    }
    process.waitFor(10, TimeUnit.SECONDS)
}