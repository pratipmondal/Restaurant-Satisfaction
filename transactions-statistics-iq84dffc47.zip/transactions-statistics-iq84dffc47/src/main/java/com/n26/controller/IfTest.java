package com.n26.controller;

public class IfTest {
    public static void main(String[] args) {
        String name = "Pratip";
        String surname = "Mondal";
        int x = 0;
        /*long loopStartTime = System.currentTimeMillis();
        for(int i = 0; i < 500000; i++){
            if(name.equalsIgnoreCase("Pratip") && surname.equalsIgnoreCase("Mondal")){
                x = 5 + 57;
            }
        }
        long loopEndTime = System.currentTimeMillis();
        System.out.println("For Loop If total Time = " + (loopEndTime - loopStartTime));*/

        long loopStartTime1 = System.currentTimeMillis();
        for(int i = 0; i < 500000; i++){
            if(name.equalsIgnoreCase("Pratip")){
                if(surname.equalsIgnoreCase("Mondal")) {
                    x = 5 + 57;
                }
            }
        }
        long loopEndTime1 = System.currentTimeMillis();
        System.out.println("For Loop Nested If total Time = " + (loopEndTime1 - loopStartTime1));
    }
}
