package com.n26.controller;

import com.n26.model.TransactionRequest;
import com.n26.service.TransactionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.xml.ws.Response;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/")
@Api(value = "Services for Transactions")
public class TransactionController {
	private TransactionService transactionService;

	public TransactionController(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	@PostMapping(
			path = "transactions",
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	@ApiOperation(value = "Create a Transaction")
	public ResponseEntity<?> createTransaction(
			@Valid @RequestBody TransactionRequest request) {
		transactionService.saveTransaction(request);
		return ResponseEntity.status(HttpStatus.CREATED).body("");
	}

	@GetMapping(
			path = "statistics",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	@ApiOperation(value = "get all Transactions in last 60 secs")
	public ResponseEntity<?> getTransaction() {
		return transactionService.getTransaction();
	}

	@DeleteMapping(
			path = "transactions",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	@ApiOperation(value = "delete all Transactions")
	public ResponseEntity<?> deleteAllTransactions() {
		transactionService.deleteAllTransactions();
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("");
	}

	@GetMapping(
			path = "getByte"
	)
	@ApiOperation(value = "get bytes")
	public ResponseEntity<byte[]> getByte() throws IOException {
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION,
						"attachment;filename=" + "DATA.txt")
				.contentType(MediaType.APPLICATION_OCTET_STREAM)
				.body("Taniya".concat("\n").concat("Tridha").getBytes());
	}
}
