package com.n26.controller;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/*
 * To execute Java, please define "static void main" on a class
 * named Solution.
 *
 * If you need more classes, simply define them inline.
 
 You are in charge of a display advertising program. Your ads are displayed on websites all over the internet. You have some CSV input data that counts how many times you showed an ad on each individual domain. Every line consists of a count and a domain name. It looks like this:

counts = [ "900,google.com",
     "60,mail.yahoo.com",
     "10,mobile.sports.yahoo.com",
     "40,sports.yahoo.com",
     "300,yahoo.com",
     "10,stackoverflow.com",
     "2,en.wikipedia.org",
     "1,es.wikipedia.org",
     "1,mobile.sports"]

Write a function that takes this input as a parameter and returns a data structure containing the number of hits that were recorded on each domain AND each domain under it. For example, an impression on "mail.yahoo.com" counts for "mail.yahoo.com", "yahoo.com", and "com". (Subdomains are added to the left of their parent domain. So "mail" and "mail.yahoo" are not valid domains. Note that "mobile.sports" appears as a separate domain as the last item of the input.)

Sample output (in any order):

getTotalsByDomain(counts)
1320    com
 900    google.com
 410    yahoo.com
  60    mail.yahoo.com
  10    mobile.sports.yahoo.com
  50    sports.yahoo.com
  10    stackoverflow.com
   3    org
   3    wikipedia.org
   2    en.wikipedia.org
   1    es.wikipedia.org
   1    mobile.sports
   1    sports

 
 */

public class Test {
    public static void main(String [] args) {
        List<String> list = new ArrayList<>();
        List<String> list1 = new ArrayList<>();

        for(int i=0; i<500; i++){
            list.add("Pratip"+i);
        }
        System.out.println("List Size = "+list.size());
        long loopStartTime = System.currentTimeMillis();
        for(String val : list){
            if(val.equalsIgnoreCase("Taniya")){
                list1.add(val);
            }
        }

        long loopEndTime = System.currentTimeMillis();
        System.out.println("For Loop total Time = " + (loopEndTime - loopStartTime));
        long loopStartTime1 = System.currentTimeMillis();
        list.stream().filter(x -> x.equalsIgnoreCase("Taniya")).collect(Collectors.toList());

        long loopEndTime1 = System.currentTimeMillis();
        System.out.println("Stream Loop total Time = " + (loopEndTime1 - loopStartTime1));

        long loopStartTime2 = System.currentTimeMillis();
        list.parallelStream().filter(x -> x.equalsIgnoreCase("Taniya")).collect(Collectors.toList());

        long loopEndTime2 = System.currentTimeMillis();
        System.out.println("Parallel Stream Loop total Time = " + (loopEndTime2 - loopStartTime2));
    }


}