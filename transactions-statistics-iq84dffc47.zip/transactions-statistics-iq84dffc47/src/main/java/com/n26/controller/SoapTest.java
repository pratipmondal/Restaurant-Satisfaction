package com.n26.controller;

import com.cdyne.ws.weatherws.ForecastReturn;
import com.cdyne.ws.weatherws.Weather;
import com.cdyne.ws.weatherws.WeatherReturn;
import com.cdyne.ws.weatherws.WeatherSoap;

public class SoapTest {
    public static void main(String[] args) {
        Weather weather = new Weather();
        WeatherSoap weatherSoap = weather.getWeatherSoap();
        ForecastReturn cityForecastByZIP = weatherSoap.getCityForecastByZIP("7");
        System.out.println("cityForecastByZIP.getResponseText() = "+cityForecastByZIP.getResponseText());
    }
}
