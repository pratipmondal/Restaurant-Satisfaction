package com.n26.com.singtel.challenge;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class Address {
    private List<String> mailingAddress = new ArrayList<>();
    private List<String> billingAddress = new ArrayList<>();
    private List<String> oldMailingAddress = new ArrayList<>();
    private List<String> oldBillingAddress = new ArrayList<>();
}
