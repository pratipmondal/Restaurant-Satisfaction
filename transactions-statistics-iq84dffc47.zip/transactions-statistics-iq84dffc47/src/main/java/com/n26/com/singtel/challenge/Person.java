package com.n26.com.singtel.challenge;

import lombok.Data;

@Data
public class Person extends Customer{
    private String finId;
}
