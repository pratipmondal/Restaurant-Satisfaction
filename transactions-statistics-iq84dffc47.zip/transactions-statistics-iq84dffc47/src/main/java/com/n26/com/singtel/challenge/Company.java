package com.n26.com.singtel.challenge;

import lombok.Data;

@Data
public class Company extends Customer{
    private String uenId;
}
