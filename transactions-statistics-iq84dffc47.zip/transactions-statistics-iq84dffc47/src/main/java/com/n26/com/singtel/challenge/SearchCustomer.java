package com.n26.com.singtel.challenge;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

public class SearchCustomer {
    private List<Person> personList = new ArrayList<>();
    private List<Company> companyList = new ArrayList<>();

    public void addCustomer(Customer customer){
        if(customer instanceof Person){
            personList.add((Person)customer);
        }else{
            companyList.add((Company)customer);
        }
    }

    public Customer searchCustomerWithId(String id){
        if(validateId(id) instanceof Person){
            return personList.stream().filter(v -> v.getFinId().equalsIgnoreCase(id)).findFirst().orElse(null);
        }else{
            return companyList.stream().filter(v -> v.getUenId().equalsIgnoreCase(id)).findFirst().orElse(null);
        }
    }

    public String getBillingAddress(String id){
        return searchCustomerWithId(id).getAddress().getBillingAddress().stream().collect(Collectors.joining( "\n"));
    }

    public String getMailingAddress(String id){
        return searchCustomerWithId(id).getAddress().getMailingAddress().stream().collect(Collectors.joining( "\n"));
    }

    public void changeMailingAddress(List<String> address, String id){
        if(validateId(id) instanceof Person){
            personList.stream()
                    .filter(v -> v.getFinId().equalsIgnoreCase(id))
                    .findFirst().orElse(new Person())
                    .setMailngAddress(address);
        }else{
            companyList.stream()
                    .filter(v -> v.getUenId().equalsIgnoreCase(id))
                    .findFirst().orElse(new Company())
                    .setMailngAddress(address);
        }
    }

    public void changeBillingAddress(List<String> address, String id){
        if(validateId(id) instanceof Person){
            personList.stream()
                    .filter(v -> v.getFinId().equalsIgnoreCase(id))
                    .findFirst().orElse(new Person())
                    .setBillingAddress(address);
        }else{
            companyList.stream()
                    .filter(v -> v.getUenId().equalsIgnoreCase(id))
                    .findFirst().orElse(new Company())
                    .setBillingAddress(address);
        }
    }

    private Customer validateId(String id){
        if(id.startsWith("UEN")){
            return new Company();
        }else{
            return new Person();
        }
    }
}
