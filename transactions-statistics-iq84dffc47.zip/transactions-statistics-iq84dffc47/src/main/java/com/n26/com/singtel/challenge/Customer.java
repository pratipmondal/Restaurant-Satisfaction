package com.n26.com.singtel.challenge;

import lombok.Data;

import java.util.List;

@Data
public class Customer {
    public Address address = null;

    public void setMailngAddress(List<String> value){
        address.getMailingAddress().clear();
        address.getMailingAddress().addAll(value);
    }

    public void setBillingAddress(List<String> value){
        address.getBillingAddress().clear();
        address.getBillingAddress().addAll(value);
    }
}
