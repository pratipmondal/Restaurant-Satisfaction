package com.n26.util;

import com.n26.exception.FutureTimeException;
import com.n26.exception.OldTimeException;
import com.n26.model.TransactionRequest;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

@Slf4j
public class TransactionUtility {

    private static final long TRANSACTION_VALIDITY = 60;

    public static boolean validate(TransactionRequest request) throws OldTimeException,FutureTimeException {
        OffsetDateTime utc = OffsetDateTime.now(ZoneOffset.UTC);
        long txnAgeInSeconds = Duration.between(request.getTimestamp(), utc.toInstant()).getSeconds();
        log.info("txnAgeInSeconds = {}", txnAgeInSeconds);
        if(txnAgeInSeconds >= TRANSACTION_VALIDITY){
            throw new OldTimeException("Given Input time is older than 60 secs");
        }else if(txnAgeInSeconds < 0){
            throw new FutureTimeException("Given Input time is a future time");
        }
        return true;
    }
}
