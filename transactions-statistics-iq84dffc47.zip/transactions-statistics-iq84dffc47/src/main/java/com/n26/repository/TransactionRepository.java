package com.n26.repository;

import com.n26.model.TransactionRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

@Repository
@Slf4j
public class TransactionRepository {

    private Queue<TransactionRequest> transactions = new ConcurrentLinkedQueue<>();

    private final long TRANSACTION_VALIDITY = 60;

    public void saveTransaction(TransactionRequest request) {
        transactions.add(request);
    }

    public void deleteAllTransactions() {
        transactions = new ConcurrentLinkedQueue<>();
    }

    public DoubleSummaryStatistics getStatistics() {
        OffsetDateTime utc = OffsetDateTime.now(ZoneOffset.UTC);
        DoubleSummaryStatistics summaryStatistics = transactions.parallelStream()
                .filter(request -> Duration.between(request.getTimestamp(), utc.toInstant()).getSeconds() < TRANSACTION_VALIDITY)
                .mapToDouble(TransactionRepository::applyAsDouble)
                .summaryStatistics();
        if(!CollectionUtils.isEmpty(transactions)) {
            cleanExpiredEntries();
        }
        return summaryStatistics;
    }

    private void cleanExpiredEntries() {
        boolean isHeadHadExpiredRequest = false;
        do {
            TransactionRequest request = transactions.peek();
            if(request != null) {
                isHeadHadExpiredRequest = isOldTransaction(request);
                if (isHeadHadExpiredRequest) {
                    transactions.remove(request);
                }
            }
        } while (isHeadHadExpiredRequest);
    }

    private boolean isOldTransaction(TransactionRequest request) {
        OffsetDateTime utc = OffsetDateTime.now(ZoneOffset.UTC);
        return Duration.between(request.getTimestamp(), utc.toInstant()).getSeconds() > TRANSACTION_VALIDITY;
    }

    private static double applyAsDouble(TransactionRequest request) {
        return request.getAmount().doubleValue();
    }
}
