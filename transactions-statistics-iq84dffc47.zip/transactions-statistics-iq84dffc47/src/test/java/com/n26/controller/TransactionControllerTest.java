package com.n26.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.n26.model.TransactionRequest;
import com.n26.service.TransactionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;

import static java.time.Instant.now;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = TransactionController.class)
public class TransactionControllerTest {

    @MockBean
    private TransactionService transactionService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper mapper;

    @Test
    public void should_get_statuscode_201() throws Exception {
        TransactionRequest transaction = new TransactionRequest(new BigDecimal(25.50), now());
        mockMvc.perform(post("/transactions")
                .contentType(APPLICATION_JSON_UTF8)
                .content(mapper.writeValueAsString(transaction))
                .accept(APPLICATION_JSON_UTF8))
                .andExpect(content().string(""))
                .andExpect(status().isCreated())
                ;

        verify(transactionService).saveTransaction(transaction);
    }

    @Test
    public void should_return_stats() throws Exception {
        MvcResult result = mockMvc.perform(get("/statistics")
                .accept(APPLICATION_JSON_UTF8))
                .andExpect(status().isOk())
                .andReturn();
        assertThat(result != null);
    }

    @Test
    public void should_return_delete_OK() throws Exception {
        MvcResult result = mockMvc.perform(delete("/transactions")
                .accept(APPLICATION_JSON_UTF8))
                .andExpect(status().isNoContent())
                .andReturn();
        assertThat(result != null);
    }
}