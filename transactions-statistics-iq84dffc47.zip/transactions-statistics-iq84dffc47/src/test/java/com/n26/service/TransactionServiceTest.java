package com.n26.service;

import com.n26.exception.OldTimeException;
import com.n26.model.StatisticsResponse;
import com.n26.model.TransactionRequest;
import com.n26.repository.TransactionRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.DoubleSummaryStatistics;
import java.util.List;

import static java.time.Instant.now;
import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private TransactionService transactionService;

    @Test
    public void should_add_transaction_when_timestamp_in_allowed_interval() {
        TransactionRequest transaction = new TransactionRequest(new BigDecimal(25.50), now());
        doNothing().when(transactionRepository).saveTransaction(transaction);

        transactionService.saveTransaction(transaction);

        verify(transactionRepository).saveTransaction(transaction);
    }

    @Test
    public void should_not_add_transaction_when_timestamp_outof_allowed_interval() {
        TransactionRequest transaction = new TransactionRequest(new BigDecimal(25.50), now().minusSeconds(61));

        try {
            transactionService.saveTransaction(transaction);
        }catch(OldTimeException exp){
           exp.printStackTrace();
        }

        verify(transactionRepository, never()).saveTransaction(transaction);
    }

    @Test
    public void should_return_stats_when_there_are_txns_in_allowed_interval() {
        List<TransactionRequest> transactions = asList(
                new TransactionRequest(new BigDecimal(15), now().minusSeconds(10)),
                new TransactionRequest(new BigDecimal(25), now().minusSeconds(20)),
                new TransactionRequest(new BigDecimal(20), now().minusSeconds(50))
        );
        DoubleSummaryStatistics doubleSummaryStatistics = transactions.parallelStream()
                .mapToDouble(v -> v.getAmount().doubleValue())
                .summaryStatistics();
        given(transactionRepository.getStatistics()).willReturn(doubleSummaryStatistics);

        StatisticsResponse statistics = (StatisticsResponse)transactionService.getTransaction().getBody();

        StatisticsResponse expected = new StatisticsResponse("60.00","20.00","25.00","15.00",3);

        verify(transactionRepository).getStatistics();
        assertThat(statistics).isEqualTo(expected);
    }

    @Test
    public void should_return_stats_with_zeros_when_there_are_no_txns_in_allowed_interval() {
        given(transactionRepository.getStatistics()).willReturn(new DoubleSummaryStatistics());

        StatisticsResponse statistics = (StatisticsResponse)transactionService.getTransaction().getBody();

        StatisticsResponse expected = new StatisticsResponse("0.00","0.00","0.00","0.00",0);

        verify(transactionRepository).getStatistics();
        assertThat(statistics).isEqualTo(expected);
    }
}