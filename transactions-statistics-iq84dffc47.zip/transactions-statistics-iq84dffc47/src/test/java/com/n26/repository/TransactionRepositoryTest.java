package com.n26.repository;

import com.n26.model.TransactionRequest;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.DoubleSummaryStatistics;

import static java.time.Instant.now;
import static org.assertj.core.api.Assertions.assertThat;

public class TransactionRepositoryTest {
    private TransactionRepository transactionRepository;

    @Before
    public void setUp() {
        transactionRepository = new TransactionRepository();
    }

    @Test
    public void should_save_transaction() {
        TransactionRequest txn = new TransactionRequest(new BigDecimal(25.50), now());
        transactionRepository.saveTransaction(txn);
        DoubleSummaryStatistics statistics = transactionRepository.getStatistics();
        assertThat(statistics.getCount()).isEqualTo(1);
    }

    @Test
    public void should_return_txns_with_timestamp_in_allowed_interval_only() {
        TransactionRequest txn1 = new TransactionRequest(new BigDecimal(25.50), now());
        TransactionRequest txn2 = new TransactionRequest(new BigDecimal(15.50), now().minusSeconds(10));
        TransactionRequest txn3 = new TransactionRequest(new BigDecimal(45.50), now().minusSeconds(61));

        transactionRepository.saveTransaction(txn1);
        transactionRepository.saveTransaction(txn2);
        transactionRepository.saveTransaction(txn3);

        assertThat(transactionRepository.getStatistics().getCount()).isEqualTo(2);
    }
}