package com.n26.util;

import com.n26.exception.FutureTimeException;
import com.n26.exception.OldTimeException;
import com.n26.model.TransactionRequest;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import static java.time.Instant.now;
import static org.junit.Assert.assertEquals;

public class TransactionUtilityTest {
    @Before
    public void setUp() {

    }

    @Test(expected = OldTimeException.class)
    public void should_throw_OldTimeException() {
        TransactionRequest txn = new TransactionRequest(new BigDecimal(25.50), now().minusSeconds(61));
        TransactionUtility.validate(txn);
    }

    @Test(expected = FutureTimeException.class)
    public void should_throw_FutureTimeException() {
        TransactionRequest txn = new TransactionRequest(new BigDecimal(25.50), now().plusSeconds(10));
        TransactionUtility.validate(txn);
    }

    @Test
    public void should_return_true() {
        TransactionRequest txn = new TransactionRequest(new BigDecimal(25.50), now().minusSeconds(10));
        boolean value = TransactionUtility.validate(txn);
        assertEquals(true, value);
    }
}