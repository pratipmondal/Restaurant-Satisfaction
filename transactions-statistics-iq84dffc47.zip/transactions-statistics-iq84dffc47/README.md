#API

- POST /transactions – called every time a transaction is made. It is also the sole input of this rest API.
- GET /statistics – returns the statistic based of the transactions of the last 60 seconds.
- DELETE /transactions – deletes all transactions.

#Swagger URL

- http://localhost:8080/swagger-ui.html

# ThreadSafe Transaction

- Implemented by ConcurrentLinkedQueue

# Managing transactions cleaning mechanism

- Cleaning transactions, which are older than 60 seconds during GET /statistics call