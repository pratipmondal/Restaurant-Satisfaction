import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';

@Component({
    moduleId: module.id,
    templateUrl: 'test.template.html'
})

export class TestComponent implements OnInit{
	ngOnInit(){
		 
  }
}
