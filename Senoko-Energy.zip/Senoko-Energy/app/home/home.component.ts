import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
    moduleId: module.id,
    templateUrl: 'home.template.html'
})

export class HomeComponent implements OnInit{
  username: string = '';
  isUsername : boolean = false;

  constructor(private route: ActivatedRoute, private router: Router) {
      //localStorage.clear();
  }

	ngOnInit(){
    this.route.queryParams.subscribe(params => {
        this.username = localStorage.getItem('username');
        if(typeof this.username !== 'undefined'){
          // const splited = this.username.split(' ');

        }
    });
  }

  logout(){
    localStorage.clear();
    this.username = '';
    // window.location.reload();
  }

}
