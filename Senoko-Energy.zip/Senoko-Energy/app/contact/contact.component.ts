import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';

@Component({
    moduleId: module.id,
    templateUrl: 'contact.template.html'
})

export class ContactComponent implements OnInit{
	ngOnInit(){
		
    }

}
