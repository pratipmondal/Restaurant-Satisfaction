import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';

@Component({
    moduleId: module.id,
    templateUrl: 'payment-successful.template.html'
})

export class PaymentSuccessfulComponent implements OnInit{
  
  constructor(private changeDetectorRef: ChangeDetectorRef) {
    
  }
  
  ngOnInit(){
    
  }
    

}
