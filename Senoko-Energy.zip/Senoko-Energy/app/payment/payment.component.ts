import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';

@Component({
    moduleId: module.id,
    templateUrl: 'payment.template.html'
})

export class PaymentComponent implements OnInit{
  
  constructor(private changeDetectorRef: ChangeDetectorRef) {
    
  }
  
  ngOnInit(){
    
  }
    

}
