import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import {ProductService} from './product.service';
import {Product} from './product';
import {Error} from './error';

@Component({
    moduleId: module.id,
    templateUrl: 'product.template.html'
})

export class ProductComponent implements OnInit{
	products: Product[];
	productForm: boolean = false;
	isNewForm: boolean;
	newProduct: any = {};
    error: any = {};
    isError: boolean = false;
    //sorting
    key: string = 'id'; //set default
    reverse: boolean = false;
    sort(key: string){
        this.key = key;
        this.reverse = !this.reverse;
    }

	constructor(private _productService:ProductService, private changeDetectorRef: ChangeDetectorRef){

	}

	ngOnInit(){
		//this.getProducts();
        this._productService.loaddata().subscribe(data => {
            this.products = data;
        })
        this.isNewForm = false;
        this.productForm = false;
    }

	getProducts(){
		this.products = this._productService.getProductsFromData();
		this.isNewForm = true;
		this.productForm = false;
	}	

	showEditProductForm(product: Product){
		if(!product){
			this.productForm = false;
			return;
		}
        this.isError = false;
		this.productForm = true;
		this.isNewForm = false;
		this.newProduct = product;
	}

	showAddProductForm(){
        this.isError = false;
		this.newProduct = {};
		this.productForm = true;
		this.isNewForm = true;
	}

    removeAddProductForm(){
        this.productForm = false;
        this.isNewForm = false;
    }

	saveProduct(product: Product){
		console.log("-----1-----this.isNewForm = "+this.isNewForm);
		if(this.isNewForm){
			console.log("-----2-----");
			//add a new product
			//this._productService.addProduct(product);
            this._productService.addAndLoaddata(product).subscribe(
                data => {
                console.log("-----3-----");
            	console.log("product = "+data);
				this.products = data;
                this.productForm = false;
			},
            err =>{
                console.log("-----4-----err = "+err.json());
                console.log("-----5-----");
                this.isError = true;
                this.error = err.json();
                this.productForm = true;
                this.isNewForm = true;
            }
			)
			console.log("-----6-----");

		}else{
            this._productService.updateAndLoaddata(product).subscribe(data => {
                this.products = data;
            })
            console.log("-----4-----");
		}
		this.productForm = false;
        this.isNewForm = false;
	}

    deleteRow(rowNumber: number, product: Product){
        //this._productService.deleteRow(rowNumber, this.changeDetectorRef);
        //this.changeDetectorRef.detectChanges();
        this.isError = false;
        this._productService.deleteAndLoaddata(product).subscribe(data => {
            this.products = data;
        })
    }

    onSorted(){
        this.getProducts();
    }
}
