import {BillingDetail} from './billingDetail';

export const TAB2_ITEMS: BillingDetail[] = [
  {
    "billableMonth": "Dec 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "0.0",
    "dateOfTransaction": "-"
  },
  {
    "billableMonth": "Nov 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "0.0",
    "dateOfTransaction": "-"
  },
  {
    "billableMonth": "Oct 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "100.00",
    "dateOfTransaction": "02 Nov 2017"
  },
  {
    "billableMonth": "Sep 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "100.00",
    "dateOfTransaction": "03 Oct 2017"
  },
  {
    "billableMonth": "Aug 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "100.00",
    "dateOfTransaction": "03 Oct 2017"
  },
  {
    "billableMonth": "Jul 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "100.00",
    "dateOfTransaction": "02 Aug 2017"
  },
  {
    "billableMonth": "Jun 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "100.00",
    "dateOfTransaction": "05 Aug 2017"
  },
  {
    "billableMonth": "May 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "100.00",
    "dateOfTransaction": "08 Jun 2017"
  },
  {
    "billableMonth": "Apr 2017",
    "energyConsumption": "2,000 kWh",
    "amountDue": "100.00",
    "dueDate": null,
    "amountPaid": "100.00",
    "dateOfTransaction": "08 Jun 2017"
  }
]