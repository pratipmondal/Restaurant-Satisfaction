"use strict";
exports.TAB1_ITEMS = [
    {
        billableMonth: 'Dec 2017',
        energyConsumption: '2,000 kWh',
        amountDue: '100.00',
        dueDate: '10 Jan 2018',
        amountPaid: null,
        dateOfTransaction: null
    },
    {
        billableMonth: 'Nov 2017',
        energyConsumption: '2,000 kWh',
        amountDue: '100.00',
        dueDate: '10 Dec 2018',
        amountPaid: null,
        dateOfTransaction: null
    }
];
//# sourceMappingURL=tab1.data.js.map