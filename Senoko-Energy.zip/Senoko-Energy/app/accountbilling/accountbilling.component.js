"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var billingDetail_service_1 = require("./billingDetail.service");
var abnav_component_1 = require("../abnav/abnav.component");
var core_1 = require("@angular/core");
var core_2 = require("@angular/core");
var AccountBillingComponent = (function (_super) {
    __extends(AccountBillingComponent, _super);
    function AccountBillingComponent(_billingService, changeDetectorRef) {
        var _this = _super.call(this) || this;
        _this._billingService = _billingService;
        _this.changeDetectorRef = changeDetectorRef;
        _this.tab1Visible = true;
        _this.tab2Visible = false;
        _this.usageVisible = false;
        _this.key = 'dateOfTransaction';
        _this.reverse = false;
        return _this;
    }
    AccountBillingComponent.prototype.sort = function (key) {
        this.key = key;
        this.reverse = !this.reverse;
    };
    AccountBillingComponent.prototype.ngOnInit = function () {
        console.log("tab1Data = " + this._billingService.getTab1Data());
        this.billingDetailList = this._billingService.getTab1Data();
        this.billingFullDetailList = this._billingService.getTab2Data();
        //    this._billingService.loaddata().subscribe(data => {
        //            this.billingDetailList = data;
        //    })
        //    
        //    this._billingService.loadFullData().subscribe(data => {
        //            this.billingFullDetailList = data;
        //    })
    };
    AccountBillingComponent.prototype.makeVisibleTab1 = function () {
        this.tab1Visible = true;
        this.tab2Visible = false;
    };
    AccountBillingComponent.prototype.makeVisibleTab2 = function () {
        this.tab2Visible = true;
        this.tab1Visible = false;
    };
    AccountBillingComponent.prototype.showHideUsage = function () {
        if (this.usageVisible) {
            this.usageVisible = false;
            return;
        }
        if (!this.usageVisible) {
            this.usageVisible = true;
            return;
        }
    };
    return AccountBillingComponent;
}(abnav_component_1.ABNavComponent));
AccountBillingComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'accountbilling.template1.html'
    }),
    __metadata("design:paramtypes", [billingDetail_service_1.BillingDetailService, core_2.ChangeDetectorRef])
], AccountBillingComponent);
exports.AccountBillingComponent = AccountBillingComponent;
//# sourceMappingURL=accountbilling.component.js.map