export interface BillingDetail{
  billableMonth:string;
	energyConsumption:string;
	amountDue:string;
	dueDate:string;
  amountPaid:string;
  dateOfTransaction:string;
}