import {Injectable} from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import {BillingDetail} from './billingDetail';
import { Http, Response } from '@angular/http';
import 'rxjs/Rx';
import {Observable} from 'rxjs/Rx';
import { TAB1_ITEMS } from './tab1.data';
import { TAB2_ITEMS } from './tab2.data';

@Injectable()
export class BillingDetailService{

	private server_url_get_billing_detail:string = "http://10.22.17.80:8080/billing/getBillingDetail";
  private server_url_get_full_billing_detail:string = "http://10.22.17.80:8080/billing/getBillingStatementOfAccounts";
  
  private tab1Items = TAB1_ITEMS;
  private tab2Items = TAB2_ITEMS;
  
  constructor(public http: Http) {

	}
    getTab1Data() : BillingDetail[]{
      return this.tab1Items;
    }
  
    getTab2Data() : BillingDetail[]{
      return this.tab2Items;
    }

    loaddata(): Observable<BillingDetail[]> {
        return this.http.get(this.server_url_get_billing_detail)
            .map(this.extractData);
    }
  
    loadFullData(): Observable<BillingDetail[]> {
        return this.http.get(this.server_url_get_full_billing_detail)
            .map(this.extractData);
    }
  
    private extractData(res: Response) {
        return res.json() || {};
    }

}