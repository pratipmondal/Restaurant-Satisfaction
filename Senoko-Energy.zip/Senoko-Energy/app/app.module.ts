import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.routing';

import { AppComponent } from './app.component';
import { ProductComponent } from './products/product.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AccountBillingComponent } from './accountbilling/accountbilling.component';
import { ABNavComponent } from './abnav/abnav.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentSuccessfulComponent } from './payment-successful/payment-successful.component';
import { NavbarComponent } from './nav/nav.component';
import {Ng2PaginationModule} from 'ng2-pagination';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { HttpModule } from '@angular/http';

import {ProductService} from './products/product.service';
import {BillingDetailService} from './accountbilling/billingDetail.service';
import { TestComponent } from './test/test.component';

@NgModule({
  imports: [ BrowserModule,
                   FormsModule,
                   AppRoutingModule,
                   Ng2PaginationModule,
                   Ng2OrderModule,
                   HttpModule
            ],
  declarations: [ AppComponent, TestComponent, ProductComponent, ContactComponent, NavbarComponent, HomeComponent, LoginComponent , AccountBillingComponent , ABNavComponent, PaymentComponent, PaymentSuccessfulComponent ],
  providers: [ BillingDetailService , ProductService  ],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }
