"use strict";

$(document).ready(function(){
	$('#arrowButton').click(function(e){
		var url = "http://api.openweathermap.org/data/2.5/weather?q=Shenzhen,China";
		var apiKey = "6136026772be013c74a434cd85db99f8";
		$.getJSON(url + '&appid=' +apiKey, null, function(data){
			updateUISuccess(data);
		});
	});
});

function updateUISuccess(data){
	console.log("data = "+data);
			var condition = data.weather[0].main;
			var degC = data.main.temp - 273.15;
			var degCInt = Math.floor(degC);
			var degF = degC * 1.8 + 32;
			var degFInt = Math.floor(degF);
			var $weatherBox = $('#weather');
			$weatherBox.html("");
			$weatherBox.append("<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F</p><p>" + condition + "</p>");
}

(function() {
	//var url = "http://localhost:8080/product/limit";
	var url = "http://api.openweathermap.org/data/2.5/weather?q=Shenzhen,China";
	var apiKey = "6136026772be013c74a434cd85db99f8";

	$.ajax({
		url : url + '&appid=' +apiKey,
		//contentType: 'application/json',
		//dataType: 'json',
		//data: JSON.stringify({"firstName":"Pratip","lastName":"Mondal"}),
		success: function(response, textStatus, jQxhr) {
			updateUISuccess(response);
		},
		error: function( jqXhr, textStatus, errorThrown ) {
			console.log("ERROR = "+errorThrown);
			updateUIError(errorThrown);
		},
		type: 'GET'
	 });

	//handle XHR success
	function updateUISuccess(response){
		//console.log("SUCCESS = "+JSON.stringify(response));
		var condition = response.weather[0].main;
		var degC = response.main.temp - 273.15;
		var degCInt = Math.floor(degC);
		var degF = degC * 1.8 + 32;
		var degFInt = Math.floor(degF);
//		var weatherBox = document.getElementById("weather");
//		weatherBox.innerHTML = "<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F</p><p>" + condition + "</p>";
		var $weatherBox = $('#weather');
		//$weatherBox.append("<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F</p><p>" + condition + "</p>");
	}
	
	//handle XHR error
	function updateUIError(errorThrown){
//		var weatherBox = document.getElementById("weather");
//		weatherBox.className = "hidden";
		var $weatherBox = $('#weather');
		//$weatherBox.addClass('hidden');
		$weatherBox.append("<p>"+errorThrown+"</p>");

	}

})();

// jQuery request
/*(function() {
	var url = "http://api.openweathermap.org/data/2.5/weather?q=Shenzhen,China";
	var apiKey = "6136026772be013c74a434cd85db99f8";

	$.get(url + '&appid=' +apiKey).done(function(response){
		updateUISuccess(response);
	}).fail(function(error){
		updateUIError();
	});

	//handle XHR success
	function updateUISuccess(response){
		//var response = JSON.parse(responseText);
		var condition = response.weather[0].main;
		var degC = response.main.temp - 273.15;
		var degCInt = Math.floor(degC);
		var degF = degC * 1.8 + 32;
		var degFInt = Math.floor(degF);
//		var weatherBox = document.getElementById("weather");
//		weatherBox.innerHTML = "<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F</p><p>" + condition + "</p>";
		var $weatherBox = $('#weather');
		$weatherBox.append("<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F</p><p>" + condition + "</p>");
	}
	
	//handle XHR error
	function updateUIError(){
//		var weatherBox = document.getElementById("weather");
//		weatherBox.className = "hidden";
		var $weatherBox = $('#weather');
		$weatherBox.addClass('hidden');

	}

})();*/

// Fetch request
/*(function() {
	var url = "http://api.openweathermap.org/data/2.5/weather?q=Shenzhen,China";
	var apiKey = "6136026772be013c74a434cd85db99f8";

	fetch(url + '&appid=' +apiKey).then(function(response){
		if(!response.ok){
			throw Error(response.statusText);
		}
		console.log(response);
		//console.log(response.json());//return Promise object
		return response.json();
	}).then(function(response){
		updateUISuccess(response);
	}).catch(function(error){
		updateUIError();
	});
	//handle XHR success
	function updateUISuccess(response){
		//var response = JSON.parse(responseText);
		var condition = response.weather[0].main;
		var degC = response.main.temp - 273.15;
		var degCInt = Math.floor(degC);
		var degF = degC * 1.8 + 32;
		var degFInt = Math.floor(degF);
		var weatherBox = document.getElementById("weather");
		weatherBox.innerHTML = "<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F</p><p>" + condition + "</p>";
	}
	//handle XHR error
	function updateUIError(){
		var weatherBox = document.getElementById("weather");
		weatherBox.className = "hidden";
	}
})();*/

/*(function() {
	var url = "http://api.openweathermap.org/data/2.5/weather?q=London,England";
	var apiKey = "6136026772be013c74a434cd85db99f8"; // Replace "APIKEY" with your own API key; otherwise, your HTTP request will not work
	var httpRequest;
	makeRequest();
	
	//create & send an XHR Request
	function makeRequest(){
		httpRequest = new XMLHttpRequest();
		httpRequest.onreadystatechange = responseMethod;
		httpRequest.open('GET', url + '&appid=' +apiKey);
		httpRequest.send();
	}

	//handle XHR response
	function responseMethod(){
		if(httpRequest.readyState === 4){
			if(httpRequest.status === 200){
				updateUISuccess(httpRequest.responseText);
			}else{
				updateUIError();
			}
			console.log(httpRequest.responseText);
		}
	}

	//handle XHR success
	function updateUISuccess(responseText){
		var response = JSON.parse(responseText);
		var condition = response.weather[0].main;
		var degC = response.main.temp - 273.15;
		var degCInt = Math.floor(degC);
		var degF = degC * 1.8 + 32;
		var degFInt = Math.floor(degF);
		var weatherBox = document.getElementById("weather");
		weatherBox.innerHTML = "<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F</p><p>" + condition + "</p>";
	}

	//handle XHR error
	function updateUIError(){
		var weatherBox = document.getElementById("weather");
		weatherBox.className = "hidden";
	}
})();*/