"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var core_2 = require("@angular/core");
var product_service_1 = require("./product.service");
var ProductComponent = (function () {
    function ProductComponent(_productService, changeDetectorRef) {
        this._productService = _productService;
        this.changeDetectorRef = changeDetectorRef;
        this.productForm = false;
        this.newProduct = {};
        this.error = {};
        this.isError = false;
        //sorting
        this.key = 'id'; //set default
        this.reverse = false;
    }
    ProductComponent.prototype.sort = function (key) {
        this.key = key;
        this.reverse = !this.reverse;
    };
    ProductComponent.prototype.ngOnInit = function () {
        var _this = this;
        //this.getProducts();
        this._productService.loaddata().subscribe(function (data) {
            _this.products = data;
        });
        this.isNewForm = false;
        this.productForm = false;
    };
    ProductComponent.prototype.getProducts = function () {
        this.products = this._productService.getProductsFromData();
        this.isNewForm = true;
        this.productForm = false;
    };
    ProductComponent.prototype.showEditProductForm = function (product) {
        if (!product) {
            this.productForm = false;
            return;
        }
        this.isError = false;
        this.productForm = true;
        this.isNewForm = false;
        this.newProduct = product;
    };
    ProductComponent.prototype.showAddProductForm = function () {
        this.isError = false;
        this.newProduct = {};
        this.productForm = true;
        this.isNewForm = true;
    };
    ProductComponent.prototype.removeAddProductForm = function () {
        this.productForm = false;
        this.isNewForm = false;
    };
    ProductComponent.prototype.saveProduct = function (product) {
        var _this = this;
        console.log("-----1-----this.isNewForm = " + this.isNewForm);
        if (this.isNewForm) {
            console.log("-----2-----");
            //add a new product
            //this._productService.addProduct(product);
            this._productService.addAndLoaddata(product).subscribe(function (data) {
                console.log("-----3-----");
                console.log("product = " + data);
                _this.products = data;
                _this.productForm = false;
            }, function (err) {
                console.log("-----4-----err = " + err.json());
                console.log("-----5-----");
                _this.isError = true;
                _this.error = err.json();
                _this.productForm = true;
                _this.isNewForm = true;
            });
            console.log("-----6-----");
        }
        else {
            this._productService.updateAndLoaddata(product).subscribe(function (data) {
                _this.products = data;
            });
            console.log("-----4-----");
        }
        this.productForm = false;
        this.isNewForm = false;
    };
    ProductComponent.prototype.deleteRow = function (rowNumber, product) {
        var _this = this;
        //this._productService.deleteRow(rowNumber, this.changeDetectorRef);
        //this.changeDetectorRef.detectChanges();
        this.isError = false;
        this._productService.deleteAndLoaddata(product).subscribe(function (data) {
            _this.products = data;
        });
    };
    ProductComponent.prototype.onSorted = function () {
        this.getProducts();
    };
    return ProductComponent;
}());
ProductComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'product.template.html'
    }),
    __metadata("design:paramtypes", [product_service_1.ProductService, core_2.ChangeDetectorRef])
], ProductComponent);
exports.ProductComponent = ProductComponent;
//# sourceMappingURL=product.component.js.map