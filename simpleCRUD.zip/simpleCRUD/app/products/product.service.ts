import {Injectable} from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import {Product} from './product';
import { PRODUCT_ITEMS } from './product.data';

@Injectable()
export class ProductService{

	private pItems = PRODUCT_ITEMS;

	getProductsFromData() : Product[]{
		return this.pItems;
	}

	addProduct(product: Product){
        console.log("Adding Product----------");
		this.pItems.push(product);
		console.log(this.pItems);
	}

    deleteRow(rowNumber: number, changeDetectorRef: ChangeDetectorRef){
        console.log("Delete Product----------");
        this.pItems.splice(rowNumber, 1);
        console.log(this.pItems);
        changeDetectorRef.detectChanges();
    }
}