import {Injectable} from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import {Product} from './product';
import { PRODUCT_ITEMS } from './product.data';
import { Http, Response } from '@angular/http';
import 'rxjs/Rx';
import {Observable} from 'rxjs/Rx';

@Injectable()
export class ProductService{

	private server_url_get:string = "http://10.22.17.80:8080/product/getItems";
    private server_url_post:string = "http://10.22.17.80:8080/product/addItem";
    private server_url_update:string = "http://10.22.17.80:8080/product/updateItem";
    private server_url_delete:string = "http://10.22.17.80:8080/product/deleteItem";
    constructor(public http: Http) {

	}

    private pItems = PRODUCT_ITEMS;

	getProductsFromData() : Product[]{
		return this.pItems;
	}

    loaddata(): Observable<Product[]> {
        return this.http.get(this.server_url_get)
            .map(this.extractData);
    }

    addAndLoaddata(product: Product): Observable<any> {
        return this.http.post(this.server_url_post, product)
            .map(this.extractData);
    }

    updateAndLoaddata(product: Product): Observable<Product[]> {
        return this.http.post(this.server_url_update, product)
            .map(this.extractData);
    }


    addProduct(product: Product){
        console.log("Adding Product----------");
		this.pItems.push(product);
		console.log(this.pItems);
	}

    deleteRow(rowNumber: number, changeDetectorRef: ChangeDetectorRef){
        console.log("Delete Product----------");
        this.pItems.splice(rowNumber, 1);
        console.log(this.pItems);
        changeDetectorRef.detectChanges();
    }

    deleteAndLoaddata(product: Product): Observable<Product[]> {
        return this.http.post(this.server_url_delete, product)
            .map(this.extractData);
    }

    private extractData(res: Response) {
        //if (res.status < 200 || res.status >= 300) {
            //throw new Error('Bad response status: ' + res.status);
            //return res.json();
        //}
		console.log(res.json());
        return res.json() || {};
    }

}