"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var product_data_1 = require("./product.data");
var http_1 = require("@angular/http");
require("rxjs/Rx");
var ProductService = (function () {
    function ProductService(http) {
        this.http = http;
        this.server_url_get = "http://10.22.17.80:8080/product/getItems";
        this.server_url_post = "http://10.22.17.80:8080/product/addItem";
        this.server_url_update = "http://10.22.17.80:8080/product/updateItem";
        this.server_url_delete = "http://10.22.17.80:8080/product/deleteItem";
        this.pItems = product_data_1.PRODUCT_ITEMS;
    }
    ProductService.prototype.getProductsFromData = function () {
        return this.pItems;
    };
    ProductService.prototype.loaddata = function () {
        return this.http.get(this.server_url_get)
            .map(this.extractData);
    };
    ProductService.prototype.addAndLoaddata = function (product) {
        return this.http.post(this.server_url_post, product)
            .map(this.extractData);
    };
    ProductService.prototype.updateAndLoaddata = function (product) {
        return this.http.post(this.server_url_update, product)
            .map(this.extractData);
    };
    ProductService.prototype.addProduct = function (product) {
        console.log("Adding Product----------");
        this.pItems.push(product);
        console.log(this.pItems);
    };
    ProductService.prototype.deleteRow = function (rowNumber, changeDetectorRef) {
        console.log("Delete Product----------");
        this.pItems.splice(rowNumber, 1);
        console.log(this.pItems);
        changeDetectorRef.detectChanges();
    };
    ProductService.prototype.deleteAndLoaddata = function (product) {
        return this.http.post(this.server_url_delete, product)
            .map(this.extractData);
    };
    ProductService.prototype.extractData = function (res) {
        //if (res.status < 200 || res.status >= 300) {
        //throw new Error('Bad response status: ' + res.status);
        //return res.json();
        //}
        console.log(res.json());
        return res.json() || {};
    };
    return ProductService;
}());
ProductService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], ProductService);
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map