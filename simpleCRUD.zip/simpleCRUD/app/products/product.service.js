"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var product_data_1 = require("./product.data");
var ProductService = (function () {
    function ProductService() {
        this.pItems = product_data_1.PRODUCT_ITEMS;
    }
    ProductService.prototype.getProductsFromData = function () {
        return this.pItems;
    };
    ProductService.prototype.addProduct = function (product) {
        console.log("Adding Product----------");
        this.pItems.push(product);
        console.log(this.pItems);
    };
    ProductService.prototype.deleteRow = function (rowNumber, changeDetectorRef) {
        console.log("Delete Product----------");
        this.pItems.splice(rowNumber, 1);
        console.log(this.pItems);
        changeDetectorRef.detectChanges();
    };
    return ProductService;
}());
ProductService = __decorate([
    core_1.Injectable()
], ProductService);
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map