import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import {ProductService} from './product.service';
import {Product} from './product';

@Component({
    moduleId: module.id,
    templateUrl: 'product.template.html'
})

export class ProductComponent implements OnInit{
	products: Product[];
	productForm: boolean = false;
	isNewForm: boolean;
	newProduct: any = {};
    //sorting
    key: string = 'name'; //set default
    reverse: boolean = false;
    sort(key: string){
        this.key = key;
        this.reverse = !this.reverse;
    }

	constructor(private _productService:ProductService, private changeDetectorRef: ChangeDetectorRef){

	}

	ngOnInit(){
		this.getProducts();
	}

	getProducts(){
		this.products = this._productService.getProductsFromData();
		this.isNewForm = true;
		this.productForm = false;
	}	

	showEditProductForm(product: Product){
		if(!product){
			this.productForm = false;
			return;
		}
		this.productForm = true;
		this.isNewForm = false;
		this.newProduct = product;
	}

	showAddProductForm(){
		this.newProduct = {};
		this.productForm = true;
		this.isNewForm = true;
	}

	saveProduct(product: Product){
		console.log("-----1-----this.isNewForm = "+this.isNewForm);
		if(this.isNewForm){
			console.log("-----2-----");
			//add a new product
			this._productService.addProduct(product);
			console.log("-----3-----");
			this.productForm = false;
		}else{
			//update a product
		}
		this.productForm = false;
	}

    deleteRow(rowNumber: number){
        this._productService.deleteRow(rowNumber, this.changeDetectorRef);
        this.changeDetectorRef.detectChanges();
    }

    onSorted(){
        this.getProducts();
    }
}
