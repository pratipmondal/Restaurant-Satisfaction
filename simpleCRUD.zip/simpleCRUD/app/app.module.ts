import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.routing';

import { AppComponent } from './app.component';
import { ProductComponent } from './products/product.component';
import { NavbarComponent } from './nav/nav.component';
import {Ng2PaginationModule} from 'ng2-pagination';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { HttpModule } from '@angular/http';

import {ProductService} from './products/product.service';

@NgModule({
  imports: [ BrowserModule,
                   FormsModule,
                   AppRoutingModule,
                   Ng2PaginationModule,
                   Ng2OrderModule,
                   HttpModule
            ],
  declarations: [ AppComponent,
                          ProductComponent,
                          NavbarComponent
                          ],
  providers: [ ProductService ],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }