package com.ubs.opsit.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ubs.opsit.exception.Error;

@RestController
@RequestMapping("/product/")
@CrossOrigin
public class ProductController {
	
	@GetMapping(
			path = "getItems",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	public ResponseEntity<List<Product>> getProductItems(){
		try {
			ResponseEntity<List<Product>> response = new ResponseEntity<>(initializeProducts(),HttpStatus.OK);
			return response;
			
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(
			path = "addItem",
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	public ResponseEntity<Object> addProductItem(@RequestBody Product product){
		try {
			if(findProductId(product.getId())) {
				Error error = new Error();
				error.setStatus(HttpStatus.BAD_REQUEST.value());
				error.setMessage("Duplicate ProductId exists!");
				return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\Pratip\\simpleCRUD\\Products.txt", true));
			writer.newLine();
			writer.write(product.getId()+":"+product.getName()+":"+product.getDescription()+":"+product.getPrice());
			writer.close();
		    return new ResponseEntity<>(initializeProducts(),HttpStatus.OK);
			
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(
			path = "updateItem",
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	public ResponseEntity<List<Product>> updateProductItem(@RequestBody Product product){
		try {
			String line = null;
			String newText = "";
			try (BufferedReader br = new BufferedReader(new FileReader(new File("D:\\Pratip\\simpleCRUD\\Products.txt")))) {
			    while ((line = br.readLine()) != null) {
			    	if(product.getId() != null && product.getId().equals(line.split(":")[0])) {
			    		newText = newText.concat(product.getId()+":"+product.getName()+":"+product.getDescription()+":"+product.getPrice() + "\r\n");
			    	}else {
			    		newText = newText.concat(line + "\r\n");
			    	}
			    }
			}
			FileWriter writer = new FileWriter("D:\\Pratip\\simpleCRUD\\Products.txt");
			writer.write(newText);
			writer.close();
		    return new ResponseEntity<>(initializeProducts(),HttpStatus.OK);
			
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(
			path = "deleteItem",
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	public ResponseEntity<List<Product>> deleteProductItem(@RequestBody Product product){
		try {
			String line = null;
			String newText = "";
			try (BufferedReader br = new BufferedReader(new FileReader(new File("D:\\Pratip\\simpleCRUD\\Products.txt")))) {
			    while ((line = br.readLine()) != null) {
			    	if(product.getId() != null && product.getId().equals(line.split(":")[0])) {
			    		
			    	}else {
			    		newText = newText.concat(line + "\r\n");
			    	}
			    }
			}
			FileWriter writer = new FileWriter("D:\\Pratip\\simpleCRUD\\Products.txt");
			writer.write(newText);
			writer.close();
		    return new ResponseEntity<>(initializeProducts(),HttpStatus.OK);
			
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.BAD_REQUEST);
		}
	}
	
	private List<Product> initializeProducts() throws FileNotFoundException, IOException {
		List<Product> list = new ArrayList<>();
		Product product = null;
		String line = null;
		String[] productLine = null;
		File file = new File("D:\\Pratip\\simpleCRUD\\Products.txt");
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
		    while ((line = br.readLine()) != null) {
		    	if(null == line || line.equals("")) continue;
		    	
		    	productLine = line.split(":");
		    	product = new Product();
		    	product.setId(productLine[0]);
				product.setName(productLine[1]);
				product.setDescription(productLine[2]);
				product.setPrice(productLine[3]);
				list.add(product);
		    }
		}
		Collections.sort(list, Product.idComparator.reversed());
		return list;
	}
	
	private boolean findProductId(String productId) throws FileNotFoundException, IOException {
		String line = null;
		String[] productLine = null;
		File file = new File("D:\\Pratip\\simpleCRUD\\Products.txt");
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
		    while ((line = br.readLine()) != null) {
		    	if(null == line || line.equals("")) continue;
		    	
		    	productLine = line.split(":");
		    	if(productLine[0].equals(productId)) {
		    		return true;
		    	}
		    }
		}
		return false;
	}

}
