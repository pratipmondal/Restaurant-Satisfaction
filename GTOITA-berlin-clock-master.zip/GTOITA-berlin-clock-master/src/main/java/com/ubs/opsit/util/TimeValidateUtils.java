package com.ubs.opsit.util;

import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.opsit.exception.WrongFormatException;

public class TimeValidateUtils {
	
	private static final Logger LOG = LoggerFactory.getLogger(TimeValidateUtils.class);
	
	private TimeValidateUtils(){
		
	}
	
	public static void validateNumericValue(int hour, int minute, int second) {
		if (hour < 0 || hour > 24) {
			LOG.error(BerlinClockConstants.HOUR_OUTOFBOUND_ERROR);
			throw new IllegalArgumentException(BerlinClockConstants.HOUR_OUTOFBOUND_ERROR);
		}else if (minute < 0 || minute > 59) {
			LOG.error(BerlinClockConstants.MINUTE_OUTOFBOUND_ERROR);
			throw new IllegalArgumentException(BerlinClockConstants.MINUTE_OUTOFBOUND_ERROR);
		}else if (second < 0 || second > 59) {
			LOG.error(BerlinClockConstants.SECOND_OUTOFBOUND_ERROR);
			throw new IllegalArgumentException(BerlinClockConstants.SECOND_OUTOFBOUND_ERROR);
		}
	}
	
	public static int[] validateFormat(String time) {
		try {
			if (StringUtils.isEmpty(time)) {
				LOG.error(BerlinClockConstants.NO_TIME_ERROR);
				throw new WrongFormatException(BerlinClockConstants.NO_TIME_ERROR);
			}
			int[] parts = Stream.of(time.split(BerlinClockConstants.COLON)).mapToInt(Integer::parseInt).toArray();
			
			if (parts.length != 3) {
				LOG.error(BerlinClockConstants.INVALID_TIME_ERROR);
				throw new WrongFormatException(BerlinClockConstants.INVALID_TIME_ERROR);
			}
			return parts;
		} catch (NumberFormatException exp) {
			LOG.error(BerlinClockConstants.NUMERIC_TIME_ERROR);
			throw new NumberFormatException(BerlinClockConstants.NUMERIC_TIME_ERROR);
		}
	}

}
