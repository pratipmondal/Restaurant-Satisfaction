package com.ubs.opsit.util;

public class BerlinClockConstants {

	public static final String NO_TIME_ERROR = "No time provided";
	public static final String INVALID_TIME_ERROR = "Invalid time provided";
	public static final String NUMERIC_TIME_ERROR = "Time values must be numeric";
	public static final String HOUR_OUTOFBOUND_ERROR = "Hour out of bounds";
	public static final String MINUTE_OUTOFBOUND_ERROR = "Minute out of bounds";
	public static final String SECOND_OUTOFBOUND_ERROR = "Second out of bounds";
	public static final String COLON = ":";
	
	public static final int TOP_BOTTOM_HOURS_SLOT = 4;
	public static final int TOP_MINUTES_SLOT = 11;
	public static final int BOTTOM_MINUTES_SLOT = 4;
	
	public static final String CLOCK_FRAME_NAME = "BERLIN CLOCK";
	
	public static final int APPLET_WIDTH = 430;
	public static final int APPLET_HEIGHT = 900;

	public static final int CIRCLE_COORDINATE_X = 170;
	public static final int CIRCLE_COORDINATE_Y = 4;
	public static final int CIRCLE_WIDTH = 105;
	public static final int CIRCLE_HEIGHT = 105;

	public static final int STARTING_COORDINATE_X = 60;
	public static final int STARTING_COORDINATE_Y = 110;
	public static final int EXTENTION_Y = 79;
	public static final int RECTANGLE_WIDTH = 77;
	public static final int RECTANGLE_HEIGHT = 77;
	public static final int SMALL_RECTANGLE_WIDTH = 25;
	public static final int RECTANGLE_SHIFT = 80;
	public static final int SMALL_RECTANGLE_SHIFT = 29;
	
	public static final int STAND_COORDINATE_X = 210;
	public static final int STAND_COORDINATE_Y = 110;
	public static final int STAND_WIDTH = 20;
	public static final int STAND_HEIGHT = 400;
}