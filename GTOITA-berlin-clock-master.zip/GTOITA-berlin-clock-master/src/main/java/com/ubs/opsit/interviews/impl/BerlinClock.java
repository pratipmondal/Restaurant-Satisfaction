package com.ubs.opsit.interviews.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.opsit.interviews.BerlinClockService;
import com.ubs.opsit.interviews.TimeConverter;

public class BerlinClock implements TimeConverter{
	
	private static final Logger LOG = LoggerFactory.getLogger(BerlinClock.class);
	
	private BerlinClockService service;
	
	@Override
	public String convertTime(String time) {
		LOG.debug("Time Provided - {}", time);
		service = new BerlinClockServiceImpl();
		return service.convertTimeToBerlinClockStandard(time);
		
	}
	
}