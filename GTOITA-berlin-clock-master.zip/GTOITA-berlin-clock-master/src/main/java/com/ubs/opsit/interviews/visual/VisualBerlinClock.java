package com.ubs.opsit.interviews.visual;

public interface VisualBerlinClock {
	
	public void createBerlinClock(String time, VisualBerlinClock impl);

}
