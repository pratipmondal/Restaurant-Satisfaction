package com.ubs.opsit.interviews;

public interface BerlinClockService {
	
	public String convertTimeToBerlinClockStandard(String time);

}
