package com.ubs.opsit.interviews.impl;

import org.apache.commons.lang.text.StrBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubs.opsit.interviews.BerlinClockService;
import com.ubs.opsit.util.BerlinClockConstants;
import com.ubs.opsit.util.Lamp;
import com.ubs.opsit.util.TimeValidateUtils;

@Service
public class BerlinClockServiceImpl implements BerlinClockService{
	
	private static final Logger LOG = LoggerFactory.getLogger(BerlinClockServiceImpl.class);
	
	@Override
	public String convertTimeToBerlinClockStandard(String time) {
		int[] parts = TimeValidateUtils.validateFormat(time);
		int hour = parts[0];
		int minute = parts[1];
		int second = parts[2];
		LOG.debug("Extracted value : Hour = {} , Minute = {} , Second = {}", hour, minute, second);
		
		TimeValidateUtils.validateNumericValue(hour,minute,second);
		
		ClockView clockView = show(getSeconds(second),getTopHours(hour),getBottomHours(hour)
				,getTopMinutes(minute),getBottomMinutes(minute));
		
		LOG.debug("Converted Berlin Time is - \n{}", clockView.toString());
		return clockView.toString();
	}

	private String getSeconds(int number) {
		if (number % 2 == 0)
			return Lamp.YELLOW.getValue();
		else
			return Lamp.OFF.getValue();
	}

	public String getTopHours(int number) {
		return getOnOff(BerlinClockConstants.TOP_BOTTOM_HOURS_SLOT, getTopNumberOfOnSigns(number));
	}

	public String getBottomHours(int number) {
		return getOnOff(BerlinClockConstants.TOP_BOTTOM_HOURS_SLOT, number % 5);
	}

	public String getTopMinutes(int number) {
		return getOnOff(BerlinClockConstants.TOP_MINUTES_SLOT, getTopNumberOfOnSigns(number), Lamp.YELLOW.getValue()).replaceAll("YYY", "YYR");
	}

	public String getBottomMinutes(int number) {
		return getOnOff(BerlinClockConstants.BOTTOM_MINUTES_SLOT, number % 5, Lamp.YELLOW.getValue());
	}

	public static ClockView show(String second,String topHour,String bottomHour,String topMinute,String bottomMinute){
    	return new ClockView(second,topHour,bottomHour,topMinute,bottomMinute);
    }

	private String getOnOff(int lamps, int onSigns) {
		return getOnOff(lamps, onSigns, Lamp.RED.getValue());
	}

	private String getOnOff(int lamps, int onSigns, String onSign) {
		String out = "";
		for (int i = 0; i < onSigns; i++) {
			out += onSign;
		}
		for (int i = 0; i < (lamps - onSigns); i++) {
			out += Lamp.OFF.getValue();
		}
		return out;
	}

	private int getTopNumberOfOnSigns(int number) {
		return (number - (number % 5)) / 5;
	}
	
	public static class ClockView {

		final String second;
    	final String topHour;
    	final String bottomHour;
    	final String topMinute;
    	final String bottomMinute;

    	private ClockView(String second,String topHour,String bottomHour,String topMinute,String bottomMinute) {
    		this.second = second;
    		this.topHour = topHour;
    		this.bottomHour = bottomHour;
    		this.topMinute = topMinute;
    		this.bottomMinute = bottomMinute;
    	}

    	@Override
    	public String toString(){
	    	return new StrBuilder()
	    		.appendWithSeparators(
	    			new String[]{ second, topHour, bottomHour, topMinute, bottomMinute }, 
	    			System.lineSeparator()
	    		).toString();

    	}
	}

}
