package com.ubs.opsit.interviews.visual.impl;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.JFrame;

import org.codehaus.plexus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ubs.opsit.interviews.visual.VisualBerlinClock;
import com.ubs.opsit.util.BerlinClockConstants;
import com.ubs.opsit.util.Lamp;

public class VisualBerlinClockImpl extends JComponent implements VisualBerlinClock{
	
	private static final Logger LOG = LoggerFactory.getLogger(VisualBerlinClockImpl.class);
	
	private static final long serialVersionUID = 1L;
	
	private String time;
	
	@Override
	public void createBerlinClock(String time, VisualBerlinClock clock) {
		LOG.debug("Provided Time is - {}", time);
		this.time = time;
		JFrame mainFrame = new JFrame(BerlinClockConstants.CLOCK_FRAME_NAME);
		mainFrame.getContentPane().add((Component) clock);
		mainFrame.pack();
		mainFrame.setVisible(true);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		String[] parts = time.split(System.lineSeparator());
		super.paintComponent(g);
		g.setColor(Color.white);
		g.fillRect(0, 0, getWidth(), getHeight());
		
		drawCircle(parts[0], g);
		
		drawRectangale(BerlinClockConstants.STARTING_COORDINATE_X, BerlinClockConstants.STARTING_COORDINATE_Y, BerlinClockConstants.RECTANGLE_WIDTH, 
				BerlinClockConstants.RECTANGLE_HEIGHT, BerlinClockConstants.RECTANGLE_SHIFT, g, parts[1]);
		drawRectangale(BerlinClockConstants.STARTING_COORDINATE_X, BerlinClockConstants.STARTING_COORDINATE_Y+BerlinClockConstants.EXTENTION_Y, 
				BerlinClockConstants.RECTANGLE_WIDTH, BerlinClockConstants.RECTANGLE_HEIGHT, BerlinClockConstants.RECTANGLE_SHIFT, g, parts[2]);
		
		drawRectangale(BerlinClockConstants.STARTING_COORDINATE_X, BerlinClockConstants.STARTING_COORDINATE_Y+BerlinClockConstants.EXTENTION_Y*2, 
				BerlinClockConstants.SMALL_RECTANGLE_WIDTH, BerlinClockConstants.RECTANGLE_HEIGHT, BerlinClockConstants.SMALL_RECTANGLE_SHIFT, g, parts[3]);
		drawRectangale(BerlinClockConstants.STARTING_COORDINATE_X, BerlinClockConstants.STARTING_COORDINATE_Y+BerlinClockConstants.EXTENTION_Y*3, 
				BerlinClockConstants.RECTANGLE_WIDTH, BerlinClockConstants.RECTANGLE_HEIGHT, BerlinClockConstants.RECTANGLE_SHIFT, g, parts[4]);
		
		g.setColor(Color.DARK_GRAY);
		g.fillRect(BerlinClockConstants.STAND_COORDINATE_X, BerlinClockConstants.STAND_COORDINATE_Y+BerlinClockConstants.EXTENTION_Y*4, BerlinClockConstants.STAND_WIDTH, 400);
		
		LOG.debug("Berlin Clock is drawn successfully !!!!");
	}
	
	private void drawCircle(String time, Graphics g) {
		if(StringUtils.equals(time, Lamp.YELLOW.getValue())) 
			g.setColor(Color.YELLOW);
		else if(StringUtils.equals(time, Lamp.OFF.getValue()))
			g.setColor(Color.GRAY);
		
		g.fillOval(BerlinClockConstants.CIRCLE_COORDINATE_X, BerlinClockConstants.CIRCLE_COORDINATE_Y, BerlinClockConstants.CIRCLE_WIDTH, BerlinClockConstants.CIRCLE_HEIGHT);
	}
	
	private void drawRectangale(int x, int y, int width, int height, int shift, Graphics g, String time) {
		int x1 = 0;
		for(int i=0;i<time.length();i++) {
			if(time.charAt(i) == Lamp.RED.getValue().charAt(0))
				g.setColor(Color.RED);
			else if(time.charAt(i) == Lamp.OFF.getValue().charAt(0))
				g.setColor(Color.GRAY);
			else if(time.charAt(i) == Lamp.YELLOW.getValue().charAt(0))
				g.setColor(Color.YELLOW);
			
			g.fillRect(x+x1, y, width, height);
			x1=x1+shift;
		}
	}

	public Dimension getPreferredSize() {
		return new Dimension(BerlinClockConstants.APPLET_WIDTH, BerlinClockConstants.APPLET_HEIGHT);
	}

	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

}
