package com.ubs.opsit.util;

public enum Lamp {
	YELLOW("Y"),
	RED("R"),
	OFF("O");
	
	private String value;
	
	private Lamp(String value) { 
		this.value = value; 
	}

	public String getValue() {
		return value;
	} 
}
