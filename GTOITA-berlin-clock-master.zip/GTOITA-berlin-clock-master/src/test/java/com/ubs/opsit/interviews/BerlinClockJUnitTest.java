package com.ubs.opsit.interviews;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ubs.opsit.exception.WrongFormatException;
import com.ubs.opsit.interviews.impl.BerlinClock;
import com.ubs.opsit.interviews.impl.BerlinClockServiceImpl;

public class BerlinClockJUnitTest {
	
	private TimeConverter berlinClock;
	private BerlinClockServiceImpl service;
	 
	@Before
	public void setUp() {
		service = new BerlinClockServiceImpl();
		berlinClock = new BerlinClock();
	}
 
    @Test
    public void testTopHoursShouldHave4Lamps() {
        Assert.assertEquals("Top hours should have 4 lamps", 4, service.getTopHours(7).length());
    }
 
    @Test
    public void testBottomHoursShouldHave4Lamps() {
        Assert.assertEquals("Bottom hours should have 4 lamps", 4, service.getBottomHours(5).length());
    }
 
    @Test
    public void testTopMinutesShouldHave11Lamps() {
        Assert.assertEquals("Top minutes should have 11 lamps", 11, service.getTopMinutes(34).length());
    }
 
    @Test
    public void testBottomMinutesShouldHave4Lamps() {
        Assert.assertEquals("Bottom minutes should have 4 lamps", 4, service.getBottomMinutes(0).length());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void testUpperInvalidHours() {
    	berlinClock.convertTime("25:00:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpperInvalidMinutes() {
        berlinClock.convertTime("00:60:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpperInvalidSeconds() {
        berlinClock.convertTime("00:00:60");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLowerInvalidHours() {
        berlinClock.convertTime("-01:00:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLowerInvalidMinutes() {
        berlinClock.convertTime("00:-01:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLowerInvalidSeconds() {
        berlinClock.convertTime("00:00:-01");
    }

    @Test(expected = WrongFormatException.class)
    public void testInvalidString() {
        berlinClock.convertTime("00:00");
    }
    
    @Test(expected = WrongFormatException.class)
    public void testAnInvalidString() {
        berlinClock.convertTime("12345");
    }
    
    @Test(expected = NumberFormatException.class)
    public void testInvalidNumber() {
        berlinClock.convertTime("14:02:XX");
    }

    @Test(expected = WrongFormatException.class)
    public void testNullString() {
        berlinClock.convertTime(null);
    }

    @Test(expected = WrongFormatException.class)
    public void testEmptyString() {
        berlinClock.convertTime("");
    }
    
    @After
    public void tear() {
    	service = null;
    	berlinClock = null;
    }

}
