package com.ubs.opsit.interviews;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BerlinClockBootTest {
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	@Test
	public void testGETAPIWithProperTime() throws Exception {
		String berlinTime = "O\r\n" + 
				"RROO\r\n" + 
				"RRRR\r\n" + 
				"YYRYYOOOOOO\r\n" + 
				"OOOO";
		ResponseEntity<String> entity = this.restTemplate.getForEntity("/berlinclock/getTime?time=14:25:39", String.class);
		assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(entity.getBody()).isEqualTo(berlinTime);

	}
	
	@Test
	public void testGETAPIWithWrongTime() throws Exception {
		ResponseEntity<String> entity = this.restTemplate.getForEntity("/berlinclock/getTime?time=14:25:79", String.class);
		assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

	}
	
	@Test
	public void testWrongAPIEndPoint() throws Exception {
		ResponseEntity<String> entity = this.restTemplate.getForEntity("/berlinclock/wrong/getTime?time=14:25:16", String.class);
		assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);

	}

}
