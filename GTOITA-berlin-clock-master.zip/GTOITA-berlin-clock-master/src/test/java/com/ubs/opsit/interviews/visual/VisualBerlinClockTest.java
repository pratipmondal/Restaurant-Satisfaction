package com.ubs.opsit.interviews.visual;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ubs.opsit.interviews.BerlinClockService;
import com.ubs.opsit.interviews.impl.BerlinClockServiceImpl;
import com.ubs.opsit.interviews.visual.impl.VisualBerlinClockImpl;

public class VisualBerlinClockTest {

	private BerlinClockService service;

	private VisualBerlinClock visualClock;

	@Before
	public void setUp() {
		service = new BerlinClockServiceImpl();
		visualClock = new VisualBerlinClockImpl();
	}

	@Test
	public void testVisualClock() throws InterruptedException {
		String berlinClockTime = service.convertTimeToBerlinClockStandard("14:16:44");
		visualClock.createBerlinClock(berlinClockTime, visualClock);
		Thread.sleep(15*1000);
	}
	
	@Test(expected = NumberFormatException.class)
	public void testVisualClockFail() throws InterruptedException {
		String berlinClockTime = service.convertTimeToBerlinClockStandard("23:59:XX");
		visualClock.createBerlinClock(berlinClockTime, visualClock);
		Thread.sleep(15*1000);
	}

	@After
	public void tear() {
		service = null;
		visualClock = null;
	}

}
