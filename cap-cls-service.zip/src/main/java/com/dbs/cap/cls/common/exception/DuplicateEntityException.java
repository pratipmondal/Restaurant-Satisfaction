package com.dbs.cap.cls.common.exception;

public class DuplicateEntityException extends RuntimeException {
	public DuplicateEntityException(String message) {
		super(message);
	}
}
