package com.dbs.cap.cls;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@ConfigurationProperties(prefix = "api.gateway")
@Slf4j
public class ApiGatewayProperties {
	private List<Endpoint> endpoints;

	public List<Endpoint> getEndpoints() {
		return endpoints;
	}

	public void setEndpoints(List<Endpoint> endpoints) {
		this.endpoints = endpoints;
	}

	@Data
	public static class Endpoint {
		private Pattern path;
		private String url;

		public boolean match(String requestUri) {
			Matcher matcher = path.matcher(requestUri);
			if (matcher.find()) {
				String restOfUri = requestUri.substring(matcher.end());
				if (restOfUri.length() == 0 || restOfUri.startsWith("/")) {
					log.debug(this.toString());
					return true;
				}
			}
			return false;
		}
	}
}
