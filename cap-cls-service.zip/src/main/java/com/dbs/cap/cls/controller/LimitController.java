package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.common.exception.DuplicateEntityException;
import com.dbs.cap.cls.common.exception.EntityNotFoundException;
import com.dbs.cap.cls.common.exception.KeyNotFoundException;
import com.dbs.cap.cls.service.LimitService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/cls/api/v1/")
@Api(value = "Services for Limits ")
public class LimitController {
	private static final String GCIN = "gcin";
	private static final String BORROWER_NAME = "borrowerName";
	private static final String APPROVAL_REF_NO = "approvalRefNo";

	private LimitService limitService;

	public LimitController(LimitService limitService) {
		this.limitService = limitService;
	}

	@GetMapping(
			path = "limit",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	@ApiOperation(value = "Get all limits")
	public List<HashMap<String, Object>> getLimits(
			@RequestParam(value = ClsConstants.FILTER) String filter)
			throws KeyNotFoundException {
		return limitService.getLimits(filter);
	}

	@PostMapping(
			path = "limit",
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	@ApiOperation(value = "Create a limitRequest")
	public HashMap<String, Object> createLimit(
			@RequestBody HashMap<String, Object> limitRequest,
			@RequestHeader(name = GCIN) String gcin,
			@RequestHeader(name = BORROWER_NAME) String borrowerName)
			throws KeyNotFoundException, DuplicateEntityException, IOException {
		return limitService.createLimit(limitRequest, gcin, borrowerName);
	}

	@PutMapping(
			path = "limit",
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	@ApiOperation(value = "Update a limitRequest")
	public HashMap<String, Object> updateLimit(
			@RequestBody HashMap<String, Object> limitRequest,
			@RequestHeader(name = GCIN) String gcin,
			@RequestHeader(name = BORROWER_NAME) String borrowerName)
			throws KeyNotFoundException, DuplicateEntityException, IOException {
		return limitService.updateLimit(limitRequest, gcin, borrowerName);
	}

	@DeleteMapping(
			path = "limit/{approvalRefNo}",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	@ApiOperation(value = "Delete a limitRequest")
	public String deleteLimit(
			@PathVariable(APPROVAL_REF_NO) String approvalRefNo)
			throws KeyNotFoundException, EntityNotFoundException {
		return limitService.deleteLimit(approvalRefNo);
	}
}
