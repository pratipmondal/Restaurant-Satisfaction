package com.dbs.cap.cls.utility;

import lombok.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class EntitySearchHeader {
	private String appName;
	private String userId;
	private String responseDateTime;
	private String language;
	private String country;
	private String serviceName;
	private String sessionToken;
	private String status;
}
