package com.dbs.cap.cls.utility;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class UploadUtility {
	public static String convertExcelToJson(MultipartFile multipartFile) throws RuntimeException {
		JSONArray payLoad = new JSONArray();
		try {
			BufferedInputStream excelFile = new BufferedInputStream(multipartFile.getInputStream());
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			List<String> columnNameList = new ArrayList<String>();
			JSONObject dtoObj = null;
			for (int i = 0; i <= datatypeSheet.getLastRowNum(); i++) {
				Row currentRow = datatypeSheet.getRow(i);
				if (i == 0) {
					for (int j = 0; j < currentRow.getLastCellNum(); j++) {
						columnNameList.add(currentRow.getCell(j).getStringCellValue());
					}
				} else {
					dtoObj = new JSONObject();
					for (int j = 0; j < currentRow.getLastCellNum(); j++) {
						if (currentRow.getCell(j).getCellType() == Cell.CELL_TYPE_NUMERIC) {
							dtoObj.put(columnNameList.get(j), currentRow.getCell(j).getNumericCellValue());
						} else if (currentRow.getCell(j).getCellType() == Cell.CELL_TYPE_STRING) {
							dtoObj.put(columnNameList.get(j), currentRow.getCell(j).getStringCellValue());
						} else if (currentRow.getCell(j).getCellType() == Cell.CELL_TYPE_BOOLEAN) {
							dtoObj.put(columnNameList.get(j), currentRow.getCell(j).getBooleanCellValue());
						}
					}
					payLoad.put(dtoObj);
				}
			}
		} catch (IOException e) {
			log.error("IO Exception while converting to Json", e);
			throw new RuntimeException("Unable to parse Json");
		}
		return payLoad.toString();
	}
}
