package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.client.EntitySearchClient;
import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.dto.CounterParty;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/cls/api/v1/")
@Api(value = "Service for Customer")
@Slf4j
public class CustomerController {
	private static final String COUNTER_PARTY = "COUNTERPARTY";

	private EntitySearchClient entitySearchClient;

	public CustomerController(EntitySearchClient entitySearchClient) {
		this.entitySearchClient = entitySearchClient;
	}

	@PostMapping(
			path = "/customer/search/",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiOperation(value = "Search Customer Information")
	public List<CounterParty> searchCustomer(
			@RequestBody String query,
			@RequestHeader(ClsConstants.AUTHORIZATION) String authToken) {
		return entitySearchClient.searchByKeyword(query, authToken)
				.getSearchResult()
				.getGroupResults()
				.stream()
				.filter(result -> COUNTER_PARTY.equalsIgnoreCase(result.getGroupName()))
				.flatMap(result -> result.getEntities().stream())
				.map(entity -> new CounterParty(entity.getLabel(),
						entity.getValue(),
						COUNTER_PARTY,
						COUNTER_PARTY))
				.collect(Collectors.toList());

	}
}
