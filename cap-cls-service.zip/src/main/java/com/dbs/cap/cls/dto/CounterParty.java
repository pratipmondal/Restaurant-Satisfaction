package com.dbs.cap.cls.dto;

import lombok.Value;

@Value
public class CounterParty {
	private String description;
	private String gcin;
	private String type;
	private String typeDescription;
}
