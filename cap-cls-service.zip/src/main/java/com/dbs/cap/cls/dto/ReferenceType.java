package com.dbs.cap.cls.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Getter
@Setter
@Builder
@JsonInclude(NON_NULL)
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReferenceType implements Comparable<ReferenceType> {
	@JsonProperty(value = "name")
	private String name;
	@JsonProperty(value = "plural")
	private String plural;

	@Override
	public int compareTo(ReferenceType referenceType) {
		return this.name.toLowerCase().compareTo(referenceType.getName().toLowerCase());
	}
}

