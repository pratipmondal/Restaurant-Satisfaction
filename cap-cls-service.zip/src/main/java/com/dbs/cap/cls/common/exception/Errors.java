package com.dbs.cap.cls.common.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Errors {
	private String code;
	private String message;
	private boolean retriable;
	private String path;
}
