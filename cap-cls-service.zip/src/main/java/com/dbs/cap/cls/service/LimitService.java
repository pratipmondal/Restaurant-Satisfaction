package com.dbs.cap.cls.service;

import com.dbs.cap.cls.client.LimitClient;
import com.dbs.cap.cls.client.LimitCustomerClient;
import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.common.exception.DuplicateEntityException;
import com.dbs.cap.cls.common.exception.EntityLinkageException;
import com.dbs.cap.cls.common.exception.EntityNotFoundException;
import com.dbs.cap.cls.common.exception.KeyNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
@Slf4j
public class LimitService {
	private static final String LIMIT_ID = "limitId";
	private static final String CUSTOMER_ENTITY_TYPE = "CUST";
	private static final String APPROVAL_REF_NO = "approvalRefNo";
	private static final String VERSION = "_version";
	private static final String ACTIVATED_LIMIT = "activatedLimit";
	private static final String ACTIVATED_DATE = "activatedDate";
	private static final String SOURCE_SYSTEM = "sourceSystem";
	private static final String ROW_STATUS = "__row_status";
	private static final String ADDED = "added";
	private static final String MODIFIED = "modified";
	private static final String DELETED = "deleted";
	private static final String ACCOUNTS_LINKAGE = "accounts";
	private static final String SOURCE_SYSTEM_ANSP = "ANSP";
	private static final String SOURCE_SYSTEM_CASP = "CASP";
	private static final String SOURCE_SYSTEM_IMEX = "IMEX";
	private static final String WFSTATUS = "wfStatus";
	private static final String WFSTATUS_FINAL = "FINAL";
	private static final String FILTER_QUERY_LIMIT_ID =
			"{\"where\":{\"limitId\": \"{id}\"},\"include\": {\"relation\": \"accounts\"}}";
	private static final String FILTER_QUERY =
			"{\"where\":{\"approvalRefNo\": \"{id}\"},\"include\": {\"relation\": \"accounts\"}}";
	private static final String ID = "{id}";
	private static final String ENTITY_ID = "entityId";
	private static final String ENTITY_TYPE = "entityType";
	private static final String ENTITY_NAME = "entityName";
	private static final String CUSTOMER_ID = "customerId";

	private LimitClient limitClient;
	private LimitCustomerClient limitCustomerClient;

	public LimitService(LimitClient limitClient, LimitCustomerClient limitCustomerClient) {
		this.limitClient = limitClient;
		this.limitCustomerClient = limitCustomerClient;
	}

	public HashMap<String, Object> createLimit(
			HashMap<String, Object> limitRequest,
			String gcin,
			String borrowerName)
			throws KeyNotFoundException, DuplicateEntityException, IOException {
		log.debug("Limit request (POST) {}", limitRequest);

		//Throw exception if approvalRefNo is missing
		String approvalRefNo = limitRequest.get(APPROVAL_REF_NO) == null ? null :
				(String) limitRequest.get(APPROVAL_REF_NO);
		if (StringUtils.isEmpty(approvalRefNo)) {
			throw new KeyNotFoundException("ApprovalRefNo is required for limit creation.");
		}

		//Throw exception if duplicate limit found with this approvalRefNo
		List<HashMap<String, Object>> getLimitResponse = getLimitById(approvalRefNo);
		if (CollectionUtils.isNotEmpty(getLimitResponse)) {
			throw new DuplicateEntityException("Duplicate limit found with this approvalRefNo - " +
					approvalRefNo);
		}

		//Create customer before limit creation
		createCustomer(gcin, borrowerName);
		//Create the limit
		HashMap<String, Object> limitResponse = limitClient.createLimit(limitRequest);
		log.debug("Limit response (POST) {}", limitResponse);
		return limitResponse;
	}

	private List<HashMap<String, Object>> getLimitById(String approvalRefNo) {
		return limitClient.getLimits(FILTER_QUERY.replace(ID, approvalRefNo));
	}

	private List<HashMap<String, Object>> getLimitBylimitId(String limitId) {
		return limitClient.getLimits(FILTER_QUERY_LIMIT_ID.replace(ID, limitId));
	}

	private void createCustomer(String gcin, String borrowerName) {
		try {
			HashMap<String, String> customerMap = new HashMap<>();
			customerMap.put(ENTITY_ID, gcin);
			customerMap.put(ENTITY_TYPE, CUSTOMER_ENTITY_TYPE);
			customerMap.put(ENTITY_NAME, borrowerName);
			limitCustomerClient.createCustomer(customerMap);
		} catch (RuntimeException e) {
			log.warn("Customer already exist", e);
		}
	}

	public List<HashMap<String, Object>> getLimits(String filter) throws KeyNotFoundException {
		if (StringUtils.isEmpty(filter)) {
			throw new KeyNotFoundException("Filter is required.");
		}
		log.debug("Get limit filter {}", filter);
		List<HashMap<String, Object>> response = limitClient.getLimits(filter);
		if (CollectionUtils.isEmpty(response)) {
			log.debug("Get limit -  No matching limit found for this filter criteria");
			throw new KeyNotFoundException("No matching limit found for this filter criteria - " + filter);
		}
		return response;
	}

	public HashMap<String, Object> updateLimit(HashMap<String, Object> limitRequest, String gcin, String
			borrowerName) throws
			KeyNotFoundException, DuplicateEntityException, IOException, EntityLinkageException {
		log.debug("Limit request (PUT) {}", limitRequest);
		List<HashMap<String, Object>> limitResponse = null;

		String approvalRefNo = limitRequest.get(APPROVAL_REF_NO) == null ? null :
				(String) limitRequest.get(APPROVAL_REF_NO);
		String limitId = limitRequest.get(LIMIT_ID) == null ? null :
				(String) limitRequest.get(LIMIT_ID);

		if (StringUtils.isNotEmpty(approvalRefNo)) {
			limitResponse = getLimitById(approvalRefNo);
		} else if (StringUtils.isEmpty(approvalRefNo) && StringUtils.isNotEmpty(limitId)) {
			// If FIG Limit ID is not sent but CLS limit id is sent
			limitResponse = getLimitBylimitId(limitId);
		} else if (StringUtils.isEmpty(approvalRefNo) && StringUtils.isEmpty(limitId)) {
			// If both FIG & CLS LimitId are not sent
			throw new KeyNotFoundException("ApprovalRefNo or limitId is required for limit update.");
		}
		log.debug("Limit response (PUT) {}", limitResponse);
		if (CollectionUtils.isEmpty(limitResponse)) {
			// If FIG limit ID is sent but we don’t find any limit in CLS
			return createLimit(limitRequest, gcin, borrowerName);
		} else {
			if (limitResponse.size() > 1) {
				throw new DuplicateEntityException("Multiple limits found with this approvalRefNo - " +
						approvalRefNo);
			}
			HashMap<String, Object> getLimitResponse = limitResponse.get(0);

			limitRequest.put(ClsConstants.ID, getLimitResponse.get(ClsConstants.ID));
			limitRequest.put(VERSION, getLimitResponse.get(VERSION));
			limitRequest.put(LIMIT_ID, getLimitResponse.get(LIMIT_ID));
			limitRequest.put(ACTIVATED_LIMIT, getLimitResponse.get(ACTIVATED_LIMIT));
			limitRequest.put(ACTIVATED_DATE, getLimitResponse.get(ACTIVATED_DATE));
			limitRequest.put(WFSTATUS, WFSTATUS_FINAL);

			modifyEntityLinkage(limitRequest, getLimitResponse);
		}
		log.debug("Limit request EV (PUT) {}", limitRequest);
		HashMap<String, Object> updateLimit = limitClient.updateLimit(limitRequest);
		log.debug("Limit response EV (PUT) {}", updateLimit);
		return updateLimit;
	}

	@SuppressWarnings("unchecked")
	private void modifyEntityLinkage(HashMap<String, Object> limitRequest, HashMap<String, Object> getLimitResponse)
			throws EntityLinkageException {
		try {
			List<HashMap<String, Object>> accountsRequestList =
					(List<HashMap<String, Object>>) limitRequest.get(ACCOUNTS_LINKAGE);

			List<HashMap<String, Object>> accountsResponseList =
					(List<HashMap<String, Object>>) getLimitResponse.get(ACCOUNTS_LINKAGE);

			if (CollectionUtils.isNotEmpty(accountsRequestList)) {
				for (HashMap<String, Object> accountRequest : accountsRequestList) {
					boolean matchFound = false;
					accountRequest.put(CUSTOMER_ID, getLimitResponse.get(CUSTOMER_ID));
					if (CollectionUtils.isNotEmpty(accountsResponseList)) {
						for (HashMap<String, Object> accountResponse : accountsResponseList) {
							if (StringUtils.equals((String) accountRequest.get(ENTITY_ID),
									(String) accountResponse.get(ENTITY_ID))
									&& StringUtils.equals((String) accountRequest.get(SOURCE_SYSTEM),
									(String) accountResponse.get(SOURCE_SYSTEM))) {
								//modification case
								matchFound = true;
								accountRequest.put(ClsConstants.ID, accountResponse.get(ClsConstants.ID));
								accountRequest.put(LIMIT_ID, accountResponse.get(LIMIT_ID));
								accountRequest.put(VERSION, accountResponse.get(VERSION));
								accountRequest.put(ROW_STATUS, MODIFIED);
								accountsResponseList.remove(accountResponse);
								break;
							}
						}
					}
					if (!matchFound) accountRequest.put(ROW_STATUS, ADDED);
				}
				if (CollectionUtils.isNotEmpty(accountsResponseList)) {
					changeRowStatusToDeleted(accountsRequestList, accountsResponseList);
				}
			} else {
				if (CollectionUtils.isNotEmpty(accountsResponseList)) {
					accountsRequestList = new ArrayList<>();
					changeRowStatusToDeleted(accountsRequestList, accountsResponseList);
					limitRequest.put(ACCOUNTS_LINKAGE, accountsRequestList);
				}
			}
		} catch (Exception e) {
			log.error("Exception during modifyEntityLinkage() - ", e);
			throw new EntityLinkageException("Exception during modifyEntityLinkage");
		}
	}

	private void changeRowStatusToDeleted(List<HashMap<String, Object>> accountsRequestList,
	                                      List<HashMap<String, Object>> accountsResponseList) {
		for (HashMap<String, Object> accountResponse : accountsResponseList) {
			if (StringUtils.equals((String) accountResponse.get(SOURCE_SYSTEM), SOURCE_SYSTEM_ANSP)
					|| StringUtils.equals((String) accountResponse.get(SOURCE_SYSTEM), SOURCE_SYSTEM_CASP)
					|| StringUtils.equals((String) accountResponse.get(SOURCE_SYSTEM), SOURCE_SYSTEM_IMEX)) {
				accountResponse.put(ROW_STATUS, DELETED);
				accountsRequestList.add(accountResponse);
			}
		}
	}

	public String deleteLimit(String approvalRefNo)
			throws KeyNotFoundException, EntityNotFoundException {
		//Throw exception if approvalRefNo is missing
		if (StringUtils.isEmpty(approvalRefNo)) {
			throw new KeyNotFoundException("ApprovalRefNo is required for limit delete.");
		}
		log.debug("Delete limit approval ref no {}", approvalRefNo);

		//Throw exception if duplicate limit found with this approvalRefNo
		List<HashMap<String, Object>> limitResponse = getLimitById(approvalRefNo);
		String deleteResponse;

		if (CollectionUtils.isNotEmpty(limitResponse)) {
			deleteResponse = limitClient.deleteLimit((String) limitResponse.get(0).get(ClsConstants.ID));
			log.debug("Successfully deleted limit {}", deleteResponse);
		} else {
			throw new EntityNotFoundException("Limit not found for this approvalRefNo - " + approvalRefNo);
		}
		return deleteResponse;
	}
}
