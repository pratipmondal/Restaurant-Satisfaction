package com.dbs.cap.cls.common.configuration;

import com.dbs.cap.cls.common.service.JWTTokenService;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class FeignRequestInterceptor implements RequestInterceptor {
	private JWTTokenService jwtTokenService;

	public FeignRequestInterceptor(JWTTokenService jwtTokenService) {
		this.jwtTokenService = jwtTokenService;
	}

	@Override
	public void apply(RequestTemplate template) {
		try {
			template.headers(jwtTokenService.getRequestHeaders());
		} catch (Exception e) {
			log.error("Exception while calling EV Service", e);
		}
	}
}
