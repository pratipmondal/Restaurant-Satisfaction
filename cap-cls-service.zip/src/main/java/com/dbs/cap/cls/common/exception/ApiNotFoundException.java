package com.dbs.cap.cls.common.exception;

public class ApiNotFoundException extends RuntimeException {
	public ApiNotFoundException(String message) {
		super(message);
	}
}
