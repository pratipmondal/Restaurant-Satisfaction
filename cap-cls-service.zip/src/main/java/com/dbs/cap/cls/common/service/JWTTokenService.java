package com.dbs.cap.cls.common.service;

import com.dbs.cap.cls.common.constants.ClsConstants;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.text.SimpleDateFormat;
import java.util.*;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Service
public class JWTTokenService {
	private RestTemplate restTemplate;

	@Value("${cls.user}")
	private String CLS_USER;
	@Value("${cls.user.email}")
	private String CLS_USER_EMAIL;
	@Value("${cls.user.roles}")
	private String CLS_USER_ROLES;
	@Value("${cls.channel.id}")
	private String CLS_CHANNEL_ID;
	@Value("${security.oauth2.client.client-id}")
	private String clientId;
	@Value("${security.oauth2.client.client-secret}")
	private String clientSecret;
	@Value("${security.oauth2.client.access-token-uri}")
	private String TOKEN_REQUEST_URL;
	private Date tokenCreationTime;
	private long expiresInSec;
	private String jwtValue;

	public JWTTokenService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	private static String base64Encode(byte[] bytes) {
		return new String(Base64.getEncoder().encode(bytes));
	}

	private String callOAuthServer() {
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		headers.set(AUTHORIZATION, "Basic " + base64Encode((clientId + ":" + clientSecret).getBytes()));

		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());

		HttpEntity<?> entity = new HttpEntity<>(null, headers);
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(TOKEN_REQUEST_URL)
				.queryParam("grant_type", "client_credentials")
				.queryParam("response_type", "token");
		String json = restTemplate.postForObject(builder.toUriString(), entity, String.class);

		JSONObject response = new JSONObject(json);
		jwtValue = (String) response.get(ClsConstants.ACCESS_TOKEN);
		expiresInSec = Long.valueOf((Integer) response.get("expires_in"));
		tokenCreationTime = new Date();
		return jwtValue;
	}

	private String getClientToken() {
		if (StringUtils.isEmpty(jwtValue)) {
			jwtValue = callOAuthServer();
			return jwtValue;
		} else if (new Date().getTime() - tokenCreationTime.getTime() >= (expiresInSec - 100) * 1000) {
			jwtValue = callOAuthServer();
			return jwtValue;
		}
		return jwtValue;
	}

	public Map<String, Collection<String>> getRequestHeaders() {
		Map<String, Collection<String>> headersMap = new HashMap<>();
		headersMap.put("x-request-id", Collections.singletonList(UUID.randomUUID().toString()));
		headersMap.put("username", Collections.singletonList(CLS_USER));
		headersMap.put("email", Collections.singletonList(CLS_USER_EMAIL));
		headersMap.put("roles", Collections.singletonList(CLS_USER_ROLES));
		headersMap.put("channel_id", Collections.singletonList(CLS_CHANNEL_ID));
		headersMap.put("timestamp", Collections.singletonList(
				new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSz").format(new java.util.Date())));
		headersMap.put(ClsConstants.X_JWT_ASSERTION, Collections.singletonList(getClientToken()));
		return headersMap;
	}
}
