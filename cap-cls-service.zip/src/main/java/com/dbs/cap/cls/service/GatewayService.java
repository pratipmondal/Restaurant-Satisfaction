package com.dbs.cap.cls.service;

import com.dbs.cap.cls.ApiGatewayProperties;
import com.dbs.cap.cls.common.exception.ApiNotFoundException;
import com.dbs.cap.cls.common.service.JWTTokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class GatewayService {
	private ApiGatewayProperties apiGatewayProperties;
	private RestTemplate restTemplate;
	private JWTTokenService jwtTokenService;

	public GatewayService(ApiGatewayProperties apiGatewayProperties, RestTemplate restTemplate, JWTTokenService
			jwtTokenService) {
		this.apiGatewayProperties = apiGatewayProperties;
		this.restTemplate = restTemplate;
		this.jwtTokenService = jwtTokenService;
	}

	public String execute(URI uri, HttpMethod method,
	                      Object body, MultiValueMap<String, String> headers) {
		HttpEntity<?> httpEntity = new HttpEntity<>(body, getHeaders(headers));
		ResponseEntity<String> response =
				restTemplate.exchange(uri, method, httpEntity, String.class);
		return response.getBody();
	}

	public URI getServiceUri(RequestEntity<Object> request)
			throws ApiNotFoundException, UnsupportedEncodingException, URISyntaxException {
		log.debug("getServiceUri request URL -{}", request.getUrl());

		String path = request.getUrl().getPath();

		ApiGatewayProperties.Endpoint endpoints = getEndpoint(path);

		String sb = endpoints.getUrl() +
				path.replace(endpoints.getPath().toString(), "");

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(sb);
		builder.query(request.getUrl().getQuery());

		log.debug("getServiceUri Resolved URI -{}", builder.toUriString());

		return builder.build().toUri();
	}

	private ApiGatewayProperties.Endpoint getEndpoint(String requestUri)
			throws ApiNotFoundException, UnsupportedEncodingException, URISyntaxException {
		ApiGatewayProperties.Endpoint endpoints =
				apiGatewayProperties.getEndpoints().stream()
						.filter(e -> e.match(requestUri))
						.findFirst()
						.orElseThrow(() -> new ApiNotFoundException("getEndpoint API -" +
								requestUri));

		log.debug("getEndpoint endpoint -{}", endpoints.toString());
		return endpoints;
	}

	private MultiValueMap<String, String> getHeaders(MultiValueMap<String, String> headers) {
		MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
		if (!CollectionUtils.isEmpty(headers)) {
			headers.forEach((k, v) -> {
				if (!k.matches("(?i)host|(?i)connection|(?i)cache-control|" +
						"(?i)user-agent|(?i)postman-token|(?i)accept|(?i)accept-encoding|(?i)accept-language")) {
					headersMap.set(k, v.get(0));
				}
			});
		}

		populateHeaders(headersMap);

		return headersMap;
	}

	private void populateHeaders(MultiValueMap<String, String> headersMap) {
		Map<String, Collection<String>> requestHeaders = jwtTokenService.getRequestHeaders();
		if (!CollectionUtils.isEmpty(requestHeaders)) {
			requestHeaders.forEach((k, v) -> headersMap.set(k, ((List) v).get(0).toString()));
		}
	}
}
