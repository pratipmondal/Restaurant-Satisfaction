package com.dbs.cap.cls.common.constants;

public class ClsConstants {
	public static final String ID = "id";
	public static final String FILTER = "filter";
	public static final String ACCESS_TOKEN = "access_token";
	public static final String X_JWT_ASSERTION = "x-jwt-assertion";
	public static final String CLIENT_ID = "client1";
	public static final String AUTHORIZATION = "Authorization";
}
