package com.dbs.cap.cls.common.configuration;

import com.dbs.cap.cls.common.exception.FeignClientException;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class FeignClientDecoder implements ErrorDecoder {
	@Override
	public Exception decode(String methodKey, Response response) {
		String responseBody = "";
		try {
			if (response.body() != null) {
				responseBody = new String(IOUtils.toByteArray(response.body().asInputStream()));
			} else {
				responseBody = new JSONObject().put("error", response.reason()).toString();
			}
		} catch (IOException e) {
			log.error("Error during Error decoding");
		}
		return new FeignClientException(responseBody, response.status());
	}
}