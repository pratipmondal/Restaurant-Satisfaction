package com.dbs.cap.cls.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dbs.cap.cls.common.constants.ClsConstants;

import java.util.HashMap;
import java.util.List;

@FeignClient(
		name = "LimitClient",
		url = "${ev.limit.service.host}")
public interface LimitClient {
	@RequestMapping(
			path = "/api/Limits",
			method = RequestMethod.GET)
	List<HashMap<String, Object>> getLimits(
			@RequestParam(ClsConstants.FILTER) String filter);

	@RequestMapping(
			path = "/api/Limits/{id}",
			method = RequestMethod.GET)
	ResponseEntity<Object> getLimitById(
			@PathVariable(ClsConstants.ID) String id);

	@RequestMapping(
			path = "/api/Limits",
			method = RequestMethod.POST)
	HashMap<String, Object> createLimit(
			@RequestBody Object limitRequest);

	@RequestMapping(
			path = "/api/Limits",
			method = RequestMethod.PUT)
	HashMap<String, Object> updateLimit(
			@RequestBody Object limitRequest);

	@RequestMapping(
			path = "/api/Limits/{id}",
			method = RequestMethod.DELETE)
	String deleteLimit(
			@PathVariable(ClsConstants.ID) String id);
}


