package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.client.ReferenceDataCollateralClient;
import com.dbs.cap.cls.client.ReferenceDataLimitClient;
import com.dbs.cap.cls.common.constants.ClsConstants;
import com.dbs.cap.cls.utility.UploadUtility;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/cls/api/v1")
@Api(value = "Model to get reference Data (CLS)")
public class ReferenceDataController {
	private static final String NAME = "name";
	private static final String PLURAL = "plural";
	private ReferenceDataLimitClient referenceDataLimitClient;
	private ReferenceDataCollateralClient referenceDataCollateralClient;

	public ReferenceDataController(ReferenceDataLimitClient referenceDataLimitClient,
	                               ReferenceDataCollateralClient referenceDataCollateralClient) {
		this.referenceDataLimitClient = referenceDataLimitClient;
		this.referenceDataCollateralClient = referenceDataCollateralClient;
	}

	@PostMapping(
			path = "/limit/model/bulk/{referenceType}",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiOperation(value = "Create bulk reference data for limit")
	public ResponseEntity<Object> createLimitReferenceData(
			@PathVariable("referenceType") String referenceType,
			@RequestParam("file") MultipartFile file) {
		if (file.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else {
			return referenceDataLimitClient.createReferenceData(referenceType,
					UploadUtility.convertExcelToJson(file));
		}
	}

	@PostMapping(
			path = "/collateral/model/bulk/{referenceType}",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiOperation(value = "Create bulk reference data for collateral")
	public ResponseEntity<Object> createCollateralReferenceData(
			@PathVariable("referenceType") String referenceType,
			@RequestParam("file") MultipartFile file) {
		if (file.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else {
			return referenceDataCollateralClient.createReferenceData(referenceType,
					UploadUtility.convertExcelToJson(file));
		}
	}

	@SuppressWarnings("serial")
	@GetMapping(
			path = "/limit/reference-type",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public List<HashMap<String, Object>> getLimitReferenceTypes(
			@RequestParam(value = ClsConstants.FILTER) String filter) {
		List<HashMap<String, Object>> limitList = referenceDataLimitClient.getAllReferenceType(filter);
		return limitList.parallelStream()
				.collect(ArrayList<HashMap<String, Object>>::new,
						(s, map) -> s.add(new HashMap<String, Object>() {{
							put(NAME, map.get(NAME));
							put(PLURAL, map.get(PLURAL));
						}}), List::addAll);
	}

	@SuppressWarnings("serial")
	@GetMapping(
			path = "/collateral/reference-type",
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public List<HashMap<String, Object>> getCollateralReferenceTypes(
			@RequestParam(value = ClsConstants.FILTER) String filter) {
		List<HashMap<String, Object>> collateralList = referenceDataCollateralClient.getAllReferenceType(filter);
		return collateralList.parallelStream()
				.collect(ArrayList<HashMap<String, Object>>::new,
						(s, map) -> s.add(new HashMap<String, Object>() {{
							put(NAME, map.get(NAME));
							put(PLURAL, map.get(PLURAL));
						}}), List::addAll);
	}
}
