package com.dbs.cap.cls.common.exception;

public class KeyNotFoundException extends RuntimeException {
	public KeyNotFoundException(String message) {
		super(message);
	}
}
