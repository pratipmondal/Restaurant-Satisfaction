package com.dbs.cap.cls.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(
		name = "LimitCustomerClient",
		url = "${ev.limit.service.host}")
public interface LimitCustomerClient {

	@RequestMapping(
			path = "/api/Customers",
			method = RequestMethod.POST)
	void createCustomer(
			@RequestBody Object customer);
}
