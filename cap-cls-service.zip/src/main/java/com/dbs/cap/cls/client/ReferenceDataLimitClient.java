package com.dbs.cap.cls.client;

import com.dbs.cap.cls.common.configuration.ClientConfiguration;
import com.dbs.cap.cls.common.constants.ClsConstants;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;

@FeignClient(
		name = "ReferenceDataLimitClient",
		url = "${ev.limit.service.host}",
		configuration = ClientConfiguration.class
)
public interface ReferenceDataLimitClient {
	@RequestMapping(
			path = "/api/{refType}",
			method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE
	)
	ResponseEntity<Object> createReferenceData(
			@RequestParam("refType") String refType,
			@RequestBody String refTypeRequest);

	@RequestMapping(
			path = "/api/ModelDefinitions",
			method = RequestMethod.GET,
			consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	List<HashMap<String,Object>> getAllReferenceType(
			@RequestParam(value=(ClsConstants.FILTER)) String filter);
}