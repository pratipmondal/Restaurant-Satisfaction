package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.stubbing.StubMapping;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
public class GatewayControllerTest extends BaseMockMvcWiremockIntegrationTest {
	@Autowired
	private OAuth2TestHelper oauthHelper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
				"{\"access_token\":\"token1234\",\"expires_in\":28776}");
	}

	@Test
	public void test_get_reference_data() throws Exception {
		mockResponse(WireMock.get(WireMock.urlMatching("^/api/Countrys.*")),
				null);
		MockHttpServletRequestBuilder getCountrys = get("/cls/api/v1/limit/model/Countrys?filter=test")
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
		mvc.perform(getCountrys.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
				.andExpect(status().isOk());
	}
}