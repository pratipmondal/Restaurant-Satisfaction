package com.dbs.cap.cls.common.test;

import com.dbs.cap.cls.common.io.ResourceFileReader;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.junit.WireMockClassRule;
import org.junit.ClassRule;
import org.junit.Ignore;
import org.junit.experimental.categories.Category;
import org.springframework.http.MediaType;

import java.io.IOException;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;

@Category(IntegrationTest.class)
@Ignore
public class BaseMockMvcWiremockIntegrationTest extends BaseMockMvcIntegrationTest {
	@ClassRule
	public static WireMockClassRule wireMockRule = new WireMockClassRule(3269);

	public void mockResponse(MappingBuilder request, String body) throws IOException {
		mockResponse(request, body, MediaType.APPLICATION_JSON_UTF8_VALUE);
	}

	public void mockResponse(MappingBuilder request, String body, String mediaType) throws IOException {
		wireMockRule.stubFor(
				request.willReturn(
						aResponse()
								.withStatus(200)
								.withHeader("Content-Type", mediaType)
								.withBody(body)
				)
		);
	}

	public void mockResponseFromFile(MappingBuilder request, String filename) throws IOException {
		mockResponseFromFile(request, filename, MediaType.APPLICATION_JSON_UTF8_VALUE);
	}

	public void mockResponseFromFile(MappingBuilder request, String filename, String mediaType) throws IOException {
		mockResponse(request, ResourceFileReader.readResourceFileToString(filename), mediaType);
	}
}
