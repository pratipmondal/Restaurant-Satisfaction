package com.dbs.cap.cls.controller;

import com.dbs.cap.cls.common.oauth.OAuth2TestHelper;
import com.dbs.cap.cls.common.test.IntegrationTest;
import com.dbs.cap.cls.common.test.BaseMockMvcWiremockIntegrationTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Category(IntegrationTest.class)
@ActiveProfiles("test")
@WithMockUser
@Ignore
public class CustomerControllerTest extends BaseMockMvcWiremockIntegrationTest {
	@Autowired
	OAuth2TestHelper oauthHelper;

	@Before
	public void setup() throws Exception {
		mockResponse(WireMock.post(WireMock.urlMatching("^/oauth/token.*")),
				"{\"access_token\":\"token1234\",\"expires_in\":28776}");
	}
	@Test
	public void post_search_entity() throws Exception {
		mockResponse(WireMock.post(WireMock.urlMatching("^/cap-entitysearch/search/.*")),
				null, MediaType.APPLICATION_JSON_UTF8_VALUE);
		mvc.perform(post("/cls/api/v1/entity/search/")
				.content("{ \"searchKeyword\": \"183105\" }")
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
				.with(oauthHelper.addBearerToken("user", "ROLE_USER")))
				.andExpect(status().isOk());
	}
}

