package com.dbs.cap.cls;

import com.dbs.cap.cls.common.test.UnitTest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import java.util.Collections;
import java.util.regex.Pattern;

@Category(UnitTest.class)
public class ApiGatewayPropertiesTest {

	private ApiGatewayProperties apiGatewayProperties;
	private ApiGatewayProperties.Endpoint endpoint;

	@Before
	public void setUp() {
		apiGatewayProperties = new ApiGatewayProperties();
		endpoint = new ApiGatewayProperties.Endpoint();
		endpoint.setPath(Pattern.compile("/cls/api/v1/test"));
		endpoint.setUrl("/api/Test");
	}

	@Test
	public void setEndpoints() throws Exception {
		apiGatewayProperties.setEndpoints(Collections.singletonList(endpoint));
		Assert.assertNotNull(apiGatewayProperties.getEndpoints());
	}

	@Test
	public void test_match_true() {
		Assert.assertTrue(endpoint.match("http://localhost:8080/cls/api/v1/test"));
	}

	@Test
	public void test_match_false() {
		Assert.assertFalse(endpoint.match("http://localhost:8080/cls/api/v1/testing"));
	}

}
