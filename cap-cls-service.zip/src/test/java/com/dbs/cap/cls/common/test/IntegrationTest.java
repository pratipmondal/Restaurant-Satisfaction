package com.dbs.cap.cls.common.test;

public interface IntegrationTest extends LocalTests {
}
