package com.dbs.cap.cls.common.oauth;

import com.dbs.cap.cls.common.constants.ClsConstants;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;
import org.springframework.stereotype.Component;
import org.springframework.test.web.servlet.request.RequestPostProcessor;

@Component
public class OAuth2TestHelper {
	private AuthorizationServerTokenServices tokenService;

	public OAuth2TestHelper(AuthorizationServerTokenServices tokenService) {
		this.tokenService = tokenService;
	}

	public RequestPostProcessor addBearerToken(String username, String... authorities) {
		return mockRequest -> {
			// Create OAuth2 token
			OAuth2Request oauth2Request =
					new OAuth2Request(null,
							ClsConstants.CLIENT_ID, null, true, null, null,
							null, null, null);
			Authentication userauth = new TestingAuthenticationToken(username, null, authorities);
			OAuth2Authentication oauth2auth = new OAuth2Authentication(oauth2Request, userauth);
			OAuth2AccessToken token = tokenService.createAccessToken(oauth2auth);
			// Set Authorization header to use Bearer
			mockRequest.addHeader(ClsConstants.AUTHORIZATION, "Bearer " + token.getValue());
			return mockRequest;
		};
	}
}
