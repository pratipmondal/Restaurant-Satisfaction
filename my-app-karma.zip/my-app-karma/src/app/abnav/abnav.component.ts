import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'ab-nav',
    templateUrl: 'abnav.template.html'
})

export class ABNavComponent implements OnInit{
  username: string;

  ngOnInit(){
    this.username = localStorage.getItem('username');
  }
  
  logout(){
    localStorage.clear();
  }

}
