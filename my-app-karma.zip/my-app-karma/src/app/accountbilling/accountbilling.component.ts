import { BillingDetail } from './billingDetail';
import { BillingDetailService } from './billingDetail.service';
import { ABNavComponent } from '../abnav/abnav.component';
import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';

@Component({
    moduleId: module.id,
    templateUrl: 'accountbilling.template2.html'
})

export class AccountBillingComponent extends ABNavComponent implements OnInit{
  
  billingDetailList: BillingDetail[];
  billingFullDetailList: BillingDetail[];
  tab1Visible: boolean = true;
  tab2Visible: boolean = false;
  usageVisible: boolean = false;
  
  constructor(private _billingService: BillingDetailService, private changeDetectorRef: ChangeDetectorRef) {
    super();
    
  }
  
  key: string = 'dateOfTransaction';
  reverse: boolean = false;
  sort(key: string){
      this.key = key;
      this.reverse = !this.reverse;
  }
  
	ngOnInit(){
      //console.log("tab1Data = "+this._billingService.getTab1Data());
      //this.billingDetailList = this._billingService.getTab1Data();
      //this.billingFullDetailList = this._billingService.getTab2Data();
    this._billingService.loaddata().subscribe(data => {
            this.billingDetailList = data;
    })
    
    //this._billingService.loadFullData().subscribe(data => {
      //      this.billingFullDetailList = data;
    //})
  }
  
  makeVisibleTab1(){
    this.tab1Visible = true;
    this.tab2Visible = false;
  }
  
  makeVisibleTab2(){
    this.tab2Visible = true;
    this.tab1Visible = false;
  }
  
  showHideUsage(){
    if(this.usageVisible){
      this.usageVisible = false;
      return;
    }
    if(!this.usageVisible){
      this.usageVisible = true;
      return;
    }
  }

}
