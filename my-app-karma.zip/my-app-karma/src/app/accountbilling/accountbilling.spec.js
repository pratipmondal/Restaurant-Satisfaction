"use strict";
var testing_1 = require("@angular/core/testing");
require("rxjs/Rx");
var Rx_1 = require("rxjs/Rx");
var billingDetail_stub_1 = require("./billingDetail.stub");
var tab1_data_1 = require("./tab1.data");
var accountbilling_component_1 = require("./accountbilling.component");
var billingDetail_service_1 = require("./billingDetail.service");
describe('BillingDetail Component', function () {
    var comp;
    var fixture;
    var dataStub;
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [accountbilling_component_1.AccountBillingComponent]
        }).overrideComponent(accountbilling_component_1.AccountBillingComponent, {
            set: {
                providers: [
                    {
                        provide: billingDetail_service_1.BillingDetailService,
                        useClass: billingDetail_stub_1.BillingDetailStub
                    },
                ]
            }
        }).compileComponents()
            .then(function () {
            fixture = testing_1.TestBed.createComponent(accountbilling_component_1.AccountBillingComponent);
            comp = fixture.componentInstance;
            dataStub = fixture.debugElement.injector.get(billingDetail_service_1.BillingDetailService);
        });
    }));
    it('should resolve test data', testing_1.fakeAsync(function () {
        var spy = spyOn(dataStub, 'loaddata').and.returnValue(Rx_1.Observable.of(tab1_data_1.TAB1_ITEMS));
        comp.ngOnInit();
        fixture.detectChanges();
        expect(comp.billingDetailList).toEqual(tab1_data_1.TAB1_ITEMS);
        expect(spy.calls.any()).toEqual(true);
    }));
});
/*describe('example test', function() {
      it('should be true', function() {
        expect('foo').toBe('foo');
      });
    });*/ 
//# sourceMappingURL=accountbilling.spec.js.map