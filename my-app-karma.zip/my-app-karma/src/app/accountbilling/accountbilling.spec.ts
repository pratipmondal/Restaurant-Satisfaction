import { TestBed, async, fakeAsync, ComponentFixture } from '@angular/core/testing';
import 'rxjs/Rx';
import {Observable} from 'rxjs/Rx';
import { BillingDetailStub } from './billingDetail.stub';
import { TAB1_ITEMS } from './tab1.data';
import { AccountBillingComponent } from './accountbilling.component';
import { ABNavComponent } from '../abnav/abnav.component';
import { BillingDetailService } from './billingDetail.service';
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('BillingDetail Component', function() {
	let comp: AccountBillingComponent;
	let fixture: ComponentFixture<AccountBillingComponent>;
	let dataStub: BillingDetailStub;
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations : [ AccountBillingComponent, ABNavComponent ],
    imports: [
                HttpModule,
                RouterTestingModule,
            ]
		}).overrideComponent(AccountBillingComponent, {
			set : {
				providers : [

					{
						provide : BillingDetailService,
						useClass : BillingDetailStub
					},

				]
			}
		}).compileComponents()

			.then(() => {
				fixture = TestBed.createComponent(AccountBillingComponent);
				comp = fixture.componentInstance;
				dataStub = fixture.debugElement.injector.get(BillingDetailService);
			});

	}));
    
  describe('BillingDetail Component', function() {
  let comp: string = "";
  it('should be true', function() {
    expect('foo').toBe('foo');
    });
  });
  
	it('should resolve test data', fakeAsync(function() {

	    const spy = spyOn(dataStub, 'loaddata').and.returnValue(

	      Observable.of(TAB1_ITEMS)

	    );

	    comp.ngOnInit();

	    fixture.detectChanges();

	    expect(comp.billingDetailList).toEqual(TAB1_ITEMS);

	    expect(spy.calls.any()).toEqual(true);

	  }));

});