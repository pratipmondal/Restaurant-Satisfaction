import 'rxjs/Rx';
import {Observable} from 'rxjs/Rx';
import { TAB1_ITEMS } from './tab1.data';
import {BillingDetail} from './billingDetail';

export class BillingDetailStub{

	loaddata(url : string): Observable<BillingDetail[]> {
		return Observable.of(TAB1_ITEMS);
    }

}