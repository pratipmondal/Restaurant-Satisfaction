"use strict";
require("rxjs/Rx");
var Rx_1 = require("rxjs/Rx");
var tab1_data_1 = require("./tab1.data");
var BillingDetailStub = (function () {
    function BillingDetailStub() {
    }
    BillingDetailStub.prototype.loaddata = function (url) {
        return Rx_1.Observable.of(tab1_data_1.TAB1_ITEMS);
    };
    return BillingDetailStub;
}());
exports.BillingDetailStub = BillingDetailStub;
//# sourceMappingURL=billingDetail.stub.js.map