"use strict";
exports.PRODUCT_ITEMS = [{
        id: 1,
        name: 'Scissors',
        description: 'use this to cut stuff',
        price: 4.99
    }, {
        id: 2,
        name: 'Steak Knives',
        description: 'use this to eat food with',
        price: 10.99
    }, {
        id: 3,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 4,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 5,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 6,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 7,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 8,
        name: 'Steak Knives',
        description: 'use this to eat food with',
        price: 10.99
    }, {
        id: 9,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 10,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 11,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 12,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 13,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }, {
        id: 14,
        name: 'Shot Glass',
        description: 'use this to take shots',
        price: 5.99
    }];
//# sourceMappingURL=product.data.js.map