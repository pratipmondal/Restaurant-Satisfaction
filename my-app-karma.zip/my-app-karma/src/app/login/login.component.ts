import { Component, OnInit } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
    moduleId: module.id,
    templateUrl: 'login.template.html'
})

export class LoginComponent implements OnInit{

  loginerror: boolean = false;
	 ngOnInit(){

    }

  constructor(private route: ActivatedRoute, private router: Router) {

   }

  login(username: string, password: string){
    if(username === password){
      localStorage.setItem('username', username);
      this.router.navigate(['/ACCOUNTBILLING'], { queryParams: { 'username': username } });
    } else {
      this.loginerror = true;
    }
  }

}
