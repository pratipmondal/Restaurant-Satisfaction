import { NgModule } from '@angular/core';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { ProductComponent } from './products/product.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentSuccessfulComponent } from './payment-successful/payment-successful.component';
import { AccountBillingComponent } from './accountbilling/accountbilling.component';
import { TestComponent } from './test/test.component';

@NgModule({
    imports: [
        RouterModule.forRoot([
            { path: 'Product', component: ProductComponent },
            { path: 'Contact', component: ContactComponent },
            { path: '', component: HomeComponent },
            { path: 'LOGIN', component: LoginComponent },
            { path: 'Test', component: TestComponent },
            { path: 'ACCOUNTBILLING', component: AccountBillingComponent },
            { path: 'PAYMENT', component: PaymentComponent },
            { path: 'PAYMENT-SUCCESSFUL', component: PaymentSuccessfulComponent }
        ] , { preloadingStrategy: PreloadAllModules })
    ],
    exports: [ RouterModule ]
})
export class AppRoutingModule { }
