package com.restaurant.config;

import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;

import javax.annotation.PostConstruct;
import javax.inject.Named;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.wadl.internal.WadlResource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.restaurant.controller.RestaurantController;

@Configuration
@ComponentScan({"com.restaurant.controller"})
public class AppConfig {
	
	@Named
    static class JerseyConfig extends ResourceConfig {
        public JerseyConfig() {
            this.packages("com.restaurant.controller");
            this.registerEndpoints();

        }
        
        private void registerEndpoints() {
            this.register(RestaurantController.class);
            this.register(WadlResource.class);
        }
        
        @Value("${spring.jersey.application-path:/}")
        private String apiPath;
        
        @PostConstruct
        public void init() {
          // Register components where DI is needed
          this.configureSwagger();
        }
      
        private void configureSwagger() {
          // Available at localhost:port/swagger.json
          this.register(ApiListingResource.class);
          this.register(SwaggerSerializers.class);
      
          BeanConfig config = new BeanConfig();
          config.setConfigId("springboot-jersey-swagger");
          config.setTitle("Restaurant Satisfaction Index");
          config.setVersion("v1");
          config.setContact("Pratip");
          config.setSchemes(new String[] { "http", "https" });
          config.setBasePath(this.apiPath);
          config.setResourcePackage("com.restaurant.controller");
          config.setPrettyPrint(true);
          config.setScan(true);
        }
    }
}
