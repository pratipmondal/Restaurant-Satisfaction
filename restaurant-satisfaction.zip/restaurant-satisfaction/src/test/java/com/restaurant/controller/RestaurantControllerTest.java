package com.restaurat.controller;

import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import static com.jayway.restassured.RestAssured.when;
import com.restaurant.config.App;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = App.class)
@WebAppConfiguration
@IntegrationTest("server.port:40474")
public class RestaurantControllerTest {

	@Test
	public void testGetRestaurantSatisfaction() {
		when().
        get("http://localhost:40474/api/getSatisfaction").
        then().
        statusCode(HttpStatus.SC_OK);
	}
}