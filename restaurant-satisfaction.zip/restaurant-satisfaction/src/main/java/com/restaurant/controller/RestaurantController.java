package com.restaurant.controller;

import io.swagger.annotations.Api;

import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;

import org.springframework.stereotype.Component;

@Component
@Named
@Path("/")
@Api(value = "Restaurant Resource")
public class RestaurantController {
    
	@GET
    @Path("/getSatisfaction")
    @Produces(MediaType.TEXT_PLAIN)
    public String getHelloWorld() {
		File file = new File("C:/Users/user/Downloads/data.txt");
		  try {
		   BufferedReader br = new BufferedReader(new FileReader(file));
		   int n = 0;
		   int W = 0;
		   int []wt = new int[7];
		   int []val = new int[7];
		   int i = 1;
		      for(String line; (line = br.readLine()) != null; ) {
		    	  if(i>1){
		    		 val[i] = Integer.valueOf(line.split("\\s+")[0]).intValue(); 	  
		    		 wt[i] = Integer.valueOf(line.split("\\s+")[1]).intValue(); 
		    	  }else{
		    		  W = Integer.valueOf(line.split("\\s+")[0]).intValue(); 
		    		  n = Integer.valueOf(line.split("\\s+")[1]).intValue(); 
		    		  wt = new int[n+2];
		   		      val = new int[n+2];
		    	  }
		    	  i++;
		      }
		      System.out.println(wt.length);
		      System.out.println(val.length);
		      br.close();
		      int result = knapSack(W, wt, val, n);
		      return String.valueOf(result);
		  }catch(Exception exp){
		   exp.printStackTrace();
		   System.out.println("exp ="+exp.getMessage());
		   return "ERROR DURING EXECUTION";
		  }
    }
	
	public int knapSack(int W, int wt[], int val[], int n)
    {
        int i, w;
        int [][]K = new int[n+1][W+1];
 
	   for (i = 0; i <= n; i++)
        {
            for (w = 0; w <= W; w++)
            {
                if (i==0 || w==0)
                    K[i][w] = 0;
                else if (wt[i-1] <= w)
                    K[i][w] = max(val[i-1] + K[i-1][w-wt[i-1]],  K[i-1][w]);
                else
                    K[i][w] = K[i-1][w];
            }
        }
 
        return K[n][W];
    }
	
	public int max(int a, int b) 
    { 
        return (a > b)? a : b; 
    }
    
}