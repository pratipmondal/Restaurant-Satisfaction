package com.restaurant.controller;

import io.swagger.annotations.Api;

import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;

import org.springframework.stereotype.Component;

@Component
@Named
@Path("/")
@Api(value = "Restaurant Resource")
public class RestaurantController {
    
	@GET
    @Path("/getSatisfaction")
    @Produces(MediaType.TEXT_PLAIN)
    public String getHelloWorld() {
		File file = new File("C:/Users/user/Downloads/data.txt");
		  try(BufferedReader br = new BufferedReader(new FileReader(file))) {
		   BigDecimal satisfaction;
		   BigDecimal time;
		   BigDecimal result;
		   BigDecimal sum = new BigDecimal(0); 
		   BigDecimal mul = new BigDecimal(0);
		   BigDecimal timeSum = new BigDecimal(0);
		   BigDecimal maxTime = new BigDecimal(0);
		   int i = 1;
		      for(String line; (line = br.readLine()) != null; ) {
		    	  if(i>1){
		    		  if(timeSum.intValue() <= maxTime.intValue()){
				          satisfaction = new BigDecimal(line.split("\\s+")[0]);
				          time = new BigDecimal(line.split("\\s+")[1]);
				          if(timeSum.add(time).intValue() <= maxTime.intValue()){
					          mul = satisfaction.multiply(time);
					          sum = sum.add(mul);
					          timeSum = timeSum.add(time);
				          }
		    		  }
		    	  }else{
		    		  maxTime = new BigDecimal(line.split("\\s+")[0]);
		    	  }
		    	  i++;
		      }
		      result = sum.divide(timeSum, 2, RoundingMode.HALF_UP);
		      System.out.println("Max Time = "+maxTime);
		      System.out.println("Time Sum = "+timeSum);
		      System.out.println("Result Satisfaction = "+result);
		      return result.toString();
		  }catch(Exception exp){
		   exp.printStackTrace();
		   System.out.println("exp ="+exp.getMessage());
		   return "ERROR DURING EXECUTION";
		  }
    }
    
}